# 厦门AI本地生活平台 - 管理后台

独立的PC端管理后台项目，与用户端小程序/H5完全分离，提供专业的数据管理和运营支持。

## 技术栈

- **前端框架**: React 18 + TypeScript
- **构建工具**: Vite 5
- **样式**: Tailwind CSS 3
- **路由**: React Router 6
- **状态管理**: Zustand
- **图表**: Recharts
- **HTTP请求**: Axios
- **图标**: Lucide React
- **WebSocket**: Socket.IO Client

## 后端API

管理后台后端基于 NestJS 实现，提供以下接口模块：

### 1. 认证模块
- `POST /api/admin/init` - 初始化管理员账号
- `POST /api/admin/login` - 管理员登录

### 2. Dashboard 统计
- `GET /api/admin/dashboard/stats` - 获取统计数据概览
- `GET /api/admin/dashboard/order-trend` - 订单趋势（支持days参数）
- `GET /api/admin/dashboard/user-trend` - 用户增长趋势
- `GET /api/admin/dashboard/order-status-distribution` - 订单状态分布
- `GET /api/admin/dashboard/recent-orders` - 最近订单
- `GET /api/admin/dashboard/recent-users` - 最近用户

### 3. 用户管理
- `GET /api/admin/users` - 用户列表（支持分页、搜索、状态筛选）
- `GET /api/admin/user/:id` - 用户详情
- `POST /api/admin/user/status` - 更新用户状态

### 4. 商家管理
- `GET /api/admin/merchants` - 商家列表
- `GET /api/admin/merchant/:id` - 商家详情
- `POST /api/admin/merchant/status` - 更新商家状态（审核通过/拒绝）

### 5. 订单管理
- `GET /api/admin/orders` - 订单列表
- `GET /api/admin/order/:id` - 订单详情
- `POST /api/admin/order/status` - 更新订单状态

### 6. 优惠券管理
- `GET /api/admin/coupons` - 优惠券列表
- `POST /api/admin/coupon/create` - 创建优惠券
- `POST /api/admin/coupon/status` - 更新优惠券状态
- `DELETE /api/admin/coupon/:id` - 删除优惠券

### 7. 系统配置
- `GET /api/admin/settings` - 获取系统配置
- `POST /api/admin/settings` - 更新系统配置

### 8. RBAC 权限管理
- `GET /api/admin/roles` - 角色列表
- `POST /api/admin/role/create` - 创建角色
- `POST /api/admin/role/update` - 更新角色
- `DELETE /api/admin/role/:id` - 删除角色
- `GET /api/admin/permissions` - 权限列表
- `GET /api/admin/admins` - 管理员列表
- `POST /api/admin/admin/create` - 创建管理员
- `POST /api/admin/admin/status` - 更新管理员状态

### 9. 数据导出
- `GET /api/admin/export/users` - 导出用户数据（CSV格式）
- `GET /api/admin/export/orders` - 导出订单数据
- `GET /api/admin/export/merchants` - 导出商家数据

### 10. 操作日志
- `GET /api/admin/logs` - 操作日志列表

## WebSocket 实时消息

后端支持 WebSocket 实时推送，用于：
- 新订单通知
- 商家入驻申请通知
- 退款申请通知
- 系统告警通知

### WebSocket 连接
```javascript
import { io } from 'socket.io-client'

const socket = io('http://localhost:3000/admin', {
  auth: { token: 'your-auth-token' }
})

socket.emit('join', { adminId: 'admin-id', role: 'super_admin' })

socket.on('new_order', (data) => {
  console.log('新订单:', data)
})

socket.on('system_alert', (data) => {
  console.log('系统告警:', data)
})
```

## 开发指南

### 安装依赖
```bash
cd admin-web
pnpm install
```

### 启动开发服务器
```bash
pnpm dev
```

### 构建生产版本
```bash
pnpm build
```

### 代码检查
```bash
pnpm lint
```

## 默认账号

- **用户名**: admin
- **密码**: admin123

## 功能特性

### ✅ 已实现功能

1. **登录认证**
   - 管理员登录/登出
   - 认证状态管理

2. **Dashboard 数据统计**
   - 用户、商家、订单概览
   - 订单趋势图表
   - 用户增长图表
   - 订单状态分布
   - 实时数据更新

3. **用户管理**
   - 用户列表（分页、搜索、筛选）
   - 用户详情查看
   - 状态管理（启用/禁用）

4. **商家管理**
   - 商家列表
   - 商家审核（通过/拒绝）
   - 状态管理

5. **订单管理**
   - 订单列表
   - 订单详情
   - 状态更新（核销、退款确认）

6. **优惠券管理**
   - 优惠券列表
   - 创建优惠券
   - 编辑/删除优惠券

7. **系统配置**
   - 基础配置
   - 分销配置
   - 消息通知配置

8. **RBAC 权限管理**
   - 角色管理
   - 权限分配
   - 管理员账号管理

9. **数据导出**
   - 用户数据导出
   - 订单数据导出
   - 商家数据导出

10. **WebSocket 实时消息**
    - 新订单通知
    - 商家入驻申请通知
    - 系统告警通知

### 🚧 待实现功能

1. 完善权限验证中间件
2. 添加操作日志详情页
3. 实现数据可视化增强
4. 集成第三方支付对账
5. 添加数据备份与恢复功能

## 项目结构

```
admin-web/
├── src/
│   ├── components/
│   │   ├── layout/          # 布局组件
│   │   └── ui/              # UI组件库
│   ├── lib/
│   │   ├── api.ts           # API接口封装
│   │   └── utils.ts         # 工具函数
│   ├── pages/
│   │   ├── login/           # 登录页面
│   │   ├── dashboard/       # 数据统计
│   │   ├── users/           # 用户管理
│   │   ├── merchants/       # 商家管理
│   │   ├── orders/          # 订单管理
│   │   ├── coupons/         # 优惠券管理
│   │   └── settings/        # 系统配置
│   ├── stores/
│   │   └── auth.ts          # 认证状态管理
│   ├── App.tsx              # 路由配置
│   ├── main.tsx             # 入口文件
│   └── index.css            # 全局样式
├── package.json
├── vite.config.ts
├── tailwind.config.js
└── tsconfig.json
```

## 部署说明

1. 构建生产版本
```bash
pnpm build
```

2. 部署到静态服务器（Nginx、Apache等）

3. 配置API代理（指向后端服务地址）

4. 配置WebSocket代理（如需要实时消息功能）

## 注意事项

- 生产环境需修改默认管理员密码
- 建议启用HTTPS
- WebSocket连接需配置正确的CORS
- 数据导出功能建议添加权限控制
