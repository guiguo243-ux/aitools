import { useState } from 'react'
import { Link, useLocation, useNavigate } from 'react-router-dom'
import { useAuthStore } from '@/stores/auth'
import { cn } from '@/lib/utils'
import {
  LayoutDashboard,
  Users,
  Store,
  ShoppingCart,
  Package,
  Ticket,
  Layers,
  FileText,
  Settings,
  LogOut,
  ChevronLeft,
  ChevronRight,
  Menu,
  X,
  Wallet,
  Share2,
  Bell,
  RotateCcw,
  MessageSquare,
  UserCog,
  Shield,
  Gift,
} from 'lucide-react'

interface MainLayoutProps {
  children: React.ReactNode
}

const menuItems = [
  { key: 'dashboard', name: '数据概览', icon: LayoutDashboard, path: '/dashboard' },
  { key: 'users', name: '用户管理', icon: Users, path: '/users' },
  { key: 'merchants', name: '商家管理', icon: Store, path: '/merchants' },
  { key: 'products', name: '商品管理', icon: Package, path: '/products' },
  { key: 'orders', name: '订单管理', icon: ShoppingCart, path: '/orders' },
  { key: 'refunds', name: '退款管理', icon: RotateCcw, path: '/refunds' },
  { key: 'reviews', name: '评价管理', icon: MessageSquare, path: '/reviews' },
  { key: 'coupons', name: '优惠券管理', icon: Ticket, path: '/coupons' },
  { key: 'points-products', name: '积分商品', icon: Gift, path: '/points-products' },
  { key: 'categories', name: '分类管理', icon: Layers, path: '/categories' },
  { key: 'withdrawals', name: '提现管理', icon: Wallet, path: '/withdrawals' },
  { key: 'referrals', name: '分销管理', icon: Share2, path: '/referrals' },
  { key: 'messages', name: '消息推送', icon: Bell, path: '/messages' },
  { key: 'admins', name: '管理员账号', icon: UserCog, path: '/admins' },
  { key: 'roles', name: '角色权限', icon: Shield, path: '/roles' },
  { key: 'logs', name: '操作日志', icon: FileText, path: '/logs' },
  { key: 'settings', name: '系统配置', icon: Settings, path: '/settings' },
]

export default function MainLayout({ children }: MainLayoutProps) {
  const location = useLocation()
  const navigate = useNavigate()
  const { admin, logout } = useAuthStore()
  const [collapsed, setCollapsed] = useState(false)
  const [mobileOpen, setMobileOpen] = useState(false)

  const handleLogout = () => {
    if (confirm('确定要退出登录吗？')) {
      logout()
      navigate('/login')
    }
  }

  const currentKey = menuItems.find(item => location.pathname === item.path)?.key || 'dashboard'

  return (
    <div className="min-h-screen bg-stone-50 flex">
      {/* PC端侧边栏 */}
      <aside
        className={cn(
          "fixed left-0 top-0 bottom-0 z-40 bg-white border-r border-stone-200 transition-all duration-300 hidden lg:flex lg:flex-col",
          collapsed ? "w-[72px]" : "w-[220px]"
        )}
      >
        {/* Logo */}
        <div className="h-16 flex items-center justify-between px-4 border-b border-stone-200">
          {!collapsed && (
            <div className="flex items-center gap-2">
              <div className="w-8 h-8 rounded-lg bg-teal-500 flex items-center justify-center">
                <LayoutDashboard size={18} color="#fff" />
              </div>
              <span className="font-semibold text-stone-800">后台管理</span>
            </div>
          )}
          <button
            onClick={() => setCollapsed(!collapsed)}
            className="p-1.5 rounded-lg hover:bg-stone-100 text-stone-400 hover:text-stone-600"
          >
            {collapsed ? <ChevronRight size={18} /> : <ChevronLeft size={18} />}
          </button>
        </div>

        {/* 菜单 */}
        <nav className="flex-1 p-3 space-y-1 overflow-y-auto">
          {menuItems.map((item) => {
            const Icon = item.icon
            const isActive = currentKey === item.key
            return (
              <Link
                key={item.key}
                to={item.path}
                className={cn(
                  "flex items-center gap-3 px-3 py-2.5 rounded-lg transition-colors",
                  isActive
                    ? "bg-teal-50 text-teal-700 font-medium"
                    : "text-stone-600 hover:bg-stone-50 hover:text-stone-900"
                )}
              >
                <Icon size={20} />
                {!collapsed && <span>{item.name}</span>}
              </Link>
            )
          })}
        </nav>

        {/* 底部 */}
        <div className="p-3 border-t border-stone-200">
          <button
            onClick={handleLogout}
            className="flex items-center gap-3 px-3 py-2.5 rounded-lg text-stone-500 hover:bg-stone-50 hover:text-stone-700 w-full"
          >
            <LogOut size={20} />
            {!collapsed && <span>退出登录</span>}
          </button>
        </div>
      </aside>

      {/* 移动端头部 */}
      <header className="fixed top-0 left-0 right-0 h-14 bg-white border-b border-stone-200 z-30 lg:hidden flex items-center px-4">
        <button
          onClick={() => setMobileOpen(true)}
          className="p-2 -ml-2 text-stone-600"
        >
          <Menu size={22} />
        </button>
        <span className="flex-1 text-center font-medium text-stone-800">
          {menuItems.find(item => currentKey === item.key)?.name || '后台管理'}
        </span>
        <div className="w-8" />
      </header>

      {/* 移动端侧边栏 */}
      {mobileOpen && (
        <>
          <div
            className="fixed inset-0 bg-black/40 z-40 lg:hidden"
            onClick={() => setMobileOpen(false)}
          />
          <aside className="fixed left-0 top-0 bottom-0 w-[260px] bg-white z-50 lg:hidden flex flex-col">
            <div className="h-14 flex items-center justify-between px-4 border-b border-stone-200">
              <div className="flex items-center gap-2">
                <div className="w-8 h-8 rounded-lg bg-teal-500 flex items-center justify-center">
                  <LayoutDashboard size={18} color="#fff" />
                </div>
                <span className="font-semibold text-stone-800">后台管理</span>
              </div>
              <button
                onClick={() => setMobileOpen(false)}
                className="p-1.5 text-stone-400"
              >
                <X size={20} />
              </button>
            </div>

            <nav className="flex-1 p-3 space-y-1 overflow-y-auto">
              {menuItems.map((item) => {
                const Icon = item.icon
                const isActive = currentKey === item.key
                return (
                  <Link
                    key={item.key}
                    to={item.path}
                    onClick={() => setMobileOpen(false)}
                    className={cn(
                      "flex items-center gap-3 px-3 py-2.5 rounded-lg transition-colors",
                      isActive
                        ? "bg-teal-50 text-teal-700 font-medium"
                        : "text-stone-600 hover:bg-stone-50 hover:text-stone-900"
                    )}
                  >
                    <Icon size={20} />
                    <span>{item.name}</span>
                  </Link>
                )
              })}
            </nav>

            <div className="p-3 border-t border-stone-200">
              <button
                onClick={handleLogout}
                className="flex items-center gap-3 px-3 py-2.5 rounded-lg text-rose-600 hover:bg-rose-50 w-full"
              >
                <LogOut size={20} />
                <span>退出登录</span>
              </button>
            </div>
          </aside>
        </>
      )}

      {/* 主内容区 */}
      <main
        className={cn(
          "flex-1 pt-14 lg:pt-0 transition-all duration-300",
          collapsed ? "lg:ml-[72px]" : "lg:ml-[220px]"
        )}
      >
        {/* 顶部标题栏 */}
        <header className="h-16 bg-white border-b border-stone-200 px-6 hidden lg:flex items-center justify-between">
          <h1 className="text-xl font-semibold text-stone-800">
            {menuItems.find(item => currentKey === item.key)?.name || '数据概览'}
          </h1>
          <div className="flex items-center gap-4">
            <span className="text-sm text-stone-500">
              {admin?.nickname || '管理员'}
            </span>
          </div>
        </header>

        {/* 内容 */}
        <div className="p-6">
          {children}
        </div>
      </main>
    </div>
  )
}
