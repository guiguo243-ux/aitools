import { useEffect, useState } from 'react'
import { userApi } from '@/lib/api'
import { formatDateTime, getStatusBadgeClass, getStatusText } from '@/lib/utils'
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog'
import { Badge } from '@/components/ui/badge'
import { Loader2, User, Phone, MapPin, Calendar, Wallet, ShoppingCart } from 'lucide-react'

interface Props {
  userId: string | null
  open: boolean
  onClose: () => void
}

interface UserDetail {
  user: {
    id: string
    nickname: string
    phone: string
    avatar: string
    region: string
    status: string
    created_at: string
    last_login_at: string
  }
  orders: Array<{
    id: string
    order_no: string
    total_amount: string
    status: string
    created_at: string
  }>
  walletTransactions: Array<{
    id: string
    type: string
    amount: string
    balance: string
    description: string
    created_at: string
  }>
}

export function UserDetailModal({ userId, open, onClose }: Props) {
  const [data, setData] = useState<UserDetail | null>(null)
  const [loading, setLoading] = useState(false)

  useEffect(() => {
    if (userId && open) {
      fetchDetail()
    }
  }, [userId, open])

  const fetchDetail = async () => {
    setLoading(true)
    try {
      const res: any = await userApi.getDetail(userId!)
      if (res.code === 200) {
        setData(res.data)
      }
    } catch (error) {
      console.error('Fetch user detail error:', error)
    } finally {
      setLoading(false)
    }
  }

  if (!userId) return null

  return (
    <Dialog open={open} onOpenChange={onClose}>
      <DialogContent className="max-w-2xl max-h-[80vh] overflow-y-auto" showClose={true}>
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <User size={20} color="#14B8A6" />
            用户详情
          </DialogTitle>
        </DialogHeader>

        {loading ? (
          <div className="flex items-center justify-center h-48">
            <Loader2 className="h-6 w-6 animate-spin text-teal-500" />
          </div>
        ) : data ? (
          <div className="space-y-6">
            {/* 基本信息 */}
            <div className="bg-stone-50 rounded-lg p-4">
              <h3 className="font-medium text-stone-800 mb-3">基本信息</h3>
              <div className="grid grid-cols-2 gap-4">
                <div className="flex items-center gap-2">
                  <User size={16} className="text-stone-400" />
                  <span className="text-sm text-stone-500">昵称:</span>
                  <span className="text-sm text-stone-800">{data.user?.nickname || '未设置'}</span>
                </div>
                <div className="flex items-center gap-2">
                  <Phone size={16} className="text-stone-400" />
                  <span className="text-sm text-stone-500">手机:</span>
                  <span className="text-sm text-stone-800">{data.user?.phone || '-'}</span>
                </div>
                <div className="flex items-center gap-2">
                  <MapPin size={16} className="text-stone-400" />
                  <span className="text-sm text-stone-500">区域:</span>
                  <span className="text-sm text-stone-800">
                    {data.user?.region === 'island_inside' ? '岛内' : data.user?.region === 'island_outside' ? '岛外' : '-'}
                  </span>
                </div>
                <div className="flex items-center gap-2">
                  <Calendar size={16} className="text-stone-400" />
                  <span className="text-sm text-stone-500">注册时间:</span>
                  <span className="text-sm text-stone-800">{formatDateTime(data.user?.created_at)}</span>
                </div>
                <div className="flex items-center gap-2">
                  <span className="text-sm text-stone-500">状态:</span>
                  <Badge className={getStatusBadgeClass(data.user?.status)}>
                    {getStatusText(data.user?.status)}
                  </Badge>
                </div>
                <div className="flex items-center gap-2">
                  <span className="text-sm text-stone-500">ID:</span>
                  <span className="text-xs text-stone-400 font-mono">{data.user?.id}</span>
                </div>
              </div>
            </div>

            {/* 订单记录 */}
            <div>
              <h3 className="font-medium text-stone-800 mb-3 flex items-center gap-2">
                <ShoppingCart size={16} />
                最近订单
              </h3>
              <div className="bg-stone-50 rounded-lg overflow-hidden">
                {data.orders?.length > 0 ? (
                  <table className="w-full text-sm">
                    <thead>
                      <tr className="border-b border-stone-200">
                        <th className="text-left py-2 px-3 text-stone-500">订单号</th>
                        <th className="text-left py-2 px-3 text-stone-500">金额</th>
                        <th className="text-left py-2 px-3 text-stone-500">状态</th>
                        <th className="text-left py-2 px-3 text-stone-500">时间</th>
                      </tr>
                    </thead>
                    <tbody>
                      {data.orders.slice(0, 5).map((order) => (
                        <tr key={order.id} className="border-b border-stone-100">
                          <td className="py-2 px-3 text-stone-800">{order.order_no}</td>
                          <td className="py-2 px-3 text-stone-600">¥{order.total_amount}</td>
                          <td className="py-2 px-3">
                            <Badge className={getStatusBadgeClass(order.status)}>
                              {getStatusText(order.status)}
                            </Badge>
                          </td>
                          <td className="py-2 px-3 text-stone-500">{formatDateTime(order.created_at)}</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                ) : (
                  <div className="py-8 text-center text-stone-400">暂无订单</div>
                )}
              </div>
            </div>

            {/* 钱包记录 */}
            <div>
              <h3 className="font-medium text-stone-800 mb-3 flex items-center gap-2">
                <Wallet size={16} />
                钱包记录
              </h3>
              <div className="bg-stone-50 rounded-lg overflow-hidden">
                {data.walletTransactions?.length > 0 ? (
                  <table className="w-full text-sm">
                    <thead>
                      <tr className="border-b border-stone-200">
                        <th className="text-left py-2 px-3 text-stone-500">类型</th>
                        <th className="text-left py-2 px-3 text-stone-500">金额</th>
                        <th className="text-left py-2 px-3 text-stone-500">余额</th>
                        <th className="text-left py-2 px-3 text-stone-500">时间</th>
                      </tr>
                    </thead>
                    <tbody>
                      {data.walletTransactions.slice(0, 5).map((tx) => (
                        <tr key={tx.id} className="border-b border-stone-100">
                          <td className="py-2 px-3 text-stone-800">{tx.description || tx.type}</td>
                          <td className={`py-2 px-3 ${parseFloat(tx.amount) > 0 ? 'text-emerald-600' : 'text-rose-600'}`}>
                            {parseFloat(tx.amount) > 0 ? '+' : ''}{tx.amount}
                          </td>
                          <td className="py-2 px-3 text-stone-600">{tx.balance}</td>
                          <td className="py-2 px-3 text-stone-500">{formatDateTime(tx.created_at)}</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                ) : (
                  <div className="py-8 text-center text-stone-400">暂无记录</div>
                )}
              </div>
            </div>
          </div>
        ) : null}
      </DialogContent>
    </Dialog>
  )
}
