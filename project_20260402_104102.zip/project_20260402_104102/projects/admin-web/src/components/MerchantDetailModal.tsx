import { useEffect, useState } from 'react'
import { merchantApi } from '@/lib/api'
import { formatDateTime, getStatusBadgeClass, getStatusText } from '@/lib/utils'
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog'
import { Badge } from '@/components/ui/badge'
import { Loader2, Store, Phone, MapPin, Calendar, Package, ShoppingCart } from 'lucide-react'

interface Props {
  merchantId: string | null
  open: boolean
  onClose: () => void
}

interface MerchantDetail {
  merchant: {
    id: string
    name: string
    category: string
    address: string
    phone: string
    description: string
    image_url: string
    status: string
    created_at: string
  }
  products: Array<{
    id: string
    name: string
    price: string
    is_active: boolean
    sales_count: number
  }>
  orders: Array<{
    id: string
    order_no: string
    total_amount: string
    status: string
    created_at: string
  }>
}

const categoryLabels: Record<string, string> = {
  food: '美食',
  entertainment: '娱乐',
  shopping: '购物',
  service: '服务',
  hotel: '酒店',
  travel: '旅游',
}

export function MerchantDetailModal({ merchantId, open, onClose }: Props) {
  const [data, setData] = useState<MerchantDetail | null>(null)
  const [loading, setLoading] = useState(false)

  useEffect(() => {
    if (merchantId && open) {
      fetchDetail()
    }
  }, [merchantId, open])

  const fetchDetail = async () => {
    setLoading(true)
    try {
      const res: any = await merchantApi.getDetail(merchantId!)
      if (res.code === 200) {
        setData(res.data)
      }
    } catch (error) {
      console.error('Fetch merchant detail error:', error)
    } finally {
      setLoading(false)
    }
  }

  if (!merchantId) return null

  return (
    <Dialog open={open} onOpenChange={onClose}>
      <DialogContent className="max-w-2xl max-h-[80vh] overflow-y-auto" showClose={true}>
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Store size={20} color="#14B8A6" />
            商家详情
          </DialogTitle>
        </DialogHeader>

        {loading ? (
          <div className="flex items-center justify-center h-48">
            <Loader2 className="h-6 w-6 animate-spin text-teal-500" />
          </div>
        ) : data ? (
          <div className="space-y-6">
            {/* 基本信息 */}
            <div className="bg-stone-50 rounded-lg p-4">
              <h3 className="font-medium text-stone-800 mb-3">基本信息</h3>
              <div className="grid grid-cols-2 gap-4">
                <div className="flex items-center gap-2">
                  <Store size={16} className="text-stone-400" />
                  <span className="text-sm text-stone-500">名称:</span>
                  <span className="text-sm text-stone-800">{data.merchant?.name || '-'}</span>
                </div>
                <div className="flex items-center gap-2">
                  <Phone size={16} className="text-stone-400" />
                  <span className="text-sm text-stone-500">电话:</span>
                  <span className="text-sm text-stone-800">{data.merchant?.phone || '-'}</span>
                </div>
                <div className="flex items-center gap-2">
                  <MapPin size={16} className="text-stone-400" />
                  <span className="text-sm text-stone-500">地址:</span>
                  <span className="text-sm text-stone-800">{data.merchant?.address || '-'}</span>
                </div>
                <div className="flex items-center gap-2">
                  <span className="text-sm text-stone-500">分类:</span>
                  <span className="text-sm text-stone-800">{categoryLabels[data.merchant?.category] || data.merchant?.category || '-'}</span>
                </div>
                <div className="flex items-center gap-2">
                  <Calendar size={16} className="text-stone-400" />
                  <span className="text-sm text-stone-500">创建时间:</span>
                  <span className="text-sm text-stone-800">{formatDateTime(data.merchant?.created_at)}</span>
                </div>
                <div className="flex items-center gap-2">
                  <span className="text-sm text-stone-500">状态:</span>
                  <Badge className={getStatusBadgeClass(data.merchant?.status)}>
                    {getStatusText(data.merchant?.status)}
                  </Badge>
                </div>
              </div>
              {data.merchant?.description && (
                <div className="mt-3 pt-3 border-t border-stone-200">
                  <span className="text-sm text-stone-500">简介:</span>
                  <p className="text-sm text-stone-800 mt-1">{data.merchant.description}</p>
                </div>
              )}
            </div>

            {/* 商品列表 */}
            <div>
              <h3 className="font-medium text-stone-800 mb-3 flex items-center gap-2">
                <Package size={16} />
                商品列表
              </h3>
              <div className="bg-stone-50 rounded-lg overflow-hidden">
                {data.products?.length > 0 ? (
                  <table className="w-full text-sm">
                    <thead>
                      <tr className="border-b border-stone-200">
                        <th className="text-left py-2 px-3 text-stone-500">商品名</th>
                        <th className="text-left py-2 px-3 text-stone-500">价格</th>
                        <th className="text-left py-2 px-3 text-stone-500">销量</th>
                        <th className="text-left py-2 px-3 text-stone-500">状态</th>
                      </tr>
                    </thead>
                    <tbody>
                      {data.products.slice(0, 5).map((product) => (
                        <tr key={product.id} className="border-b border-stone-100">
                          <td className="py-2 px-3 text-stone-800">{product.name}</td>
                          <td className="py-2 px-3 text-teal-600">¥{product.price}</td>
                          <td className="py-2 px-3 text-stone-600">{product.sales_count || 0}</td>
                          <td className="py-2 px-3">
                            <Badge className={product.is_active ? 'bg-emerald-50 text-emerald-700' : 'bg-stone-100 text-stone-500'}>
                              {product.is_active ? '上架' : '下架'}
                            </Badge>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                ) : (
                  <div className="py-8 text-center text-stone-400">暂无商品</div>
                )}
              </div>
            </div>

            {/* 订单记录 */}
            <div>
              <h3 className="font-medium text-stone-800 mb-3 flex items-center gap-2">
                <ShoppingCart size={16} />
                最近订单
              </h3>
              <div className="bg-stone-50 rounded-lg overflow-hidden">
                {data.orders?.length > 0 ? (
                  <table className="w-full text-sm">
                    <thead>
                      <tr className="border-b border-stone-200">
                        <th className="text-left py-2 px-3 text-stone-500">订单号</th>
                        <th className="text-left py-2 px-3 text-stone-500">金额</th>
                        <th className="text-left py-2 px-3 text-stone-500">状态</th>
                        <th className="text-left py-2 px-3 text-stone-500">时间</th>
                      </tr>
                    </thead>
                    <tbody>
                      {data.orders.slice(0, 5).map((order) => (
                        <tr key={order.id} className="border-b border-stone-100">
                          <td className="py-2 px-3 text-stone-800">{order.order_no}</td>
                          <td className="py-2 px-3 text-stone-600">¥{order.total_amount}</td>
                          <td className="py-2 px-3">
                            <Badge className={getStatusBadgeClass(order.status)}>
                              {getStatusText(order.status)}
                            </Badge>
                          </td>
                          <td className="py-2 px-3 text-stone-500">{formatDateTime(order.created_at)}</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                ) : (
                  <div className="py-8 text-center text-stone-400">暂无订单</div>
                )}
              </div>
            </div>
          </div>
        ) : null}
      </DialogContent>
    </Dialog>
  )
}
