import { useEffect, useState } from 'react'
import { orderApi } from '@/lib/api'
import { formatDateTime, getStatusText } from '@/lib/utils'
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog'
import { Badge } from '@/components/ui/badge'
import { Loader2, ShoppingCart, User, Store, CreditCard, Calendar } from 'lucide-react'

interface Props {
  orderId: string | null
  open: boolean
  onClose: () => void
}

interface OrderDetail {
  id: string
  order_no: string
  total_amount: string
  pay_amount: string
  discount_amount: string
  status: string
  payment_method: string
  created_at: string
  paid_at: string
  completed_at: string
  cancelled_at: string
  users: { nickname: string; phone: string; avatar: string } | null
  merchants: { name: string; address: string; phone: string } | null
  products: { name: string; image_url: string } | null
}

const paymentMethodLabels: Record<string, string> = {
  wechat: '微信支付',
  alipay: '支付宝',
  balance: '余额支付',
}

export function OrderDetailModal({ orderId, open, onClose }: Props) {
  const [data, setData] = useState<OrderDetail | null>(null)
  const [loading, setLoading] = useState(false)

  useEffect(() => {
    if (orderId && open) {
      fetchDetail()
    }
  }, [orderId, open])

  const fetchDetail = async () => {
    setLoading(true)
    try {
      const res: any = await orderApi.getDetail(orderId!)
      if (res.code === 200) {
        setData(res.data)
      }
    } catch (error) {
      console.error('Fetch order detail error:', error)
    } finally {
      setLoading(false)
    }
  }

  if (!orderId) return null

  return (
    <Dialog open={open} onOpenChange={onClose}>
      <DialogContent className="max-w-2xl max-h-[80vh] overflow-y-auto" showClose={true}>
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <ShoppingCart size={20} color="#14B8A6" />
            订单详情
          </DialogTitle>
        </DialogHeader>

        {loading ? (
          <div className="flex items-center justify-center h-48">
            <Loader2 className="h-6 w-6 animate-spin text-teal-500" />
          </div>
        ) : data ? (
          <div className="space-y-6">
            {/* 订单状态 */}
            <div className="bg-gradient-to-r from-teal-500 to-teal-600 rounded-lg p-4 text-white">
              <div className="flex items-center justify-between">
                <div>
                  <div className="text-teal-100 text-sm">订单号</div>
                  <div className="text-lg font-semibold">{data.order_no}</div>
                </div>
                <Badge className="bg-white/20 text-white border-0 text-base px-4 py-1">
                  {getStatusText(data.status)}
                </Badge>
              </div>
            </div>

            {/* 金额信息 */}
            <div className="bg-stone-50 rounded-lg p-4">
              <h3 className="font-medium text-stone-800 mb-3 flex items-center gap-2">
                <CreditCard size={16} />
                金额信息
              </h3>
              <div className="space-y-2">
                <div className="flex justify-between">
                  <span className="text-sm text-stone-500">订单金额</span>
                  <span className="text-sm text-stone-800">¥{data.total_amount}</span>
                </div>
                {data.discount_amount && parseFloat(data.discount_amount) > 0 && (
                  <div className="flex justify-between">
                    <span className="text-sm text-stone-500">优惠金额</span>
                    <span className="text-sm text-rose-600">-¥{data.discount_amount}</span>
                  </div>
                )}
                <div className="flex justify-between pt-2 border-t border-stone-200">
                  <span className="text-sm font-medium text-stone-700">实付金额</span>
                  <span className="text-lg font-bold text-teal-600">¥{data.pay_amount}</span>
                </div>
              </div>
            </div>

            {/* 用户信息 */}
            <div className="bg-stone-50 rounded-lg p-4">
              <h3 className="font-medium text-stone-800 mb-3 flex items-center gap-2">
                <User size={16} />
                用户信息
              </h3>
              <div className="grid grid-cols-2 gap-4">
                <div className="flex items-center gap-2">
                  <span className="text-sm text-stone-500">用户:</span>
                  <span className="text-sm text-stone-800">{data.users?.nickname || '-'}</span>
                </div>
                <div className="flex items-center gap-2">
                  <span className="text-sm text-stone-500">手机:</span>
                  <span className="text-sm text-stone-800">{data.users?.phone || '-'}</span>
                </div>
              </div>
            </div>

            {/* 商家信息 */}
            <div className="bg-stone-50 rounded-lg p-4">
              <h3 className="font-medium text-stone-800 mb-3 flex items-center gap-2">
                <Store size={16} />
                商家信息
              </h3>
              <div className="grid grid-cols-2 gap-4">
                <div className="flex items-center gap-2">
                  <span className="text-sm text-stone-500">商家:</span>
                  <span className="text-sm text-stone-800">{data.merchants?.name || '-'}</span>
                </div>
                <div className="flex items-center gap-2">
                  <span className="text-sm text-stone-500">电话:</span>
                  <span className="text-sm text-stone-800">{data.merchants?.phone || '-'}</span>
                </div>
                <div className="col-span-2 flex items-center gap-2">
                  <span className="text-sm text-stone-500">地址:</span>
                  <span className="text-sm text-stone-800">{data.merchants?.address || '-'}</span>
                </div>
              </div>
            </div>

            {/* 商品信息 */}
            {data.products && (
              <div className="bg-stone-50 rounded-lg p-4">
                <h3 className="font-medium text-stone-800 mb-3">商品信息</h3>
                <div className="flex items-center gap-3">
                  <div className="w-16 h-16 rounded-lg bg-stone-200 overflow-hidden">
                    {data.products.image_url ? (
                      <img src={data.products.image_url} alt="" className="w-full h-full object-cover" />
                    ) : (
                      <div className="w-full h-full flex items-center justify-center text-stone-400">
                        <ShoppingCart size={24} />
                      </div>
                    )}
                  </div>
                  <span className="text-sm text-stone-800">{data.products.name}</span>
                </div>
              </div>
            )}

            {/* 时间信息 */}
            <div className="bg-stone-50 rounded-lg p-4">
              <h3 className="font-medium text-stone-800 mb-3 flex items-center gap-2">
                <Calendar size={16} />
                时间信息
              </h3>
              <div className="grid grid-cols-2 gap-4">
                <div className="flex items-center gap-2">
                  <span className="text-sm text-stone-500">创建时间:</span>
                  <span className="text-sm text-stone-800">{formatDateTime(data.created_at)}</span>
                </div>
                {data.paid_at && (
                  <div className="flex items-center gap-2">
                    <span className="text-sm text-stone-500">支付时间:</span>
                    <span className="text-sm text-stone-800">{formatDateTime(data.paid_at)}</span>
                  </div>
                )}
                {data.completed_at && (
                  <div className="flex items-center gap-2">
                    <span className="text-sm text-stone-500">完成时间:</span>
                    <span className="text-sm text-stone-800">{formatDateTime(data.completed_at)}</span>
                  </div>
                )}
                {data.cancelled_at && (
                  <div className="flex items-center gap-2">
                    <span className="text-sm text-stone-500">取消时间:</span>
                    <span className="text-sm text-stone-800">{formatDateTime(data.cancelled_at)}</span>
                  </div>
                )}
                <div className="flex items-center gap-2">
                  <span className="text-sm text-stone-500">支付方式:</span>
                  <span className="text-sm text-stone-800">{paymentMethodLabels[data.payment_method] || data.payment_method || '-'}</span>
                </div>
              </div>
            </div>
          </div>
        ) : null}
      </DialogContent>
    </Dialog>
  )
}
