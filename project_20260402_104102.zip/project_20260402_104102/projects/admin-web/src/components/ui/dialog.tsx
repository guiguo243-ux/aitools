import * as React from "react"
import { cn } from "@/lib/utils"
import { X } from 'lucide-react'

interface DialogProps {
  open: boolean
  onOpenChange: (open: boolean) => void
  children: React.ReactNode
}

// 创建Context来传递关闭函数
const DialogContext = React.createContext<{
  close: () => void
} | null>(null)

export function Dialog({ open, onOpenChange, children }: DialogProps) {
  if (!open) return null

  const close = () => onOpenChange(false)

  return (
    <DialogContext.Provider value={{ close }}>
      <div className="fixed inset-0 z-50">
        <div 
          className="fixed inset-0 bg-black/50" 
          onClick={close}
        />
        <div className="fixed inset-0 overflow-y-auto">
          <div className="flex min-h-full items-center justify-center p-4">
            {children}
          </div>
        </div>
      </div>
    </DialogContext.Provider>
  )
}

interface DialogContentProps extends React.HTMLAttributes<HTMLDivElement> {
  children: React.ReactNode
  showClose?: boolean
}

export function DialogContent({ children, className, showClose = true, ...props }: DialogContentProps) {
  const context = React.useContext(DialogContext)
  const onClose = context?.close

  return (
    <div
      className={cn(
        "relative bg-white rounded-lg shadow-xl max-w-lg w-full max-h-[85vh] overflow-y-auto",
        className
      )}
      onClick={(e) => e.stopPropagation()}
      {...props}
    >
      {showClose && onClose && (
        <button
          onClick={onClose}
          className="absolute top-4 right-4 p-1.5 rounded-lg text-stone-400 hover:text-stone-600 hover:bg-stone-100 transition-colors z-10"
          title="关闭"
        >
          <X size={18} />
        </button>
      )}
      {children}
    </div>
  )
}

export function DialogHeader({ children, className, ...props }: React.HTMLAttributes<HTMLDivElement>) {
  return (
    <div className={cn("flex items-center justify-between p-4 border-b border-stone-200 pr-12", className)} {...props}>
      {children}
    </div>
  )
}

export function DialogTitle({ children, className, ...props }: React.HTMLAttributes<HTMLHeadingElement>) {
  return (
    <h2 className={cn("text-lg font-semibold text-stone-800", className)} {...props}>
      {children}
    </h2>
  )
}

export function DialogDescription({ children, className, ...props }: React.HTMLAttributes<HTMLParagraphElement>) {
  return (
    <p className={cn("text-sm text-stone-500", className)} {...props}>
      {children}
    </p>
  )
}

export function DialogFooter({ children, className, ...props }: React.HTMLAttributes<HTMLDivElement>) {
  return (
    <div className={cn("flex items-center justify-end gap-3 p-4 border-t border-stone-200", className)} {...props}>
      {children}
    </div>
  )
}
