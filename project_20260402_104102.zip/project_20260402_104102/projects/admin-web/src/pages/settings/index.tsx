import { useState, useEffect } from 'react'
import { settingApi } from '@/lib/api'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { 
  Settings, Save, Loader2, Eye, EyeOff, CheckCircle, XCircle, TestTube,
  Smartphone, CreditCard, MessageSquare, Database, Bot, Globe, DollarSign,
  MapPin, LucideIcon
} from 'lucide-react'

interface ConfigItem {
  id?: number
  configKey: string
  configValue: string
  configType: string
  category: string
  description?: string
  isSecret: boolean
}

interface ConfigCategory {
  key: string
  title: string
  icon: LucideIcon
  description: string
  configs: ConfigItem[]
}

// 完整的配置项定义
const configDefinitions: ConfigCategory[] = [
  {
    key: 'wechat_mini',
    title: '微信小程序配置',
    icon: Smartphone,
    description: '小程序登录、授权相关配置',
    configs: [
      { configKey: 'wechat_appid', configValue: '', configType: 'text', category: 'wechat_mini', description: '小程序 AppID', isSecret: false },
      { configKey: 'wechat_secret', configValue: '', configType: 'text', category: 'wechat_mini', description: '小程序 AppSecret', isSecret: true },
      { configKey: 'wechat_original_id', configValue: '', configType: 'text', category: 'wechat_mini', description: '小程序原始ID (gh_开头)', isSecret: false },
    ]
  },
  {
    key: 'wechat_pay',
    title: '微信支付配置',
    icon: CreditCard,
    description: '微信支付商户配置',
    configs: [
      { configKey: 'payment_mchid', configValue: '', configType: 'text', category: 'wechat_pay', description: '商户号 MCHID', isSecret: false },
      { configKey: 'payment_api_key', configValue: '', configType: 'text', category: 'wechat_pay', description: 'API密钥 (v2)', isSecret: true },
      { configKey: 'payment_apiv3_key', configValue: '', configType: 'text', category: 'wechat_pay', description: 'APIv3密钥', isSecret: true },
      { configKey: 'payment_serial_no', configValue: '', configType: 'text', category: 'wechat_pay', description: '商户证书序列号', isSecret: false },
      { configKey: 'payment_private_key', configValue: '', configType: 'textarea', category: 'wechat_pay', description: '商户私钥内容', isSecret: true },
      { configKey: 'payment_notify_url', configValue: '', configType: 'text', category: 'wechat_pay', description: '支付回调地址', isSecret: false },
    ]
  },
  {
    key: 'sms',
    title: '短信接口配置',
    icon: MessageSquare,
    description: '短信验证码、通知发送配置',
    configs: [
      { configKey: 'sms_provider', configValue: 'aliyun', configType: 'select', category: 'sms', description: '短信服务商', isSecret: false },
      { configKey: 'sms_access_key', configValue: '', configType: 'text', category: 'sms', description: 'AccessKey ID', isSecret: false },
      { configKey: 'sms_access_secret', configValue: '', configType: 'text', category: 'sms', description: 'AccessKey Secret', isSecret: true },
      { configKey: 'sms_sign_name', configValue: '', configType: 'text', category: 'sms', description: '短信签名', isSecret: false },
      { configKey: 'sms_template_code', configValue: '', configType: 'text', category: 'sms', description: '验证码模板ID', isSecret: false },
      { configKey: 'sms_notify_template', configValue: '', configType: 'text', category: 'sms', description: '通知模板ID (可选)', isSecret: false },
    ]
  },
  {
    key: 'storage',
    title: '对象存储配置',
    icon: Database,
    description: '图片、文件存储配置 (默认使用Coze内置TOS)',
    configs: [
      { configKey: 'storage_provider', configValue: 'tos', configType: 'select', category: 'storage', description: '存储服务商', isSecret: false },
      { configKey: 'storage_bucket', configValue: '', configType: 'text', category: 'storage', description: 'Bucket名称', isSecret: false },
      { configKey: 'storage_region', configValue: '', configType: 'text', category: 'storage', description: '地域 (如: cn-beijing)', isSecret: false },
      { configKey: 'storage_access_key', configValue: '', configType: 'text', category: 'storage', description: 'AccessKey', isSecret: false },
      { configKey: 'storage_access_secret', configValue: '', configType: 'text', category: 'storage', description: 'AccessSecret', isSecret: true },
      { configKey: 'storage_endpoint', configValue: '', configType: 'text', category: 'storage', description: 'Endpoint地址', isSecret: false },
    ]
  },
  {
    key: 'ai',
    title: 'AI导购配置',
    icon: Bot,
    description: 'AI智能导购、推荐相关配置',
    configs: [
      { configKey: 'ai_enabled', configValue: 'true', configType: 'boolean', category: 'ai', description: '启用AI导购功能', isSecret: false },
      { configKey: 'ai_provider', configValue: 'coze', configType: 'select', category: 'ai', description: 'AI服务商', isSecret: false },
      { configKey: 'ai_api_key', configValue: '', configType: 'text', category: 'ai', description: 'API Key', isSecret: true },
      { configKey: 'ai_bot_id', configValue: '', configType: 'text', category: 'ai', description: 'Bot ID (Coze)', isSecret: false },
      { configKey: 'ai_model', configValue: 'gpt-3.5-turbo', configType: 'text', category: 'ai', description: '模型名称', isSecret: false },
    ]
  },
  {
    key: 'basic',
    title: '基础配置',
    icon: Globe,
    description: '网站基础信息配置',
    configs: [
      { configKey: 'site_name', configValue: '厦门AI本地生活', configType: 'text', category: 'basic', description: '网站名称', isSecret: false },
      { configKey: 'site_logo', configValue: '', configType: 'text', category: 'basic', description: '网站Logo URL', isSecret: false },
      { configKey: 'contact_phone', configValue: '', configType: 'text', category: 'basic', description: '客服电话', isSecret: false },
      { configKey: 'contact_email', configValue: '', configType: 'text', category: 'basic', description: '客服邮箱', isSecret: false },
      { configKey: 'contact_wechat', configValue: '', configType: 'text', category: 'basic', description: '客服微信', isSecret: false },
    ]
  },
  {
    key: 'commission',
    title: '分销佣金配置',
    icon: DollarSign,
    description: '分销返佣、提现相关配置',
    configs: [
      { configKey: 'commission_enabled', configValue: 'true', configType: 'boolean', category: 'commission', description: '启用分销功能', isSecret: false },
      { configKey: 'commission_rate', configValue: '10', configType: 'number', category: 'commission', description: '默认佣金比例 (%)', isSecret: false },
      { configKey: 'commission_level1_rate', configValue: '5', configType: 'number', category: 'commission', description: '一级佣金比例 (%)', isSecret: false },
      { configKey: 'commission_level2_rate', configValue: '3', configType: 'number', category: 'commission', description: '二级佣金比例 (%)', isSecret: false },
      { configKey: 'withdraw_min_amount', configValue: '100', configType: 'number', category: 'commission', description: '最低提现金额 (元)', isSecret: false },
      { configKey: 'withdraw_fee_rate', configValue: '0', configType: 'number', category: 'commission', description: '提现手续费率 (%)', isSecret: false },
    ]
  },
  {
    key: 'region',
    title: '区域配置',
    icon: MapPin,
    description: '厦门岛内外区域配送配置',
    configs: [
      { configKey: 'region_delivery_fee_inside', configValue: '0', configType: 'number', category: 'region', description: '岛内配送费 (元)', isSecret: false },
      { configKey: 'region_delivery_fee_outside', configValue: '5', configType: 'number', category: 'region', description: '岛外配送费 (元)', isSecret: false },
      { configKey: 'region_free_delivery_amount', configValue: '50', configType: 'number', category: 'region', description: '免配送费门槛 (元)', isSecret: false },
    ]
  },
]

export default function SettingsPage() {
  const [configs, setConfigs] = useState<ConfigCategory[]>(configDefinitions)
  const [loading, setLoading] = useState(true)
  const [saving, setSaving] = useState(false)
  const [activeCategory, setActiveCategory] = useState<string>('wechat_mini')
  const [showSecrets, setShowSecrets] = useState<Record<string, boolean>>({})
  const [testResults, setTestResults] = useState<Record<string, { success: boolean; message: string }>>({})

  useEffect(() => {
    fetchConfigs()
  }, [])

  const fetchConfigs = async () => {
    setLoading(true)
    try {
      const res: any = await settingApi.getAll()
      if (res.code === 200 && res.data) {
        // 合并数据库配置到定义中
        const mergedConfigs = configDefinitions.map(category => ({
          ...category,
          configs: category.configs.map(config => {
            const dbConfig = res.data.find((c: any) => c.config_key === config.configKey)
            return dbConfig ? { ...config, configValue: dbConfig.config_value || '', id: dbConfig.id } : config
          })
        }))
        setConfigs(mergedConfigs)
      }
    } catch (error) {
      console.error('Fetch configs error:', error)
    } finally {
      setLoading(false)
    }
  }

  const handleValueChange = (categoryKey: string, configKey: string, value: string) => {
    setConfigs(prev => prev.map(category => {
      if (category.key === categoryKey) {
        return {
          ...category,
          configs: category.configs.map(config => 
            config.configKey === configKey ? { ...config, configValue: value } : config
          )
        }
      }
      return category
    }))
  }

  const handleSave = async () => {
    setSaving(true)
    try {
      const allConfigs = configs.flatMap(category => 
        category.configs.map(config => ({
          configKey: config.configKey,
          configValue: config.configValue,
          configType: config.configType,
          category: config.category,
          description: config.description,
          isSecret: config.isSecret
        }))
      )
      
      const res: any = await settingApi.batchUpdate({ configs: allConfigs })
      if (res.code === 200) {
        alert('保存成功')
        fetchConfigs()
      } else {
        alert(res.msg || '保存失败')
      }
    } catch (error) {
      console.error('Save configs error:', error)
      alert('保存失败')
    } finally {
      setSaving(false)
    }
  }

  const handleTest = async (categoryKey: string) => {
    try {
      setTestResults(prev => ({ ...prev, [categoryKey]: { success: false, message: '测试中...' } }))
      const res: any = await settingApi.test(categoryKey)
      setTestResults(prev => ({ 
        ...prev, 
        [categoryKey]: { 
          success: res.code === 200 && res.data?.success, 
          message: res.data?.message || '测试完成' 
        } 
      }))
    } catch (error) {
      setTestResults(prev => ({ 
        ...prev, 
        [categoryKey]: { success: false, message: '测试失败' } 
      }))
    }
  }

  const toggleShowSecret = (key: string) => {
    setShowSecrets(prev => ({ ...prev, [key]: !prev[key] }))
  }

  const renderConfigInput = (config: ConfigItem, categoryKey: string) => {
    const inputId = `${categoryKey}_${config.configKey}`
    const isSecretVisible = showSecrets[inputId]

    switch (config.configType) {
      case 'boolean':
        return (
          <select
            className="w-full h-10 px-3 rounded-lg border border-stone-200 focus:border-teal-500 focus:ring-1 focus:ring-teal-500"
            value={config.configValue}
            onChange={(e) => handleValueChange(categoryKey, config.configKey, e.target.value)}
          >
            <option value="true">启用</option>
            <option value="false">禁用</option>
          </select>
        )
      case 'select':
        const options: Record<string, string[]> = {
          'sms_provider': ['aliyun', 'tencent', 'huawei'],
          'storage_provider': ['tos', 'oss', 'cos', 'qiniu'],
          'ai_provider': ['coze', 'openai', 'azure'],
        }
        return (
          <select
            className="w-full h-10 px-3 rounded-lg border border-stone-200 focus:border-teal-500 focus:ring-1 focus:ring-teal-500"
            value={config.configValue}
            onChange={(e) => handleValueChange(categoryKey, config.configKey, e.target.value)}
          >
            {(options[config.configKey] || []).map(opt => (
              <option key={opt} value={opt}>{opt.toUpperCase()}</option>
            ))}
          </select>
        )
      case 'textarea':
        return (
          <div className="relative">
            <textarea
              className="w-full min-h-[100px] px-3 py-2 rounded-lg border border-stone-200 focus:border-teal-500 focus:ring-1 focus:ring-teal-500 font-mono text-sm"
              value={isSecretVisible ? config.configValue : (config.configValue ? '••••••••••••' : '')}
              onChange={(e) => handleValueChange(categoryKey, config.configKey, e.target.value)}
              placeholder={`请输入${config.description}`}
            />
            {config.isSecret && config.configValue && (
              <button
                type="button"
                className="absolute right-2 top-2 p-1 text-stone-400 hover:text-stone-600"
                onClick={() => toggleShowSecret(inputId)}
              >
                {isSecretVisible ? <EyeOff size={16} /> : <Eye size={16} />}
              </button>
            )}
          </div>
        )
      case 'number':
        return (
          <Input
            type="number"
            value={config.configValue}
            onChange={(e) => handleValueChange(categoryKey, config.configKey, e.target.value)}
            placeholder={`请输入${config.description}`}
          />
        )
      default:
        return (
          <div className="relative">
            <Input
              type={config.isSecret && !isSecretVisible ? 'password' : 'text'}
              value={config.configValue}
              onChange={(e) => handleValueChange(categoryKey, config.configKey, e.target.value)}
              placeholder={`请输入${config.description}`}
              className={config.isSecret ? 'pr-10' : ''}
            />
            {config.isSecret && config.configValue && (
              <button
                type="button"
                className="absolute right-2 top-1/2 -translate-y-1/2 p-1 text-stone-400 hover:text-stone-600"
                onClick={() => toggleShowSecret(inputId)}
              >
                {isSecretVisible ? <EyeOff size={16} /> : <Eye size={16} />}
              </button>
            )}
          </div>
        )
    }
  }

  const currentCategory = configs.find(c => c.key === activeCategory)

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h1 className="text-2xl font-bold text-stone-800 flex items-center gap-2">
          <Settings size={24} color="#14B8A6" />
          系统配置
        </h1>
        <Button onClick={handleSave} disabled={saving || loading}>
          {saving ? (
            <>
              <Loader2 className="h-4 w-4 animate-spin mr-2" />
              保存中...
            </>
          ) : (
            <>
              <Save size={16} className="mr-2" />
              保存配置
            </>
          )}
        </Button>
      </div>

      {loading ? (
        <div className="flex items-center justify-center h-64">
          <Loader2 className="h-6 w-6 animate-spin text-teal-500" />
        </div>
      ) : (
        <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
          {/* 左侧分类导航 */}
          <div className="lg:col-span-1">
            <Card>
              <CardContent className="p-2">
                <nav className="space-y-1">
                  {configs.map(category => {
                    const IconComponent = category.icon
                    return (
                      <button
                        key={category.key}
                        onClick={() => setActiveCategory(category.key)}
                        className={`w-full text-left px-3 py-2 rounded-lg transition-colors ${
                          activeCategory === category.key 
                            ? 'bg-teal-50 text-teal-700 border-l-2 border-teal-500' 
                            : 'hover:bg-stone-50 text-stone-600'
                        }`}
                      >
                        <div className="flex items-center gap-2">
                          <IconComponent size={18} />
                          <span className="font-medium text-sm">{category.title}</span>
                        </div>
                        <p className="text-xs text-stone-400 mt-0.5 ml-6 truncate">{category.description}</p>
                      </button>
                    )
                  })}
                </nav>
              </CardContent>
            </Card>
          </div>

          {/* 右侧配置内容 */}
          <div className="lg:col-span-3">
            {currentCategory && (
              <Card>
                <CardHeader className="flex flex-row items-center justify-between">
                  <div className="flex items-center gap-2">
                    <currentCategory.icon size={20} color="#14B8A6" />
                    <div>
                      <CardTitle className="text-lg">{currentCategory.title}</CardTitle>
                      <p className="text-sm text-stone-500 mt-1">{currentCategory.description}</p>
                    </div>
                  </div>
                  {['wechat_mini', 'wechat_pay', 'sms', 'storage'].includes(activeCategory) && (
                    <Button 
                      variant="outline" 
                      size="sm"
                      onClick={() => handleTest(activeCategory)}
                      className="flex items-center gap-1"
                    >
                      <TestTube size={14} />
                      测试连接
                    </Button>
                  )}
                </CardHeader>
                <CardContent>
                  {/* 测试结果提示 */}
                  {testResults[activeCategory] && (
                    <div className={`mb-4 p-3 rounded-lg flex items-center gap-2 ${
                      testResults[activeCategory].success 
                        ? 'bg-green-50 text-green-700' 
                        : 'bg-red-50 text-red-700'
                    }`}>
                      {testResults[activeCategory].success ? <CheckCircle size={16} /> : <XCircle size={16} />}
                      {testResults[activeCategory].message}
                    </div>
                  )}

                  <div className="space-y-6">
                    {currentCategory.configs.map(config => (
                      <div key={config.configKey} className="grid grid-cols-[200px_1fr] gap-4 items-start">
                        <div>
                          <label className="block text-sm font-medium text-stone-700">
                            {config.description}
                            {config.isSecret && (
                              <span className="ml-1 text-xs text-amber-500">(敏感)</span>
                            )}
                          </label>
                          <p className="text-xs text-stone-400 mt-0.5">{config.configKey}</p>
                        </div>
                        <div className="max-w-xl">
                          {renderConfigInput(config, activeCategory)}
                        </div>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            )}
          </div>
        </div>
      )}
    </div>
  )
}
