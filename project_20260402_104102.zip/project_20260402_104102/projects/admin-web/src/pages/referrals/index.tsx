import { useState, useEffect, ChangeEvent } from 'react'
import { Search, Users, TrendingUp, DollarSign, UserPlus, Eye, RefreshCw } from 'lucide-react'
import { referralApi } from '@/lib/api'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'

interface Referrer {
  id: string
  nickname: string
  phone: string
  avatar_url: string
  referral_code: string
  created_at: string
  referralCount: number
  totalCommission: string
}

interface CommissionRecord {
  id: string
  user_id: string
  related_user_id: string
  amount: string
  status: string
  created_at: string
  users?: {
    nickname: string
    phone: string
  }
  related_users?: {
    nickname: string
    phone: string
  }
}

interface Stats {
  totalCommission: string
  monthCommission: string
  referrerCount: number
  todayReferrals: number
}

interface ReferrersResponse {
  referrers: Referrer[]
  total: number
}

interface RecordsResponse {
  records: CommissionRecord[]
  total: number
}

export default function ReferralsPage() {
  const [activeTab, setActiveTab] = useState<'referrers' | 'records'>('referrers')
  const [referrers, setReferrers] = useState<Referrer[]>([])
  const [records, setRecords] = useState<CommissionRecord[]>([])
  const [stats, setStats] = useState<Stats | null>(null)
  const [total, setTotal] = useState(0)
  const [page, setPage] = useState(1)
  const [pageSize] = useState(20)
  const [keyword, setKeyword] = useState('')
  const [loading, setLoading] = useState(false)

  useEffect(() => {
    fetchStats()
    if (activeTab === 'referrers') {
      fetchReferrers()
    } else {
      fetchRecords()
    }
  }, [activeTab, page])

  const fetchStats = async () => {
    try {
      const res = await referralApi.getStats() as { data: Stats }
      setStats(res.data)
    } catch (error) {
      console.error('获取统计数据失败:', error)
    }
  }

  const fetchReferrers = async () => {
    setLoading(true)
    try {
      const res = await referralApi.getReferrers({
        page,
        pageSize,
        keyword: keyword || undefined,
      }) as { data: ReferrersResponse }
      setReferrers(res.data.referrers || [])
      setTotal(res.data.total || 0)
    } catch (error) {
      console.error('获取分销员列表失败:', error)
    } finally {
      setLoading(false)
    }
  }

  const fetchRecords = async () => {
    setLoading(true)
    try {
      const res = await referralApi.getRecords({
        page,
        pageSize,
      }) as { data: RecordsResponse }
      setRecords(res.data.records || [])
      setTotal(res.data.total || 0)
    } catch (error) {
      console.error('获取佣金记录失败:', error)
    } finally {
      setLoading(false)
    }
  }

  const handleSearch = () => {
    setPage(1)
    if (activeTab === 'referrers') {
      fetchReferrers()
    }
  }

  const handleViewReferrerRecords = async (referrer: Referrer) => {
    setLoading(true)
    try {
      const res = await referralApi.getRecords({
        page: 1,
        pageSize: 100,
        userId: referrer.id,
      }) as { data: RecordsResponse }
      setRecords(res.data.records || [])
      setActiveTab('records')
    } catch (error) {
      console.error('获取佣金记录失败:', error)
    } finally {
      setLoading(false)
    }
  }

  const getStatusBadge = (status: string) => {
    const styles: Record<string, string> = {
      pending: 'bg-yellow-100 text-yellow-800',
      completed: 'bg-green-100 text-green-800',
      failed: 'bg-red-100 text-red-800',
    }
    const labels: Record<string, string> = {
      pending: '待结算',
      completed: '已结算',
      failed: '已取消',
    }
    return (
      <span className={`px-2 py-1 rounded-full text-xs ${styles[status] || 'bg-gray-100 text-gray-800'}`}>
        {labels[status] || status}
      </span>
    )
  }

  const totalPages = Math.ceil(total / pageSize)

  return (
    <div className="space-y-6">
      {/* 页面标题 */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-gray-900">分销管理</h1>
          <p className="text-gray-500 mt-1">管理分销员、查看佣金统计</p>
        </div>
        <Button variant="outline" onClick={() => { fetchStats(); activeTab === 'referrers' ? fetchReferrers() : fetchRecords() }}>
          <RefreshCw className="w-4 h-4 mr-2" />
          刷新
        </Button>
      </div>

      {/* 统计卡片 */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <div className="bg-white rounded-lg shadow p-6">
          <div className="flex items-center">
            <div className="p-2 bg-orange-100 rounded-lg">
              <DollarSign className="w-6 h-6 text-orange-600" />
            </div>
            <div className="ml-4">
              <p className="text-sm text-gray-500">累计佣金发放</p>
              <p className="text-2xl font-bold text-gray-900">¥{stats?.totalCommission || '0.00'}</p>
            </div>
          </div>
        </div>
        <div className="bg-white rounded-lg shadow p-6">
          <div className="flex items-center">
            <div className="p-2 bg-blue-100 rounded-lg">
              <TrendingUp className="w-6 h-6 text-blue-600" />
            </div>
            <div className="ml-4">
              <p className="text-sm text-gray-500">本月佣金发放</p>
              <p className="text-2xl font-bold text-gray-900">¥{stats?.monthCommission || '0.00'}</p>
            </div>
          </div>
        </div>
        <div className="bg-white rounded-lg shadow p-6">
          <div className="flex items-center">
            <div className="p-2 bg-green-100 rounded-lg">
              <Users className="w-6 h-6 text-green-600" />
            </div>
            <div className="ml-4">
              <p className="text-sm text-gray-500">分销员数量</p>
              <p className="text-2xl font-bold text-gray-900">{stats?.referrerCount || 0}</p>
            </div>
          </div>
        </div>
        <div className="bg-white rounded-lg shadow p-6">
          <div className="flex items-center">
            <div className="p-2 bg-purple-100 rounded-lg">
              <UserPlus className="w-6 h-6 text-purple-600" />
            </div>
            <div className="ml-4">
              <p className="text-sm text-gray-500">今日新增推荐</p>
              <p className="text-2xl font-bold text-gray-900">{stats?.todayReferrals || 0}</p>
            </div>
          </div>
        </div>
      </div>

      {/* 标签页切换 */}
      <div className="bg-white rounded-lg shadow">
        <div className="border-b">
          <div className="flex">
            <button
              onClick={() => { setActiveTab('referrers'); setPage(1) }}
              className={`px-6 py-3 text-sm font-medium border-b-2 transition-colors ${
                activeTab === 'referrers'
                  ? 'border-orange-500 text-orange-600'
                  : 'border-transparent text-gray-500 hover:text-gray-700'
              }`}
            >
              分销员列表
            </button>
            <button
              onClick={() => { setActiveTab('records'); setPage(1) }}
              className={`px-6 py-3 text-sm font-medium border-b-2 transition-colors ${
                activeTab === 'records'
                  ? 'border-orange-500 text-orange-600'
                  : 'border-transparent text-gray-500 hover:text-gray-700'
              }`}
            >
              佣金记录
            </button>
          </div>
        </div>

        {/* 搜索栏 */}
        {activeTab === 'referrers' && (
          <div className="p-4 border-b">
            <div className="flex items-center gap-2">
              <Input
                placeholder="搜索手机号/昵称"
                value={keyword}
                onChange={(e: ChangeEvent<HTMLInputElement>) => setKeyword(e.target.value)}
                className="w-64"
              />
              <Button onClick={handleSearch}>
                <Search className="w-4 h-4 mr-2" />
                搜索
              </Button>
            </div>
          </div>
        )}

        {/* 分销员列表 */}
        {activeTab === 'referrers' && (
          <table className="min-w-full divide-y divide-gray-200">
            <thead className="bg-gray-50">
              <tr>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">分销员</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">邀请码</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">推荐人数</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">累计佣金</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">注册时间</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">操作</th>
              </tr>
            </thead>
            <tbody className="bg-white divide-y divide-gray-200">
              {loading ? (
                <tr>
                  <td colSpan={6} className="px-6 py-12 text-center text-gray-500">
                    加载中...
                  </td>
                </tr>
              ) : referrers.length === 0 ? (
                <tr>
                  <td colSpan={6} className="px-6 py-12 text-center text-gray-500">
                    暂无分销员
                  </td>
                </tr>
              ) : (
                referrers.map((r) => (
                  <tr key={r.id} className="hover:bg-gray-50">
                    <td className="px-6 py-4 whitespace-nowrap">
                      <div className="flex items-center">
                        <div className="w-8 h-8 bg-orange-100 rounded-full flex items-center justify-center mr-3">
                          {r.avatar_url ? (
                            <img src={r.avatar_url} alt="" className="w-8 h-8 rounded-full" />
                          ) : (
                            <span className="text-xs text-orange-600">{(r.nickname || '?')[0]}</span>
                          )}
                        </div>
                        <div>
                          <div className="text-sm font-medium text-gray-900">{r.nickname || '未知用户'}</div>
                          <div className="text-xs text-gray-500">{r.phone || '-'}</div>
                        </div>
                      </div>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <span className="font-mono text-sm bg-gray-100 px-2 py-1 rounded">
                        {r.referral_code}
                      </span>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                      {r.referralCount} 人
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-orange-600">
                      ¥{r.totalCommission}
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                      {new Date(r.created_at).toLocaleDateString()}
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm">
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => handleViewReferrerRecords(r)}
                      >
                        <Eye className="w-4 h-4 mr-1" />
                        查看记录
                      </Button>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        )}

        {/* 佣金记录列表 */}
        {activeTab === 'records' && (
          <table className="min-w-full divide-y divide-gray-200">
            <thead className="bg-gray-50">
              <tr>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">分销员</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">被推荐人</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">佣金金额</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">状态</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">时间</th>
              </tr>
            </thead>
            <tbody className="bg-white divide-y divide-gray-200">
              {loading ? (
                <tr>
                  <td colSpan={5} className="px-6 py-12 text-center text-gray-500">
                    加载中...
                  </td>
                </tr>
              ) : records.length === 0 ? (
                <tr>
                  <td colSpan={5} className="px-6 py-12 text-center text-gray-500">
                    暂无佣金记录
                  </td>
                </tr>
              ) : (
                records.map((r) => (
                  <tr key={r.id} className="hover:bg-gray-50">
                    <td className="px-6 py-4 whitespace-nowrap">
                      <div className="text-sm font-medium text-gray-900">
                        {r.users?.nickname || '未知用户'}
                      </div>
                      <div className="text-xs text-gray-500">{r.users?.phone || '-'}</div>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <div className="text-sm text-gray-900">
                        {r.related_users?.nickname || '未知用户'}
                      </div>
                      <div className="text-xs text-gray-500">{r.related_users?.phone || '-'}</div>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-orange-600">
                      ¥{r.amount}
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">{getStatusBadge(r.status)}</td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                      {new Date(r.created_at).toLocaleString()}
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        )}

        {/* 分页 */}
        {totalPages > 1 && (
          <div className="bg-white px-4 py-3 flex items-center justify-between border-t">
            <div className="text-sm text-gray-500">共 {total} 条记录</div>
            <div className="flex gap-2">
              <Button
                variant="outline"
                size="sm"
                disabled={page === 1}
                onClick={() => setPage(page - 1)}
              >
                上一页
              </Button>
              <span className="px-3 py-1 text-sm text-gray-500">
                {page} / {totalPages}
              </span>
              <Button
                variant="outline"
                size="sm"
                disabled={page === totalPages}
                onClick={() => setPage(page + 1)}
              >
                下一页
              </Button>
            </div>
          </div>
        )}
      </div>
    </div>
  )
}
