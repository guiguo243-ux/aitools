import { useState, useEffect, ChangeEvent } from 'react'
import { CheckCircle, XCircle, Eye, RefreshCw } from 'lucide-react'
import { refundApi } from '@/lib/api'
import { Button } from '@/components/ui/button'
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from '@/components/ui/dialog'

interface Refund {
  id: string
  order_id: string
  user_id: string
  amount: string
  reason: string
  status: string
  created_at: string
  processed_at?: string
  reject_reason?: string
  users?: {
    nickname: string
    phone: string
    avatar_url: string
  }
  orders?: {
    order_no: string
    pay_amount: string
    merchants?: { name: string }
  }
}

interface RefundsResponse {
  refunds: Refund[]
  total: number
}

export default function RefundsPage() {
  const [refunds, setRefunds] = useState<Refund[]>([])
  const [total, setTotal] = useState(0)
  const [page, setPage] = useState(1)
  const [pageSize] = useState(20)
  const [statusFilter, setStatusFilter] = useState('')
  const [loading, setLoading] = useState(false)
  const [selectedRefund, setSelectedRefund] = useState<Refund | null>(null)
  const [showDetail, setShowDetail] = useState(false)
  const [showReject, setShowReject] = useState(false)
  const [rejectReason, setRejectReason] = useState('')

  useEffect(() => {
    fetchRefunds()
  }, [page, statusFilter])

  const fetchRefunds = async () => {
    setLoading(true)
    try {
      const res = await refundApi.getList({
        page,
        pageSize,
        status: statusFilter || undefined,
      }) as { data: RefundsResponse }
      setRefunds(res.data.refunds || [])
      setTotal(res.data.total || 0)
    } catch (error) {
      console.error('获取退款列表失败:', error)
    } finally {
      setLoading(false)
    }
  }

  const handleApprove = async (refundId: string) => {
    if (!confirm('确认通过该退款申请？金额将返还用户余额。')) return
    
    try {
      const adminId = localStorage.getItem('adminId') || '1'
      const res = await refundApi.approve(refundId, adminId)
      const responseData = res as unknown as { msg: string }
      alert(responseData.msg)
      fetchRefunds()
    } catch (error) {
      console.error('审批失败:', error)
    }
  }

  const handleReject = async () => {
    if (!selectedRefund || !rejectReason.trim()) {
      alert('请填写拒绝原因')
      return
    }

    try {
      const adminId = localStorage.getItem('adminId') || '1'
      const res = await refundApi.reject(selectedRefund.id, adminId, rejectReason)
      const responseData = res as unknown as { msg: string }
      alert(responseData.msg)
      setShowReject(false)
      setRejectReason('')
      setSelectedRefund(null)
      fetchRefunds()
    } catch (error) {
      console.error('拒绝失败:', error)
    }
  }

  const getStatusBadge = (status: string) => {
    const styles: Record<string, string> = {
      pending: 'bg-yellow-100 text-yellow-800',
      approved: 'bg-green-100 text-green-800',
      rejected: 'bg-red-100 text-red-800',
    }
    const labels: Record<string, string> = {
      pending: '待处理',
      approved: '已通过',
      rejected: '已拒绝',
    }
    return (
      <span className={`px-2 py-1 rounded-full text-xs ${styles[status] || 'bg-gray-100 text-gray-800'}`}>
        {labels[status] || status}
      </span>
    )
  }

  const totalPages = Math.ceil(total / pageSize)

  return (
    <div className="space-y-6">
      {/* 页面标题 */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-gray-900">退款管理</h1>
          <p className="text-gray-500 mt-1">审核用户退款申请</p>
        </div>
        <Button variant="outline" onClick={fetchRefunds}>
          <RefreshCw className="w-4 h-4 mr-2" />
          刷新
        </Button>
      </div>

      {/* 筛选条件 */}
      <div className="bg-white rounded-lg shadow p-4">
        <div className="flex items-center gap-4">
          <select
            value={statusFilter}
            onChange={(e) => setStatusFilter(e.target.value)}
            className="px-3 py-2 border rounded-md"
          >
            <option value="">全部状态</option>
            <option value="pending">待处理</option>
            <option value="approved">已通过</option>
            <option value="rejected">已拒绝</option>
          </select>
        </div>
      </div>

      {/* 退款列表 */}
      <div className="bg-white rounded-lg shadow overflow-hidden">
        <table className="min-w-full divide-y divide-gray-200">
          <thead className="bg-gray-50">
            <tr>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">用户</th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">订单号</th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">商家</th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">退款金额</th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">状态</th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">申请时间</th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">操作</th>
            </tr>
          </thead>
          <tbody className="bg-white divide-y divide-gray-200">
            {loading ? (
              <tr>
                <td colSpan={7} className="px-6 py-12 text-center text-gray-500">
                  加载中...
                </td>
              </tr>
            ) : refunds.length === 0 ? (
              <tr>
                <td colSpan={7} className="px-6 py-12 text-center text-gray-500">
                  暂无退款记录
                </td>
              </tr>
            ) : (
              refunds.map((r) => (
                <tr key={r.id} className="hover:bg-gray-50">
                  <td className="px-6 py-4 whitespace-nowrap">
                    <div className="flex items-center">
                      <div className="w-8 h-8 bg-gray-200 rounded-full flex items-center justify-center mr-3">
                        {r.users?.avatar_url ? (
                          <img src={r.users.avatar_url} alt="" className="w-8 h-8 rounded-full" />
                        ) : (
                          <span className="text-xs text-gray-500">
                            {(r.users?.nickname || '?')[0]}
                          </span>
                        )}
                      </div>
                      <div>
                        <div className="text-sm font-medium text-gray-900">
                          {r.users?.nickname || '未知用户'}
                        </div>
                        <div className="text-xs text-gray-500">{r.users?.phone || '-'}</div>
                      </div>
                    </div>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                    {r.orders?.order_no || r.order_id?.slice(0, 12)}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                    {r.orders?.merchants?.name || '-'}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <span className="text-sm font-medium text-orange-600">¥{r.amount}</span>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">{getStatusBadge(r.status)}</td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                    {new Date(r.created_at).toLocaleString()}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm">
                    <div className="flex items-center gap-2">
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => {
                          setSelectedRefund(r)
                          setShowDetail(true)
                        }}
                      >
                        <Eye className="w-4 h-4" />
                      </Button>
                      {r.status === 'pending' && (
                        <>
                          <Button
                            variant="ghost"
                            size="sm"
                            className="text-green-600 hover:text-green-700"
                            onClick={() => handleApprove(r.id)}
                          >
                            <CheckCircle className="w-4 h-4" />
                          </Button>
                          <Button
                            variant="ghost"
                            size="sm"
                            className="text-red-600 hover:text-red-700"
                            onClick={() => {
                              setSelectedRefund(r)
                              setShowReject(true)
                            }}
                          >
                            <XCircle className="w-4 h-4" />
                          </Button>
                        </>
                      )}
                    </div>
                  </td>
                </tr>
              ))
            )}
          </tbody>
        </table>

        {/* 分页 */}
        {totalPages > 1 && (
          <div className="bg-white px-4 py-3 flex items-center justify-between border-t">
            <div className="text-sm text-gray-500">共 {total} 条记录</div>
            <div className="flex gap-2">
              <Button
                variant="outline"
                size="sm"
                disabled={page === 1}
                onClick={() => setPage(page - 1)}
              >
                上一页
              </Button>
              <span className="px-3 py-1 text-sm text-gray-500">
                {page} / {totalPages}
              </span>
              <Button
                variant="outline"
                size="sm"
                disabled={page === totalPages}
                onClick={() => setPage(page + 1)}
              >
                下一页
              </Button>
            </div>
          </div>
        )}
      </div>

      {/* 详情弹窗 */}
      <Dialog open={showDetail} onOpenChange={setShowDetail}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle>退款详情</DialogTitle>
          </DialogHeader>
          {selectedRefund && (
            <div className="space-y-4 py-4">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <div className="text-xs text-gray-500">用户昵称</div>
                  <div className="font-medium">{selectedRefund.users?.nickname || '-'}</div>
                </div>
                <div>
                  <div className="text-xs text-gray-500">手机号</div>
                  <div className="font-medium">{selectedRefund.users?.phone || '-'}</div>
                </div>
                <div>
                  <div className="text-xs text-gray-500">退款金额</div>
                  <div className="font-medium text-orange-600">¥{selectedRefund.amount}</div>
                </div>
                <div>
                  <div className="text-xs text-gray-500">状态</div>
                  <div>{getStatusBadge(selectedRefund.status)}</div>
                </div>
                <div>
                  <div className="text-xs text-gray-500">订单号</div>
                  <div className="font-medium">{selectedRefund.orders?.order_no || '-'}</div>
                </div>
                <div>
                  <div className="text-xs text-gray-500">商家</div>
                  <div className="font-medium">{selectedRefund.orders?.merchants?.name || '-'}</div>
                </div>
                <div className="col-span-2">
                  <div className="text-xs text-gray-500">退款原因</div>
                  <div className="font-medium">{selectedRefund.reason || '-'}</div>
                </div>
                <div className="col-span-2">
                  <div className="text-xs text-gray-500">申请时间</div>
                  <div className="font-medium">{new Date(selectedRefund.created_at).toLocaleString()}</div>
                </div>
                {selectedRefund.processed_at && (
                  <div className="col-span-2">
                    <div className="text-xs text-gray-500">处理时间</div>
                    <div className="font-medium">{new Date(selectedRefund.processed_at).toLocaleString()}</div>
                  </div>
                )}
                {selectedRefund.reject_reason && (
                  <div className="col-span-2">
                    <div className="text-xs text-gray-500">拒绝原因</div>
                    <div className="font-medium text-red-600">{selectedRefund.reject_reason}</div>
                  </div>
                )}
              </div>
            </div>
          )}
          <DialogFooter>
            <Button variant="outline" onClick={() => setShowDetail(false)}>
              关闭
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* 拒绝弹窗 */}
      <Dialog open={showReject} onOpenChange={setShowReject}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle>拒绝退款</DialogTitle>
          </DialogHeader>
          <div className="space-y-4 py-4">
            <div className="text-sm text-gray-500">
              请填写拒绝原因
            </div>
            <textarea
              value={rejectReason}
              onChange={(e: ChangeEvent<HTMLTextAreaElement>) => setRejectReason(e.target.value)}
              placeholder="请输入拒绝原因"
              className="w-full px-3 py-2 border rounded-md min-h-[100px]"
            />
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setShowReject(false)}>
              取消
            </Button>
            <Button variant="destructive" onClick={handleReject}>
              确认拒绝
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  )
}
