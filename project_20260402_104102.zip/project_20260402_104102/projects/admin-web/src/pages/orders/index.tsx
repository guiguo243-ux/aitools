import { useState, useEffect } from 'react'
import { orderApi, exportApi } from '@/lib/api'
import { formatDateTime, getStatusBadgeClass, getStatusText } from '@/lib/utils'
import { useAuthStore } from '@/stores/auth'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Badge } from '@/components/ui/badge'
import { ShoppingCart, Search, Loader2, ChevronLeft, ChevronRight, Eye, Download } from 'lucide-react'
import { OrderDetailModal } from '@/components/OrderDetailModal'

interface Order {
  id: string
  order_no: string
  total_amount: string
  pay_amount: string
  status: string
  payment_method: string
  created_at: string
  paid_at: string
  users: { nickname: string; phone: string } | null
  merchants: { name: string } | null
}

interface OrderListResponse {
  orders: Order[]
  total: number
}

export default function OrdersPage() {
  const { admin } = useAuthStore()
  const [data, setData] = useState<OrderListResponse | null>(null)
  const [loading, setLoading] = useState(true)
  const [page, setPage] = useState(1)
  const [keyword, setKeyword] = useState('')
  const [searchKeyword, setSearchKeyword] = useState('')
  const [statusFilter, setStatusFilter] = useState('')
  const [selectedOrderId, setSelectedOrderId] = useState<string | null>(null)
  const [showDetail, setShowDetail] = useState(false)
  const [exporting, setExporting] = useState(false)
  const pageSize = 10

  useEffect(() => {
    fetchOrders()
  }, [page, searchKeyword, statusFilter])

  const fetchOrders = async () => {
    setLoading(true)
    try {
      const res: any = await orderApi.getList({
        page,
        pageSize,
        keyword: searchKeyword || undefined,
        status: statusFilter || undefined,
      })

      if (res.code === 200) {
        setData(res.data)
      }
    } catch (error) {
      console.error('Fetch orders error:', error)
    } finally {
      setLoading(false)
    }
  }

  const handleExport = async () => {
    setExporting(true)
    try {
      const res: any = await exportApi.orders({
        status: statusFilter || undefined,
      })
      if (res.code === 200 && res.data?.data) {
        const csvContent = [
          Object.keys(res.data.data[0] || {}).join(','),
          ...res.data.data.map((row: any) => Object.values(row).join(','))
        ].join('\n')
        
        const blob = new Blob(['\ufeff' + csvContent], { type: 'text/csv;charset=utf-8;' })
        const link = document.createElement('a')
        link.href = URL.createObjectURL(blob)
        link.download = `订单数据_${new Date().toISOString().split('T')[0]}.csv`
        link.click()
      }
    } catch (error) {
      console.error('Export error:', error)
      alert('导出失败')
    } finally {
      setExporting(false)
    }
  }

  const handleSearch = () => {
    setSearchKeyword(keyword)
    setPage(1)
  }

  const handleStatusChange = async (orderId: string, status: string) => {
    if (!confirm(`确定要修改订单状态吗？`)) {
      return
    }

    try {
      const res: any = await orderApi.updateStatus(orderId, status, admin?.id || '')
      if (res.code === 200) {
        fetchOrders()
      } else {
        alert(res.msg || '操作失败')
      }
    } catch (error) {
      console.error('Update status error:', error)
      alert('操作失败')
    }
  }

  const totalPages = Math.ceil((data?.total || 0) / pageSize)

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <div className="flex items-center justify-between flex-wrap gap-4">
            <CardTitle className="flex items-center gap-2">
              <ShoppingCart size={20} color="#14B8A6" />
              订单列表
            </CardTitle>
            <div className="flex items-center gap-3 flex-wrap">
              <div className="flex items-center gap-2">
                <Input
                  className="w-48"
                  placeholder="搜索订单号"
                  value={keyword}
                  onChange={(e) => setKeyword(e.target.value)}
                  onKeyDown={(e) => e.key === 'Enter' && handleSearch()}
                />
                <Button onClick={handleSearch}>
                  <Search size={16} className="mr-1" />
                  搜索
                </Button>
              </div>
              <select
                className="h-10 px-3 rounded-lg border border-stone-200 text-sm"
                value={statusFilter}
                onChange={(e) => {
                  setStatusFilter(e.target.value)
                  setPage(1)
                }}
              >
                <option value="">全部状态</option>
                <option value="pending">待支付</option>
                <option value="paid">已支付</option>
                <option value="completed">已完成</option>
                <option value="cancelled">已取消</option>
                <option value="refunding">退款中</option>
                <option value="refunded">已退款</option>
              </select>
              <Button variant="outline" onClick={handleExport} disabled={exporting}>
                {exporting ? (
                  <Loader2 size={16} className="mr-1 animate-spin" />
                ) : (
                  <Download size={16} className="mr-1" />
                )}
                导出
              </Button>
            </div>
          </div>
        </CardHeader>
        <CardContent>
          {loading ? (
            <div className="flex items-center justify-center h-64">
              <Loader2 className="h-6 w-6 animate-spin text-teal-500" />
            </div>
          ) : (
            <>
              <div className="overflow-x-auto">
                <table className="w-full">
                  <thead>
                    <tr className="border-b border-stone-200">
                      <th className="text-left py-3 px-4 text-sm font-medium text-stone-500">订单号</th>
                      <th className="text-left py-3 px-4 text-sm font-medium text-stone-500">用户</th>
                      <th className="text-left py-3 px-4 text-sm font-medium text-stone-500">商家</th>
                      <th className="text-left py-3 px-4 text-sm font-medium text-stone-500">金额</th>
                      <th className="text-left py-3 px-4 text-sm font-medium text-stone-500">状态</th>
                      <th className="text-left py-3 px-4 text-sm font-medium text-stone-500">创建时间</th>
                      <th className="text-left py-3 px-4 text-sm font-medium text-stone-500">操作</th>
                    </tr>
                  </thead>
                  <tbody>
                    {data?.orders.map((order) => (
                      <tr key={order.id} className="border-b border-stone-100 hover:bg-stone-50">
                        <td className="py-3 px-4">
                          <div className="font-medium text-stone-800">{order.order_no}</div>
                        </td>
                        <td className="py-3 px-4">
                          <div className="text-stone-600">{order.users?.nickname || '-'}</div>
                          <div className="text-xs text-stone-400">{order.users?.phone || ''}</div>
                        </td>
                        <td className="py-3 px-4 text-stone-600">
                          {order.merchants?.name || '-'}
                        </td>
                        <td className="py-3 px-4">
                          <div className="font-medium text-stone-800">¥{order.pay_amount}</div>
                          {order.total_amount !== order.pay_amount && (
                            <div className="text-xs text-stone-400 line-through">¥{order.total_amount}</div>
                          )}
                        </td>
                        <td className="py-3 px-4">
                          <Badge className={getStatusBadgeClass(order.status)}>
                            {getStatusText(order.status)}
                          </Badge>
                        </td>
                        <td className="py-3 px-4 text-stone-500 text-sm">
                          {formatDateTime(order.created_at)}
                        </td>
                        <td className="py-3 px-4">
                          <div className="flex items-center gap-2">
                            <Button
                              variant="outline"
                              size="sm"
                              onClick={() => {
                                setSelectedOrderId(order.id)
                                setShowDetail(true)
                              }}
                            >
                              <Eye size={14} />
                            </Button>
                            {order.status === 'pending' && (
                              <Button
                                variant="outline"
                                size="sm"
                                className="text-rose-600 hover:text-rose-700"
                                onClick={() => handleStatusChange(order.id, 'cancelled')}
                              >
                                取消
                              </Button>
                            )}
                            {order.status === 'paid' && (
                              <>
                                <Button
                                  variant="outline"
                                  size="sm"
                                  className="text-emerald-600 hover:text-emerald-700"
                                  onClick={() => handleStatusChange(order.id, 'completed')}
                                >
                                  核销
                                </Button>
                                <Button
                                  variant="outline"
                                  size="sm"
                                  className="text-orange-600 hover:text-orange-700"
                                  onClick={() => handleStatusChange(order.id, 'refunding')}
                                >
                                  退款
                                </Button>
                              </>
                            )}
                            {order.status === 'refunding' && (
                              <Button
                                variant="outline"
                                size="sm"
                                className="text-blue-600 hover:text-blue-700"
                                onClick={() => handleStatusChange(order.id, 'refunded')}
                              >
                                确认退款
                              </Button>
                            )}
                          </div>
                        </td>
                      </tr>
                    ))}
                    {(!data?.orders || data.orders.length === 0) && (
                      <tr>
                        <td colSpan={7} className="py-12 text-center text-stone-400">
                          暂无数据
                        </td>
                      </tr>
                    )}
                  </tbody>
                </table>
              </div>

              {/* 分页 */}
              {totalPages > 1 && (
                <div className="flex items-center justify-between mt-4 pt-4 border-t border-stone-200">
                  <div className="text-sm text-stone-500">
                    共 {data?.total || 0} 条记录
                  </div>
                  <div className="flex items-center gap-2">
                    <Button
                      variant="outline"
                      size="sm"
                      disabled={page <= 1}
                      onClick={() => setPage(page - 1)}
                    >
                      <ChevronLeft size={16} />
                    </Button>
                    <span className="text-sm text-stone-600">
                      {page} / {totalPages}
                    </span>
                    <Button
                      variant="outline"
                      size="sm"
                      disabled={page >= totalPages}
                      onClick={() => setPage(page + 1)}
                    >
                      <ChevronRight size={16} />
                    </Button>
                  </div>
                </div>
              )}
            </>
          )}
        </CardContent>
      </Card>

      {/* 订单详情弹窗 */}
      <OrderDetailModal
        orderId={selectedOrderId}
        open={showDetail}
        onClose={() => {
          setShowDetail(false)
          setSelectedOrderId(null)
        }}
      />
    </div>
  )
}
