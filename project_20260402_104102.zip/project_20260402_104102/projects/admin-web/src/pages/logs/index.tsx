import { useState, useEffect } from 'react'
import { adminApi } from '@/lib/api'
import { formatDateTime } from '@/lib/utils'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { FileText, Loader2, ChevronLeft, ChevronRight, User } from 'lucide-react'

interface AdminLog {
  id: string
  admin_id: string
  action: string
  target: string
  target_id: string
  details: string
  created_at: string
  admins: { username: string; nickname: string } | null
}

interface LogListResponse {
  logs: AdminLog[]
  total: number
}

const actionLabels: Record<string, string> = {
  update_order_status: '更新订单状态',
  update_product_status: '更新商品状态',
  update_user_status: '更新用户状态',
  update_merchant_status: '更新商家状态',
  login: '登录系统',
  logout: '退出登录',
  create_coupon: '创建优惠券',
  update_coupon_status: '更新优惠券状态',
  create_category: '创建分类',
  update_category: '更新分类',
  delete_category: '删除分类',
}

const actionBadgeColors: Record<string, string> = {
  update_order_status: 'bg-blue-50 text-blue-700',
  update_product_status: 'bg-purple-50 text-purple-700',
  update_user_status: 'bg-amber-50 text-amber-700',
  update_merchant_status: 'bg-emerald-50 text-emerald-700',
  login: 'bg-teal-50 text-teal-700',
  logout: 'bg-stone-50 text-stone-700',
  create_coupon: 'bg-pink-50 text-pink-700',
  update_coupon_status: 'bg-orange-50 text-orange-700',
  create_category: 'bg-indigo-50 text-indigo-700',
  update_category: 'bg-cyan-50 text-cyan-700',
  delete_category: 'bg-rose-50 text-rose-700',
}

const targetLabels: Record<string, string> = {
  order: '订单',
  product: '商品',
  user: '用户',
  merchant: '商家',
  coupon: '优惠券',
  category: '分类',
  system: '系统',
}

export default function LogsPage() {
  const [data, setData] = useState<LogListResponse | null>(null)
  const [loading, setLoading] = useState(true)
  const [page, setPage] = useState(1)
  const pageSize = 20

  useEffect(() => {
    fetchLogs()
  }, [page])

  const fetchLogs = async () => {
    setLoading(true)
    try {
      const res: any = await adminApi.getLogs({ page, pageSize })

      if (res.code === 200) {
        setData(res.data)
      }
    } catch (error) {
      console.error('Fetch logs error:', error)
    } finally {
      setLoading(false)
    }
  }

  const totalPages = Math.ceil((data?.total || 0) / pageSize)

  const parseDetails = (details: string) => {
    try {
      return JSON.parse(details)
    } catch {
      return {}
    }
  }

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <FileText size={20} color="#14B8A6" />
            操作日志
          </CardTitle>
        </CardHeader>
        <CardContent>
          {loading ? (
            <div className="flex items-center justify-center h-64">
              <Loader2 className="h-6 w-6 animate-spin text-teal-500" />
            </div>
          ) : (
            <>
              <div className="space-y-3">
                {data?.logs.map((log) => {
                  const details = parseDetails(log.details)
                  return (
                    <div
                      key={log.id}
                      className="flex items-start gap-4 p-4 bg-stone-50 rounded-lg"
                    >
                      {/* 操作人 */}
                      <div className="flex items-center gap-2 min-w-[120px]">
                        <div className="w-8 h-8 rounded-full bg-teal-100 flex items-center justify-center">
                          <User size={16} color="#14B8A6" />
                        </div>
                        <div>
                          <div className="text-sm font-medium text-stone-800">
                            {log.admins?.nickname || log.admins?.username || '未知'}
                          </div>
                        </div>
                      </div>

                      {/* 操作内容 */}
                      <div className="flex-1">
                        <div className="flex items-center gap-2 mb-1">
                          <Badge className={actionBadgeColors[log.action] || 'bg-stone-100 text-stone-600'}>
                            {actionLabels[log.action] || log.action}
                          </Badge>
                          <span className="text-xs text-stone-400">
                            {targetLabels[log.target] || log.target}
                            {log.target_id && ` #${log.target_id.slice(0, 8)}`}
                          </span>
                        </div>
                        {Object.keys(details).length > 0 && (
                          <div className="text-xs text-stone-500 bg-white px-2 py-1 rounded border border-stone-200 inline-block">
                            {Object.entries(details).map(([key, value]) => (
                              <span key={key} className="mr-3">
                                {key}: <span className="text-stone-700">{String(value)}</span>
                              </span>
                            ))}
                          </div>
                        )}
                      </div>

                      {/* 时间 */}
                      <div className="text-xs text-stone-400 text-right min-w-[140px]">
                        {formatDateTime(log.created_at)}
                      </div>
                    </div>
                  )
                })}

                {(!data?.logs || data.logs.length === 0) && (
                  <div className="py-12 text-center text-stone-400">
                    暂无操作日志
                  </div>
                )}
              </div>

              {/* 分页 */}
              {totalPages > 1 && (
                <div className="flex items-center justify-between mt-4 pt-4 border-t border-stone-200">
                  <div className="text-sm text-stone-500">
                    共 {data?.total || 0} 条记录
                  </div>
                  <div className="flex items-center gap-2">
                    <Button
                      variant="outline"
                      size="sm"
                      disabled={page <= 1}
                      onClick={() => setPage(page - 1)}
                    >
                      <ChevronLeft size={16} />
                    </Button>
                    <span className="text-sm text-stone-600">
                      {page} / {totalPages}
                    </span>
                    <Button
                      variant="outline"
                      size="sm"
                      disabled={page >= totalPages}
                      onClick={() => setPage(page + 1)}
                    >
                      <ChevronRight size={16} />
                    </Button>
                  </div>
                </div>
              )}
            </>
          )}
        </CardContent>
      </Card>
    </div>
  )
}
