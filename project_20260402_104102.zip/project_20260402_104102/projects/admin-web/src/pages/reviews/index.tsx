import { useState, useEffect, ChangeEvent } from 'react'
import { MessageSquare, Star, Reply, Trash2, RefreshCw } from 'lucide-react'
import { reviewApi } from '@/lib/api'
import { Button } from '@/components/ui/button'
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from '@/components/ui/dialog'

interface Review {
  id: string
  rating: number
  content: string
  images?: string[]
  tags?: string[]
  reply?: string
  reply_at?: string
  is_anonymous: boolean
  created_at: string
  users?: {
    nickname: string
    phone: string
    avatar_url: string
  }
  merchants?: {
    name: string
  }
  orders?: {
    order_no: string
    pay_amount: string
  }
}

interface ReviewStats {
  totalReviews: number
  avgRating: number
  distribution: Record<number, number>
  todayReviews: number
}

interface ReviewsResponse {
  reviews: Review[]
  total: number
}

export default function ReviewsPage() {
  const [reviews, setReviews] = useState<Review[]>([])
  const [stats, setStats] = useState<ReviewStats | null>(null)
  const [total, setTotal] = useState(0)
  const [page, setPage] = useState(1)
  const [pageSize] = useState(20)
  const [ratingFilter, setRatingFilter] = useState('')
  const [loading, setLoading] = useState(false)
  const [selectedReview, setSelectedReview] = useState<Review | null>(null)
  const [showDetail, setShowDetail] = useState(false)
  const [showReply, setShowReply] = useState(false)
  const [replyContent, setReplyContent] = useState('')

  useEffect(() => {
    fetchStats()
    fetchReviews()
  }, [page, ratingFilter])

  const fetchStats = async () => {
    try {
      const res = await reviewApi.getStats() as { data: ReviewStats }
      setStats(res.data)
    } catch (error) {
      console.error('获取统计失败:', error)
    }
  }

  const fetchReviews = async () => {
    setLoading(true)
    try {
      const res = await reviewApi.getList({
        page,
        pageSize,
        rating: ratingFilter ? parseInt(ratingFilter) : undefined,
      }) as { data: ReviewsResponse }
      setReviews(res.data.reviews || [])
      setTotal(res.data.total || 0)
    } catch (error) {
      console.error('获取评价列表失败:', error)
    } finally {
      setLoading(false)
    }
  }

  const handleReply = async () => {
    if (!selectedReview || !replyContent.trim()) {
      alert('请填写回复内容')
      return
    }

    try {
      const res = await reviewApi.reply(selectedReview.id, replyContent)
      const responseData = res as unknown as { msg: string }
      alert(responseData.msg)
      setShowReply(false)
      setReplyContent('')
      setSelectedReview(null)
      fetchReviews()
    } catch (error) {
      console.error('回复失败:', error)
    }
  }

  const handleDelete = async (reviewId: string) => {
    if (!confirm('确定要删除该评价吗？此操作不可恢复。')) return

    try {
      const res = await reviewApi.delete(reviewId)
      const responseData = res as unknown as { msg: string }
      alert(responseData.msg)
      fetchReviews()
      fetchStats()
    } catch (error) {
      console.error('删除失败:', error)
    }
  }

  const renderStars = (rating: number) => {
    return (
      <div className="flex items-center">
        {[1, 2, 3, 4, 5].map((star) => (
          <Star
            key={star}
            className={`w-4 h-4 ${star <= rating ? 'text-yellow-400 fill-yellow-400' : 'text-gray-300'}`}
          />
        ))}
      </div>
    )
  }

  const totalPages = Math.ceil(total / pageSize)

  return (
    <div className="space-y-6">
      {/* 页面标题 */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-gray-900">评价管理</h1>
          <p className="text-gray-500 mt-1">管理用户评价，回复评论</p>
        </div>
        <Button variant="outline" onClick={() => { fetchStats(); fetchReviews() }}>
          <RefreshCw className="w-4 h-4 mr-2" />
          刷新
        </Button>
      </div>

      {/* 统计卡片 */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <div className="bg-white rounded-lg shadow p-6">
          <div className="flex items-center">
            <div className="p-2 bg-blue-100 rounded-lg">
              <MessageSquare className="w-6 h-6 text-blue-600" />
            </div>
            <div className="ml-4">
              <p className="text-sm text-gray-500">总评价数</p>
              <p className="text-2xl font-bold text-gray-900">{stats?.totalReviews || 0}</p>
            </div>
          </div>
        </div>
        <div className="bg-white rounded-lg shadow p-6">
          <div className="flex items-center">
            <div className="p-2 bg-yellow-100 rounded-lg">
              <Star className="w-6 h-6 text-yellow-600" />
            </div>
            <div className="ml-4">
              <p className="text-sm text-gray-500">平均评分</p>
              <p className="text-2xl font-bold text-gray-900">{stats?.avgRating || 0}</p>
            </div>
          </div>
        </div>
        <div className="bg-white rounded-lg shadow p-6">
          <div className="flex items-center">
            <div className="p-2 bg-green-100 rounded-lg">
              <Star className="w-6 h-6 text-green-600" />
            </div>
            <div className="ml-4">
              <p className="text-sm text-gray-500">好评数(4-5星)</p>
              <p className="text-2xl font-bold text-gray-900">
                {(stats?.distribution?.[4] || 0) + (stats?.distribution?.[5] || 0)}
              </p>
            </div>
          </div>
        </div>
        <div className="bg-white rounded-lg shadow p-6">
          <div className="flex items-center">
            <div className="p-2 bg-purple-100 rounded-lg">
              <MessageSquare className="w-6 h-6 text-purple-600" />
            </div>
            <div className="ml-4">
              <p className="text-sm text-gray-500">今日新增</p>
              <p className="text-2xl font-bold text-gray-900">{stats?.todayReviews || 0}</p>
            </div>
          </div>
        </div>
      </div>

      {/* 筛选条件 */}
      <div className="bg-white rounded-lg shadow p-4">
        <div className="flex items-center gap-4">
          <select
            value={ratingFilter}
            onChange={(e) => setRatingFilter(e.target.value)}
            className="px-3 py-2 border rounded-md"
          >
            <option value="">全部评分</option>
            <option value="5">5星</option>
            <option value="4">4星</option>
            <option value="3">3星</option>
            <option value="2">2星</option>
            <option value="1">1星</option>
          </select>
        </div>
      </div>

      {/* 评价列表 */}
      <div className="bg-white rounded-lg shadow overflow-hidden">
        <table className="min-w-full divide-y divide-gray-200">
          <thead className="bg-gray-50">
            <tr>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">用户</th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">商家</th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">评分</th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">内容</th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">回复</th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">时间</th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">操作</th>
            </tr>
          </thead>
          <tbody className="bg-white divide-y divide-gray-200">
            {loading ? (
              <tr>
                <td colSpan={7} className="px-6 py-12 text-center text-gray-500">
                  加载中...
                </td>
              </tr>
            ) : reviews.length === 0 ? (
              <tr>
                <td colSpan={7} className="px-6 py-12 text-center text-gray-500">
                  暂无评价记录
                </td>
              </tr>
            ) : (
              reviews.map((r) => (
                <tr key={r.id} className="hover:bg-gray-50">
                  <td className="px-6 py-4 whitespace-nowrap">
                    <div className="flex items-center">
                      <div className="w-8 h-8 bg-gray-200 rounded-full flex items-center justify-center mr-3">
                        {r.is_anonymous ? (
                          <span className="text-xs text-gray-400">匿</span>
                        ) : r.users?.avatar_url ? (
                          <img src={r.users.avatar_url} alt="" className="w-8 h-8 rounded-full" />
                        ) : (
                          <span className="text-xs text-gray-500">
                            {(r.users?.nickname || '?')[0]}
                          </span>
                        )}
                      </div>
                      <div>
                        <div className="text-sm font-medium text-gray-900">
                          {r.is_anonymous ? '匿名用户' : (r.users?.nickname || '未知用户')}
                        </div>
                        {!r.is_anonymous && (
                          <div className="text-xs text-gray-500">{r.users?.phone || '-'}</div>
                        )}
                      </div>
                    </div>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                    {r.merchants?.name || '-'}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    {renderStars(r.rating)}
                  </td>
                  <td className="px-6 py-4 text-sm text-gray-500 max-w-[200px] truncate">
                    {r.content || '-'}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    {r.reply ? (
                      <span className="text-xs text-green-600">已回复</span>
                    ) : (
                      <span className="text-xs text-gray-400">未回复</span>
                    )}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                    {new Date(r.created_at).toLocaleDateString()}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm">
                    <div className="flex items-center gap-2">
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => {
                          setSelectedReview(r)
                          setShowDetail(true)
                        }}
                      >
                        查看
                      </Button>
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => {
                          setSelectedReview(r)
                          setShowReply(true)
                        }}
                      >
                        <Reply className="w-4 h-4" />
                      </Button>
                      <Button
                        variant="ghost"
                        size="sm"
                        className="text-red-600 hover:text-red-700"
                        onClick={() => handleDelete(r.id)}
                      >
                        <Trash2 className="w-4 h-4" />
                      </Button>
                    </div>
                  </td>
                </tr>
              ))
            )}
          </tbody>
        </table>

        {/* 分页 */}
        {totalPages > 1 && (
          <div className="bg-white px-4 py-3 flex items-center justify-between border-t">
            <div className="text-sm text-gray-500">共 {total} 条记录</div>
            <div className="flex gap-2">
              <Button
                variant="outline"
                size="sm"
                disabled={page === 1}
                onClick={() => setPage(page - 1)}
              >
                上一页
              </Button>
              <span className="px-3 py-1 text-sm text-gray-500">
                {page} / {totalPages}
              </span>
              <Button
                variant="outline"
                size="sm"
                disabled={page === totalPages}
                onClick={() => setPage(page + 1)}
              >
                下一页
              </Button>
            </div>
          </div>
        )}
      </div>

      {/* 详情弹窗 */}
      <Dialog open={showDetail} onOpenChange={setShowDetail}>
        <DialogContent className="max-w-lg">
          <DialogHeader>
            <DialogTitle>评价详情</DialogTitle>
          </DialogHeader>
          {selectedReview && (
            <div className="space-y-4 py-4">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <div className="text-xs text-gray-500">用户</div>
                  <div className="font-medium">
                    {selectedReview.is_anonymous ? '匿名用户' : (selectedReview.users?.nickname || '-')}
                  </div>
                </div>
                <div>
                  <div className="text-xs text-gray-500">商家</div>
                  <div className="font-medium">{selectedReview.merchants?.name || '-'}</div>
                </div>
                <div>
                  <div className="text-xs text-gray-500">评分</div>
                  <div>{renderStars(selectedReview.rating)}</div>
                </div>
                <div>
                  <div className="text-xs text-gray-500">评价时间</div>
                  <div className="font-medium">{new Date(selectedReview.created_at).toLocaleString()}</div>
                </div>
              </div>
              <div>
                <div className="text-xs text-gray-500 mb-2">评价内容</div>
                <div className="bg-gray-50 rounded-lg p-3">{selectedReview.content || '-'}</div>
              </div>
              {selectedReview.images && selectedReview.images.length > 0 && (
                <div>
                  <div className="text-xs text-gray-500 mb-2">评价图片</div>
                  <div className="flex gap-2 flex-wrap">
                    {selectedReview.images.map((img, idx) => (
                      <img key={idx} src={img} alt="" className="w-20 h-20 rounded object-cover" />
                    ))}
                  </div>
                </div>
              )}
              {selectedReview.reply && (
                <div>
                  <div className="text-xs text-gray-500 mb-2">商家回复</div>
                  <div className="bg-green-50 rounded-lg p-3">{selectedReview.reply}</div>
                  <div className="text-xs text-gray-400 mt-1">
                    回复时间: {new Date(selectedReview.reply_at || '').toLocaleString()}
                  </div>
                </div>
              )}
            </div>
          )}
          <DialogFooter>
            <Button variant="outline" onClick={() => setShowDetail(false)}>
              关闭
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* 回复弹窗 */}
      <Dialog open={showReply} onOpenChange={setShowReply}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle>回复评价</DialogTitle>
          </DialogHeader>
          <div className="space-y-4 py-4">
            {selectedReview && (
              <div className="bg-gray-50 rounded-lg p-3">
                <div className="flex items-center gap-2 mb-2">
                  {renderStars(selectedReview.rating)}
                </div>
                <div className="text-sm text-gray-700">{selectedReview.content}</div>
              </div>
            )}
            <textarea
              value={replyContent}
              onChange={(e: ChangeEvent<HTMLTextAreaElement>) => setReplyContent(e.target.value)}
              placeholder="请输入回复内容"
              className="w-full px-3 py-2 border rounded-md min-h-[100px]"
            />
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setShowReply(false)}>
              取消
            </Button>
            <Button onClick={handleReply}>
              提交回复
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  )
}
