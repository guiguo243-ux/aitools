import { useState, useEffect, ChangeEvent } from 'react'
import { Search, CheckCircle, XCircle, Eye, RefreshCw } from 'lucide-react'
import { withdrawalApi } from '@/lib/api'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from '@/components/ui/dialog'

interface Withdrawal {
  id: string
  user_id: string
  type: string
  amount: number
  status: string
  description: string
  created_at: string
  users?: {
    nickname: string
    phone: string
    avatar: string
  }
}

interface WithdrawalsResponse {
  withdrawals: Withdrawal[]
  total: number
}

export default function WithdrawalsPage() {
  const [withdrawals, setWithdrawals] = useState<Withdrawal[]>([])
  const [total, setTotal] = useState(0)
  const [page, setPage] = useState(1)
  const [pageSize] = useState(20)
  const [keyword, setKeyword] = useState('')
  const [statusFilter, setStatusFilter] = useState('')
  const [loading, setLoading] = useState(false)
  const [selectedWithdrawal, setSelectedWithdrawal] = useState<Withdrawal | null>(null)
  const [showDetail, setShowDetail] = useState(false)
  const [showReject, setShowReject] = useState(false)
  const [rejectReason, setRejectReason] = useState('')

  useEffect(() => {
    fetchWithdrawals()
  }, [page, statusFilter])

  const fetchWithdrawals = async () => {
    setLoading(true)
    try {
      const res = await withdrawalApi.getList({
        page,
        pageSize,
        status: statusFilter || undefined,
        keyword: keyword || undefined,
      }) as { data: WithdrawalsResponse }
      setWithdrawals(res.data.withdrawals || [])
      setTotal(res.data.total || 0)
    } catch (error) {
      console.error('获取提现列表失败:', error)
    } finally {
      setLoading(false)
    }
  }

  const handleSearch = () => {
    setPage(1)
    fetchWithdrawals()
  }

  const handleApprove = async (withdrawalId: string) => {
    if (!confirm('确认通过该提现申请并打款？')) return
    
    try {
      const adminId = localStorage.getItem('adminId') || '1'
      const res = await withdrawalApi.approve(withdrawalId, adminId)
      const responseData = res as unknown as { msg: string }
      alert(responseData.msg)
      fetchWithdrawals()
    } catch (error) {
      console.error('审批失败:', error)
    }
  }

  const handleReject = async () => {
    if (!selectedWithdrawal || !rejectReason.trim()) {
      alert('请填写拒绝原因')
      return
    }

    try {
      const adminId = localStorage.getItem('adminId') || '1'
      const res = await withdrawalApi.reject(selectedWithdrawal.id, adminId, rejectReason)
      const responseData = res as unknown as { msg: string }
      alert(responseData.msg)
      setShowReject(false)
      setRejectReason('')
      setSelectedWithdrawal(null)
      fetchWithdrawals()
    } catch (error) {
      console.error('拒绝失败:', error)
    }
  }

  const getStatusBadge = (status: string) => {
    const styles: Record<string, string> = {
      pending: 'bg-yellow-100 text-yellow-800',
      completed: 'bg-green-100 text-green-800',
      failed: 'bg-red-100 text-red-800',
    }
    const labels: Record<string, string> = {
      pending: '待处理',
      completed: '已完成',
      failed: '已拒绝',
    }
    return (
      <span className={`px-2 py-1 rounded-full text-xs ${styles[status] || 'bg-gray-100 text-gray-800'}`}>
        {labels[status] || status}
      </span>
    )
  }

  const formatAmount = (amount: number) => {
    return `¥${Math.abs(amount).toFixed(2)}`
  }

  const totalPages = Math.ceil(total / pageSize)

  return (
    <div className="space-y-6">
      {/* 页面标题 */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-gray-900">提现管理</h1>
          <p className="text-gray-500 mt-1">审核用户提现申请，管理打款流程</p>
        </div>
        <Button variant="outline" onClick={fetchWithdrawals}>
          <RefreshCw className="w-4 h-4 mr-2" />
          刷新
        </Button>
      </div>

      {/* 筛选条件 */}
      <div className="bg-white rounded-lg shadow p-4">
        <div className="flex flex-wrap items-center gap-4">
          <div className="flex items-center gap-2 flex-1 min-w-[240px]">
            <Input
              placeholder="搜索用户手机号/昵称"
              value={keyword}
              onChange={(e: ChangeEvent<HTMLInputElement>) => setKeyword(e.target.value)}
              className="flex-1"
            />
            <Button onClick={handleSearch}>
              <Search className="w-4 h-4" />
            </Button>
          </div>
          
          <select
            value={statusFilter}
            onChange={(e: ChangeEvent<HTMLSelectElement>) => setStatusFilter(e.target.value)}
            className="px-3 py-2 border rounded-md"
          >
            <option value="">全部状态</option>
            <option value="pending">待处理</option>
            <option value="completed">已完成</option>
            <option value="failed">已拒绝</option>
          </select>
        </div>
      </div>

      {/* 提现列表 */}
      <div className="bg-white rounded-lg shadow overflow-hidden">
        <table className="min-w-full divide-y divide-gray-200">
          <thead className="bg-gray-50">
            <tr>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">用户</th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">提现金额</th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">状态</th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">申请时间</th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">备注</th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">操作</th>
            </tr>
          </thead>
          <tbody className="bg-white divide-y divide-gray-200">
            {loading ? (
              <tr>
                <td colSpan={6} className="px-6 py-12 text-center text-gray-500">
                  加载中...
                </td>
              </tr>
            ) : withdrawals.length === 0 ? (
              <tr>
                <td colSpan={6} className="px-6 py-12 text-center text-gray-500">
                  暂无提现记录
                </td>
              </tr>
            ) : (
              withdrawals.map((w) => (
                <tr key={w.id} className="hover:bg-gray-50">
                  <td className="px-6 py-4 whitespace-nowrap">
                    <div className="flex items-center">
                      <div className="w-8 h-8 bg-gray-200 rounded-full flex items-center justify-center mr-3">
                        {w.users?.avatar ? (
                          <img src={w.users.avatar} alt="" className="w-8 h-8 rounded-full" />
                        ) : (
                          <span className="text-xs text-gray-500">
                            {(w.users?.nickname || '?')[0]}
                          </span>
                        )}
                      </div>
                      <div>
                        <div className="text-sm font-medium text-gray-900">
                          {w.users?.nickname || '未知用户'}
                        </div>
                        <div className="text-xs text-gray-500">{w.users?.phone || '-'}</div>
                      </div>
                    </div>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <span className="text-sm font-medium text-orange-600">{formatAmount(w.amount)}</span>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">{getStatusBadge(w.status)}</td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                    {new Date(w.created_at).toLocaleString()}
                  </td>
                  <td className="px-6 py-4 text-sm text-gray-500 max-w-[200px] truncate">
                    {w.description || '-'}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm">
                    <div className="flex items-center gap-2">
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => {
                          setSelectedWithdrawal(w)
                          setShowDetail(true)
                        }}
                      >
                        <Eye className="w-4 h-4" />
                      </Button>
                      {w.status === 'pending' && (
                        <>
                          <Button
                            variant="ghost"
                            size="sm"
                            className="text-green-600 hover:text-green-700"
                            onClick={() => handleApprove(w.id)}
                          >
                            <CheckCircle className="w-4 h-4" />
                          </Button>
                          <Button
                            variant="ghost"
                            size="sm"
                            className="text-red-600 hover:text-red-700"
                            onClick={() => {
                              setSelectedWithdrawal(w)
                              setShowReject(true)
                            }}
                          >
                            <XCircle className="w-4 h-4" />
                          </Button>
                        </>
                      )}
                    </div>
                  </td>
                </tr>
              ))
            )}
          </tbody>
        </table>

        {/* 分页 */}
        {totalPages > 1 && (
          <div className="bg-white px-4 py-3 flex items-center justify-between border-t">
            <div className="text-sm text-gray-500">
              共 {total} 条记录
            </div>
            <div className="flex gap-2">
              <Button
                variant="outline"
                size="sm"
                disabled={page === 1}
                onClick={() => setPage(page - 1)}
              >
                上一页
              </Button>
              <span className="px-3 py-1 text-sm text-gray-500">
                {page} / {totalPages}
              </span>
              <Button
                variant="outline"
                size="sm"
                disabled={page === totalPages}
                onClick={() => setPage(page + 1)}
              >
                下一页
              </Button>
            </div>
          </div>
        )}
      </div>

      {/* 详情弹窗 */}
      <Dialog open={showDetail} onOpenChange={setShowDetail}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle>提现详情</DialogTitle>
          </DialogHeader>
          {selectedWithdrawal && (
            <div className="space-y-4 py-4">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <div className="text-xs text-gray-500">用户昵称</div>
                  <div className="font-medium">{selectedWithdrawal.users?.nickname || '-'}</div>
                </div>
                <div>
                  <div className="text-xs text-gray-500">手机号</div>
                  <div className="font-medium">{selectedWithdrawal.users?.phone || '-'}</div>
                </div>
                <div>
                  <div className="text-xs text-gray-500">提现金额</div>
                  <div className="font-medium text-orange-600">{formatAmount(selectedWithdrawal.amount)}</div>
                </div>
                <div>
                  <div className="text-xs text-gray-500">状态</div>
                  <div>{getStatusBadge(selectedWithdrawal.status)}</div>
                </div>
                <div className="col-span-2">
                  <div className="text-xs text-gray-500">申请时间</div>
                  <div className="font-medium">{new Date(selectedWithdrawal.created_at).toLocaleString()}</div>
                </div>
                <div className="col-span-2">
                  <div className="text-xs text-gray-500">备注</div>
                  <div className="font-medium">{selectedWithdrawal.description || '-'}</div>
                </div>
              </div>
            </div>
          )}
          <DialogFooter>
            <Button variant="outline" onClick={() => setShowDetail(false)}>
              关闭
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* 拒绝弹窗 */}
      <Dialog open={showReject} onOpenChange={setShowReject}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle>拒绝提现</DialogTitle>
          </DialogHeader>
          <div className="space-y-4 py-4">
            <div className="text-sm text-gray-500">
              请填写拒绝原因，拒绝后金额将退回用户余额
            </div>
            <textarea
              value={rejectReason}
              onChange={(e: ChangeEvent<HTMLTextAreaElement>) => setRejectReason(e.target.value)}
              placeholder="请输入拒绝原因"
              className="w-full px-3 py-2 border rounded-md min-h-[100px]"
            />
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setShowReject(false)}>
              取消
            </Button>
            <Button variant="destructive" onClick={handleReject}>
              确认拒绝
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  )
}
