import { useState, useEffect, ChangeEvent } from 'react'
import { Plus, Edit, Trash2, RefreshCw, Gift, Package, Star, Loader2 } from 'lucide-react'
import { pointsProductApi } from '@/lib/api'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from '@/components/ui/dialog'

interface Product {
  id: string
  name: string
  description: string
  image_url: string
  points_price: number
  original_price: number
  stock: number
  total_count: number
  exchange_count: number
  category: string
  region: string | null
  is_active: boolean
  sort_order: number
  created_at: string
}

interface ProductsResponse {
  products: Product[]
  total: number
}

const categories = [
  { key: 'coupon', name: '优惠券' },
  { key: 'virtual', name: '虚拟商品' },
  { key: 'ticket', name: '票券' },
  { key: 'physical', name: '实物商品' },
  { key: 'other', name: '其他' },
]

export default function PointsProductsPage() {
  const [products, setProducts] = useState<Product[]>([])
  const [total, setTotal] = useState(0)
  const [page, setPage] = useState(1)
  const [pageSize] = useState(20)
  const [loading, setLoading] = useState(false)
  const [showCreate, setShowCreate] = useState(false)
  const [showEdit, setShowEdit] = useState(false)
  const [selectedProduct, setSelectedProduct] = useState<Product | null>(null)
  const [submitting, setSubmitting] = useState(false)
  const [formData, setFormData] = useState({
    name: '',
    description: '',
    image_url: '',
    points_price: 0,
    original_price: 0,
    stock: 0,
    category: 'other',
    region: '',
    sort_order: 0,
  })

  useEffect(() => {
    fetchProducts()
  }, [page])

  const fetchProducts = async () => {
    setLoading(true)
    try {
      const res = await pointsProductApi.getList({
        page,
        pageSize,
      }) as { data: ProductsResponse }
      setProducts(res.data.products || [])
      setTotal(res.data.total || 0)
    } catch (error) {
      console.error('获取商品列表失败:', error)
    } finally {
      setLoading(false)
    }
  }

  const handleCreate = async () => {
    if (!formData.name.trim() || formData.points_price <= 0) {
      alert('请填写商品名称和积分价格')
      return
    }

    setSubmitting(true)
    try {
      const res = await pointsProductApi.create({
        name: formData.name,
        description: formData.description,
        image_url: formData.image_url || undefined,
        points_price: formData.points_price,
        original_price: formData.original_price || undefined,
        stock: formData.stock,
        total_count: formData.stock,
        category: formData.category,
        region: formData.region || undefined,
        sort_order: formData.sort_order,
      })
      const responseData = res as unknown as { msg: string }
      alert(responseData.msg)
      setShowCreate(false)
      resetForm()
      fetchProducts()
    } catch (error) {
      console.error('创建失败:', error)
      alert('创建失败')
    } finally {
      setSubmitting(false)
    }
  }

  const handleEdit = async () => {
    if (!selectedProduct || !formData.name.trim()) {
      alert('请填写商品名称')
      return
    }

    setSubmitting(true)
    try {
      const res = await pointsProductApi.update(selectedProduct.id, {
        name: formData.name,
        description: formData.description,
        image_url: formData.image_url || undefined,
        points_price: formData.points_price,
        original_price: formData.original_price || undefined,
        stock: formData.stock,
        category: formData.category,
        region: formData.region || undefined,
        sort_order: formData.sort_order,
      })
      const responseData = res as unknown as { msg: string }
      alert(responseData.msg)
      setShowEdit(false)
      setSelectedProduct(null)
      resetForm()
      fetchProducts()
    } catch (error) {
      console.error('更新失败:', error)
      alert('更新失败')
    } finally {
      setSubmitting(false)
    }
  }

  const handleDelete = async (productId: string) => {
    if (!confirm('确定要删除该商品吗？')) return

    try {
      const res = await pointsProductApi.delete(productId)
      const responseData = res as unknown as { msg: string }
      alert(responseData.msg)
      fetchProducts()
    } catch (error) {
      console.error('删除失败:', error)
    }
  }

  const handleToggleStatus = async (product: Product) => {
    try {
      const res = await pointsProductApi.updateStatus(product.id, !product.is_active)
      const responseData = res as unknown as { msg: string }
      alert(responseData.msg)
      fetchProducts()
    } catch (error) {
      console.error('更新状态失败:', error)
    }
  }

  const openEditDialog = (product: Product) => {
    setSelectedProduct(product)
    setFormData({
      name: product.name,
      description: product.description || '',
      image_url: product.image_url || '',
      points_price: product.points_price,
      original_price: Number(product.original_price) || 0,
      stock: product.stock,
      category: product.category || 'other',
      region: product.region || '',
      sort_order: product.sort_order || 0,
    })
    setShowEdit(true)
  }

  const resetForm = () => {
    setFormData({
      name: '',
      description: '',
      image_url: '',
      points_price: 0,
      original_price: 0,
      stock: 0,
      category: 'other',
      region: '',
      sort_order: 0,
    })
  }

  const getCategoryName = (key: string) => {
    return categories.find(c => c.key === key)?.name || key
  }

  const totalPages = Math.ceil(total / pageSize)

  return (
    <div className="space-y-6">
      {/* 页面标题 */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-gray-900">积分商品管理</h1>
          <p className="text-gray-500 mt-1">管理积分商城的商品</p>
        </div>
        <div className="flex gap-2">
          <Button variant="outline" onClick={fetchProducts}>
            <RefreshCw className="w-4 h-4 mr-2" />
            刷新
          </Button>
          <Button onClick={() => { resetForm(); setShowCreate(true) }}>
            <Plus className="w-4 h-4 mr-2" />
            新增商品
          </Button>
        </div>
      </div>

      {/* 统计卡片 */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <div className="bg-white rounded-lg shadow p-6">
          <div className="flex items-center">
            <div className="p-2 bg-purple-100 rounded-lg">
              <Gift className="w-6 h-6 text-purple-600" />
            </div>
            <div className="ml-4">
              <p className="text-sm text-gray-500">商品总数</p>
              <p className="text-2xl font-bold text-gray-900">{total}</p>
            </div>
          </div>
        </div>
        <div className="bg-white rounded-lg shadow p-6">
          <div className="flex items-center">
            <div className="p-2 bg-green-100 rounded-lg">
              <Package className="w-6 h-6 text-green-600" />
            </div>
            <div className="ml-4">
              <p className="text-sm text-gray-500">上架商品</p>
              <p className="text-2xl font-bold text-gray-900">
                {products.filter(p => p.is_active).length}
              </p>
            </div>
          </div>
        </div>
        <div className="bg-white rounded-lg shadow p-6">
          <div className="flex items-center">
            <div className="p-2 bg-blue-100 rounded-lg">
              <Star className="w-6 h-6 text-blue-600" />
            </div>
            <div className="ml-4">
              <p className="text-sm text-gray-500">总兑换次数</p>
              <p className="text-2xl font-bold text-gray-900">
                {products.reduce((sum, p) => sum + p.exchange_count, 0)}
              </p>
            </div>
          </div>
        </div>
        <div className="bg-white rounded-lg shadow p-6">
          <div className="flex items-center">
            <div className="p-2 bg-orange-100 rounded-lg">
              <Package className="w-6 h-6 text-orange-600" />
            </div>
            <div className="ml-4">
              <p className="text-sm text-gray-500">低库存商品</p>
              <p className="text-2xl font-bold text-gray-900">
                {products.filter(p => p.stock > 0 && p.stock <= 10).length}
              </p>
            </div>
          </div>
        </div>
      </div>

      {/* 商品列表 */}
      <div className="bg-white rounded-lg shadow overflow-hidden">
        <table className="min-w-full divide-y divide-gray-200">
          <thead className="bg-gray-50">
            <tr>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">商品</th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">分类</th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">积分</th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">库存</th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">兑换</th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">状态</th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">操作</th>
            </tr>
          </thead>
          <tbody className="bg-white divide-y divide-gray-200">
            {loading ? (
              <tr>
                <td colSpan={7} className="px-6 py-12 text-center text-gray-500">
                  加载中...
                </td>
              </tr>
            ) : products.length === 0 ? (
              <tr>
                <td colSpan={7} className="px-6 py-12 text-center text-gray-500">
                  暂无商品
                </td>
              </tr>
            ) : (
              products.map((p) => (
                <tr key={p.id} className="hover:bg-gray-50">
                  <td className="px-6 py-4 whitespace-nowrap">
                    <div className="flex items-center">
                      <div className="w-10 h-10 bg-gray-100 rounded-lg flex items-center justify-center mr-3">
                        {p.image_url ? (
                          <img src={p.image_url} alt="" className="w-10 h-10 rounded-lg object-cover" />
                        ) : (
                          <Gift className="w-5 h-5 text-gray-400" />
                        )}
                      </div>
                      <div>
                        <div className="text-sm font-medium text-gray-900">{p.name}</div>
                        <div className="text-xs text-gray-500 truncate max-w-[200px]">{p.description}</div>
                      </div>
                    </div>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <span className="px-2 py-1 rounded-full text-xs bg-purple-100 text-purple-800">
                      {getCategoryName(p.category)}
                    </span>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <div className="text-sm font-medium text-orange-600">{p.points_price} 积分</div>
                    {p.original_price && (
                      <div className="text-xs text-gray-400 line-through">¥{p.original_price}</div>
                    )}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <span className={`text-sm ${p.stock <= 10 ? 'text-red-600 font-medium' : 'text-gray-500'}`}>
                      {p.stock}
                    </span>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                    {p.exchange_count}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <button
                      onClick={() => handleToggleStatus(p)}
                      className={`px-2 py-1 rounded-full text-xs cursor-pointer ${
                        p.is_active
                          ? 'bg-green-100 text-green-800'
                          : 'bg-gray-100 text-gray-600'
                      }`}
                    >
                      {p.is_active ? '上架' : '下架'}
                    </button>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm">
                    <div className="flex items-center gap-2">
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => openEditDialog(p)}
                      >
                        <Edit className="w-4 h-4 mr-1" />
                        编辑
                      </Button>
                      <Button
                        variant="ghost"
                        size="sm"
                        className="text-red-600 hover:text-red-700"
                        onClick={() => handleDelete(p.id)}
                      >
                        <Trash2 className="w-4 h-4 mr-1" />
                        删除
                      </Button>
                    </div>
                  </td>
                </tr>
              ))
            )}
          </tbody>
        </table>

        {/* 分页 */}
        {totalPages > 1 && (
          <div className="bg-white px-4 py-3 flex items-center justify-between border-t">
            <div className="text-sm text-gray-500">共 {total} 条记录</div>
            <div className="flex gap-2">
              <Button
                variant="outline"
                size="sm"
                disabled={page === 1}
                onClick={() => setPage(page - 1)}
              >
                上一页
              </Button>
              <span className="px-3 py-1 text-sm text-gray-500">
                {page} / {totalPages}
              </span>
              <Button
                variant="outline"
                size="sm"
                disabled={page === totalPages}
                onClick={() => setPage(page + 1)}
              >
                下一页
              </Button>
            </div>
          </div>
        )}
      </div>

      {/* 新增/编辑弹窗 */}
      <Dialog open={showCreate || showEdit} onOpenChange={() => { setShowCreate(false); setShowEdit(false) }}>
        <DialogContent className="max-w-lg">
          <DialogHeader>
            <DialogTitle>{showCreate ? '新增商品' : '编辑商品'}</DialogTitle>
          </DialogHeader>
          <div className="space-y-4 py-4">
            <div>
              <label className="text-sm font-medium text-gray-700">商品名称 *</label>
              <Input
                value={formData.name}
                onChange={(e: ChangeEvent<HTMLInputElement>) => setFormData({ ...formData, name: e.target.value })}
                placeholder="请输入商品名称"
                className="mt-1"
              />
            </div>
            <div>
              <label className="text-sm font-medium text-gray-700">商品描述</label>
              <Input
                value={formData.description}
                onChange={(e: ChangeEvent<HTMLInputElement>) => setFormData({ ...formData, description: e.target.value })}
                placeholder="请输入商品描述"
                className="mt-1"
              />
            </div>
            <div>
              <label className="text-sm font-medium text-gray-700">图片URL</label>
              <Input
                value={formData.image_url}
                onChange={(e: ChangeEvent<HTMLInputElement>) => setFormData({ ...formData, image_url: e.target.value })}
                placeholder="https://..."
                className="mt-1"
              />
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="text-sm font-medium text-gray-700">积分价格 *</label>
                <Input
                  type="number"
                  value={formData.points_price}
                  onChange={(e: ChangeEvent<HTMLInputElement>) => setFormData({ ...formData, points_price: Number(e.target.value) })}
                  placeholder="积分"
                  className="mt-1"
                />
              </div>
              <div>
                <label className="text-sm font-medium text-gray-700">原价(元)</label>
                <Input
                  type="number"
                  value={formData.original_price}
                  onChange={(e: ChangeEvent<HTMLInputElement>) => setFormData({ ...formData, original_price: Number(e.target.value) })}
                  placeholder="元"
                  className="mt-1"
                />
              </div>
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="text-sm font-medium text-gray-700">库存</label>
                <Input
                  type="number"
                  value={formData.stock}
                  onChange={(e: ChangeEvent<HTMLInputElement>) => setFormData({ ...formData, stock: Number(e.target.value) })}
                  placeholder="库存数量"
                  className="mt-1"
                />
              </div>
              <div>
                <label className="text-sm font-medium text-gray-700">分类</label>
                <select
                  value={formData.category}
                  onChange={(e) => setFormData({ ...formData, category: e.target.value })}
                  className="w-full mt-1 px-3 py-2 border rounded-md"
                >
                  {categories.map(cat => (
                    <option key={cat.key} value={cat.key}>{cat.name}</option>
                  ))}
                </select>
              </div>
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="text-sm font-medium text-gray-700">区域限制</label>
                <select
                  value={formData.region}
                  onChange={(e) => setFormData({ ...formData, region: e.target.value })}
                  className="w-full mt-1 px-3 py-2 border rounded-md"
                >
                  <option value="">不限区域</option>
                  <option value="island_inside">仅岛内</option>
                  <option value="island_outside">仅岛外</option>
                </select>
              </div>
              <div>
                <label className="text-sm font-medium text-gray-700">排序</label>
                <Input
                  type="number"
                  value={formData.sort_order}
                  onChange={(e: ChangeEvent<HTMLInputElement>) => setFormData({ ...formData, sort_order: Number(e.target.value) })}
                  placeholder="数字越大越靠前"
                  className="mt-1"
                />
              </div>
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => { setShowCreate(false); setShowEdit(false) }} disabled={submitting}>
              取消
            </Button>
            <Button onClick={showCreate ? handleCreate : handleEdit} disabled={submitting}>
              {submitting && <Loader2 size={16} className="mr-1 animate-spin" />}
              {showCreate ? '创建' : '保存'}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  )
}
