import { useState, useEffect } from 'react'
import { categoryApi } from '@/lib/api'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Badge } from '@/components/ui/badge'
import { 
  Layers, Plus, Edit, Trash2, Loader2, GripVertical, 
  Image, Save, X
} from 'lucide-react'

interface Category {
  id: number
  name: string
  icon: string
  image_url: string
  sort_order: number
  is_active: boolean
  created_at: string
}

export default function CategoriesPage() {
  const [categories, setCategories] = useState<Category[]>([])
  const [loading, setLoading] = useState(true)
  const [saving, setSaving] = useState(false)
  const [showForm, setShowForm] = useState(false)
  const [editingCategory, setEditingCategory] = useState<Category | null>(null)
  const [formData, setFormData] = useState({
    name: '',
    icon: '',
    image_url: '',
    sort_order: 0,
    is_active: true,
  })

  useEffect(() => {
    fetchCategories()
  }, [])

  const fetchCategories = async () => {
    setLoading(true)
    try {
      const res: any = await categoryApi.getList()
      if (res.code === 200) {
        setCategories(res.data || [])
      }
    } catch (error) {
      console.error('Fetch categories error:', error)
    } finally {
      setLoading(false)
    }
  }

  const handleSubmit = async () => {
    if (!formData.name) {
      alert('请输入分类名称')
      return
    }

    setSaving(true)
    try {
      let res: any
      if (editingCategory) {
        res = await categoryApi.update(editingCategory.id, formData)
      } else {
        res = await categoryApi.create(formData)
      }

      if (res.code === 200) {
        setShowForm(false)
        setEditingCategory(null)
        setFormData({ name: '', icon: '', image_url: '', sort_order: 0, is_active: true })
        fetchCategories()
      } else {
        alert(res.msg || '操作失败')
      }
    } catch (error) {
      console.error('Save category error:', error)
      alert('操作失败')
    } finally {
      setSaving(false)
    }
  }

  const handleEdit = (category: Category) => {
    setEditingCategory(category)
    setFormData({
      name: category.name,
      icon: category.icon || '',
      image_url: category.image_url || '',
      sort_order: category.sort_order || 0,
      is_active: category.is_active,
    })
    setShowForm(true)
  }

  const handleDelete = async (categoryId: number) => {
    if (!confirm('确定要删除该分类吗？删除后无法恢复。')) {
      return
    }

    try {
      const res: any = await categoryApi.delete(categoryId)
      if (res.code === 200) {
        fetchCategories()
      } else {
        alert(res.msg || '删除失败')
      }
    } catch (error) {
      console.error('Delete category error:', error)
      alert('删除失败')
    }
  }

  const handleToggleActive = async (category: Category) => {
    try {
      const res: any = await categoryApi.update(category.id, { is_active: !category.is_active })
      if (res.code === 200) {
        fetchCategories()
      } else {
        alert(res.msg || '操作失败')
      }
    } catch (error) {
      console.error('Toggle active error:', error)
      alert('操作失败')
    }
  }

  const resetForm = () => {
    setShowForm(false)
    setEditingCategory(null)
    setFormData({ name: '', icon: '', image_url: '', sort_order: 0, is_active: true })
  }

  return (
    <div className="space-y-6">
      {/* 创建/编辑表单 */}
      {showForm && (
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center justify-between">
              <span>{editingCategory ? '编辑分类' : '创建分类'}</span>
              <Button variant="ghost" size="sm" onClick={resetForm}>
                <X size={16} />
              </Button>
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-medium text-stone-700 mb-1">分类名称 *</label>
                <Input
                  value={formData.name}
                  onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                  placeholder="如：美食、娱乐"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-stone-700 mb-1">图标名称</label>
                <Input
                  value={formData.icon}
                  onChange={(e) => setFormData({ ...formData, icon: e.target.value })}
                  placeholder="lucide图标名，如：Utensils"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-stone-700 mb-1">图片URL</label>
                <Input
                  value={formData.image_url}
                  onChange={(e) => setFormData({ ...formData, image_url: e.target.value })}
                  placeholder="分类图片地址"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-stone-700 mb-1">排序</label>
                <Input
                  type="number"
                  value={formData.sort_order}
                  onChange={(e) => setFormData({ ...formData, sort_order: parseInt(e.target.value) || 0 })}
                  placeholder="数字越小越靠前"
                />
              </div>
              <div className="md:col-span-2">
                <label className="flex items-center gap-2 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={formData.is_active}
                    onChange={(e) => setFormData({ ...formData, is_active: e.target.checked })}
                    className="w-4 h-4 rounded border-stone-300"
                  />
                  <span className="text-sm text-stone-700">启用该分类</span>
                </label>
              </div>
            </div>
            <div className="flex justify-end gap-3 mt-6">
              <Button variant="outline" onClick={resetForm}>
                取消
              </Button>
              <Button onClick={handleSubmit} disabled={saving}>
                {saving ? (
                  <>
                    <Loader2 className="h-4 w-4 animate-spin mr-2" />
                    保存中...
                  </>
                ) : (
                  <>
                    <Save size={16} className="mr-2" />
                    保存
                  </>
                )}
              </Button>
            </div>
          </CardContent>
        </Card>
      )}

      <Card>
        <CardHeader>
          <div className="flex items-center justify-between">
            <CardTitle className="flex items-center gap-2">
              <Layers size={20} color="#14B8A6" />
              分类管理
            </CardTitle>
            <Button onClick={() => setShowForm(!showForm)}>
              <Plus size={16} className="mr-1" />
              创建分类
            </Button>
          </div>
        </CardHeader>
        <CardContent>
          {loading ? (
            <div className="flex items-center justify-center h-64">
              <Loader2 className="h-6 w-6 animate-spin text-teal-500" />
            </div>
          ) : (
            <div className="space-y-3">
              {categories.map((category) => (
                <div
                  key={category.id}
                  className="flex items-center gap-4 p-4 bg-stone-50 rounded-lg hover:bg-stone-100 transition-colors"
                >
                  {/* 排序标识 */}
                  <div className="text-stone-400">
                    <GripVertical size={20} />
                  </div>

                  {/* 图标/图片 */}
                  <div className="w-12 h-12 rounded-lg bg-white border border-stone-200 flex items-center justify-center overflow-hidden">
                    {category.image_url ? (
                      <img src={category.image_url} alt={category.name} className="w-full h-full object-cover" />
                    ) : (
                      <Image size={24} className="text-stone-300" />
                    )}
                  </div>

                  {/* 分类信息 */}
                  <div className="flex-1">
                    <div className="font-medium text-stone-800">{category.name}</div>
                    <div className="text-xs text-stone-400">
                      排序: {category.sort_order} · ID: {category.id}
                    </div>
                  </div>

                  {/* 状态 */}
                  <Badge className={category.is_active ? 'bg-emerald-50 text-emerald-700' : 'bg-stone-100 text-stone-500'}>
                    {category.is_active ? '启用' : '禁用'}
                  </Badge>

                  {/* 操作按钮 */}
                  <div className="flex items-center gap-2">
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => handleToggleActive(category)}
                    >
                      {category.is_active ? '禁用' : '启用'}
                    </Button>
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => handleEdit(category)}
                    >
                      <Edit size={14} />
                    </Button>
                    <Button
                      variant="outline"
                      size="sm"
                      className="text-rose-600 hover:text-rose-700"
                      onClick={() => handleDelete(category.id)}
                    >
                      <Trash2 size={14} />
                    </Button>
                  </div>
                </div>
              ))}

              {categories.length === 0 && (
                <div className="py-12 text-center text-stone-400">
                  暂无分类，点击上方按钮创建
                </div>
              )}
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  )
}
