import { useState, useEffect, ChangeEvent } from 'react'
import { Search, Send, Bell, Megaphone, RefreshCw, Plus } from 'lucide-react'
import { messageApi, userApi } from '@/lib/api'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from '@/components/ui/dialog'

interface Message {
  id: string
  user_id: string
  type: string
  title: string
  content: string
  status: string
  created_at: string
}

interface User {
  id: string
  nickname: string
  phone: string
  avatar_url: string
}

interface MessagesResponse {
  messages: Message[]
  total: number
}

interface UsersResponse {
  users: User[]
  total: number
}

export default function MessagesPage() {
  const [messages, setMessages] = useState<Message[]>([])
  const [total, setTotal] = useState(0)
  const [page, setPage] = useState(1)
  const [pageSize] = useState(20)
  const [typeFilter, setTypeFilter] = useState('')
  const [loading, setLoading] = useState(false)
  const [showSendDialog, setShowSendDialog] = useState(false)
  const [sendType, setSendType] = useState<'all' | 'selected'>('all')
  const [messageForm, setMessageForm] = useState({
    type: 'system',
    title: '',
    content: '',
  })
  const [userKeyword, setUserKeyword] = useState('')
  const [userList, setUserList] = useState<User[]>([])
  const [selectedUsers, setSelectedUsers] = useState<string[]>([])
  const [sending, setSending] = useState(false)

  useEffect(() => {
    fetchMessages()
  }, [page, typeFilter])

  const fetchMessages = async () => {
    setLoading(true)
    try {
      const res = await messageApi.getList({
        page,
        pageSize,
        type: typeFilter || undefined,
      }) as { data: MessagesResponse }
      setMessages(res.data.messages || [])
      setTotal(res.data.total || 0)
    } catch (error) {
      console.error('获取消息列表失败:', error)
    } finally {
      setLoading(false)
    }
  }

  const fetchUsers = async () => {
    try {
      const res = await userApi.getList({
        page: 1,
        pageSize: 50,
        keyword: userKeyword || undefined,
        status: 'active',
      }) as { data: UsersResponse }
      setUserList(res.data.users || [])
    } catch (error) {
      console.error('获取用户列表失败:', error)
    }
  }

  const handleOpenSendDialog = () => {
    setShowSendDialog(true)
    fetchUsers()
  }

  const handleSend = async () => {
    if (!messageForm.title.trim() || !messageForm.content.trim()) {
      alert('请填写标题和内容')
      return
    }

    if (sendType === 'selected' && selectedUsers.length === 0) {
      alert('请选择接收用户')
      return
    }

    setSending(true)
    try {
      const res = sendType === 'all' 
        ? await messageApi.sendToAll(messageForm)
        : await messageApi.sendToUsers({
            userIds: selectedUsers,
            ...messageForm,
          })
      const responseData = res as unknown as { msg: string }
      alert(responseData.msg)
      setShowSendDialog(false)
      setMessageForm({ type: 'system', title: '', content: '' })
      setSelectedUsers([])
      fetchMessages()
    } catch (error) {
      console.error('发送失败:', error)
      alert('发送失败')
    } finally {
      setSending(false)
    }
  }

  const toggleUserSelection = (userId: string) => {
    setSelectedUsers((prev) =>
      prev.includes(userId) ? prev.filter((id) => id !== userId) : [...prev, userId]
    )
  }

  const getTypeBadge = (type: string) => {
    const styles: Record<string, string> = {
      system: 'bg-blue-100 text-blue-800',
      promotion: 'bg-orange-100 text-orange-800',
      order: 'bg-green-100 text-green-800',
    }
    const labels: Record<string, string> = {
      system: '系统消息',
      promotion: '营销推送',
      order: '订单通知',
    }
    return (
      <span className={`px-2 py-1 rounded-full text-xs ${styles[type] || 'bg-gray-100 text-gray-800'}`}>
        {labels[type] || type}
      </span>
    )
  }

  const totalPages = Math.ceil(total / pageSize)

  return (
    <div className="space-y-6">
      {/* 页面标题 */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-gray-900">消息推送</h1>
          <p className="text-gray-500 mt-1">发送系统消息和营销推送</p>
        </div>
        <div className="flex gap-2">
          <Button variant="outline" onClick={fetchMessages}>
            <RefreshCw className="w-4 h-4 mr-2" />
            刷新
          </Button>
          <Button onClick={handleOpenSendDialog}>
            <Plus className="w-4 h-4 mr-2" />
            发送消息
          </Button>
        </div>
      </div>

      {/* 统计卡片 */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <div className="bg-white rounded-lg shadow p-6">
          <div className="flex items-center">
            <div className="p-2 bg-blue-100 rounded-lg">
              <Bell className="w-6 h-6 text-blue-600" />
            </div>
            <div className="ml-4">
              <p className="text-sm text-gray-500">系统消息</p>
              <p className="text-2xl font-bold text-gray-900">
                {messages.filter((m) => m.type === 'system').length}
              </p>
            </div>
          </div>
        </div>
        <div className="bg-white rounded-lg shadow p-6">
          <div className="flex items-center">
            <div className="p-2 bg-orange-100 rounded-lg">
              <Megaphone className="w-6 h-6 text-orange-600" />
            </div>
            <div className="ml-4">
              <p className="text-sm text-gray-500">营销推送</p>
              <p className="text-2xl font-bold text-gray-900">
                {messages.filter((m) => m.type === 'promotion').length}
              </p>
            </div>
          </div>
        </div>
        <div className="bg-white rounded-lg shadow p-6">
          <div className="flex items-center">
            <div className="p-2 bg-green-100 rounded-lg">
              <Send className="w-6 h-6 text-green-600" />
            </div>
            <div className="ml-4">
              <p className="text-sm text-gray-500">今日发送</p>
              <p className="text-2xl font-bold text-gray-900">
                {messages.filter((m) => new Date(m.created_at).toDateString() === new Date().toDateString()).length}
              </p>
            </div>
          </div>
        </div>
      </div>

      {/* 筛选条件 */}
      <div className="bg-white rounded-lg shadow p-4">
        <div className="flex items-center gap-4">
          <select
            value={typeFilter}
            onChange={(e) => setTypeFilter(e.target.value)}
            className="px-3 py-2 border rounded-md"
          >
            <option value="">全部类型</option>
            <option value="system">系统消息</option>
            <option value="promotion">营销推送</option>
            <option value="order">订单通知</option>
          </select>
        </div>
      </div>

      {/* 消息列表 */}
      <div className="bg-white rounded-lg shadow overflow-hidden">
        <table className="min-w-full divide-y divide-gray-200">
          <thead className="bg-gray-50">
            <tr>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">类型</th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">标题</th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">内容</th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">状态</th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">发送时间</th>
            </tr>
          </thead>
          <tbody className="bg-white divide-y divide-gray-200">
            {loading ? (
              <tr>
                <td colSpan={5} className="px-6 py-12 text-center text-gray-500">
                  加载中...
                </td>
              </tr>
            ) : messages.length === 0 ? (
              <tr>
                <td colSpan={5} className="px-6 py-12 text-center text-gray-500">
                  暂无消息记录
                </td>
              </tr>
            ) : (
              messages.map((m) => (
                <tr key={m.id} className="hover:bg-gray-50">
                  <td className="px-6 py-4 whitespace-nowrap">{getTypeBadge(m.type)}</td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">
                    {m.title}
                  </td>
                  <td className="px-6 py-4 text-sm text-gray-500 max-w-[300px] truncate">
                    {m.content}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <span className={`px-2 py-1 rounded-full text-xs ${
                      m.status === 'unread' ? 'bg-red-100 text-red-800' : 'bg-gray-100 text-gray-800'
                    }`}>
                      {m.status === 'unread' ? '未读' : '已读'}
                    </span>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                    {new Date(m.created_at).toLocaleString()}
                  </td>
                </tr>
              ))
            )}
          </tbody>
        </table>

        {/* 分页 */}
        {totalPages > 1 && (
          <div className="bg-white px-4 py-3 flex items-center justify-between border-t">
            <div className="text-sm text-gray-500">共 {total} 条记录</div>
            <div className="flex gap-2">
              <Button
                variant="outline"
                size="sm"
                disabled={page === 1}
                onClick={() => setPage(page - 1)}
              >
                上一页
              </Button>
              <span className="px-3 py-1 text-sm text-gray-500">
                {page} / {totalPages}
              </span>
              <Button
                variant="outline"
                size="sm"
                disabled={page === totalPages}
                onClick={() => setPage(page + 1)}
              >
                下一页
              </Button>
            </div>
          </div>
        )}
      </div>

      {/* 发送消息弹窗 */}
      <Dialog open={showSendDialog} onOpenChange={setShowSendDialog}>
        <DialogContent className="max-w-lg">
          <DialogHeader>
            <DialogTitle>发送消息</DialogTitle>
          </DialogHeader>
          <div className="space-y-4 py-4">
            {/* 发送类型 */}
            <div className="space-y-2">
              <label className="text-sm font-medium text-gray-700">发送对象</label>
              <div className="flex gap-4">
                <label className="flex items-center">
                  <input
                    type="radio"
                    checked={sendType === 'all'}
                    onChange={() => setSendType('all')}
                    className="mr-2"
                  />
                  全部用户
                </label>
                <label className="flex items-center">
                  <input
                    type="radio"
                    checked={sendType === 'selected'}
                    onChange={() => setSendType('selected')}
                    className="mr-2"
                  />
                  指定用户
                </label>
              </div>
            </div>

            {/* 用户选择 */}
            {sendType === 'selected' && (
              <div className="space-y-2">
                <label className="text-sm font-medium text-gray-700">选择用户</label>
                <div className="flex gap-2 mb-2">
                  <Input
                    placeholder="搜索用户"
                    value={userKeyword}
                    onChange={(e: ChangeEvent<HTMLInputElement>) => setUserKeyword(e.target.value)}
                    className="flex-1"
                  />
                  <Button variant="outline" size="sm" onClick={fetchUsers}>
                    <Search className="w-4 h-4" />
                  </Button>
                </div>
                <div className="border rounded-md max-h-[200px] overflow-y-auto">
                  {userList.map((user) => (
                    <label
                      key={user.id}
                      className="flex items-center px-3 py-2 hover:bg-gray-50 cursor-pointer"
                    >
                      <input
                        type="checkbox"
                        checked={selectedUsers.includes(user.id)}
                        onChange={() => toggleUserSelection(user.id)}
                        className="mr-3"
                      />
                      <div className="w-6 h-6 bg-gray-200 rounded-full flex items-center justify-center mr-2">
                        {user.avatar_url ? (
                          <img src={user.avatar_url} alt="" className="w-6 h-6 rounded-full" />
                        ) : (
                          <span className="text-xs text-gray-500">{(user.nickname || '?')[0]}</span>
                        )}
                      </div>
                      <div>
                        <div className="text-sm">{user.nickname || '未知用户'}</div>
                        <div className="text-xs text-gray-500">{user.phone || '-'}</div>
                      </div>
                    </label>
                  ))}
                </div>
                {selectedUsers.length > 0 && (
                  <div className="text-sm text-gray-500">
                    已选择 {selectedUsers.length} 位用户
                  </div>
                )}
              </div>
            )}

            {/* 消息类型 */}
            <div className="space-y-2">
              <label className="text-sm font-medium text-gray-700">消息类型</label>
              <select
                value={messageForm.type}
                onChange={(e) => setMessageForm({ ...messageForm, type: e.target.value })}
                className="w-full px-3 py-2 border rounded-md"
              >
                <option value="system">系统消息</option>
                <option value="promotion">营销推送</option>
                <option value="order">订单通知</option>
              </select>
            </div>

            {/* 标题 */}
            <div className="space-y-2">
              <label className="text-sm font-medium text-gray-700">标题</label>
              <Input
                value={messageForm.title}
                onChange={(e) => setMessageForm({ ...messageForm, title: e.target.value })}
                placeholder="请输入消息标题"
              />
            </div>

            {/* 内容 */}
            <div className="space-y-2">
              <label className="text-sm font-medium text-gray-700">内容</label>
              <textarea
                value={messageForm.content}
                onChange={(e: ChangeEvent<HTMLTextAreaElement>) => setMessageForm({ ...messageForm, content: e.target.value })}
                placeholder="请输入消息内容"
                className="w-full px-3 py-2 border rounded-md min-h-[100px]"
              />
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setShowSendDialog(false)}>
              取消
            </Button>
            <Button onClick={handleSend} disabled={sending}>
              {sending ? '发送中...' : '发送'}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  )
}
