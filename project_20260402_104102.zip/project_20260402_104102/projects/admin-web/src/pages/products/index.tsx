import { useState, useEffect } from 'react'
import { productApi, merchantApi } from '@/lib/api'
import { formatDateTime, getStatusBadgeClass } from '@/lib/utils'
import { useAuthStore } from '@/stores/auth'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Badge } from '@/components/ui/badge'
import { Package, Search, Loader2, ChevronLeft, ChevronRight } from 'lucide-react'

interface Product {
  id: string
  name: string
  description: string
  price: string
  original_price: string
  image_url: string
  is_active: boolean
  sales_count: number
  stock: number
  created_at: string
  merchants: { name: string } | null
}

interface ProductListResponse {
  products: Product[]
  total: number
}

interface Merchant {
  id: string
  name: string
}

export default function ProductsPage() {
  const { admin } = useAuthStore()
  const [data, setData] = useState<ProductListResponse | null>(null)
  const [merchants, setMerchants] = useState<Merchant[]>([])
  const [loading, setLoading] = useState(true)
  const [page, setPage] = useState(1)
  const [keyword, setKeyword] = useState('')
  const [searchKeyword, setSearchKeyword] = useState('')
  const [statusFilter, setStatusFilter] = useState('')
  const [merchantFilter, setMerchantFilter] = useState('')
  const pageSize = 10

  useEffect(() => {
    fetchMerchants()
  }, [])

  useEffect(() => {
    fetchProducts()
  }, [page, searchKeyword, statusFilter, merchantFilter])

  const fetchMerchants = async () => {
    try {
      const res: any = await merchantApi.getList({ page: 1, pageSize: 100, status: 'active' })
      if (res.code === 200) {
        setMerchants(res.data.merchants || [])
      }
    } catch (error) {
      console.error('Fetch merchants error:', error)
    }
  }

  const fetchProducts = async () => {
    setLoading(true)
    try {
      const res: any = await productApi.getList({
        page,
        pageSize,
        keyword: searchKeyword || undefined,
        status: statusFilter || undefined,
        merchantId: merchantFilter || undefined,
      })

      if (res.code === 200) {
        setData(res.data)
      }
    } catch (error) {
      console.error('Fetch products error:', error)
    } finally {
      setLoading(false)
    }
  }

  const handleSearch = () => {
    setSearchKeyword(keyword)
    setPage(1)
  }

  const handleStatusChange = async (productId: string, isActive: boolean) => {
    if (!confirm(`确定要${isActive ? '上架' : '下架'}该商品吗？`)) {
      return
    }

    try {
      const res: any = await productApi.updateStatus(productId, isActive, admin?.id || '')
      if (res.code === 200) {
        fetchProducts()
      } else {
        alert(res.msg || '操作失败')
      }
    } catch (error) {
      console.error('Update status error:', error)
      alert('操作失败')
    }
  }

  const totalPages = Math.ceil((data?.total || 0) / pageSize)

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <div className="flex items-center justify-between flex-wrap gap-4">
            <CardTitle className="flex items-center gap-2">
              <Package size={20} color="#14B8A6" />
              商品列表
            </CardTitle>
            <div className="flex items-center gap-3 flex-wrap">
              <div className="flex items-center gap-2">
                <Input
                  className="w-48"
                  placeholder="搜索商品名称"
                  value={keyword}
                  onChange={(e) => setKeyword(e.target.value)}
                  onKeyDown={(e) => e.key === 'Enter' && handleSearch()}
                />
                <Button onClick={handleSearch}>
                  <Search size={16} className="mr-1" />
                  搜索
                </Button>
              </div>
              <select
                className="h-10 px-3 rounded-lg border border-stone-200 text-sm"
                value={statusFilter}
                onChange={(e) => {
                  setStatusFilter(e.target.value)
                  setPage(1)
                }}
              >
                <option value="">全部状态</option>
                <option value="active">上架中</option>
                <option value="inactive">已下架</option>
              </select>
              <select
                className="h-10 px-3 rounded-lg border border-stone-200 text-sm"
                value={merchantFilter}
                onChange={(e) => {
                  setMerchantFilter(e.target.value)
                  setPage(1)
                }}
              >
                <option value="">全部商家</option>
                {merchants.map((m) => (
                  <option key={m.id} value={m.id}>{m.name}</option>
                ))}
              </select>
            </div>
          </div>
        </CardHeader>
        <CardContent>
          {loading ? (
            <div className="flex items-center justify-center h-64">
              <Loader2 className="h-6 w-6 animate-spin text-teal-500" />
            </div>
          ) : (
            <>
              <div className="overflow-x-auto">
                <table className="w-full">
                  <thead>
                    <tr className="border-b border-stone-200">
                      <th className="text-left py-3 px-4 text-sm font-medium text-stone-500">商品信息</th>
                      <th className="text-left py-3 px-4 text-sm font-medium text-stone-500">商家</th>
                      <th className="text-left py-3 px-4 text-sm font-medium text-stone-500">价格</th>
                      <th className="text-left py-3 px-4 text-sm font-medium text-stone-500">库存/销量</th>
                      <th className="text-left py-3 px-4 text-sm font-medium text-stone-500">状态</th>
                      <th className="text-left py-3 px-4 text-sm font-medium text-stone-500">创建时间</th>
                      <th className="text-left py-3 px-4 text-sm font-medium text-stone-500">操作</th>
                    </tr>
                  </thead>
                  <tbody>
                    {data?.products.map((product) => (
                      <tr key={product.id} className="border-b border-stone-100 hover:bg-stone-50">
                        <td className="py-3 px-4">
                          <div className="flex items-center gap-3">
                            <div className="w-12 h-12 rounded-lg bg-stone-100 flex items-center justify-center overflow-hidden">
                              {product.image_url ? (
                                <img src={product.image_url} alt={product.name} className="w-full h-full object-cover" />
                              ) : (
                                <Package size={24} className="text-stone-300" />
                              )}
                            </div>
                            <div>
                              <div className="font-medium text-stone-800 line-clamp-1">{product.name}</div>
                              <div className="text-xs text-stone-400 line-clamp-1">{product.description || '-'}</div>
                            </div>
                          </div>
                        </td>
                        <td className="py-3 px-4 text-stone-600">
                          {product.merchants?.name || '-'}
                        </td>
                        <td className="py-3 px-4">
                          <div className="text-teal-600 font-semibold">¥{product.price}</div>
                          {product.original_price && parseFloat(product.original_price) > parseFloat(product.price) && (
                            <div className="text-xs text-stone-400 line-through">¥{product.original_price}</div>
                          )}
                        </td>
                        <td className="py-3 px-4 text-stone-600">
                          <div>库存: {product.stock ?? '-'}</div>
                          <div className="text-xs text-stone-400">销量: {product.sales_count || 0}</div>
                        </td>
                        <td className="py-3 px-4">
                          <Badge className={getStatusBadgeClass(product.is_active ? 'active' : 'inactive')}>
                            {product.is_active ? '上架中' : '已下架'}
                          </Badge>
                        </td>
                        <td className="py-3 px-4 text-stone-500 text-sm">
                          {formatDateTime(product.created_at)}
                        </td>
                        <td className="py-3 px-4">
                          <div className="flex items-center gap-2">
                            {product.is_active ? (
                              <Button
                                variant="outline"
                                size="sm"
                                className="text-rose-600 hover:text-rose-700"
                                onClick={() => handleStatusChange(product.id, false)}
                              >
                                下架
                              </Button>
                            ) : (
                              <Button
                                variant="outline"
                                size="sm"
                                className="text-emerald-600 hover:text-emerald-700"
                                onClick={() => handleStatusChange(product.id, true)}
                              >
                                上架
                              </Button>
                            )}
                          </div>
                        </td>
                      </tr>
                    ))}
                    {(!data?.products || data.products.length === 0) && (
                      <tr>
                        <td colSpan={7} className="py-12 text-center text-stone-400">
                          暂无数据
                        </td>
                      </tr>
                    )}
                  </tbody>
                </table>
              </div>

              {/* 分页 */}
              {totalPages > 1 && (
                <div className="flex items-center justify-between mt-4 pt-4 border-t border-stone-200">
                  <div className="text-sm text-stone-500">
                    共 {data?.total || 0} 条记录
                  </div>
                  <div className="flex items-center gap-2">
                    <Button
                      variant="outline"
                      size="sm"
                      disabled={page <= 1}
                      onClick={() => setPage(page - 1)}
                    >
                      <ChevronLeft size={16} />
                    </Button>
                    <span className="text-sm text-stone-600">
                      {page} / {totalPages}
                    </span>
                    <Button
                      variant="outline"
                      size="sm"
                      disabled={page >= totalPages}
                      onClick={() => setPage(page + 1)}
                    >
                      <ChevronRight size={16} />
                    </Button>
                  </div>
                </div>
              )}
            </>
          )}
        </CardContent>
      </Card>
    </div>
  )
}
