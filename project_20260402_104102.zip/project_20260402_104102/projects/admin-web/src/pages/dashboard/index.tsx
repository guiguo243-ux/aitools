import { useState, useEffect } from 'react'
import { Link } from 'react-router-dom'
import { dashboardApi } from '@/lib/api'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { 
  Users, 
  Store, 
  ShoppingCart, 
  Wallet, 
  TrendingUp, 
  AlertTriangle,
  ArrowRight,
  BarChart3,
  PieChart,
  Loader2
} from 'lucide-react'
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  PieChart as RechartsPie,
  Pie,
  Cell,
} from 'recharts'

interface Stats {
  totalUsers: number
  totalMerchants: number
  totalOrders: number
  todayOrders: number
  todayRevenue: string
  pendingMerchants: number
}

interface TrendData {
  date: string
  count: number
  revenue: number
}

interface StatusDistribution {
  status: string
  count: number
  label: string
}

const COLORS = ['#14B8A6', '#3b82f6', '#f59e0b', '#78716c']

export default function DashboardPage() {
  const [stats, setStats] = useState<Stats | null>(null)
  const [orderTrend, setOrderTrend] = useState<TrendData[]>([])
  const [statusDistribution, setStatusDistribution] = useState<StatusDistribution[]>([])
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    fetchData()
  }, [])

  const fetchData = async () => {
    setLoading(true)
    try {
      const [statsRes, trendRes, distRes]: any[] = await Promise.all([
        dashboardApi.getStats(),
        dashboardApi.getOrderTrend(7),
        dashboardApi.getOrderStatusDistribution(),
      ])

      if (statsRes.code === 200) {
        setStats(statsRes.data)
      }
      if (trendRes.code === 200) {
        setOrderTrend(trendRes.data || [])
      }
      if (distRes.code === 200) {
        setStatusDistribution(distRes.data || [])
      }
    } catch (error) {
      console.error('Fetch dashboard error:', error)
    } finally {
      setLoading(false)
    }
  }

  if (loading) {
    return (
      <div className="flex items-center justify-center h-96">
        <Loader2 className="h-8 w-8 animate-spin text-teal-500" />
      </div>
    )
  }

  return (
    <div className="space-y-6">
      {/* 统计卡片 */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <Card>
          <CardContent className="p-6">
            <div className="flex items-center gap-4">
              <div className="w-12 h-12 rounded-xl bg-teal-50 flex items-center justify-center">
                <Users size={24} color="#14B8A6" />
              </div>
              <div>
                <div className="text-sm text-stone-500">用户总数</div>
                <div className="text-2xl font-bold text-stone-800">{stats?.totalUsers || 0}</div>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center gap-4">
              <div className="w-12 h-12 rounded-xl bg-emerald-50 flex items-center justify-center">
                <Store size={24} color="#10b981" />
              </div>
              <div>
                <div className="text-sm text-stone-500">商家总数</div>
                <div className="text-2xl font-bold text-stone-800">{stats?.totalMerchants || 0}</div>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center gap-4">
              <div className="w-12 h-12 rounded-xl bg-blue-50 flex items-center justify-center">
                <ShoppingCart size={24} color="#3b82f6" />
              </div>
              <div>
                <div className="text-sm text-stone-500">订单总数</div>
                <div className="text-2xl font-bold text-stone-800">{stats?.totalOrders || 0}</div>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center gap-4">
              <div className="w-12 h-12 rounded-xl bg-amber-50 flex items-center justify-center">
                <Wallet size={24} color="#f59e0b" />
              </div>
              <div>
                <div className="text-sm text-stone-500">今日营收</div>
                <div className="text-2xl font-bold text-stone-800">¥{stats?.todayRevenue || '0'}</div>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* 今日订单 */}
      <Card className="bg-gradient-to-r from-teal-500 to-teal-600 border-0">
        <CardContent className="p-6">
          <div className="flex items-center justify-between text-white">
            <div>
              <div className="text-teal-100 text-sm">今日订单</div>
              <div className="text-4xl font-bold mt-1">{stats?.todayOrders || 0}</div>
            </div>
            <TrendingUp size={56} className="text-white/30" />
          </div>
        </CardContent>
      </Card>

      {/* 待处理事项 */}
      {stats?.pendingMerchants && stats.pendingMerchants > 0 && (
        <Card className="border-amber-200 bg-amber-50">
          <CardContent className="p-4">
            <div className="flex items-center gap-4">
              <AlertTriangle size={24} color="#f59e0b" />
              <div className="flex-1">
                <div className="font-semibold text-amber-800">待审核商家</div>
                <div className="text-amber-600 text-sm">
                  有 {stats.pendingMerchants} 个商家等待审核
                </div>
              </div>
              <Link
                to="/merchants?status=pending"
                className="flex items-center gap-1 text-amber-600 hover:text-amber-700"
              >
                去处理 <ArrowRight size={16} />
              </Link>
            </div>
          </CardContent>
        </Card>
      )}

      {/* 图表 */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* 订单趋势 */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-base">
              <BarChart3 size={18} color="#14B8A6" />
              近7天订单趋势
            </CardTitle>
          </CardHeader>
          <CardContent>
            {orderTrend.length > 0 ? (
              <ResponsiveContainer width="100%" height={240}>
                <BarChart data={orderTrend}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#e7e5e4" />
                  <XAxis 
                    dataKey="date" 
                    tick={{ fontSize: 12 }} 
                    tickFormatter={(v) => v.slice(5)}
                  />
                  <YAxis tick={{ fontSize: 12 }} />
                  <Tooltip 
                    contentStyle={{ borderRadius: 8, border: '1px solid #e7e5e4' }}
                  />
                  <Bar dataKey="count" fill="#14B8A6" radius={[4, 4, 0, 0]} />
                </BarChart>
              </ResponsiveContainer>
            ) : (
              <div className="h-60 flex items-center justify-center text-stone-400">
                暂无数据
              </div>
            )}
          </CardContent>
        </Card>

        {/* 订单状态分布 */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-base">
              <PieChart size={18} color="#8b5cf6" />
              订单状态分布
            </CardTitle>
          </CardHeader>
          <CardContent>
            {statusDistribution.length > 0 ? (
              <div className="flex items-center gap-8">
                <ResponsiveContainer width={160} height={160}>
                  <RechartsPie>
                    <Pie
                      data={statusDistribution}
                      dataKey="count"
                      nameKey="label"
                      cx="50%"
                      cy="50%"
                      innerRadius={40}
                      outerRadius={70}
                      paddingAngle={2}
                    >
                      {statusDistribution.map((_, index) => (
                        <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                      ))}
                    </Pie>
                  </RechartsPie>
                </ResponsiveContainer>
                <div className="flex-1 space-y-2">
                  {statusDistribution.map((item, index) => {
                    const total = statusDistribution.reduce((s, d) => s + d.count, 0)
                    const percent = total > 0 ? ((item.count / total) * 100).toFixed(1) : '0'
                    return (
                      <div key={item.status} className="flex items-center gap-3">
                        <div
                          className="w-3 h-3 rounded-sm"
                          style={{ backgroundColor: COLORS[index % COLORS.length] }}
                        />
                        <span className="text-sm text-stone-600 flex-1">{item.label}</span>
                        <span className="text-sm text-stone-500">{item.count}</span>
                        <span className="text-xs text-stone-400 w-12 text-right">{percent}%</span>
                      </div>
                    )
                  })}
                </div>
              </div>
            ) : (
              <div className="h-40 flex items-center justify-center text-stone-400">
                暂无数据
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
