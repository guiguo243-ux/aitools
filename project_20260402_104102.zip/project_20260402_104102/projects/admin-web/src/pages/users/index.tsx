import { useState, useEffect } from 'react'
import { userApi, exportApi } from '@/lib/api'
import { formatDateTime, getStatusBadgeClass, getStatusText } from '@/lib/utils'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Badge } from '@/components/ui/badge'
import { Users, Search, Loader2, ChevronLeft, ChevronRight, Eye, Download } from 'lucide-react'
import { UserDetailModal } from '@/components/UserDetailModal'

interface User {
  id: string
  nickname: string
  phone: string
  avatar: string
  region: string
  status: string
  created_at: string
}

interface UserListResponse {
  users: User[]
  total: number
}

export default function UsersPage() {
  const [data, setData] = useState<UserListResponse | null>(null)
  const [loading, setLoading] = useState(true)
  const [page, setPage] = useState(1)
  const [keyword, setKeyword] = useState('')
  const [searchKeyword, setSearchKeyword] = useState('')
  const [statusFilter, setStatusFilter] = useState('')
  const [selectedUserId, setSelectedUserId] = useState<string | null>(null)
  const [showDetail, setShowDetail] = useState(false)
  const [exporting, setExporting] = useState(false)
  const pageSize = 10

  useEffect(() => {
    fetchUsers()
  }, [page, searchKeyword, statusFilter])

  const fetchUsers = async () => {
    setLoading(true)
    try {
      const res: any = await userApi.getList({
        page,
        pageSize,
        keyword: searchKeyword || undefined,
        status: statusFilter || undefined,
      })

      if (res.code === 200) {
        setData(res.data)
      }
    } catch (error) {
      console.error('Fetch users error:', error)
    } finally {
      setLoading(false)
    }
  }

  const handleExport = async () => {
    setExporting(true)
    try {
      const res: any = await exportApi.users({
        status: statusFilter || undefined,
      })
      if (res.code === 200 && res.data?.data) {
        // 转换为CSV并下载
        const csvContent = [
          Object.keys(res.data.data[0] || {}).join(','),
          ...res.data.data.map((row: any) => Object.values(row).join(','))
        ].join('\n')
        
        const blob = new Blob(['\ufeff' + csvContent], { type: 'text/csv;charset=utf-8;' })
        const link = document.createElement('a')
        link.href = URL.createObjectURL(blob)
        link.download = `用户数据_${new Date().toISOString().split('T')[0]}.csv`
        link.click()
      }
    } catch (error) {
      console.error('Export error:', error)
      alert('导出失败')
    } finally {
      setExporting(false)
    }
  }

  const handleSearch = () => {
    setSearchKeyword(keyword)
    setPage(1)
  }

  const handleStatusChange = async (userId: string, status: string) => {
    if (!confirm(`确定要${status === 'active' ? '启用' : '禁用'}该用户吗？`)) {
      return
    }

    try {
      const res: any = await userApi.updateStatus(userId, status)
      if (res.code === 200) {
        fetchUsers()
      } else {
        alert(res.msg || '操作失败')
      }
    } catch (error) {
      console.error('Update status error:', error)
      alert('操作失败')
    }
  }

  const totalPages = Math.ceil((data?.total || 0) / pageSize)

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <div className="flex items-center justify-between flex-wrap gap-4">
            <CardTitle className="flex items-center gap-2">
              <Users size={20} color="#14B8A6" />
              用户列表
            </CardTitle>
            <div className="flex items-center gap-3 flex-wrap">
              <div className="flex items-center gap-2">
                <Input
                  className="w-48"
                  placeholder="搜索用户昵称/手机号"
                  value={keyword}
                  onChange={(e) => setKeyword(e.target.value)}
                  onKeyDown={(e) => e.key === 'Enter' && handleSearch()}
                />
                <Button onClick={handleSearch}>
                  <Search size={16} className="mr-1" />
                  搜索
                </Button>
              </div>
              <select
                className="h-10 px-3 rounded-lg border border-stone-200 text-sm"
                value={statusFilter}
                onChange={(e) => {
                  setStatusFilter(e.target.value)
                  setPage(1)
                }}
              >
                <option value="">全部状态</option>
                <option value="active">正常</option>
                <option value="inactive">已禁用</option>
              </select>
              <Button variant="outline" onClick={handleExport} disabled={exporting}>
                {exporting ? (
                  <Loader2 size={16} className="mr-1 animate-spin" />
                ) : (
                  <Download size={16} className="mr-1" />
                )}
                导出
              </Button>
            </div>
          </div>
        </CardHeader>
        <CardContent>
          {loading ? (
            <div className="flex items-center justify-center h-64">
              <Loader2 className="h-6 w-6 animate-spin text-teal-500" />
            </div>
          ) : (
            <>
              <div className="overflow-x-auto">
                <table className="w-full">
                  <thead>
                    <tr className="border-b border-stone-200">
                      <th className="text-left py-3 px-4 text-sm font-medium text-stone-500">用户信息</th>
                      <th className="text-left py-3 px-4 text-sm font-medium text-stone-500">手机号</th>
                      <th className="text-left py-3 px-4 text-sm font-medium text-stone-500">区域</th>
                      <th className="text-left py-3 px-4 text-sm font-medium text-stone-500">状态</th>
                      <th className="text-left py-3 px-4 text-sm font-medium text-stone-500">注册时间</th>
                      <th className="text-left py-3 px-4 text-sm font-medium text-stone-500">操作</th>
                    </tr>
                  </thead>
                  <tbody>
                    {data?.users.map((user) => (
                      <tr key={user.id} className="border-b border-stone-100 hover:bg-stone-50">
                        <td className="py-3 px-4">
                          <div className="flex items-center gap-3">
                            <div className="w-10 h-10 rounded-full bg-stone-200 flex items-center justify-center text-stone-500">
                              {user.nickname?.[0] || 'U'}
                            </div>
                            <div>
                              <div className="font-medium text-stone-800">{user.nickname || '未设置'}</div>
                              <div className="text-xs text-stone-400">ID: {user.id.slice(0, 8)}</div>
                            </div>
                          </div>
                        </td>
                        <td className="py-3 px-4 text-stone-600">{user.phone || '-'}</td>
                        <td className="py-3 px-4 text-stone-600">
                          {user.region === 'island_inside' ? '岛内' : user.region === 'island_outside' ? '岛外' : '-'}
                        </td>
                        <td className="py-3 px-4">
                          <Badge className={getStatusBadgeClass(user.status)}>
                            {getStatusText(user.status)}
                          </Badge>
                        </td>
                        <td className="py-3 px-4 text-stone-500 text-sm">
                          {formatDateTime(user.created_at)}
                        </td>
                        <td className="py-3 px-4">
                          <div className="flex items-center gap-2">
                            <Button
                              variant="outline"
                              size="sm"
                              onClick={() => {
                                setSelectedUserId(user.id)
                                setShowDetail(true)
                              }}
                            >
                              <Eye size={14} />
                            </Button>
                            {user.status === 'active' ? (
                              <Button
                                variant="outline"
                                size="sm"
                                className="text-rose-600 hover:text-rose-700"
                                onClick={() => handleStatusChange(user.id, 'inactive')}
                              >
                                禁用
                              </Button>
                            ) : (
                              <Button
                                variant="outline"
                                size="sm"
                                className="text-emerald-600 hover:text-emerald-700"
                                onClick={() => handleStatusChange(user.id, 'active')}
                              >
                                启用
                              </Button>
                            )}
                          </div>
                        </td>
                      </tr>
                    ))}
                    {(!data?.users || data.users.length === 0) && (
                      <tr>
                        <td colSpan={6} className="py-12 text-center text-stone-400">
                          暂无数据
                        </td>
                      </tr>
                    )}
                  </tbody>
                </table>
              </div>

              {/* 分页 */}
              {totalPages > 1 && (
                <div className="flex items-center justify-between mt-4 pt-4 border-t border-stone-200">
                  <div className="text-sm text-stone-500">
                    共 {data?.total || 0} 条记录
                  </div>
                  <div className="flex items-center gap-2">
                    <Button
                      variant="outline"
                      size="sm"
                      disabled={page <= 1}
                      onClick={() => setPage(page - 1)}
                    >
                      <ChevronLeft size={16} />
                    </Button>
                    <span className="text-sm text-stone-600">
                      {page} / {totalPages}
                    </span>
                    <Button
                      variant="outline"
                      size="sm"
                      disabled={page >= totalPages}
                      onClick={() => setPage(page + 1)}
                    >
                      <ChevronRight size={16} />
                    </Button>
                  </div>
                </div>
              )}
            </>
          )}
        </CardContent>
      </Card>

      {/* 用户详情弹窗 */}
      <UserDetailModal
        userId={selectedUserId}
        open={showDetail}
        onClose={() => {
          setShowDetail(false)
          setSelectedUserId(null)
        }}
      />
    </div>
  )
}
