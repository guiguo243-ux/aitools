import { useState, useEffect, ChangeEvent } from 'react'
import { UserPlus, Lock, Unlock, RefreshCw, Shield, Users } from 'lucide-react'
import { adminAccountApi } from '@/lib/api'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from '@/components/ui/dialog'

interface Admin {
  id: string
  username: string
  nickname: string
  phone?: string
  email?: string
  role: string
  status: string
  last_login_at?: string
  created_at: string
}

interface Role {
  id: string
  name: string
  description?: string
}

interface AdminsResponse {
  admins: Admin[]
  total: number
}

interface RolesResponse {
  roles: Role[]
}

export default function AdminsPage() {
  const [admins, setAdmins] = useState<Admin[]>([])
  const [roles, setRoles] = useState<Role[]>([])
  const [total, setTotal] = useState(0)
  const [page, setPage] = useState(1)
  const [pageSize] = useState(20)
  const [loading, setLoading] = useState(false)
  const [showCreate, setShowCreate] = useState(false)
  const [formData, setFormData] = useState({
    username: '',
    password: '',
    nickname: '',
    phone: '',
    email: '',
    role: '',
  })

  useEffect(() => {
    fetchAdmins()
    fetchRoles()
  }, [page])

  const fetchAdmins = async () => {
    setLoading(true)
    try {
      const res = await adminAccountApi.getList({
        page,
        pageSize,
      }) as { data: AdminsResponse }
      setAdmins(res.data.admins || [])
      setTotal(res.data.total || 0)
    } catch (error) {
      console.error('获取管理员列表失败:', error)
    } finally {
      setLoading(false)
    }
  }

  const fetchRoles = async () => {
    try {
      const res = await adminAccountApi.getRoles() as { data: RolesResponse }
      setRoles(res.data.roles || [])
    } catch (error) {
      console.error('获取角色列表失败:', error)
    }
  }

  const handleCreate = async () => {
    if (!formData.username.trim() || !formData.password.trim()) {
      alert('请填写用户名和密码')
      return
    }

    try {
      const res = await adminAccountApi.create({
        username: formData.username,
        password: formData.password,
        nickname: formData.nickname,
        phone: formData.phone || undefined,
        email: formData.email || undefined,
        role: formData.role || 'admin',
      })
      const responseData = res as unknown as { msg: string }
      alert(responseData.msg)
      setShowCreate(false)
      setFormData({ username: '', password: '', nickname: '', phone: '', email: '', role: '' })
      fetchAdmins()
    } catch (error) {
      console.error('创建失败:', error)
    }
  }

  const handleStatusChange = async (adminId: string, status: string) => {
    if (!confirm(`确定要${status === 'active' ? '启用' : '禁用'}该管理员吗？`)) return

    try {
      const res = await adminAccountApi.updateStatus(adminId, status)
      const responseData = res as unknown as { msg: string }
      alert(responseData.msg)
      fetchAdmins()
    } catch (error) {
      console.error('操作失败:', error)
    }
  }

  const getStatusBadge = (status: string) => {
    const styles: Record<string, string> = {
      active: 'bg-green-100 text-green-800',
      inactive: 'bg-red-100 text-red-800',
    }
    const labels: Record<string, string> = {
      active: '正常',
      inactive: '已禁用',
    }
    return (
      <span className={`px-2 py-1 rounded-full text-xs ${styles[status] || 'bg-gray-100 text-gray-800'}`}>
        {labels[status] || status}
      </span>
    )
  }

  const totalPages = Math.ceil(total / pageSize)

  return (
    <div className="space-y-6">
      {/* 页面标题 */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-gray-900">管理员账号</h1>
          <p className="text-gray-500 mt-1">管理系统管理员账号</p>
        </div>
        <div className="flex gap-2">
          <Button variant="outline" onClick={fetchAdmins}>
            <RefreshCw className="w-4 h-4 mr-2" />
            刷新
          </Button>
          <Button onClick={() => setShowCreate(true)}>
            <UserPlus className="w-4 h-4 mr-2" />
            新增管理员
          </Button>
        </div>
      </div>

      {/* 统计卡片 */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <div className="bg-white rounded-lg shadow p-6">
          <div className="flex items-center">
            <div className="p-2 bg-blue-100 rounded-lg">
              <Users className="w-6 h-6 text-blue-600" />
            </div>
            <div className="ml-4">
              <p className="text-sm text-gray-500">管理员总数</p>
              <p className="text-2xl font-bold text-gray-900">{total}</p>
            </div>
          </div>
        </div>
        <div className="bg-white rounded-lg shadow p-6">
          <div className="flex items-center">
            <div className="p-2 bg-green-100 rounded-lg">
              <Unlock className="w-6 h-6 text-green-600" />
            </div>
            <div className="ml-4">
              <p className="text-sm text-gray-500">正常账号</p>
              <p className="text-2xl font-bold text-gray-900">
                {admins.filter(a => a.status === 'active').length}
              </p>
            </div>
          </div>
        </div>
        <div className="bg-white rounded-lg shadow p-6">
          <div className="flex items-center">
            <div className="p-2 bg-purple-100 rounded-lg">
              <Shield className="w-6 h-6 text-purple-600" />
            </div>
            <div className="ml-4">
              <p className="text-sm text-gray-500">角色数量</p>
              <p className="text-2xl font-bold text-gray-900">{roles.length}</p>
            </div>
          </div>
        </div>
      </div>

      {/* 管理员列表 */}
      <div className="bg-white rounded-lg shadow overflow-hidden">
        <table className="min-w-full divide-y divide-gray-200">
          <thead className="bg-gray-50">
            <tr>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">用户名</th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">昵称</th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">角色</th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">联系方式</th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">状态</th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">最后登录</th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">操作</th>
            </tr>
          </thead>
          <tbody className="bg-white divide-y divide-gray-200">
            {loading ? (
              <tr>
                <td colSpan={7} className="px-6 py-12 text-center text-gray-500">
                  加载中...
                </td>
              </tr>
            ) : admins.length === 0 ? (
              <tr>
                <td colSpan={7} className="px-6 py-12 text-center text-gray-500">
                  暂无管理员
                </td>
              </tr>
            ) : (
              admins.map((a) => (
                <tr key={a.id} className="hover:bg-gray-50">
                  <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">
                    {a.username}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                    {a.nickname || '-'}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <span className="px-2 py-1 rounded-full text-xs bg-purple-100 text-purple-800">
                      {a.role || 'admin'}
                    </span>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                    <div>{a.phone || '-'}</div>
                    <div className="text-xs text-gray-400">{a.email || '-'}</div>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">{getStatusBadge(a.status)}</td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                    {a.last_login_at ? new Date(a.last_login_at).toLocaleString() : '-'}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm">
                    <div className="flex items-center gap-2">
                      {a.status === 'active' ? (
                        <Button
                          variant="ghost"
                          size="sm"
                          className="text-red-600 hover:text-red-700"
                          onClick={() => handleStatusChange(a.id, 'inactive')}
                        >
                          <Lock className="w-4 h-4 mr-1" />
                          禁用
                        </Button>
                      ) : (
                        <Button
                          variant="ghost"
                          size="sm"
                          className="text-green-600 hover:text-green-700"
                          onClick={() => handleStatusChange(a.id, 'active')}
                        >
                          <Unlock className="w-4 h-4 mr-1" />
                          启用
                        </Button>
                      )}
                    </div>
                  </td>
                </tr>
              ))
            )}
          </tbody>
        </table>

        {/* 分页 */}
        {totalPages > 1 && (
          <div className="bg-white px-4 py-3 flex items-center justify-between border-t">
            <div className="text-sm text-gray-500">共 {total} 条记录</div>
            <div className="flex gap-2">
              <Button
                variant="outline"
                size="sm"
                disabled={page === 1}
                onClick={() => setPage(page - 1)}
              >
                上一页
              </Button>
              <span className="px-3 py-1 text-sm text-gray-500">
                {page} / {totalPages}
              </span>
              <Button
                variant="outline"
                size="sm"
                disabled={page === totalPages}
                onClick={() => setPage(page + 1)}
              >
                下一页
              </Button>
            </div>
          </div>
        )}
      </div>

      {/* 新增管理员弹窗 */}
      <Dialog open={showCreate} onOpenChange={setShowCreate}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle>新增管理员</DialogTitle>
          </DialogHeader>
          <div className="space-y-4 py-4">
            <div>
              <label className="text-sm font-medium text-gray-700">用户名 *</label>
              <Input
                value={formData.username}
                onChange={(e: ChangeEvent<HTMLInputElement>) => setFormData({ ...formData, username: e.target.value })}
                placeholder="请输入用户名"
                className="mt-1"
              />
            </div>
            <div>
              <label className="text-sm font-medium text-gray-700">密码 *</label>
              <Input
                type="password"
                value={formData.password}
                onChange={(e: ChangeEvent<HTMLInputElement>) => setFormData({ ...formData, password: e.target.value })}
                placeholder="请输入密码"
                className="mt-1"
              />
            </div>
            <div>
              <label className="text-sm font-medium text-gray-700">昵称</label>
              <Input
                value={formData.nickname}
                onChange={(e: ChangeEvent<HTMLInputElement>) => setFormData({ ...formData, nickname: e.target.value })}
                placeholder="请输入昵称"
                className="mt-1"
              />
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="text-sm font-medium text-gray-700">手机号</label>
                <Input
                  value={formData.phone}
                  onChange={(e: ChangeEvent<HTMLInputElement>) => setFormData({ ...formData, phone: e.target.value })}
                  placeholder="手机号"
                  className="mt-1"
                />
              </div>
              <div>
                <label className="text-sm font-medium text-gray-700">邮箱</label>
                <Input
                  value={formData.email}
                  onChange={(e: ChangeEvent<HTMLInputElement>) => setFormData({ ...formData, email: e.target.value })}
                  placeholder="邮箱"
                  className="mt-1"
                />
              </div>
            </div>
            <div>
              <label className="text-sm font-medium text-gray-700">角色</label>
              <select
                value={formData.role}
                onChange={(e) => setFormData({ ...formData, role: e.target.value })}
                className="w-full mt-1 px-3 py-2 border rounded-md"
              >
                <option value="admin">管理员</option>
                {roles.map((role) => (
                  <option key={role.id} value={role.id}>{role.name}</option>
                ))}
              </select>
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setShowCreate(false)}>
              取消
            </Button>
            <Button onClick={handleCreate}>
              创建
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  )
}
