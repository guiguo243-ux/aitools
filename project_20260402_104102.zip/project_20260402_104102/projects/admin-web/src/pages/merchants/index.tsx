import { useState, useEffect } from 'react'
import { merchantApi, exportApi } from '@/lib/api'
import { formatDateTime, getStatusBadgeClass, getStatusText } from '@/lib/utils'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Badge } from '@/components/ui/badge'
import { Store, Search, Loader2, ChevronLeft, ChevronRight, Eye, Download } from 'lucide-react'
import { MerchantDetailModal } from '@/components/MerchantDetailModal'

interface Merchant {
  id: string
  name: string
  category: string
  address: string
  phone: string
  status: string
  created_at: string
}

interface MerchantListResponse {
  merchants: Merchant[]
  total: number
}

const categoryLabels: Record<string, string> = {
  food: '美食',
  entertainment: '娱乐',
  shopping: '购物',
  service: '服务',
  hotel: '酒店',
  travel: '旅游',
}

export default function MerchantsPage() {
  const [data, setData] = useState<MerchantListResponse | null>(null)
  const [loading, setLoading] = useState(true)
  const [page, setPage] = useState(1)
  const [keyword, setKeyword] = useState('')
  const [searchKeyword, setSearchKeyword] = useState('')
  const [statusFilter, setStatusFilter] = useState('')
  const [selectedMerchantId, setSelectedMerchantId] = useState<string | null>(null)
  const [showDetail, setShowDetail] = useState(false)
  const [exporting, setExporting] = useState(false)
  const pageSize = 10

  useEffect(() => {
    fetchMerchants()
  }, [page, searchKeyword, statusFilter])

  const fetchMerchants = async () => {
    setLoading(true)
    try {
      const res: any = await merchantApi.getList({
        page,
        pageSize,
        keyword: searchKeyword || undefined,
        status: statusFilter || undefined,
      })

      if (res.code === 200) {
        setData(res.data)
      }
    } catch (error) {
      console.error('Fetch merchants error:', error)
    } finally {
      setLoading(false)
    }
  }

  const handleExport = async () => {
    setExporting(true)
    try {
      const res: any = await exportApi.merchants({
        status: statusFilter || undefined,
      })
      if (res.code === 200 && res.data?.data) {
        const csvContent = [
          Object.keys(res.data.data[0] || {}).join(','),
          ...res.data.data.map((row: any) => Object.values(row).join(','))
        ].join('\n')
        
        const blob = new Blob(['\ufeff' + csvContent], { type: 'text/csv;charset=utf-8;' })
        const link = document.createElement('a')
        link.href = URL.createObjectURL(blob)
        link.download = `商家数据_${new Date().toISOString().split('T')[0]}.csv`
        link.click()
      }
    } catch (error) {
      console.error('Export error:', error)
      alert('导出失败')
    } finally {
      setExporting(false)
    }
  }

  const handleSearch = () => {
    setSearchKeyword(keyword)
    setPage(1)
  }

  const handleStatusChange = async (merchantId: string, status: string) => {
    const statusText = status === 'approved' ? '通过' : status === 'rejected' ? '拒绝' : status
    if (!confirm(`确定要${statusText}该商家吗？`)) {
      return
    }

    try {
      const res: any = await merchantApi.updateStatus(merchantId, status)
      if (res.code === 200) {
        fetchMerchants()
      } else {
        alert(res.msg || '操作失败')
      }
    } catch (error) {
      console.error('Update status error:', error)
      alert('操作失败')
    }
  }

  const totalPages = Math.ceil((data?.total || 0) / pageSize)

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <div className="flex items-center justify-between flex-wrap gap-4">
            <CardTitle className="flex items-center gap-2">
              <Store size={20} color="#14B8A6" />
              商家列表
            </CardTitle>
            <div className="flex items-center gap-3 flex-wrap">
              <div className="flex items-center gap-2">
                <Input
                  className="w-48"
                  placeholder="搜索商家名称"
                  value={keyword}
                  onChange={(e) => setKeyword(e.target.value)}
                  onKeyDown={(e) => e.key === 'Enter' && handleSearch()}
                />
                <Button onClick={handleSearch}>
                  <Search size={16} className="mr-1" />
                  搜索
                </Button>
              </div>
              <select
                className="h-10 px-3 rounded-lg border border-stone-200 text-sm"
                value={statusFilter}
                onChange={(e) => {
                  setStatusFilter(e.target.value)
                  setPage(1)
                }}
              >
                <option value="">全部状态</option>
                <option value="pending">待审核</option>
                <option value="approved">已通过</option>
                <option value="rejected">已拒绝</option>
                <option value="active">正常运营</option>
                <option value="inactive">已禁用</option>
              </select>
              <Button variant="outline" onClick={handleExport} disabled={exporting}>
                {exporting ? (
                  <Loader2 size={16} className="mr-1 animate-spin" />
                ) : (
                  <Download size={16} className="mr-1" />
                )}
                导出
              </Button>
            </div>
          </div>
        </CardHeader>
        <CardContent>
          {loading ? (
            <div className="flex items-center justify-center h-64">
              <Loader2 className="h-6 w-6 animate-spin text-teal-500" />
            </div>
          ) : (
            <>
              <div className="overflow-x-auto">
                <table className="w-full">
                  <thead>
                    <tr className="border-b border-stone-200">
                      <th className="text-left py-3 px-4 text-sm font-medium text-stone-500">商家名称</th>
                      <th className="text-left py-3 px-4 text-sm font-medium text-stone-500">分类</th>
                      <th className="text-left py-3 px-4 text-sm font-medium text-stone-500">地址</th>
                      <th className="text-left py-3 px-4 text-sm font-medium text-stone-500">电话</th>
                      <th className="text-left py-3 px-4 text-sm font-medium text-stone-500">状态</th>
                      <th className="text-left py-3 px-4 text-sm font-medium text-stone-500">创建时间</th>
                      <th className="text-left py-3 px-4 text-sm font-medium text-stone-500">操作</th>
                    </tr>
                  </thead>
                  <tbody>
                    {data?.merchants.map((merchant) => (
                      <tr key={merchant.id} className="border-b border-stone-100 hover:bg-stone-50">
                        <td className="py-3 px-4">
                          <div className="font-medium text-stone-800">{merchant.name}</div>
                        </td>
                        <td className="py-3 px-4 text-stone-600">
                          {categoryLabels[merchant.category] || merchant.category}
                        </td>
                        <td className="py-3 px-4 text-stone-600">{merchant.address || '-'}</td>
                        <td className="py-3 px-4 text-stone-600">{merchant.phone || '-'}</td>
                        <td className="py-3 px-4">
                          <Badge className={getStatusBadgeClass(merchant.status)}>
                            {getStatusText(merchant.status)}
                          </Badge>
                        </td>
                        <td className="py-3 px-4 text-stone-500 text-sm">
                          {formatDateTime(merchant.created_at)}
                        </td>
                        <td className="py-3 px-4">
                          <div className="flex items-center gap-2">
                            <Button
                              variant="outline"
                              size="sm"
                              onClick={() => {
                                setSelectedMerchantId(merchant.id)
                                setShowDetail(true)
                              }}
                            >
                              <Eye size={14} />
                            </Button>
                            {merchant.status === 'pending' && (
                              <>
                                <Button
                                  variant="outline"
                                  size="sm"
                                  className="text-emerald-600 hover:text-emerald-700"
                                  onClick={() => handleStatusChange(merchant.id, 'approved')}
                                >
                                  通过
                                </Button>
                                <Button
                                  variant="outline"
                                  size="sm"
                                  className="text-rose-600 hover:text-rose-700"
                                  onClick={() => handleStatusChange(merchant.id, 'rejected')}
                                >
                                  拒绝
                                </Button>
                              </>
                            )}
                            {merchant.status === 'approved' && (
                              <Button
                                variant="outline"
                                size="sm"
                                className="text-rose-600 hover:text-rose-700"
                                onClick={() => handleStatusChange(merchant.id, 'inactive')}
                              >
                                禁用
                              </Button>
                            )}
                            {merchant.status === 'rejected' && (
                              <Button
                                variant="outline"
                                size="sm"
                                className="text-emerald-600 hover:text-emerald-700"
                                onClick={() => handleStatusChange(merchant.id, 'approved')}
                              >
                                通过
                              </Button>
                            )}
                            {merchant.status === 'active' && (
                              <Button
                                variant="outline"
                                size="sm"
                                className="text-rose-600 hover:text-rose-700"
                                onClick={() => handleStatusChange(merchant.id, 'inactive')}
                              >
                                禁用
                              </Button>
                            )}
                            {merchant.status === 'inactive' && (
                              <Button
                                variant="outline"
                                size="sm"
                                className="text-emerald-600 hover:text-emerald-700"
                                onClick={() => handleStatusChange(merchant.id, 'active')}
                              >
                                启用
                              </Button>
                            )}
                          </div>
                        </td>
                      </tr>
                    ))}
                    {(!data?.merchants || data.merchants.length === 0) && (
                      <tr>
                        <td colSpan={7} className="py-12 text-center text-stone-400">
                          暂无数据
                        </td>
                      </tr>
                    )}
                  </tbody>
                </table>
              </div>

              {/* 分页 */}
              {totalPages > 1 && (
                <div className="flex items-center justify-between mt-4 pt-4 border-t border-stone-200">
                  <div className="text-sm text-stone-500">
                    共 {data?.total || 0} 条记录
                  </div>
                  <div className="flex items-center gap-2">
                    <Button
                      variant="outline"
                      size="sm"
                      disabled={page <= 1}
                      onClick={() => setPage(page - 1)}
                    >
                      <ChevronLeft size={16} />
                    </Button>
                    <span className="text-sm text-stone-600">
                      {page} / {totalPages}
                    </span>
                    <Button
                      variant="outline"
                      size="sm"
                      disabled={page >= totalPages}
                      onClick={() => setPage(page + 1)}
                    >
                      <ChevronRight size={16} />
                    </Button>
                  </div>
                </div>
              )}
            </>
          )}
        </CardContent>
      </Card>

      {/* 商家详情弹窗 */}
      <MerchantDetailModal
        merchantId={selectedMerchantId}
        open={showDetail}
        onClose={() => {
          setShowDetail(false)
          setSelectedMerchantId(null)
        }}
      />
    </div>
  )
}
