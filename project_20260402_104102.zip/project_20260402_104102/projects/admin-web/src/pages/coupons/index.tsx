import { useState, useEffect } from 'react'
import { couponApi } from '@/lib/api'
import { formatDateTime, getStatusBadgeClass, getStatusText } from '@/lib/utils'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Badge } from '@/components/ui/badge'
import { Ticket, Plus, Search, Loader2, ChevronLeft, ChevronRight, Edit, Trash2 } from 'lucide-react'

interface Coupon {
  id: string
  name: string
  type: string
  value: string
  min_amount: string
  total_count: number
  used_count: number
  start_time: string
  end_time: string
  status: string
  created_at: string
}

interface CouponListResponse {
  coupons: Coupon[]
  total: number
}

export default function CouponsPage() {
  const [data, setData] = useState<CouponListResponse | null>(null)
  const [loading, setLoading] = useState(true)
  const [page, setPage] = useState(1)
  const [keyword, setKeyword] = useState('')
  const [searchKeyword, setSearchKeyword] = useState('')
  const [showForm, setShowForm] = useState(false)
  const [editingCoupon, setEditingCoupon] = useState<Coupon | null>(null)
  const [submitting, setSubmitting] = useState(false)
  const [formData, setFormData] = useState({
    name: '',
    type: 'discount',
    value: '',
    min_amount: '',
    total_count: '',
    start_time: '',
    end_time: '',
  })
  const pageSize = 10

  useEffect(() => {
    fetchCoupons()
  }, [page, searchKeyword])

  const fetchCoupons = async () => {
    setLoading(true)
    try {
      const res: any = await couponApi.getList({
        page,
        pageSize,
        keyword: searchKeyword || undefined,
      })

      if (res.code === 200) {
        setData(res.data)
      }
    } catch (error) {
      console.error('Fetch coupons error:', error)
    } finally {
      setLoading(false)
    }
  }

  const handleSearch = () => {
    setSearchKeyword(keyword)
    setPage(1)
  }

  const handleSubmit = async () => {
    if (!formData.name || !formData.value || !formData.start_time || !formData.end_time) {
      alert('请填写完整信息')
      return
    }

    setSubmitting(true)
    try {
      if (editingCoupon) {
        // 编辑模式 - 调用更新接口
        const res: any = await couponApi.update(editingCoupon.id, {
          name: formData.name,
          type: formData.type,
          value: formData.value,
          min_amount: formData.min_amount || '0',
          total_count: parseInt(formData.total_count) || 100,
          start_time: formData.start_time,
          end_time: formData.end_time,
        })
        
        if (res.code === 200) {
          setShowForm(false)
          setEditingCoupon(null)
          setFormData({
            name: '',
            type: 'discount',
            value: '',
            min_amount: '',
            total_count: '',
            start_time: '',
            end_time: '',
          })
          fetchCoupons()
        } else {
          alert(res.msg || '更新失败')
        }
        return
      }

      const res: any = await couponApi.create({
        name: formData.name,
        type: formData.type,
        value: formData.value,
        min_amount: formData.min_amount || '0',
        total_count: parseInt(formData.total_count) || 100,
        start_time: formData.start_time,
        end_time: formData.end_time,
      })

      if (res.code === 200) {
        setShowForm(false)
        setEditingCoupon(null)
        setFormData({
          name: '',
          type: 'discount',
          value: '',
          min_amount: '',
          total_count: '',
          start_time: '',
          end_time: '',
        })
        fetchCoupons()
      } else {
        alert(res.msg || '创建失败')
      }
    } catch (error) {
      console.error('Create coupon error:', error)
      alert('操作失败')
    } finally {
      setSubmitting(false)
    }
  }

  const handleDelete = async (couponId: string) => {
    if (!confirm('确定要删除该优惠券吗？')) {
      return
    }

    try {
      const res: any = await couponApi.delete(couponId)
      if (res.code === 200) {
        fetchCoupons()
      } else {
        alert(res.msg || '删除失败')
      }
    } catch (error) {
      console.error('Delete coupon error:', error)
      alert('删除失败')
    }
  }

  const handleEdit = (coupon: Coupon) => {
    setEditingCoupon(coupon)
    setFormData({
      name: coupon.name,
      type: coupon.type,
      value: coupon.value,
      min_amount: coupon.min_amount,
      total_count: coupon.total_count.toString(),
      start_time: coupon.start_time.slice(0, 16),
      end_time: coupon.end_time.slice(0, 16),
    })
    setShowForm(true)
  }

  const handleStatusChange = async (couponId: string, isActive: boolean) => {
    try {
      const res: any = await couponApi.updateStatus(couponId, isActive)
      if (res.code === 200) {
        fetchCoupons()
      } else {
        alert(res.msg || '操作失败')
      }
    } catch (error) {
      console.error('Update status error:', error)
      alert('操作失败')
    }
  }

  const totalPages = Math.ceil((data?.total || 0) / pageSize)

  return (
    <div className="space-y-6">
      {/* 创建/编辑表单 */}
      {showForm && (
        <Card>
          <CardHeader>
            <CardTitle>{editingCoupon ? '编辑优惠券' : '创建优惠券'}</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-medium text-stone-700 mb-1">优惠券名称</label>
                <Input
                  value={formData.name}
                  onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                  placeholder="如：新用户专享"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-stone-700 mb-1">类型</label>
                <select
                  className="w-full h-10 px-3 rounded-lg border border-stone-200"
                  value={formData.type}
                  onChange={(e) => setFormData({ ...formData, type: e.target.value })}
                >
                  <option value="discount">满减券</option>
                  <option value="cash">代金券</option>
                </select>
              </div>
              <div>
                <label className="block text-sm font-medium text-stone-700 mb-1">优惠金额（元）</label>
                <Input
                  type="number"
                  value={formData.value}
                  onChange={(e) => setFormData({ ...formData, value: e.target.value })}
                  placeholder="如：10"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-stone-700 mb-1">最低消费金额（元）</label>
                <Input
                  type="number"
                  value={formData.min_amount}
                  onChange={(e) => setFormData({ ...formData, min_amount: e.target.value })}
                  placeholder="如：50"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-stone-700 mb-1">发放数量</label>
                <Input
                  type="number"
                  value={formData.total_count}
                  onChange={(e) => setFormData({ ...formData, total_count: e.target.value })}
                  placeholder="如：100"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-stone-700 mb-1">有效期开始时间</label>
                <Input
                  type="datetime-local"
                  value={formData.start_time}
                  onChange={(e) => setFormData({ ...formData, start_time: e.target.value })}
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-stone-700 mb-1">有效期结束时间</label>
                <Input
                  type="datetime-local"
                  value={formData.end_time}
                  onChange={(e) => setFormData({ ...formData, end_time: e.target.value })}
                />
              </div>
            </div>
            <div className="flex justify-end gap-3 mt-6">
              <Button variant="outline" onClick={() => {
                setShowForm(false)
                setEditingCoupon(null)
              }} disabled={submitting}>
                取消
              </Button>
              <Button onClick={handleSubmit} disabled={submitting}>
                {submitting && <Loader2 size={16} className="mr-1 animate-spin" />}
                {editingCoupon ? '保存' : '创建'}
              </Button>
            </div>
          </CardContent>
        </Card>
      )}

      <Card>
        <CardHeader>
          <div className="flex items-center justify-between flex-wrap gap-4">
            <CardTitle className="flex items-center gap-2">
              <Ticket size={20} color="#14B8A6" />
              优惠券列表
            </CardTitle>
            <div className="flex items-center gap-3">
              <Input
                className="w-48"
                placeholder="搜索优惠券名称"
                value={keyword}
                onChange={(e) => setKeyword(e.target.value)}
                onKeyDown={(e) => e.key === 'Enter' && handleSearch()}
              />
              <Button variant="outline" onClick={handleSearch}>
                <Search size={16} className="mr-1" />
                搜索
              </Button>
              <Button onClick={() => setShowForm(!showForm)}>
                <Plus size={16} className="mr-1" />
                创建
              </Button>
            </div>
          </div>
        </CardHeader>
        <CardContent>
          {loading ? (
            <div className="flex items-center justify-center h-64">
              <Loader2 className="h-6 w-6 animate-spin text-teal-500" />
            </div>
          ) : (
            <>
              <div className="overflow-x-auto">
                <table className="w-full">
                  <thead>
                    <tr className="border-b border-stone-200">
                      <th className="text-left py-3 px-4 text-sm font-medium text-stone-500">名称</th>
                      <th className="text-left py-3 px-4 text-sm font-medium text-stone-500">类型</th>
                      <th className="text-left py-3 px-4 text-sm font-medium text-stone-500">优惠</th>
                      <th className="text-left py-3 px-4 text-sm font-medium text-stone-500">使用情况</th>
                      <th className="text-left py-3 px-4 text-sm font-medium text-stone-500">有效期</th>
                      <th className="text-left py-3 px-4 text-sm font-medium text-stone-500">状态</th>
                      <th className="text-left py-3 px-4 text-sm font-medium text-stone-500">操作</th>
                    </tr>
                  </thead>
                  <tbody>
                    {data?.coupons.map((coupon) => (
                      <tr key={coupon.id} className="border-b border-stone-100 hover:bg-stone-50">
                        <td className="py-3 px-4">
                          <div className="font-medium text-stone-800">{coupon.name}</div>
                        </td>
                        <td className="py-3 px-4 text-stone-600">
                          {coupon.type === 'discount' ? '满减券' : '代金券'}
                        </td>
                        <td className="py-3 px-4">
                          <div className="text-teal-600 font-semibold">¥{coupon.value}</div>
                          {parseFloat(coupon.min_amount) > 0 && (
                            <div className="text-xs text-stone-400">满{coupon.min_amount}可用</div>
                          )}
                        </td>
                        <td className="py-3 px-4 text-stone-600">
                          {coupon.used_count} / {coupon.total_count}
                        </td>
                        <td className="py-3 px-4 text-stone-500 text-sm">
                          <div>{formatDateTime(coupon.start_time)}</div>
                          <div>至 {formatDateTime(coupon.end_time)}</div>
                        </td>
                        <td className="py-3 px-4">
                          <Badge className={getStatusBadgeClass(coupon.status)}>
                            {getStatusText(coupon.status)}
                          </Badge>
                        </td>
                        <td className="py-3 px-4">
                          <div className="flex items-center gap-2">
                            <Button
                              variant="outline"
                              size="sm"
                              onClick={() => handleEdit(coupon)}
                            >
                              <Edit size={14} />
                            </Button>
                            {coupon.status === 'active' ? (
                              <Button
                                variant="outline"
                                size="sm"
                                className="text-amber-600 hover:text-amber-700"
                                onClick={() => handleStatusChange(coupon.id, false)}
                              >
                                禁用
                              </Button>
                            ) : (
                              <Button
                                variant="outline"
                                size="sm"
                                className="text-emerald-600 hover:text-emerald-700"
                                onClick={() => handleStatusChange(coupon.id, true)}
                              >
                                启用
                              </Button>
                            )}
                            <Button
                              variant="outline"
                              size="sm"
                              className="text-rose-600 hover:text-rose-700"
                              onClick={() => handleDelete(coupon.id)}
                            >
                              <Trash2 size={14} />
                            </Button>
                          </div>
                        </td>
                      </tr>
                    ))}
                    {(!data?.coupons || data.coupons.length === 0) && (
                      <tr>
                        <td colSpan={7} className="py-12 text-center text-stone-400">
                          暂无数据
                        </td>
                      </tr>
                    )}
                  </tbody>
                </table>
              </div>

              {/* 分页 */}
              {totalPages > 1 && (
                <div className="flex items-center justify-between mt-4 pt-4 border-t border-stone-200">
                  <div className="text-sm text-stone-500">
                    共 {data?.total || 0} 条记录
                  </div>
                  <div className="flex items-center gap-2">
                    <Button
                      variant="outline"
                      size="sm"
                      disabled={page <= 1}
                      onClick={() => setPage(page - 1)}
                    >
                      <ChevronLeft size={16} />
                    </Button>
                    <span className="text-sm text-stone-600">
                      {page} / {totalPages}
                    </span>
                    <Button
                      variant="outline"
                      size="sm"
                      disabled={page >= totalPages}
                      onClick={() => setPage(page + 1)}
                    >
                      <ChevronRight size={16} />
                    </Button>
                  </div>
                </div>
              )}
            </>
          )}
        </CardContent>
      </Card>
    </div>
  )
}
