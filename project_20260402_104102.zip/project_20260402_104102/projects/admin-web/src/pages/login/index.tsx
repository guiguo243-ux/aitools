import { useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { useAuthStore } from '@/stores/auth'
import { adminApi } from '@/lib/api'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Card, CardContent } from '@/components/ui/card'
import { Shield, User, Lock, Loader2 } from 'lucide-react'

export default function LoginPage() {
  const navigate = useNavigate()
  const { login } = useAuthStore()
  const [username, setUsername] = useState('')
  const [password, setPassword] = useState('')
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState('')

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault()
    setError('')

    if (!username.trim() || !password.trim()) {
      setError('请输入用户名和密码')
      return
    }

    setLoading(true)
    try {
      const res: any = await adminApi.login(username, password)

      if (res.code === 200 && res.data) {
        login(res.data)
        navigate('/dashboard')
      } else {
        setError(res.msg || '登录失败')
      }
    } catch (err: any) {
      setError(err.response?.data?.msg || '登录失败，请重试')
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="min-h-screen bg-stone-50 flex">
      {/* 左侧品牌区 */}
      <div className="hidden lg:flex lg:w-1/2 bg-gradient-to-br from-teal-500 to-teal-600 p-12 flex-col justify-center items-center text-white">
        <div className="w-20 h-20 bg-white/20 rounded-2xl flex items-center justify-center mb-6">
          <Shield size={48} />
        </div>
        <h1 className="text-3xl font-bold mb-3">厦门本地生活</h1>
        <p className="text-teal-100 text-lg mb-12">后台管理系统</p>

        <div className="flex gap-8">
          <div className="text-center">
            <div className="text-4xl font-bold">1000+</div>
            <div className="text-teal-100 text-sm mt-1">合作商家</div>
          </div>
          <div className="text-center">
            <div className="text-4xl font-bold">50000+</div>
            <div className="text-teal-100 text-sm mt-1">活跃用户</div>
          </div>
          <div className="text-center">
            <div className="text-4xl font-bold">98%</div>
            <div className="text-teal-100 text-sm mt-1">好评率</div>
          </div>
        </div>
      </div>

      {/* 右侧登录区 */}
      <div className="flex-1 flex items-center justify-center p-6">
        <Card className="w-full max-w-md border-0 shadow-lg">
          <CardContent className="p-8">
            {/* 移动端Logo */}
            <div className="lg:hidden flex flex-col items-center mb-8">
              <div className="w-14 h-14 bg-teal-500 rounded-xl flex items-center justify-center mb-3">
                <Shield size={28} color="#fff" />
              </div>
              <h1 className="text-xl font-semibold text-stone-800">后台管理</h1>
            </div>

            <h2 className="text-2xl font-semibold text-stone-800 mb-2">管理员登录</h2>
            <p className="text-stone-500 mb-6">请输入您的账号信息</p>

            <form onSubmit={handleLogin} className="space-y-5">
              <div className="space-y-2">
                <label className="text-sm font-medium text-stone-700">用户名</label>
                <div className="relative">
                  <User className="absolute left-3 top-1/2 -translate-y-1/2 text-stone-400" size={18} />
                  <Input
                    className="pl-10"
                    placeholder="请输入用户名"
                    value={username}
                    onChange={(e) => setUsername(e.target.value)}
                    disabled={loading}
                  />
                </div>
              </div>

              <div className="space-y-2">
                <label className="text-sm font-medium text-stone-700">密码</label>
                <div className="relative">
                  <Lock className="absolute left-3 top-1/2 -translate-y-1/2 text-stone-400" size={18} />
                  <Input
                    type="password"
                    className="pl-10"
                    placeholder="请输入密码"
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    disabled={loading}
                  />
                </div>
              </div>

              {error && (
                <div className="text-rose-500 text-sm">{error}</div>
              )}

              <Button
                type="submit"
                className="w-full h-11"
                disabled={loading}
              >
                {loading ? (
                  <>
                    <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                    登录中...
                  </>
                ) : (
                  '登录'
                )}
              </Button>
            </form>

            <p className="text-center text-stone-400 text-sm mt-6">
              默认账号: admin / admin123
            </p>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
