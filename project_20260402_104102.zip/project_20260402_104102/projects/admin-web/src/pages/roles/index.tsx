import { useState, useEffect, ChangeEvent } from 'react'
import { Plus, Edit, Trash2, RefreshCw, Shield, Key } from 'lucide-react'
import { roleApi } from '@/lib/api'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from '@/components/ui/dialog'

interface Permission {
  id: string
  name: string
  key: string
  category: string
}

interface Role {
  id: string
  name: string
  description?: string
  permissions?: string[]
  created_at: string
}

interface RolesResponse {
  roles: Role[]
}

interface PermissionsResponse {
  permissions: Permission[]
}

const permissionCategories: Record<string, string> = {
  user: '用户管理',
  merchant: '商家管理',
  order: '订单管理',
  product: '商品管理',
  coupon: '优惠券管理',
  refund: '退款管理',
  review: '评价管理',
  admin: '管理员管理',
  system: '系统配置',
}

export default function RolesPage() {
  const [roles, setRoles] = useState<Role[]>([])
  const [permissions, setPermissions] = useState<Permission[]>([])
  const [loading, setLoading] = useState(false)
  const [showCreate, setShowCreate] = useState(false)
  const [showEdit, setShowEdit] = useState(false)
  const [selectedRole, setSelectedRole] = useState<Role | null>(null)
  const [formData, setFormData] = useState({
    name: '',
    description: '',
    permissions: [] as string[],
  })

  useEffect(() => {
    fetchRoles()
    fetchPermissions()
  }, [])

  const fetchRoles = async () => {
    setLoading(true)
    try {
      const res = await roleApi.getList() as { data: RolesResponse }
      setRoles(res.data.roles || [])
    } catch (error) {
      console.error('获取角色列表失败:', error)
    } finally {
      setLoading(false)
    }
  }

  const fetchPermissions = async () => {
    try {
      const res = await roleApi.getPermissions() as { data: PermissionsResponse }
      setPermissions(res.data.permissions || [])
    } catch (error) {
      console.error('获取权限列表失败:', error)
    }
  }

  const handleCreate = async () => {
    if (!formData.name.trim()) {
      alert('请填写角色名称')
      return
    }

    try {
      const res = await roleApi.create({
        name: formData.name,
        description: formData.description,
        permissions: formData.permissions,
      })
      const responseData = res as unknown as { msg: string }
      alert(responseData.msg)
      setShowCreate(false)
      setFormData({ name: '', description: '', permissions: [] })
      fetchRoles()
    } catch (error) {
      console.error('创建失败:', error)
    }
  }

  const handleEdit = async () => {
    if (!selectedRole || !formData.name.trim()) {
      alert('请填写角色名称')
      return
    }

    try {
      const res = await roleApi.update(selectedRole.id, {
        name: formData.name,
        description: formData.description,
        permissions: formData.permissions,
      })
      const responseData = res as unknown as { msg: string }
      alert(responseData.msg)
      setShowEdit(false)
      setSelectedRole(null)
      setFormData({ name: '', description: '', permissions: [] })
      fetchRoles()
    } catch (error) {
      console.error('更新失败:', error)
    }
  }

  const handleDelete = async (roleId: string) => {
    if (!confirm('确定要删除该角色吗？')) return

    try {
      const res = await roleApi.delete(roleId)
      const responseData = res as unknown as { msg: string }
      alert(responseData.msg)
      fetchRoles()
    } catch (error) {
      console.error('删除失败:', error)
    }
  }

  const openEditDialog = (role: Role) => {
    setSelectedRole(role)
    setFormData({
      name: role.name,
      description: role.description || '',
      permissions: role.permissions || [],
    })
    setShowEdit(true)
  }

  const togglePermission = (permKey: string) => {
    setFormData((prev) => ({
      ...prev,
      permissions: prev.permissions.includes(permKey)
        ? prev.permissions.filter((p) => p !== permKey)
        : [...prev.permissions, permKey],
    }))
  }

  const groupedPermissions = permissions.reduce((acc, perm) => {
    const category = perm.category || 'other'
    if (!acc[category]) acc[category] = []
    acc[category].push(perm)
    return acc
  }, {} as Record<string, Permission[]>)

  return (
    <div className="space-y-6">
      {/* 页面标题 */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-gray-900">角色权限</h1>
          <p className="text-gray-500 mt-1">管理角色和权限分配</p>
        </div>
        <div className="flex gap-2">
          <Button variant="outline" onClick={fetchRoles}>
            <RefreshCw className="w-4 h-4 mr-2" />
            刷新
          </Button>
          <Button onClick={() => setShowCreate(true)}>
            <Plus className="w-4 h-4 mr-2" />
            新增角色
          </Button>
        </div>
      </div>

      {/* 统计卡片 */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <div className="bg-white rounded-lg shadow p-6">
          <div className="flex items-center">
            <div className="p-2 bg-purple-100 rounded-lg">
              <Shield className="w-6 h-6 text-purple-600" />
            </div>
            <div className="ml-4">
              <p className="text-sm text-gray-500">角色数量</p>
              <p className="text-2xl font-bold text-gray-900">{roles.length}</p>
            </div>
          </div>
        </div>
        <div className="bg-white rounded-lg shadow p-6">
          <div className="flex items-center">
            <div className="p-2 bg-blue-100 rounded-lg">
              <Key className="w-6 h-6 text-blue-600" />
            </div>
            <div className="ml-4">
              <p className="text-sm text-gray-500">权限数量</p>
              <p className="text-2xl font-bold text-gray-900">{permissions.length}</p>
            </div>
          </div>
        </div>
      </div>

      {/* 角色列表 */}
      <div className="bg-white rounded-lg shadow overflow-hidden">
        <table className="min-w-full divide-y divide-gray-200">
          <thead className="bg-gray-50">
            <tr>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">角色名称</th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">描述</th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">权限数量</th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">创建时间</th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">操作</th>
            </tr>
          </thead>
          <tbody className="bg-white divide-y divide-gray-200">
            {loading ? (
              <tr>
                <td colSpan={5} className="px-6 py-12 text-center text-gray-500">
                  加载中...
                </td>
              </tr>
            ) : roles.length === 0 ? (
              <tr>
                <td colSpan={5} className="px-6 py-12 text-center text-gray-500">
                  暂无角色数据
                </td>
              </tr>
            ) : (
              roles.map((r) => (
                <tr key={r.id} className="hover:bg-gray-50">
                  <td className="px-6 py-4 whitespace-nowrap">
                    <span className="text-sm font-medium text-gray-900">{r.name}</span>
                  </td>
                  <td className="px-6 py-4 text-sm text-gray-500 max-w-[300px] truncate">
                    {r.description || '-'}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <span className="px-2 py-1 rounded-full text-xs bg-blue-100 text-blue-800">
                      {r.permissions?.length || 0} 个权限
                    </span>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                    {new Date(r.created_at).toLocaleDateString()}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm">
                    <div className="flex items-center gap-2">
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => openEditDialog(r)}
                      >
                        <Edit className="w-4 h-4 mr-1" />
                        编辑
                      </Button>
                      <Button
                        variant="ghost"
                        size="sm"
                        className="text-red-600 hover:text-red-700"
                        onClick={() => handleDelete(r.id)}
                      >
                        <Trash2 className="w-4 h-4 mr-1" />
                        删除
                      </Button>
                    </div>
                  </td>
                </tr>
              ))
            )}
          </tbody>
        </table>
      </div>

      {/* 新增角色弹窗 */}
      <Dialog open={showCreate} onOpenChange={setShowCreate}>
        <DialogContent className="max-w-lg max-h-[80vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>新增角色</DialogTitle>
          </DialogHeader>
          <div className="space-y-4 py-4">
            <div>
              <label className="text-sm font-medium text-gray-700">角色名称 *</label>
              <Input
                value={formData.name}
                onChange={(e: ChangeEvent<HTMLInputElement>) => setFormData({ ...formData, name: e.target.value })}
                placeholder="请输入角色名称"
                className="mt-1"
              />
            </div>
            <div>
              <label className="text-sm font-medium text-gray-700">描述</label>
              <Input
                value={formData.description}
                onChange={(e: ChangeEvent<HTMLInputElement>) => setFormData({ ...formData, description: e.target.value })}
                placeholder="请输入描述"
                className="mt-1"
              />
            </div>
            <div>
              <label className="text-sm font-medium text-gray-700 mb-2 block">权限选择</label>
              <div className="space-y-4 border rounded-lg p-4 max-h-[300px] overflow-y-auto">
                {Object.entries(groupedPermissions).map(([category, perms]) => (
                  <div key={category}>
                    <div className="text-sm font-medium text-gray-700 mb-2">
                      {permissionCategories[category] || category}
                    </div>
                    <div className="flex flex-wrap gap-2">
                      {perms.map((perm) => (
                        <label
                          key={perm.id}
                          className={`px-3 py-1 rounded-full text-xs cursor-pointer transition-colors ${
                            formData.permissions.includes(perm.key)
                              ? 'bg-blue-500 text-white'
                              : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
                          }`}
                        >
                          <input
                            type="checkbox"
                            checked={formData.permissions.includes(perm.key)}
                            onChange={() => togglePermission(perm.key)}
                            className="hidden"
                          />
                          {perm.name}
                        </label>
                      ))}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setShowCreate(false)}>
              取消
            </Button>
            <Button onClick={handleCreate}>
              创建
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* 编辑角色弹窗 */}
      <Dialog open={showEdit} onOpenChange={setShowEdit}>
        <DialogContent className="max-w-lg max-h-[80vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>编辑角色</DialogTitle>
          </DialogHeader>
          <div className="space-y-4 py-4">
            <div>
              <label className="text-sm font-medium text-gray-700">角色名称 *</label>
              <Input
                value={formData.name}
                onChange={(e: ChangeEvent<HTMLInputElement>) => setFormData({ ...formData, name: e.target.value })}
                placeholder="请输入角色名称"
                className="mt-1"
              />
            </div>
            <div>
              <label className="text-sm font-medium text-gray-700">描述</label>
              <Input
                value={formData.description}
                onChange={(e: ChangeEvent<HTMLInputElement>) => setFormData({ ...formData, description: e.target.value })}
                placeholder="请输入描述"
                className="mt-1"
              />
            </div>
            <div>
              <label className="text-sm font-medium text-gray-700 mb-2 block">权限选择</label>
              <div className="space-y-4 border rounded-lg p-4 max-h-[300px] overflow-y-auto">
                {Object.entries(groupedPermissions).map(([category, perms]) => (
                  <div key={category}>
                    <div className="text-sm font-medium text-gray-700 mb-2">
                      {permissionCategories[category] || category}
                    </div>
                    <div className="flex flex-wrap gap-2">
                      {perms.map((perm) => (
                        <label
                          key={perm.id}
                          className={`px-3 py-1 rounded-full text-xs cursor-pointer transition-colors ${
                            formData.permissions.includes(perm.key)
                              ? 'bg-blue-500 text-white'
                              : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
                          }`}
                        >
                          <input
                            type="checkbox"
                            checked={formData.permissions.includes(perm.key)}
                            onChange={() => togglePermission(perm.key)}
                            className="hidden"
                          />
                          {perm.name}
                        </label>
                      ))}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setShowEdit(false)}>
              取消
            </Button>
            <Button onClick={handleEdit}>
              保存
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  )
}
