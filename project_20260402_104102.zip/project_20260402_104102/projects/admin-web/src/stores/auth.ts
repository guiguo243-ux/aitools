import { create } from 'zustand'
import { persist } from 'zustand/middleware'

interface AdminUser {
  id: string
  username: string
  nickname: string
  role: string
}

interface AuthState {
  admin: AdminUser | null
  token: string | null
  isAdmin: boolean
  login: (admin: AdminUser) => void
  logout: () => void
}

export const useAuthStore = create<AuthState>()(
  persist(
    (set) => ({
      admin: null,
      token: null,
      isAdmin: false,
      login: (admin) => set({ admin, isAdmin: true }),
      logout: () => set({ admin: null, token: null, isAdmin: false }),
    }),
    {
      name: 'admin-auth',
    }
  )
)
