import axios from 'axios'
import { useAuthStore } from '@/stores/auth'

const api = axios.create({
  baseURL: '/api',
  timeout: 30000,
  headers: {
    'Content-Type': 'application/json',
  },
})

// 请求拦截器
api.interceptors.request.use(
  (config) => {
    console.log(`[API] ${config.method?.toUpperCase()} ${config.url}`, config.data || config.params)
    return config
  },
  (error) => {
    return Promise.reject(error)
  }
)

// 响应拦截器
api.interceptors.response.use(
  (response) => {
    console.log(`[API] Response:`, response.data)
    return response.data
  },
  (error) => {
    console.error('[API] Error:', error.response?.data || error.message)
    
    // 401 未授权，跳转登录
    if (error.response?.status === 401) {
      useAuthStore.getState().logout()
      window.location.href = '/login'
    }
    
    return Promise.reject(error)
  }
)

export default api

// 管理员相关接口
export const adminApi = {
  login: (username: string, password: string) => 
    api.post('/admin/login', { username, password }),
  
  init: () => 
    api.post('/admin/init'),
  
  getLogs: (params: { page: number; pageSize: number; adminId?: string }) => 
    api.get('/admin/logs', { params }),
}

// 数据统计接口
export const dashboardApi = {
  getStats: () => 
    api.get('/admin/dashboard/stats'),
  
  getOrderTrend: (days: number = 7) => 
    api.get(`/admin/dashboard/order-trend?days=${days}`),
  
  getUserTrend: (days: number = 7) => 
    api.get(`/admin/dashboard/user-trend?days=${days}`),
  
  getOrderStatusDistribution: () => 
    api.get('/admin/dashboard/order-status-distribution'),
  
  getRecentOrders: (limit: number = 10) => 
    api.get(`/admin/dashboard/recent-orders?limit=${limit}`),
  
  getRecentUsers: (limit: number = 10) => 
    api.get(`/admin/dashboard/recent-users?limit=${limit}`),
}

// 用户管理接口
export const userApi = {
  getList: (params: { page: number; pageSize: number; keyword?: string; status?: string }) => 
    api.get('/admin/users', { params }),
  
  getDetail: (userId: string) => 
    api.get(`/admin/user/${userId}`),
  
  updateStatus: (userId: string, status: string) => 
    api.post('/admin/user/status', { userId, status }),
}

// 商家管理接口
export const merchantApi = {
  getList: (params: { page: number; pageSize: number; keyword?: string; status?: string; category?: string }) => 
    api.get('/admin/merchants', { params }),
  
  getDetail: (merchantId: string) => 
    api.get(`/admin/merchant/${merchantId}`),
  
  updateStatus: (merchantId: string, status: string, reason?: string) => 
    api.post('/admin/merchant/status', { merchantId, status, reason }),
}

// 订单管理接口
export const orderApi = {
  getList: (params: { page: number; pageSize: number; keyword?: string; status?: string; startDate?: string; endDate?: string }) => 
    api.get('/admin/orders', { params }),
  
  getDetail: (orderId: string) => 
    api.get(`/admin/order/${orderId}`),
  
  updateStatus: (orderId: string, status: string, adminId: string) => 
    api.post('/admin/order/status', { orderId, status, adminId }),
}

// 优惠券管理接口
export const couponApi = {
  getList: (params: { page: number; pageSize: number; keyword?: string; type?: string; status?: string }) => 
    api.get('/admin/coupons', { params }),
  
  create: (data: any) => 
    api.post('/admin/coupon/create', data),
  
  update: (couponId: string, data: any) => 
    api.post('/admin/coupon/update', { couponId, ...data }),
  
  updateStatus: (couponId: string, isActive: boolean) => 
    api.post('/admin/coupon/status', { couponId, isActive }),
  
  delete: (couponId: string) => 
    api.delete(`/admin/coupon/${couponId}`),
}

// 系统配置接口
export const systemApi = {
  getConfigs: () => 
    api.get('/system/configs'),
  
  updateConfig: (key: string, value: string) => 
    api.post('/system/config', { key, value }),
}

// 设置接口（系统配置）
export const settingApi = {
  getAll: () => 
    api.get('/system-config'),
  
  getByCategory: (category: string) => 
    api.get(`/system-config/category/${category}`),
  
  update: (settings: any[]) => 
    api.post('/system-config/batch', { configs: settings }),
  
  batchUpdate: (data: { configs: any[] }) => 
    api.post('/system-config/batch', data),
  
  test: (category: string) => 
    api.post(`/system-config/test/${category}`),
}

// 商品管理接口
export const productApi = {
  getList: (params: { page: number; pageSize: number; keyword?: string; status?: string; merchantId?: string }) => 
    api.get('/admin/products', { params }),
  
  updateStatus: (productId: string, isActive: boolean, adminId: string) => 
    api.post('/admin/product/status', { productId, isActive, adminId }),
}

// 分类管理接口
export const categoryApi = {
  getList: () => 
    api.get('/admin/categories'),
  
  create: (data: any) => 
    api.post('/admin/category/create', data),
  
  update: (categoryId: number, data: any) => 
    api.post('/admin/category/update', { categoryId, data }),
  
  delete: (categoryId: number) => 
    api.post('/admin/category/delete', { categoryId }),
}

// 数据导出接口
export const exportApi = {
  users: (params: { status?: string; startDate?: string; endDate?: string }) => 
    api.get('/admin/export/users', { params }),
  
  orders: (params: { status?: string; startDate?: string; endDate?: string }) => 
    api.get('/admin/export/orders', { params }),
  
  merchants: (params: { status?: string; category?: string }) => 
    api.get('/admin/export/merchants', { params }),
}

// 提现管理接口
export const withdrawalApi = {
  getList: (params: { page: number; pageSize: number; status?: string; keyword?: string }) => 
    api.get('/admin/withdrawals', { params }),
  
  approve: (withdrawalId: string, adminId: string) => 
    api.post('/admin/withdrawal/approve', { withdrawalId, adminId }),
  
  reject: (withdrawalId: string, adminId: string, reason: string) => 
    api.post('/admin/withdrawal/reject', { withdrawalId, adminId, reason }),
}

// 分销管理接口
export const referralApi = {
  getReferrers: (params: { page: number; pageSize: number; keyword?: string }) => 
    api.get('/admin/referrers', { params }),
  
  getStats: () => 
    api.get('/admin/commission-stats'),
  
  getRecords: (params: { page: number; pageSize: number; userId?: string }) => 
    api.get('/admin/commission-records', { params }),
}

// 消息推送接口
export const messageApi = {
  getList: (params: { page: number; pageSize: number; type?: string }) => 
    api.get('/admin/messages', { params }),
  
  sendToUsers: (data: { userIds: string[]; type: string; title: string; content: string }) => 
    api.post('/admin/message/send', data),
  
  sendToAll: (data: { type: string; title: string; content: string }) => 
    api.post('/admin/message/send-all', data),
}

// 退款管理接口
export const refundApi = {
  getList: (params: { page: number; pageSize: number; status?: string; keyword?: string }) => 
    api.get('/admin/refunds', { params }),
  
  approve: (refundId: string, adminId: string) => 
    api.post('/admin/refund/approve', { refundId, adminId }),
  
  reject: (refundId: string, adminId: string, reason: string) => 
    api.post('/admin/refund/reject', { refundId, adminId, reason }),
}

// 评价管理接口
export const reviewApi = {
  getList: (params: { page: number; pageSize: number; rating?: number }) => 
    api.get('/admin/reviews', { params }),
  
  getStats: () => 
    api.get('/admin/review-stats'),
  
  reply: (reviewId: string, reply: string) => 
    api.post('/admin/review/reply', { reviewId, reply }),
  
  delete: (reviewId: string) => 
    api.delete(`/admin/review/${reviewId}`),
}

// 管理员账号接口
export const adminAccountApi = {
  getList: (params: { page: number; pageSize: number }) => 
    api.get('/admin/admins', { params }),
  
  create: (data: { username: string; password: string; nickname?: string; phone?: string; email?: string; role?: string }) => 
    api.post('/admin/admin/create', data),
  
  updateStatus: (adminId: string, status: string) => 
    api.post('/admin/admin/status', { adminId, status }),
  
  getRoles: () => 
    api.get('/admin/roles'),
}

// 角色权限接口
export const roleApi = {
  getList: () => 
    api.get('/admin/roles'),
  
  create: (data: { name: string; description?: string; permissions?: string[] }) => 
    api.post('/admin/role/create', data),
  
  update: (roleId: string, data: { name: string; description?: string; permissions?: string[] }) => 
    api.post('/admin/role/update', { roleId, ...data }),
  
  delete: (roleId: string) => 
    api.delete(`/admin/role/${roleId}`),
  
  getPermissions: () => 
    api.get('/admin/permissions'),
}

// 积分商品管理接口
export const pointsProductApi = {
  getList: (params: { page: number; pageSize: number }) => 
    api.get('/admin/points-products', { params }),
  
  create: (data: {
    name: string
    description?: string
    image_url?: string
    points_price: number
    original_price?: number
    stock: number
    total_count?: number
    category?: string
    region?: string
    sort_order?: number
  }) => 
    api.post('/admin/points-product/create', data),
  
  update: (productId: string, data: any) => 
    api.post('/admin/points-product/update', { productId, ...data }),
  
  updateStatus: (productId: string, isActive: boolean) => 
    api.post('/admin/points-product/status', { productId, isActive }),
  
  delete: (productId: string) => 
    api.delete(`/admin/points-product/${productId}`),
}

// 积分兑换记录接口
export const pointsExchangeApi = {
  getList: (params: { page: number; pageSize: number; status?: string }) => 
    api.get('/admin/points-exchanges', { params }),
  
  ship: (exchangeId: string, trackingNo: string) => 
    api.post('/admin/points-exchange/ship', { exchangeId, trackingNo }),
  
  complete: (exchangeId: string) => 
    api.post('/admin/points-exchange/complete', { exchangeId }),
}
