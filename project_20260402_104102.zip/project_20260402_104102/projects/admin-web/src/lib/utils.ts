import { clsx, type ClassValue } from 'clsx'
import { twMerge } from 'tailwind-merge'

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs))
}

export function formatDateTime(dateStr: string | undefined | null): string {
  if (!dateStr) return '-'
  
  try {
    const date = new Date(dateStr)
    return date.toLocaleString('zh-CN', {
      year: 'numeric',
      month: '2-digit',
      day: '2-digit',
      hour: '2-digit',
      minute: '2-digit',
    })
  } catch (error) {
    return dateStr
  }
}

export function formatDate(dateStr: string | undefined | null): string {
  if (!dateStr) return '-'
  
  try {
    const date = new Date(dateStr)
    return date.toLocaleDateString('zh-CN', {
      year: 'numeric',
      month: '2-digit',
      day: '2-digit',
    })
  } catch (error) {
    return dateStr
  }
}

export function getStatusBadgeClass(status: string): string {
  const statusClasses: Record<string, string> = {
    // 通用状态
    active: 'bg-emerald-100 text-emerald-700',
    inactive: 'bg-stone-100 text-stone-600',
    pending: 'bg-amber-100 text-amber-700',
    
    // 订单状态
    paid: 'bg-blue-100 text-blue-700',
    completed: 'bg-emerald-100 text-emerald-700',
    cancelled: 'bg-rose-100 text-rose-700',
    refunding: 'bg-orange-100 text-orange-700',
    refunded: 'bg-stone-100 text-stone-600',
    
    // 商家状态
    approved: 'bg-emerald-100 text-emerald-700',
    rejected: 'bg-rose-100 text-rose-700',
  }
  
  return statusClasses[status] || 'bg-stone-100 text-stone-600'
}

export function getStatusText(status: string): string {
  const statusTexts: Record<string, string> = {
    // 通用状态
    active: '正常运营',
    inactive: '已禁用',
    pending: '待审核',
    
    // 订单状态
    paid: '已支付',
    completed: '已完成',
    cancelled: '已取消',
    refunding: '退款中',
    refunded: '已退款',
    
    // 商家状态
    approved: '已通过',
    rejected: '已拒绝',
  }
  
  return statusTexts[status] || status
}

export function formatMoney(amount: string | number | undefined | null): string {
  if (!amount) return '0.00'
  
  const num = typeof amount === 'string' ? parseFloat(amount) : amount
  return num.toFixed(2)
}

export function truncate(str: string, length: number): string {
  if (!str) return ''
  if (str.length <= length) return str
  return str.slice(0, length) + '...'
}

export function debounce<T extends (...args: any[]) => any>(
  func: T,
  wait: number
): (...args: Parameters<T>) => void {
  let timeout: ReturnType<typeof setTimeout> | null = null
  
  return (...args: Parameters<T>) => {
    if (timeout) clearTimeout(timeout)
    timeout = setTimeout(() => func(...args), wait)
  }
}

export function downloadCSV(data: any[], filename: string) {
  if (!data || data.length === 0) {
    alert('没有数据可导出')
    return
  }
  
  const headers = Object.keys(data[0])
  const csvContent = [
    headers.join(','),
    ...data.map(row => 
      headers.map(header => {
        const value = row[header]
        // 处理包含逗号或引号的值
        if (typeof value === 'string' && (value.includes(',') || value.includes('"'))) {
          return `"${value.replace(/"/g, '""')}"`
        }
        return value
      }).join(',')
    )
  ].join('\n')
  
  const blob = new Blob(['\ufeff' + csvContent], { type: 'text/csv;charset=utf-8;' })
  const link = document.createElement('a')
  link.href = URL.createObjectURL(blob)
  link.download = `${filename}_${new Date().toISOString().split('T')[0]}.csv`
  link.click()
}
