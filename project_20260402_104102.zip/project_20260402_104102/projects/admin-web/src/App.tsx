import { Routes, Route, Navigate } from 'react-router-dom'
import { useAuthStore } from '@/stores/auth'
import MainLayout from '@/components/layout/MainLayout'
import LoginPage from '@/pages/login'
import DashboardPage from '@/pages/dashboard'
import UsersPage from '@/pages/users'
import MerchantsPage from '@/pages/merchants'
import OrdersPage from '@/pages/orders'
import CouponsPage from '@/pages/coupons'
import ProductsPage from '@/pages/products'
import CategoriesPage from '@/pages/categories'
import LogsPage from '@/pages/logs'
import SettingsPage from '@/pages/settings'
import WithdrawalsPage from '@/pages/withdrawals'
import ReferralsPage from '@/pages/referrals'
import MessagesPage from '@/pages/messages'
import RefundsPage from '@/pages/refunds'
import ReviewsPage from '@/pages/reviews'
import AdminsPage from '@/pages/admins'
import RolesPage from '@/pages/roles'
import PointsProductsPage from '@/pages/points-products'

// 受保护的路由
function ProtectedRoute({ children }: { children: React.ReactNode }) {
  const { isAdmin } = useAuthStore()
  
  if (!isAdmin) {
    return <Navigate to="/login" replace />
  }
  
  return <MainLayout>{children}</MainLayout>
}

function App() {
  return (
    <Routes>
      {/* 登录页 */}
      <Route path="/login" element={<LoginPage />} />
      
      {/* 受保护的管理页面 */}
      <Route path="/" element={<ProtectedRoute><DashboardPage /></ProtectedRoute>} />
      <Route path="/dashboard" element={<ProtectedRoute><DashboardPage /></ProtectedRoute>} />
      <Route path="/users" element={<ProtectedRoute><UsersPage /></ProtectedRoute>} />
      <Route path="/merchants" element={<ProtectedRoute><MerchantsPage /></ProtectedRoute>} />
      <Route path="/orders" element={<ProtectedRoute><OrdersPage /></ProtectedRoute>} />
      <Route path="/products" element={<ProtectedRoute><ProductsPage /></ProtectedRoute>} />
      <Route path="/coupons" element={<ProtectedRoute><CouponsPage /></ProtectedRoute>} />
      <Route path="/categories" element={<ProtectedRoute><CategoriesPage /></ProtectedRoute>} />
      <Route path="/withdrawals" element={<ProtectedRoute><WithdrawalsPage /></ProtectedRoute>} />
      <Route path="/refunds" element={<ProtectedRoute><RefundsPage /></ProtectedRoute>} />
      <Route path="/reviews" element={<ProtectedRoute><ReviewsPage /></ProtectedRoute>} />
      <Route path="/referrals" element={<ProtectedRoute><ReferralsPage /></ProtectedRoute>} />
      <Route path="/messages" element={<ProtectedRoute><MessagesPage /></ProtectedRoute>} />
      <Route path="/admins" element={<ProtectedRoute><AdminsPage /></ProtectedRoute>} />
      <Route path="/roles" element={<ProtectedRoute><RolesPage /></ProtectedRoute>} />
      <Route path="/points-products" element={<ProtectedRoute><PointsProductsPage /></ProtectedRoute>} />
      <Route path="/logs" element={<ProtectedRoute><LogsPage /></ProtectedRoute>} />
      <Route path="/settings" element={<ProtectedRoute><SettingsPage /></ProtectedRoute>} />
      
      {/* 默认重定向 */}
      <Route path="*" element={<Navigate to="/" replace />} />
    </Routes>
  )
}

export default App
