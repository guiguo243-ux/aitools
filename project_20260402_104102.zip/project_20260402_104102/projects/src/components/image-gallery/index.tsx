import { View, Text, ScrollView } from '@tarojs/components'
import { ChevronLeft, ChevronRight } from 'lucide-react-taro'
import Taro from '@tarojs/taro'
import { useState, useCallback } from 'react'
import LazyImage from '../lazy-image'

interface ImageGalleryProps {
  images: string[]
  width?: string | number
  height?: string | number
  showIndicator?: boolean
  showArrows?: boolean
  autoPlay?: boolean
  interval?: number
  className?: string
  onLoad?: (index: number) => void
  onClick?: (index: number) => void
}

export default function ImageGallery({
  images,
  width = '100%',
  height = 300,
  showIndicator = true,
  showArrows = false,
  autoPlay = false,
  interval = 3000,
  className = '',
  onLoad,
  onClick,
}: ImageGalleryProps) {
  const [currentIndex, setCurrentIndex] = useState(0)

  // 处理滚动
  const handleScroll = useCallback((e: any) => {
    const scrollLeft = e.detail.scrollLeft
    const imageWidth = Taro.getSystemInfoSync().windowWidth
    const index = Math.round(scrollLeft / imageWidth)
    setCurrentIndex(index)
  }, [])

  // 上一张
  const handlePrev = useCallback(() => {
    const newIndex = currentIndex > 0 ? currentIndex - 1 : images.length - 1
    setCurrentIndex(newIndex)
    Taro.pageScrollTo({
      selector: `.gallery-item-${newIndex}`,
      duration: 300,
    })
  }, [currentIndex, images.length])

  // 下一张
  const handleNext = useCallback(() => {
    const newIndex = currentIndex < images.length - 1 ? currentIndex + 1 : 0
    setCurrentIndex(newIndex)
    Taro.pageScrollTo({
      selector: `.gallery-item-${newIndex}`,
      duration: 300,
    })
  }, [currentIndex, images.length])

  // 图片加载完成
  const handleImageLoad = useCallback((index: number) => {
    onLoad?.(index)
  }, [onLoad])

  // 点击图片
  const handleImageClick = useCallback((index: number) => {
    onClick?.(index)
  }, [onClick])

  // 自动播放
  useState(() => {
    if (autoPlay && images.length > 1) {
      const timer = setInterval(() => {
        handleNext()
      }, interval)
      return () => clearInterval(timer)
    }
  })

  if (!images || images.length === 0) {
    return (
      <View 
        className={`bg-gray-100 flex items-center justify-center ${className}`}
        style={{ width, height }}
      >
        <Text className="text-gray-400 text-sm">暂无图片</Text>
      </View>
    )
  }

  return (
    <View className={`relative ${className}`} style={{ width, height }}>
      {/* 图片滚动容器 */}
      <ScrollView
        scrollX
        scrollWithAnimation
        className="w-full h-full"
        onScroll={handleScroll}
        style={{ whiteSpace: 'nowrap' }}
      >
        {images.map((imageSrc, index) => (
          <View
            key={index}
            style={{ 
              width: typeof width === 'number' ? `${width}px` : width, 
              height: typeof height === 'number' ? `${height}px` : height,
              display: 'inline-block',
              flexShrink: 0
            }}
            onClick={() => handleImageClick(index)}
          >
            <LazyImage
              src={imageSrc}
              width="100%"
              height="100%"
              mode="aspectFill"
              fadeIn
              onLoad={() => handleImageLoad(index)}
            />
          </View>
        ))}
      </ScrollView>

      {/* 左右箭头 */}
      {showArrows && images.length > 1 && (
        <>
          <View
            className="absolute left-2 top-1/2 -translate-y-1/2 w-8 h-8 bg-black bg-opacity-40 rounded-full flex items-center justify-center"
            onClick={handlePrev}
          >
            <ChevronLeft size={20} color="#fff" />
          </View>
          <View
            className="absolute right-2 top-1/2 -translate-y-1/2 w-8 h-8 bg-black bg-opacity-40 rounded-full flex items-center justify-center"
            onClick={handleNext}
          >
            <ChevronRight size={20} color="#fff" />
          </View>
        </>
      )}

      {/* 指示器 */}
      {showIndicator && images.length > 1 && (
        <View className="absolute bottom-3 left-0 right-0 flex justify-center" style={{ gap: '6px' }}>
          {images.map((_, index) => (
            <View
              key={index}
              className={`rounded-full transition-all ${
                index === currentIndex ? 'bg-white w-4 h-2' : 'bg-white bg-opacity-50 w-2 h-2'
              }`}
            />
          ))}
        </View>
      )}
    </View>
  )
}
