import { View } from '@tarojs/components'
import { useEffect, useState } from 'react'

interface SkeletonProps {
  width?: string | number
  height?: string | number
  className?: string
  borderRadius?: string | number
  animation?: 'pulse' | 'wave' | 'none'
}

// 基础骨架元素
export function Skeleton({
  width = '100%',
  height = 20,
  className = '',
  borderRadius = 4,
  animation = 'pulse',
}: SkeletonProps) {
  const [animationClass, setAnimationClass] = useState('')

  useEffect(() => {
    if (animation === 'pulse') {
      setAnimationClass('animate-pulse')
    } else if (animation === 'wave') {
      setAnimationClass('skeleton-wave')
    }
  }, [animation])

  const style: React.CSSProperties = {
    width: typeof width === 'number' ? `${width}px` : width,
    height: typeof height === 'number' ? `${height}px` : height,
    borderRadius: typeof borderRadius === 'number' ? `${borderRadius}px` : borderRadius,
    backgroundColor: '#f0f0f0',
  }

  return <View className={`${animationClass} ${className}`} style={style} />
}

// 文本骨架
export function TextSkeleton({
  lines = 3,
  lineHeight = 16,
  lineGap = 8,
  lastLineWidth = '60%',
  className = '',
}: {
  lines?: number
  lineHeight?: number
  lineGap?: number
  lastLineWidth?: string | number
  className?: string
}) {
  return (
    <View className={className}>
      {Array.from({ length: lines }).map((_, index) => (
        <View key={index} style={{ marginBottom: index < lines - 1 ? lineGap : 0 }}>
          <Skeleton
            width={index === lines - 1 ? lastLineWidth : '100%'}
            height={lineHeight}
          />
        </View>
      ))}
    </View>
  )
}

// 头像骨架
export function AvatarSkeleton({
  size = 48,
  shape = 'circle',
  className = '',
}: {
  size?: number
  shape?: 'circle' | 'square'
  className?: string
}) {
  return (
    <Skeleton
      width={size}
      height={size}
      borderRadius={shape === 'circle' ? size / 2 : 8}
      className={className}
    />
  )
}

// 图片骨架
export function ImageSkeleton({
  width = '100%',
  height = 200,
  borderRadius = 8,
  className = '',
}: SkeletonProps) {
  return (
    <Skeleton
      width={width}
      height={height}
      borderRadius={borderRadius}
      className={className}
    />
  )
}

// 商家卡片骨架
export function MerchantCardSkeleton({ className = '' }: { className?: string }) {
  return (
    <View className={`bg-white rounded-xl p-4 ${className}`}>
      <View className="flex gap-3">
        <ImageSkeleton width={80} height={80} borderRadius={12} />
        <View className="flex-1">
          <Skeleton width="60%" height={18} className="mb-2" />
          <Skeleton width="80%" height={14} className="mb-2" />
          <View className="flex gap-2 mt-2">
            <Skeleton width={60} height={20} borderRadius={10} />
            <Skeleton width={60} height={20} borderRadius={10} />
          </View>
        </View>
      </View>
      <View className="flex justify-between mt-3 pt-3 border-t border-gray-100">
        <Skeleton width={80} height={12} />
        <Skeleton width={50} height={12} />
      </View>
    </View>
  )
}

// 订单卡片骨架
export function OrderCardSkeleton({ className = '' }: { className?: string }) {
  return (
    <View className={`bg-white rounded-xl p-4 ${className}`}>
      <View className="flex justify-between items-center mb-3">
        <Skeleton width={120} height={14} />
        <Skeleton width={60} height={14} />
      </View>
      <View className="flex gap-3">
        <ImageSkeleton width={60} height={60} borderRadius={8} />
        <View className="flex-1">
          <Skeleton width="70%" height={16} className="mb-2" />
          <Skeleton width="50%" height={12} />
        </View>
        <View className="text-right">
          <Skeleton width={60} height={18} />
        </View>
      </View>
      <View className="flex justify-between items-center mt-3 pt-3 border-t border-gray-100">
        <Skeleton width={100} height={12} />
        <Skeleton width={80} height={32} borderRadius={16} />
      </View>
    </View>
  )
}

// 商品卡片骨架
export function ProductCardSkeleton({ className = '' }: { className?: string }) {
  return (
    <View className={`bg-white rounded-xl overflow-hidden ${className}`}>
      <ImageSkeleton width="100%" height={150} borderRadius={0} />
      <View className="p-3">
        <Skeleton width="80%" height={16} className="mb-2" />
        <Skeleton width="60%" height={12} className="mb-3" />
        <View className="flex justify-between items-center">
          <Skeleton width={80} height={20} />
          <Skeleton width={60} height={28} borderRadius={14} />
        </View>
      </View>
    </View>
  )
}

// 列表骨架
export function ListSkeleton({
  count = 3,
  itemSkeleton,
  gap = 12,
  className = '',
}: {
  count?: number
  itemSkeleton: React.ReactNode
  gap?: number
  className?: string
}) {
  return (
    <View className={className} style={{ gap }}>
      {Array.from({ length: count }).map((_, index) => (
        <View key={index}>{itemSkeleton}</View>
      ))}
    </View>
  )
}
