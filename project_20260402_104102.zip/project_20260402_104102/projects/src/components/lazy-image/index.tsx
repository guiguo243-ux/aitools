import { View, Image, Text } from '@tarojs/components'
import { useState, useCallback } from 'react'

interface LazyImageProps {
  src: string
  mode?: 'scaleToFill' | 'aspectFit' | 'aspectFill' | 'widthFix' | 'heightFix' | 'top' | 'bottom' | 'center' | 'left' | 'right' | 'top left' | 'top right' | 'bottom left' | 'bottom right'
  width?: string | number
  height?: string | number
  className?: string
  style?: React.CSSProperties
  placeholder?: string
  errorImage?: string
  lazyLoad?: boolean
  fadeIn?: boolean
  threshold?: number
  onLoad?: () => void
  onError?: () => void
}

export default function LazyImage({
  src,
  mode = 'aspectFill',
  width = '100%',
  height = '100%',
  className = '',
  style = {},
  placeholder,
  errorImage,
  lazyLoad = true,
  fadeIn = true,
  onLoad,
  onError,
}: LazyImageProps) {
  const [loaded, setLoaded] = useState(false)
  const [error, setError] = useState(false)
  const [opacity, setOpacity] = useState(fadeIn ? 0 : 1)

  // 处理图片加载成功
  const handleLoad = useCallback(() => {
    setLoaded(true)
    setError(false)
    if (fadeIn) {
      // 渐入动画
      setTimeout(() => setOpacity(1), 50)
    }
    onLoad?.()
  }, [fadeIn, onLoad])

  // 处理图片加载失败
  const handleError = useCallback(() => {
    setError(true)
    setLoaded(true)
    onError?.()
  }, [onError])

  // 图片 URL 处理
  const imageUrl = error && errorImage ? errorImage : src

  // 容器样式
  const containerStyle: React.CSSProperties = {
    width: typeof width === 'number' ? `${width}px` : width,
    height: typeof height === 'number' ? `${height}px` : height,
    position: 'relative',
    overflow: 'hidden',
    ...style,
  }

  // 图片样式
  const imageStyle: React.CSSProperties = {
    width: '100%',
    height: '100%',
    opacity,
    transition: fadeIn ? 'opacity 0.3s ease-in-out' : 'none',
  }

  // 占位符样式
  const placeholderStyle: React.CSSProperties = {
    position: 'absolute',
    top: 0,
    left: 0,
    width: '100%',
    height: '100%',
    backgroundColor: '#f5f5f5',
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center',
  }

  // 默认占位符
  const defaultPlaceholder = (
    <View style={placeholderStyle}>
      <Text className="text-gray-300 text-sm">加载中...</Text>
    </View>
  )

  return (
    <View className={className} style={containerStyle}>
      {/* 占位符 */}
      {!loaded && (
        placeholder ? (
          <Image
            src={placeholder}
            mode={mode}
            style={{ width: '100%', height: '100%', position: 'absolute', top: 0, left: 0 }}
          />
        ) : (
          defaultPlaceholder
        )
      )}

      {/* 实际图片 */}
      <Image
        src={imageUrl}
        mode={mode}
        style={imageStyle}
        lazyLoad={lazyLoad}
        onLoad={handleLoad}
        onError={handleError}
      />

      {/* 错误提示 */}
      {error && !errorImage && (
        <View style={{ ...placeholderStyle, backgroundColor: '#fafafa' }}>
          <Text className="text-gray-400 text-sm">图片加载失败</Text>
        </View>
      )}
    </View>
  )
}
