import { View, Text } from '@tarojs/components'
import { useState, useEffect } from 'react'
import Taro from '@tarojs/taro'
import { 
  LayoutDashboard, 
  Users, 
  Store, 
  ShoppingCart, 
  Ticket, 
  Settings, 
  LogOut,
  ChevronRight,
  Menu,
  X
} from 'lucide-react-taro'
import './index.css'

interface AdminLayoutProps {
  children: React.ReactNode
  title: string
  currentPage?: string
}

const menuItems = [
  { key: 'dashboard', name: '数据概览', icon: LayoutDashboard, path: '/pages/admin/dashboard/index' },
  { key: 'users', name: '用户管理', icon: Users, path: '/pages/admin/users/index' },
  { key: 'merchants', name: '商家管理', icon: Store, path: '/pages/admin/merchants/index' },
  { key: 'orders', name: '订单管理', icon: ShoppingCart, path: '/pages/admin/orders/index' },
  { key: 'coupons', name: '优惠券管理', icon: Ticket, path: '/pages/admin/coupons/index' },
  { key: 'system', name: '系统配置', icon: Settings, path: '/pages/admin/system-config/index' },
]

const AdminLayout: React.FC<AdminLayoutProps> = ({ children, title, currentPage }) => {
  const [adminInfo, setAdminInfo] = useState<any>(null)
  const [sidebarCollapsed, setSidebarCollapsed] = useState(false)
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false)

  useEffect(() => {
    const admin = Taro.getStorageSync('admin_info')
    if (!admin) {
      Taro.redirectTo({ url: '/pages/admin/login/index' })
      return
    }
    setAdminInfo(admin)
    
    // PC端默认展开侧边栏
    if (typeof window !== 'undefined' && window.innerWidth >= 768) {
      setSidebarCollapsed(false)
    }
  }, [])

  const handleLogout = () => {
    Taro.showModal({
      title: '确认退出',
      content: '确定要退出登录吗？',
      success: (res) => {
        if (res.confirm) {
          Taro.removeStorageSync('admin_info')
          Taro.redirectTo({ url: '/pages/admin/login/index' })
        }
      }
    })
  }

  const handleNavigate = (path: string) => {
    setMobileMenuOpen(false)
    Taro.navigateTo({ url: path })
  }

  return (
    <View className="admin-layout">
      {/* PC端侧边栏 */}
      <View className={`admin-sidebar ${sidebarCollapsed ? 'collapsed' : ''}`}>
        {/* Logo */}
        <View className="admin-sidebar-header">
          <View className="admin-logo">
            <LayoutDashboard size={24} color="#14B8A6" />
            {!sidebarCollapsed && (
              <Text className="admin-logo-text">后台管理</Text>
            )}
          </View>
        </View>

        {/* 菜单 */}
        <View className="admin-sidebar-menu">
          {menuItems.map((item) => {
            const Icon = item.icon
            const isActive = currentPage === item.key
            return (
              <View
                key={item.key}
                className={`admin-menu-item ${isActive ? 'active' : ''}`}
                onClick={() => handleNavigate(item.path)}
              >
                <Icon size={20} color={isActive ? '#14B8A6' : '#94a3b8'} />
                {!sidebarCollapsed && (
                  <Text className="admin-menu-text">{item.name}</Text>
                )}
              </View>
            )
          })}
        </View>

        {/* 底部 */}
        <View className="admin-sidebar-footer">
          <View
            className="admin-menu-item"
            onClick={handleLogout}
          >
            <LogOut size={20} color="#94a3b8" />
            {!sidebarCollapsed && (
              <Text className="admin-menu-text">退出登录</Text>
            )}
          </View>
        </View>
      </View>

      {/* 移动端顶部导航 */}
      <View className="admin-mobile-header">
        <View 
          className="admin-mobile-menu-btn"
          onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
        >
          {mobileMenuOpen ? <X size={24} color="#fff" /> : <Menu size={24} color="#fff" />}
        </View>
        <Text className="admin-mobile-title">{title}</Text>
        <View className="admin-mobile-user">
          <Text className="admin-mobile-username">{adminInfo?.nickname || '管理员'}</Text>
        </View>
      </View>

      {/* 移动端菜单遮罩 */}
      {mobileMenuOpen && (
        <View 
          className="admin-mobile-overlay"
          onClick={() => setMobileMenuOpen(false)}
        >
          <View className="admin-mobile-drawer" onClick={(e) => e.stopPropagation()}>
            <View className="admin-drawer-header">
              <Text className="admin-drawer-title">后台管理</Text>
              <Text className="admin-drawer-user">{adminInfo?.nickname || '管理员'}</Text>
            </View>
            <View className="admin-drawer-menu">
              {menuItems.map((item) => {
                const Icon = item.icon
                const isActive = currentPage === item.key
                return (
                  <View
                    key={item.key}
                    className={`admin-drawer-item ${isActive ? 'active' : ''}`}
                    onClick={() => handleNavigate(item.path)}
                  >
                    <View className="admin-drawer-item-left">
                      <Icon size={20} color={isActive ? '#14B8A6' : '#94a3b8'} />
                      <Text className="admin-drawer-item-text">{item.name}</Text>
                    </View>
                    <ChevronRight size={18} color="#64748b" />
                  </View>
                )
              })}
            </View>
            <View className="admin-drawer-footer">
              <View className="admin-drawer-item" onClick={handleLogout}>
                <LogOut size={20} color="#ef4444" />
                <Text className="admin-drawer-item-text text-red-400">退出登录</Text>
              </View>
            </View>
          </View>
        </View>
      )}

      {/* 主内容区 */}
      <View className="admin-main">
        {/* PC端顶部标题栏 */}
        <View className="admin-main-header">
          <Text className="admin-page-title">{title}</Text>
          <View className="admin-user-info">
            <Text className="admin-username">{adminInfo?.nickname || '管理员'}</Text>
          </View>
        </View>

        {/* 内容区 */}
        <View className="admin-content">
          {children}
        </View>
      </View>
    </View>
  )
}

export default AdminLayout
