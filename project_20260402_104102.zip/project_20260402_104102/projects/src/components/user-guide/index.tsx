import { View, Text } from '@tarojs/components'
import Taro from '@tarojs/taro'
import { useState, useEffect, useCallback } from 'react'
import { Button } from '@/components/ui/button'
import { Card, CardContent } from '@/components/ui/card'
import { X, Lightbulb, Gift, Store, Users } from 'lucide-react-taro'

interface GuideStep {
  id: string
  title: string
  description: string
  icon: React.ReactNode
  highlight?: string // 高亮元素选择器
}

interface UserGuideProps {
  guideKey: string // 用于存储进度的唯一标识
  steps: GuideStep[]
  onComplete?: () => void
  onSkip?: () => void
  showSkip?: boolean
  showProgress?: boolean
}

export default function UserGuide({
  guideKey,
  steps,
  onComplete,
  onSkip,
  showSkip = true,
  showProgress = true,
}: UserGuideProps) {
  const [currentStep, setCurrentStep] = useState(0)
  const [visible, setVisible] = useState(false)
  const [completed, setCompleted] = useState(false)

  useEffect(() => {
    // 检查是否已完成引导
    const storageKey = `guide_${guideKey}_completed`
    const isCompleted = Taro.getStorageSync(storageKey)
    
    if (!isCompleted) {
      // 检查是否有未完成的进度
      const progressKey = `guide_${guideKey}_progress`
      const savedProgress = Taro.getStorageSync(progressKey)
      if (savedProgress) {
        setCurrentStep(parseInt(savedProgress, 10))
      }
      setVisible(true)
    } else {
      setCompleted(true)
    }
  }, [guideKey])

  // 保存进度
  const saveProgress = useCallback((step: number) => {
    const progressKey = `guide_${guideKey}_progress`
    Taro.setStorageSync(progressKey, step.toString())
  }, [guideKey])

  // 下一步
  const handleNext = useCallback(() => {
    if (currentStep < steps.length - 1) {
      const nextStep = currentStep + 1
      setCurrentStep(nextStep)
      saveProgress(nextStep)
    } else {
      handleComplete()
    }
  }, [currentStep, steps.length, saveProgress])

  // 跳过
  const handleSkip = useCallback(() => {
    setVisible(false)
    onSkip?.()
  }, [onSkip])

  // 完成
  const handleComplete = useCallback(() => {
    const storageKey = `guide_${guideKey}_completed`
    Taro.setStorageSync(storageKey, 'true')
    
    const progressKey = `guide_${guideKey}_progress`
    Taro.removeStorageSync(progressKey)
    
    setVisible(false)
    setCompleted(true)
    onComplete?.()
  }, [guideKey, onComplete])

  if (!visible || completed) {
    return null
  }

  const step = steps[currentStep]

  return (
    <View 
      className="fixed inset-0 z-50 flex items-center justify-center"
      style={{ backgroundColor: 'rgba(0, 0, 0, 0.7)' }}
    >
      <Card className="w-4/5 max-w-md bg-white rounded-2xl overflow-hidden">
        <CardContent className="p-0">
          {/* 头部 */}
          <View className="flex justify-between items-center p-4 border-b border-gray-100">
            <Text className="text-lg font-semibold text-slate-800">
              新手引导
            </Text>
            {showSkip && (
              <View onClick={handleSkip}>
                <X size={20} color="#9ca3af" />
              </View>
            )}
          </View>

          {/* 内容 */}
          <View className="p-6">
            {/* 图标 */}
            <View className="flex justify-center mb-4">
              <View className="w-16 h-16 rounded-full bg-teal-50 flex items-center justify-center">
                {step.icon}
              </View>
            </View>

            {/* 标题 */}
            <Text className="block text-center text-xl font-semibold text-slate-800 mb-3">
              {step.title}
            </Text>

            {/* 描述 */}
            <Text className="block text-center text-slate-600 leading-relaxed mb-6">
              {step.description}
            </Text>

            {/* 进度指示器 */}
            {showProgress && (
              <View className="flex justify-center gap-2 mb-6">
                {steps.map((_, index) => (
                  <View
                    key={index}
                    className={`w-2 h-2 rounded-full transition-all ${
                      index === currentStep ? 'bg-teal-500 w-6' : 'bg-gray-300'
                    }`}
                  />
                ))}
              </View>
            )}

            {/* 按钮 */}
            <View className="flex gap-3">
              {currentStep > 0 && (
                <Button
                  variant="outline"
                  className="flex-1 rounded-full"
                  onClick={() => setCurrentStep(currentStep - 1)}
                >
                  上一步
                </Button>
              )}
              <Button
                className="flex-1 bg-teal-500 text-white rounded-full"
                onClick={handleNext}
              >
                {currentStep === steps.length - 1 ? '完成' : '下一步'}
              </Button>
            </View>
          </View>
        </CardContent>
      </Card>
    </View>
  )
}

// 预定义的引导步骤
export const GUIDE_STEPS = {
  // 首页引导
  HOME: [
    {
      id: 'welcome',
      title: '欢迎来到厦门本地生活',
      description: 'AI驱动的本地生活平台，为您提供最优质的商家推荐和服务',
      icon: <Lightbulb size={32} color="#14B8A6" />,
    },
    {
      id: 'ai_recommend',
      title: 'AI智能推荐',
      description: '根据您的位置和偏好，AI会为您推荐最合适的商家和优惠',
      icon: <Gift size={32} color="#14B8A6" />,
    },
    {
      id: 'region',
      title: '岛内外分区',
      description: '支持厦门岛内外分区浏览，快速找到附近的优质商家',
      icon: <Store size={32} color="#14B8A6" />,
    },
  ],

  // 商家端引导
  MERCHANT: [
    {
      id: 'apply',
      title: '申请商家入驻',
      description: '填写店铺信息，提交营业执照，等待审核通过即可开始营业',
      icon: <Store size={32} color="#14B8A6" />,
    },
    {
      id: 'products',
      title: '商品管理',
      description: '添加商品信息，设置价格和库存，用户即可浏览和下单',
      icon: <Gift size={32} color="#14B8A6" />,
    },
    {
      id: 'verify',
      title: '订单核销',
      description: '用户到店后出示核销码，扫码或输入核销码完成服务',
      icon: <Users size={32} color="#14B8A6" />,
    },
  ],

  // 订单流程引导
  ORDER: [
    {
      id: 'select',
      title: '选择商品',
      description: '浏览商家详情，选择心仪的商品或套餐',
      icon: <Gift size={32} color="#14B8A6" />,
    },
    {
      id: 'pay',
      title: '在线支付',
      description: '支持微信支付，订单生成后获得核销码',
      icon: <Lightbulb size={32} color="#14B8A6" />,
    },
    {
      id: 'verify',
      title: '到店核销',
      description: '凭核销码到店消费，享受优惠服务',
      icon: <Store size={32} color="#14B8A6" />,
    },
  ],
}

// 工具函数：检查是否需要显示引导
export function shouldShowGuide(guideKey: string): boolean {
  const storageKey = `guide_${guideKey}_completed`
  return !Taro.getStorageSync(storageKey)
}

// 工具函数：标记引导为已完成
export function markGuideCompleted(guideKey: string): void {
  const storageKey = `guide_${guideKey}_completed`
  Taro.setStorageSync(storageKey, 'true')
}
