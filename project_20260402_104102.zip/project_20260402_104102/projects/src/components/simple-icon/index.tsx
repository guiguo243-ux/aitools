import { View } from '@tarojs/components'

interface SimpleIconProps {
  name: string
  size?: number
  color?: string
}

// 极简图标组件 - 使用简单几何图形，兼容H5和小程序
const SimpleIcon = ({ name, size = 24, color = '#333' }: SimpleIconProps) => {
  const s = size
  const lw = Math.max(2, Math.round(s / 10)) // 线宽

  // 基础容器样式
  const boxStyle = {
    width: s,
    height: s,
    position: 'relative' as const,
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center',
  }

  // 绝对定位辅助
  const abs = (extra: Record<string, unknown> = {}) => ({
    position: 'absolute' as const,
    ...extra,
  })

  const renderIcon = () => {
    switch (name) {
      // 首页 - 实心房子
      case 'home':
        return (
          <View style={boxStyle}>
            {/* 屋顶 - 三角形用圆形模拟 */}
            <View style={{
              ...abs({ top: s * 0.05 }),
              width: s * 0.7,
              height: s * 0.35,
              backgroundColor: color,
              borderRadius: s * 0.1,
            }}
            />
            {/* 房身 */}
            <View style={{
              ...abs({ bottom: s * 0.05 }),
              width: s * 0.6,
              height: s * 0.45,
              backgroundColor: color,
              borderRadius: s * 0.06,
            }}
            />
            {/* 门 */}
            <View style={{
              ...abs({ bottom: s * 0.05 }),
              width: s * 0.18,
              height: s * 0.25,
              backgroundColor: '#fff',
              borderRadius: s * 0.02,
            }}
            />
          </View>
        )

      // 分类 - 四个方块
      case 'category':
        const bs = (s - 6) / 2
        return (
          <View style={boxStyle}>
            <View style={{ width: s, height: s, display: 'flex', flexDirection: 'row', flexWrap: 'wrap', justifyContent: 'space-between', alignContent: 'space-between' }}>
              <View style={{ width: bs, height: bs, backgroundColor: color, borderRadius: s * 0.08 }} />
              <View style={{ width: bs, height: bs, backgroundColor: color, borderRadius: s * 0.08 }} />
              <View style={{ width: bs, height: bs, backgroundColor: color, borderRadius: s * 0.08 }} />
              <View style={{ width: bs, height: bs, backgroundColor: color, borderRadius: s * 0.08 }} />
            </View>
          </View>
        )

      // 消息 - 对话框
      case 'message':
        return (
          <View style={boxStyle}>
            <View style={{
              width: s * 0.65,
              height: s * 0.45,
              backgroundColor: color,
              borderRadius: s * 0.1,
            }}
            />
            <View style={{
              ...abs({ bottom: s * 0.05, left: s * 0.12 }),
              width: s * 0.12,
              height: s * 0.12,
              backgroundColor: color,
              transform: 'rotate(45deg)',
            }}
            />
          </View>
        )

      // 用户 - 头+身
      case 'user':
        return (
          <View style={boxStyle}>
            {/* 头 */}
            <View style={{
              ...abs({ top: s * 0.05 }),
              width: s * 0.35,
              height: s * 0.35,
              backgroundColor: color,
              borderRadius: s * 0.5,
            }}
            />
            {/* 身体 */}
            <View style={{
              ...abs({ bottom: s * 0.02 }),
              width: s * 0.55,
              height: s * 0.35,
              backgroundColor: color,
              borderRadius: s * 0.25,
            }}
            />
          </View>
        )

      // 订单 - 文档
      case 'order':
        return (
          <View style={boxStyle}>
            <View style={{ ...abs({ top: s * 0.1 }), width: s * 0.6, height: lw * 1.3, backgroundColor: color, borderRadius: lw }} />
            <View style={{ ...abs({ top: s * 0.3 }), width: s * 0.45, height: lw * 1.3, backgroundColor: color, borderRadius: lw }} />
            <View style={{ ...abs({ top: s * 0.5 }), width: s * 0.55, height: lw * 1.3, backgroundColor: color, borderRadius: lw }} />
            <View style={{ ...abs({ top: s * 0.7 }), width: s * 0.35, height: lw * 1.3, backgroundColor: color, borderRadius: lw }} />
          </View>
        )

      // 礼物/红包
      case 'gift':
        return (
          <View style={boxStyle}>
            <View style={{
              width: s * 0.55,
              height: s * 0.45,
              backgroundColor: color,
              borderRadius: s * 0.06,
            }}
            />
            <View style={{
              ...abs(),
              width: lw * 1.3,
              height: s * 0.55,
              backgroundColor: '#fff',
            }}
            />
            <View style={{
              ...abs(),
              width: s * 0.55,
              height: lw * 1.3,
              backgroundColor: '#fff',
            }}
            />
          </View>
        )

      // 分享 - 两个圆+线
      case 'share':
        return (
          <View style={boxStyle}>
            <View style={{
              ...abs({ top: 0, left: 0 }),
              width: s * 0.35,
              height: s * 0.35,
              backgroundColor: color,
              borderRadius: s * 0.5,
            }}
            />
            <View style={{
              ...abs({ bottom: 0, right: 0 }),
              width: s * 0.35,
              height: s * 0.35,
              backgroundColor: color,
              borderRadius: s * 0.5,
            }}
            />
            <View style={{
              ...abs({ top: s * 0.18, left: s * 0.18 }),
              width: s * 0.45,
              height: lw * 1.3,
              backgroundColor: color,
              transform: 'rotate(45deg)',
            }}
            />
          </View>
        )

      // 钱包
      case 'wallet':
        return (
          <View style={boxStyle}>
            <View style={{
              width: s * 0.7,
              height: s * 0.45,
              backgroundColor: color,
              borderRadius: s * 0.06,
            }}
            />
            <View style={{
              ...abs({ right: s * 0.08 }),
              width: s * 0.15,
              height: s * 0.18,
              backgroundColor: '#fff',
              borderRadius: lw,
            }}
            />
          </View>
        )

      // 位置 - 定位针
      case 'location':
        return (
          <View style={boxStyle}>
            <View style={{
              width: s * 0.5,
              height: s * 0.5,
              backgroundColor: color,
              borderRadius: s * 0.5,
            }}
            />
            <View style={{
              ...abs({ bottom: 0 }),
              width: 0,
              height: 0,
              borderTopWidth: s * 0.15,
              borderLeftWidth: s * 0.12,
              borderRightWidth: s * 0.12,
              borderTopColor: color,
              borderLeftColor: 'transparent',
              borderRightColor: 'transparent',
            }}
            />
            <View style={{
              ...abs(),
              width: s * 0.18,
              height: s * 0.18,
              backgroundColor: '#fff',
              borderRadius: s * 0.5,
            }}
            />
          </View>
        )

      // 反馈
      case 'feedback':
        return (
          <View style={boxStyle}>
            <View style={{
              width: s * 0.6,
              height: s * 0.4,
              backgroundColor: color,
              borderRadius: s * 0.08,
            }}
            />
            <View style={{
              ...abs({ bottom: s * 0.05, left: s * 0.12 }),
              width: s * 0.1,
              height: s * 0.1,
              backgroundColor: color,
              transform: 'rotate(45deg)',
            }}
            />
          </View>
        )

      // 设置 - 齿轮
      case 'settings':
        return (
          <View style={boxStyle}>
            <View style={{
              width: s * 0.65,
              height: s * 0.65,
              borderWidth: lw * 1.5,
              borderColor: color,
              borderRadius: s * 0.5,
            }}
            />
            <View style={{
              ...abs(),
              width: s * 0.25,
              height: s * 0.25,
              backgroundColor: color,
              borderRadius: s * 0.5,
            }}
            />
          </View>
        )

      // 搜索 - 放大镜
      case 'search':
        return (
          <View style={boxStyle}>
            <View style={{
              width: s * 0.5,
              height: s * 0.5,
              borderWidth: lw * 1.5,
              borderColor: color,
              borderRadius: s * 0.5,
            }}
            />
            <View style={{
              ...abs({ bottom: s * 0.02, right: 0 }),
              width: s * 0.3,
              height: lw * 1.5,
              backgroundColor: color,
              borderRadius: lw,
              transform: 'rotate(45deg)',
            }}
            />
          </View>
        )

      // 星星 - 菱形
      case 'star':
        return (
          <View style={boxStyle}>
            <View style={{
              width: s * 0.55,
              height: s * 0.55,
              backgroundColor: color,
              borderRadius: s * 0.1,
              transform: 'rotate(45deg)',
            }}
            />
          </View>
        )

      // 箭头右
      case 'arrow-right':
        return (
          <View style={boxStyle}>
            <View style={{
              width: s * 0.3,
              height: s * 0.3,
              borderRightWidth: lw * 2,
              borderBottomWidth: lw * 2,
              borderColor: color,
              transform: 'rotate(-45deg)',
            }}
            />
          </View>
        )

      // 箭头左
      case 'arrow-left':
        return (
          <View style={boxStyle}>
            <View style={{
              width: s * 0.3,
              height: s * 0.3,
              borderLeftWidth: lw * 2,
              borderTopWidth: lw * 2,
              borderColor: color,
              transform: 'rotate(-45deg)',
            }}
            />
          </View>
        )

      // 关闭 - X
      case 'close':
        return (
          <View style={boxStyle}>
            <View style={{
              ...abs(),
              width: s * 0.55,
              height: lw * 1.5,
              backgroundColor: color,
              borderRadius: lw,
              transform: 'rotate(45deg)',
            }}
            />
            <View style={{
              ...abs(),
              width: s * 0.55,
              height: lw * 1.5,
              backgroundColor: color,
              borderRadius: lw,
              transform: 'rotate(-45deg)',
            }}
            />
          </View>
        )

      // 勾选
      case 'check':
        return (
          <View style={boxStyle}>
            <View style={{
              width: s * 0.35,
              height: s * 0.18,
              borderLeftWidth: lw * 2,
              borderBottomWidth: lw * 2,
              borderColor: color,
              transform: 'rotate(-45deg)',
            }}
            />
          </View>
        )

      // 加号
      case 'plus':
        return (
          <View style={boxStyle}>
            <View style={{
              ...abs(),
              width: s * 0.5,
              height: lw * 1.5,
              backgroundColor: color,
              borderRadius: lw,
            }}
            />
            <View style={{
              ...abs(),
              width: lw * 1.5,
              height: s * 0.5,
              backgroundColor: color,
              borderRadius: lw,
            }}
            />
          </View>
        )

      // AI - 机器人
      case 'ai':
        return (
          <View style={boxStyle}>
            <View style={{
              width: s * 0.55,
              height: s * 0.4,
              backgroundColor: color,
              borderRadius: s * 0.08,
            }}
            />
            <View style={{
              ...abs({ left: s * 0.15 }),
              width: s * 0.1,
              height: s * 0.1,
              backgroundColor: '#fff',
              borderRadius: s * 0.5,
            }}
            />
            <View style={{
              ...abs({ right: s * 0.15 }),
              width: s * 0.1,
              height: s * 0.1,
              backgroundColor: '#fff',
              borderRadius: s * 0.5,
            }}
            />
          </View>
        )

      // 美食 - 碗
      case 'food':
        return (
          <View style={boxStyle}>
            {/* 碗 */}
            <View style={{
              ...abs({ bottom: s * 0.08 }),
              width: s * 0.6,
              height: s * 0.32,
              backgroundColor: color,
              borderRadius: s * 0.06,
            }}
            />
            {/* 筷子 */}
            <View style={{
              ...abs({ top: s * 0.05, left: s * 0.22 }),
              width: lw * 1.2,
              height: s * 0.45,
              backgroundColor: color,
              borderRadius: lw,
              transform: 'rotate(-20deg)',
            }}
            />
            <View style={{
              ...abs({ top: s * 0.05, right: s * 0.22 }),
              width: lw * 1.2,
              height: s * 0.45,
              backgroundColor: color,
              borderRadius: lw,
              transform: 'rotate(20deg)',
            }}
            />
          </View>
        )

      // 购物袋
      case 'shop':
        return (
          <View style={boxStyle}>
            {/* 袋子 */}
            <View style={{
              ...abs({ bottom: 0 }),
              width: s * 0.6,
              height: s * 0.45,
              backgroundColor: color,
              borderRadius: s * 0.06,
            }}
            />
            {/* 提手 */}
            <View style={{
              ...abs({ top: s * 0.05 }),
              width: s * 0.32,
              height: s * 0.2,
              borderWidth: lw * 1.2,
              borderColor: color,
              borderBottomWidth: 0,
              borderRadius: s * 0.5,
            }}
            />
          </View>
        )

      // 心形
      case 'heart':
        return (
          <View style={boxStyle}>
            <View style={{
              width: s * 0.5,
              height: s * 0.45,
              backgroundColor: color,
              borderRadius: s * 0.1,
              transform: 'rotate(45deg)',
            }}
            />
            <View style={{
              ...abs({ top: 0, left: s * 0.05 }),
              width: s * 0.3,
              height: s * 0.3,
              backgroundColor: color,
              borderRadius: s * 0.5,
            }}
            />
            <View style={{
              ...abs({ top: 0, right: s * 0.05 }),
              width: s * 0.3,
              height: s * 0.3,
              backgroundColor: color,
              borderRadius: s * 0.5,
            }}
            />
          </View>
        )

      // 火焰 - 水滴形
      case 'fire':
        return (
          <View style={boxStyle}>
            <View style={{
              width: s * 0.4,
              height: s * 0.6,
              backgroundColor: color,
              borderRadius: s * 0.5,
            }}
            />
          </View>
        )

      // 礼盒
      case 'box':
        return (
          <View style={boxStyle}>
            <View style={{
              width: s * 0.55,
              height: s * 0.55,
              backgroundColor: color,
              borderRadius: s * 0.05,
            }}
            />
            <View style={{
              ...abs(),
              width: lw * 1.3,
              height: s * 0.6,
              backgroundColor: '#fff',
            }}
            />
            <View style={{
              ...abs(),
              width: s * 0.6,
              height: lw * 1.3,
              backgroundColor: '#fff',
            }}
            />
          </View>
        )

      // 默认 - 圆点
      default:
        return (
          <View style={boxStyle}>
            <View style={{
              width: s * 0.4,
              height: s * 0.4,
              backgroundColor: color,
              borderRadius: s * 0.5,
            }}
            />
          </View>
        )
    }
  }

  return <View style={{ width: s, height: s, display: 'flex', alignItems: 'center', justifyContent: 'center' }}>{renderIcon()}</View>
}

export default SimpleIcon
