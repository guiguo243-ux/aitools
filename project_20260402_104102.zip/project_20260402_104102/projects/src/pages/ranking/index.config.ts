export default typeof definePageConfig === 'function'
  ? definePageConfig({ navigationBarTitleText: '区域榜单' })
  : { navigationBarTitleText: '区域榜单' }
