import { View, Text, ScrollView } from '@tarojs/components'
import { useState, useEffect } from 'react'
import Taro from '@tarojs/taro'
import { Card, CardContent } from '@/components/ui/card'
import { Avatar, AvatarImage, AvatarFallback } from '@/components/ui/avatar'
import { Badge } from '@/components/ui/badge'
import { Network } from '@/network'
import { useUserStore } from '@/stores/user'
import { Crown, TrendingUp, TrendingDown, Minus, Gift } from 'lucide-react-taro'

// 排行项
interface RankingItem {
  rank: number
  id: string
  name?: string
  nickname?: string
  avatar?: string
  orders?: number
  rating?: number
  gmv?: number
  referralCount?: number
  referralAmount?: number
  spending?: number
  district?: string
  category?: string
  trend: 'up' | 'down' | 'same'
}

type RankingType = 'merchant' | 'user_referral' | 'user_spending'
type TimeRange = 'daily' | 'weekly' | 'monthly'

const RankingPage = () => {
  const [activeTab, setActiveTab] = useState<RankingType>('merchant')
  const [timeRange, setTimeRange] = useState<TimeRange>('weekly')
  const [rankings, setRankings] = useState<RankingItem[]>([])
  const [loading, setLoading] = useState(false)
  const [userRank, setUserRank] = useState<{ rank: number; value: number; reward: number } | null>(null)

  // 获取用户信息
  const { userInfo } = useUserStore()
  const userId = userInfo?.id || Taro.getStorageSync('user_id') || ''
  const region = userInfo?.region || ''

  useEffect(() => {
    fetchRankings()
  }, [activeTab, timeRange, region])

  const fetchRankings = async () => {
    setLoading(true)
    try {
      let url = '/api/ranking/'
      const params: Record<string, string> = { timeRange }
      
      if (activeTab === 'merchant') {
        url += 'merchant'
        if (region) params.region = region
      } else if (activeTab === 'user_referral') {
        url += 'user-referral'
      } else {
        url += 'user-spending'
        if (region) params.region = region
      }

      const res = await Network.request({
        url,
        method: 'GET',
        data: params
      })

      console.log('Rankings response:', res.data)

      if (res.data?.code === 200) {
        setRankings(res.data.data?.rankings || [])
      } else {
        setRankings(getMockRankings(activeTab))
      }

      // 获取用户排名
      fetchUserRank()
    } catch (error) {
      console.error('Fetch rankings error:', error)
      setRankings(getMockRankings(activeTab))
    } finally {
      setLoading(false)
    }
  }

  const fetchUserRank = async () => {
    try {
      const res = await Network.request({
        url: '/api/ranking/user-rank',
        method: 'GET',
        data: { userId, type: activeTab, timeRange }
      })

      if (res.data?.code === 200) {
        setUserRank(res.data.data)
      }
    } catch (error) {
      console.error('Fetch user rank error:', error)
    }
  }

  // 模拟数据
  const getMockRankings = (type: RankingType): RankingItem[] => {
    if (type === 'merchant') {
      return [
        { rank: 1, id: 'm1', name: '老厦门沙茶面', orders: 1234, rating: 4.9, gmv: 45600, district: '思明区', trend: 'up' },
        { rank: 2, id: 'm2', name: '鼓浪屿海鲜大排档', orders: 987, rating: 4.8, gmv: 38900, district: '思明区', trend: 'up' },
        { rank: 3, id: 'm3', name: '曾厝垵小吃街', orders: 876, rating: 4.7, gmv: 32100, district: '思明区', trend: 'down' },
        { rank: 4, id: 'm4', name: '集美学村奶茶店', orders: 765, rating: 4.8, gmv: 28700, district: '集美区', trend: 'up' },
        { rank: 5, id: 'm5', name: '海沧湾民宿', orders: 654, rating: 4.9, gmv: 98100, district: '海沧区', trend: 'same' },
      ]
    } else if (type === 'user_referral') {
      return [
        { rank: 1, id: 'u1', nickname: '小明同学', referralCount: 28, referralAmount: 168, trend: 'up' },
        { rank: 2, id: 'u2', nickname: '厦门吃货', referralCount: 24, referralAmount: 144, trend: 'same' },
        { rank: 3, id: 'u3', nickname: '旅游达人', referralCount: 21, referralAmount: 126, trend: 'down' },
        { rank: 4, id: 'u4', nickname: '生活家', referralCount: 18, referralAmount: 108, trend: 'up' },
        { rank: 5, id: 'u5', nickname: '本地通', referralCount: 15, referralAmount: 90, trend: 'same' },
      ]
    } else {
      return [
        { rank: 1, id: 'u1', nickname: '消费达人', spending: 3280, trend: 'up' },
        { rank: 2, id: 'u2', nickname: '生活家', spending: 2560, trend: 'same' },
        { rank: 3, id: 'u3', nickname: '美食控', spending: 1890, trend: 'up' },
        { rank: 4, id: 'u4', nickname: '宅男', spending: 1540, trend: 'down' },
        { rank: 5, id: 'u5', nickname: '购物狂', spending: 1230, trend: 'up' },
      ]
    }
  }

  const getRankIcon = (rank: number) => {
    if (rank === 1) return <Crown size={24} color="#FFD700" />
    if (rank === 2) return <View className="w-6 h-6 rounded-full bg-slate-300 flex items-center justify-center"><Text className="text-white text-xs font-bold">2</Text></View>
    if (rank === 3) return <View className="w-6 h-6 rounded-full bg-amber-600 flex items-center justify-center"><Text className="text-white text-xs font-bold">3</Text></View>
    return <Text className="text-slate-500 font-bold">{rank}</Text>
  }

  const getTrendIcon = (trend: 'up' | 'down' | 'same') => {
    if (trend === 'up') return <TrendingUp size={16} color="#10B981" />
    if (trend === 'down') return <TrendingDown size={16} color="#EF4444" />
    return <Minus size={16} color="#9ca3af" />
  }

  const getRewardText = (rank: number) => {
    if (rank === 1) return '50元红包'
    if (rank === 2) return '30元红包'
    if (rank === 3) return '20元红包'
    if (rank <= 10) return '10元红包'
    return ''
  }

  const renderMerchantItem = (item: RankingItem) => (
    <Card className="mb-2">
      <CardContent className="p-3 flex items-center gap-3">
        <View className="w-8 h-8 flex items-center justify-center">
          {getRankIcon(item.rank)}
        </View>
        <View className="flex-1">
          <View className="flex items-center gap-2">
            <Text className="font-semibold text-zinc-800">{item.name}</Text>
            <Badge variant="secondary" className="text-xs">{item.district}</Badge>
          </View>
          <View className="flex items-center gap-3 mt-1">
            <Text className="text-xs text-zinc-500">订单 {item.orders}</Text>
            <Text className="text-xs text-zinc-500">评分 {item.rating}</Text>
          </View>
        </View>
        <View className="flex items-center gap-1">
          {getTrendIcon(item.trend)}
        </View>
      </CardContent>
    </Card>
  )

  const renderUserItem = (item: RankingItem) => (
    <Card className="mb-2">
      <CardContent className="p-3 flex items-center gap-3">
        <View className="w-8 h-8 flex items-center justify-center">
          {getRankIcon(item.rank)}
        </View>
        <Avatar className="w-10 h-10">
          <AvatarImage src={item.avatar || ''} />
          <AvatarFallback>{(item.nickname || '用户').charAt(0)}</AvatarFallback>
        </Avatar>
        <View className="flex-1">
          <Text className="font-semibold text-zinc-800">{item.nickname || '用户'}</Text>
          <Text className="text-xs text-zinc-500">
            {activeTab === 'user_referral' 
              ? `邀请${item.referralCount}人 · ¥${item.referralAmount}` 
              : `消费¥${item.spending}`}
          </Text>
        </View>
        <View className="flex items-center gap-2">
          {item.rank <= 10 && (
            <Badge className="bg-teal-100 text-teal-600 text-xs">
              <Gift size={12} color="#14B8A6" />
              <Text className="ml-1">{getRewardText(item.rank)}</Text>
            </Badge>
          )}
          {getTrendIcon(item.trend)}
        </View>
      </CardContent>
    </Card>
  )

  return (
    <View className="min-h-screen bg-zinc-50">
      {/* 顶部Tab */}
      <View className="bg-white px-4 pt-2 pb-3 sticky top-0 z-10">
        <View className="flex gap-2">
          <View
            className={`flex-1 py-3 rounded-xl text-center ${
              activeTab === 'merchant'
                ? 'bg-teal-500 shadow-lg shadow-teal-500'
                : 'bg-slate-100'
            }`}
            onClick={() => setActiveTab('merchant')}
          >
            <Text className={activeTab === 'merchant' ? 'text-white font-semibold' : 'text-slate-500'}>
              商家人气
            </Text>
          </View>
          <View
            className={`flex-1 py-3 rounded-xl text-center ${
              activeTab === 'user_referral'
                ? 'bg-teal-500 shadow-lg shadow-teal-500'
                : 'bg-slate-100'
            }`}
            onClick={() => setActiveTab('user_referral')}
          >
            <Text className={activeTab === 'user_referral' ? 'text-white font-semibold' : 'text-slate-500'}>
              推广达人
            </Text>
          </View>
          <View
            className={`flex-1 py-3 rounded-xl text-center ${
              activeTab === 'user_spending'
                ? 'bg-teal-500 shadow-lg shadow-teal-500'
                : 'bg-slate-100'
            }`}
            onClick={() => setActiveTab('user_spending')}
          >
            <Text className={activeTab === 'user_spending' ? 'text-white font-semibold' : 'text-slate-500'}>
              消费达人
            </Text>
          </View>
        </View>

        {/* 时间范围 */}
        <View className="flex items-center justify-center gap-4 mt-3">
          {['daily', 'weekly', 'monthly'].map((t) => (
            <View 
              key={t}
              className={`px-4 py-2 rounded-full ${timeRange === t ? 'bg-teal-500 shadow-lg shadow-teal-500' : 'bg-slate-100'}`}
              onClick={() => setTimeRange(t as TimeRange)}
            >
              <Text className={`text-sm ${timeRange === t ? 'text-white font-semibold' : 'text-slate-500'}`}>
                {t === 'daily' ? '日榜' : t === 'weekly' ? '周榜' : '月榜'}
              </Text>
            </View>
          ))}
        </View>
      </View>

      <ScrollView scrollY className="px-4 mt-4" style={{ height: 'calc(100vh - 140px)' }}>
        {/* 我的排名 */}
        {userRank && activeTab !== 'merchant' && (
          <Card className="mb-4 bg-gradient-to-r from-teal-500 to-teal-400 border-0">
            <CardContent className="p-4 flex items-center justify-between">
              <View>
                <Text className="text-white text-opacity-80 text-sm">我的排名</Text>
                <Text className="text-white text-2xl font-bold">第 {userRank.rank} 名</Text>
              </View>
              {userRank.reward > 0 && (
                <Badge className="bg-white text-teal-500">
                  <Gift size={14} color="#14B8A6" />
                  <Text className="ml-1 text-xs">可领{userRank.reward}元</Text>
                </Badge>
              )}
            </CardContent>
          </Card>
        )}

        {/* 榜单说明 */}
        <View className="mb-3">
          <Text className="text-zinc-500 text-xs">
            {activeTab === 'merchant' && '按订单量排名，TOP10商家获得推广金奖励'}
            {activeTab === 'user_referral' && '按邀请人数排名，TOP10用户获得红包奖励'}
            {activeTab === 'user_spending' && '按消费金额排名，TOP10用户获得返现奖励'}
          </Text>
        </View>

        {/* 榜单列表 */}
        {loading ? (
          <View className="flex items-center justify-center py-8">
            <Text className="text-zinc-400">加载中...</Text>
          </View>
        ) : rankings.length > 0 ? (
          rankings.map((item) => (
            <View key={item.id}>
              {activeTab === 'merchant' ? renderMerchantItem(item) : renderUserItem(item)}
            </View>
          ))
        ) : (
          <View className="flex flex-col items-center justify-center py-8">
            <TrendingUp size={48} color="#9ca3af" />
            <Text className="text-slate-400 mt-2">暂无排行数据</Text>
          </View>
        )}

        {/* 底部留白 */}
        <View className="h-8" />
      </ScrollView>
    </View>
  )
}

export default RankingPage
