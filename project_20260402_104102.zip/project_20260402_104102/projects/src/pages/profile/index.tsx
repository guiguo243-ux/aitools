import { View, Text, ScrollView } from '@tarojs/components'
import { useEffect } from 'react'
import Taro from '@tarojs/taro'
import { Card, CardContent } from '@/components/ui/card'
import { Avatar, AvatarImage, AvatarFallback } from '@/components/ui/avatar'
import { Button } from '@/components/ui/button'
import { useUserStore } from '@/stores/user'
import { ChevronRight, User, Receipt, Gift, Share2, Wallet, MapPin, MessageSquare, Settings, Store } from 'lucide-react-taro'
import './index.css'

const menuItems = [
  { id: 'orders', name: '我的订单', icon: 'receipt', color: '#14B8A6', bg: 'bg-teal-500' },
  { id: 'red-packet', name: '我的红包', icon: 'gift', color: '#14B8A6', bg: 'bg-teal-500' },
  { id: 'referral', name: '邀请好友', icon: 'share', color: '#14B8A6', bg: 'bg-teal-500' },
  { id: 'wallet', name: '我的钱包', icon: 'wallet', color: '#14B8A6', bg: 'bg-teal-500' },
]

const settingItems = [
  { id: 'merchant', name: '商家入驻', icon: 'store' },
  { id: 'address', name: '收货地址', icon: 'location' },
  { id: 'feedback', name: '意见反馈', icon: 'feedback' },
  { id: 'settings', name: '设置', icon: 'settings' },
]

// 图标映射
const getIcon = (iconName: string, size: number, color: string) => {
  const iconMap: Record<string, React.ReactNode> = {
    'receipt': <Receipt size={size} color={color} />,
    'gift': <Gift size={size} color={color} />,
    'share': <Share2 size={size} color={color} />,
    'wallet': <Wallet size={size} color={color} />,
    'location': <MapPin size={size} color={color} />,
    'feedback': <MessageSquare size={size} color={color} />,
    'settings': <Settings size={size} color={color} />,
    'store': <Store size={size} color={color} />,
  }
  return iconMap[iconName] || <Settings size={size} color={color} />
}

const ProfilePage = () => {
  const { isLoggedIn, userInfo, loadFromStorage } = useUserStore()

  // 初始化时加载存储的登录状态
  useEffect(() => {
    loadFromStorage()
  }, [])

  const handleLogin = () => {
    Taro.navigateTo({ url: '/pages/login/index' })
  }

  const goToPage = (pageId: string) => {
    // 检查登录状态
    if (!isLoggedIn && !['settings', 'feedback'].includes(pageId)) {
      Taro.navigateTo({ url: '/pages/login/index' })
      return
    }

    // 跳转到对应页面
    if (pageId === 'red-packet') {
      Taro.navigateTo({ url: '/pages/red-packet/index' })
    } else if (pageId === 'referral') {
      Taro.navigateTo({ url: '/pages/referral/index' })
    } else if (pageId === 'orders') {
      Taro.navigateTo({ url: '/pages/order/index' })
    } else if (pageId === 'wallet') {
      Taro.navigateTo({ url: '/pages/wallet/index' })
    } else if (pageId === 'address') {
      Taro.navigateTo({ url: '/pages/address/index' })
    } else if (pageId === 'settings') {
      Taro.navigateTo({ url: '/pages/settings/index' })
    } else if (pageId === 'feedback') {
      Taro.navigateTo({ url: '/pages/settings/feedback' })
    } else if (pageId === 'merchant') {
      Taro.navigateTo({ url: '/pages/merchant/portal' })
    } else {
      Taro.showToast({
        title: `功能开发中: ${pageId}`,
        icon: 'none'
      })
    }
  }

  return (
    <View className="min-h-screen bg-gradient-to-b from-slate-50 via-stone-50 to-stone-50">
      <ScrollView scrollY className="h-screen">
        {/* 渐变顶部用户信息 - 青绿色 */}
        <View className="bg-gradient-to-br from-teal-500 to-teal-600 px-4 pt-12 pb-8 rounded-b-[32px]">
          {isLoggedIn && userInfo ? (
            <View 
              className="flex items-center gap-4" 
              onClick={() => Taro.navigateTo({ url: '/pages/edit-profile/index' })}
            >
              <Avatar className="w-18 h-18 border-3 border-white shadow-lg">
                <AvatarImage src={userInfo.avatar || ''} />
                <AvatarFallback className="text-white text-xl" style={{ backgroundColor: 'rgba(255,255,255,0.2)' }}>
                  {userInfo.nickname?.charAt(0) || '用'}
                </AvatarFallback>
              </Avatar>
              <View className="flex-1">
                <Text className="text-white text-xl font-bold block">{userInfo.nickname}</Text>
                <View className="flex items-center gap-2 mt-1">
                  <View className="px-2 py-1 rounded-full backdrop-blur" style={{ backgroundColor: 'rgba(255,255,255,0.2)' }}>
                    <Text className="text-white text-xs">
                      {userInfo.region === 'island_inside' ? '岛内用户' : '岛外用户'}
                    </Text>
                  </View>
                </View>
              </View>
              <View className="w-10 h-10 rounded-full flex items-center justify-center" style={{ backgroundColor: 'rgba(255,255,255,0.2)' }}>
                <ChevronRight size={20} color="#fff" />
              </View>
            </View>
          ) : (
            <View className="flex flex-col items-center py-6">
              <View className="w-20 h-20 rounded-full backdrop-blur flex items-center justify-center mb-3" style={{ backgroundColor: 'rgba(255,255,255,0.2)' }}>
                <User size={40} color="rgba(255,255,255,0.9)" />
              </View>
              <Button 
                className="bg-white text-teal-600 font-semibold px-8 rounded-full shadow-lg"
                onClick={handleLogin}
              >
                点击登录
              </Button>
            </View>
          )}

          {/* 积分和余额统计 */}
          {isLoggedIn && userInfo && (
            <View className="flex items-center justify-around mt-6 pt-5 border-t border-white border-opacity-20">
              <View className="flex flex-col items-center">
                <Text className="text-white text-2xl font-bold">{userInfo.points || 0}</Text>
                <Text className="text-white text-xs mt-1" style={{ opacity: 0.7 }}>积分</Text>
              </View>
              <View className="w-px h-8 bg-white" style={{ opacity: 0.2 }} />
              <View 
                className="flex flex-col items-center"
                onClick={() => Taro.navigateTo({ url: '/pages/wallet/index' })}
              >
                <Text className="text-white text-2xl font-bold">¥{userInfo.balance || 0}</Text>
                <Text className="text-white text-xs mt-1" style={{ opacity: 0.7 }}>余额</Text>
              </View>
              <View className="w-px h-8 bg-white" style={{ opacity: 0.2 }} />
              <View 
                className="flex flex-col items-center"
                onClick={() => Taro.navigateTo({ url: '/pages/coupon-center/index?tab=my' })}
              >
                <Text className="text-white text-2xl font-bold">3</Text>
                <Text className="text-white text-xs mt-1" style={{ opacity: 0.7 }}>优惠券</Text>
              </View>
            </View>
          )}
        </View>

        {/* 功能菜单 - 卡片网格 */}
        <View className="px-4 -mt-4">
          <Card className="bg-white backdrop-blur border-0 shadow-xl shadow-slate-200 rounded-2xl overflow-hidden">
            <CardContent className="p-4">
              <View className="grid grid-cols-4 gap-3">
                {menuItems.map((item) => (
                  <View 
                    key={item.id} 
                    className="flex flex-col items-center gap-2"
                    onClick={() => goToPage(item.id)}
                  >
                    <View className={`w-12 h-12 rounded-2xl ${item.bg} flex items-center justify-center shadow-lg`}>
                      {getIcon(item.icon, 24, '#fff')}
                    </View>
                    <Text className="text-xs text-slate-600 font-medium">{item.name}</Text>
                  </View>
                ))}
              </View>
            </CardContent>
          </Card>
        </View>

        {/* 邀请好友卡片 */}
        <View className="px-4 mt-4">
          <Card className="bg-gradient-to-r from-teal-500 to-teal-600 border-0 shadow-xl shadow-teal-200 overflow-hidden">
            <CardContent className="p-4 flex items-center justify-between">
              <View className="flex items-center gap-3">
                <View className="w-12 h-12 rounded-2xl backdrop-blur flex items-center justify-center" style={{ backgroundColor: 'rgba(255,255,255,0.2)' }}>
                  <Gift size={24} color="#fff" />
                </View>
                <View>
                  <Text className="text-white text-base font-bold block">邀请好友得红包</Text>
                  <Text className="text-white text-xs" style={{ opacity: 0.8 }}>每邀请1人得5元</Text>
                </View>
              </View>
              <View 
                className="px-4 py-2 rounded-full bg-white shadow-md"
                onClick={() => goToPage('referral')}
              >
                <Text className="text-teal-600 text-sm font-semibold">立即邀请</Text>
              </View>
            </CardContent>
          </Card>
        </View>

        {/* 设置列表 */}
        <View className="px-4 mt-4 mb-4">
          <Card className="bg-white backdrop-blur border-0 shadow-lg shadow-slate-200 rounded-2xl overflow-hidden">
            <CardContent className="p-0">
              {settingItems.map((item, index) => (
                <View 
                  key={item.id}
                  className={`flex items-center justify-between p-4 ${index < settingItems.length - 1 ? 'border-b border-slate-100' : ''}`}
                  onClick={() => goToPage(item.id)}
                >
                  <View className="flex items-center gap-3">
                    <View className="w-9 h-9 rounded-xl bg-slate-100 flex items-center justify-center">
                      {getIcon(item.icon, 20, '#64748b')}
                    </View>
                    <Text className="text-sm text-slate-700 font-medium">{item.name}</Text>
                  </View>
                  <ChevronRight size={18} color="#cbd5e1" />
                </View>
              ))}
            </CardContent>
          </Card>
        </View>

        {/* 底部留白 */}
        <View className="h-24" />
      </ScrollView>
    </View>
  )
}

export default ProfilePage
