import { View, Text, ScrollView } from '@tarojs/components'
import { useState, useEffect } from 'react'
import Taro, { useRouter } from '@tarojs/taro'
import { Card, CardContent } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Textarea } from '@/components/ui/textarea'
import { Network } from '@/network'
import { useUserStore } from '@/stores/user'
import { Star, Store } from 'lucide-react-taro'

import './index.css'

// 快捷标签
const quickTags = [
  '味道不错',
  '分量足',
  '环境好',
  '服务态度好',
  '性价比高',
  '上菜快',
  '位置好找',
  '价格实惠'
]

const ReviewPage = () => {
  const router = useRouter()
  const { orderId } = router.params
  
  const { isLoggedIn, userInfo } = useUserStore()
  
  const [rating, setRating] = useState(5)
  const [content, setContent] = useState('')
  const [selectedTags, setSelectedTags] = useState<string[]>([])
  const [isAnonymous, setIsAnonymous] = useState(false)
  const [submitting, setSubmitting] = useState(false)
  const [orderInfo, setOrderInfo] = useState<{
    id: string
    orderNo: string
    merchantName?: string
    merchantId?: string
  } | null>(null)

  useEffect(() => {
    if (!isLoggedIn) {
      Taro.navigateTo({ url: '/pages/login/index' })
      return
    }

    if (orderId) {
      loadOrderInfo()
    }
  }, [orderId, isLoggedIn])

  const loadOrderInfo = async () => {
    try {
      const res = await Network.request<{
        code: number
        data: {
          id: string
          orderNo: string
          merchantId: string
          merchantName: string
        } | null
      }>({
        url: `/api/order/detail/${orderId}`
      })

      if (res.data?.code === 200 && res.data.data) {
        setOrderInfo({
          id: res.data.data.id,
          orderNo: res.data.data.orderNo,
          merchantName: res.data.data.merchantName,
          merchantId: res.data.data.merchantId
        })
      }
    } catch (error) {
      console.error('Load order info error:', error)
    }
  }

  const toggleTag = (tag: string) => {
    if (selectedTags.includes(tag)) {
      setSelectedTags(selectedTags.filter(t => t !== tag))
    } else {
      if (selectedTags.length < 5) {
        setSelectedTags([...selectedTags, tag])
      }
    }
  }

  const handleSubmit = async () => {
    if (!content.trim()) {
      Taro.showToast({ title: '请输入评价内容', icon: 'none' })
      return
    }

    if (content.length < 10) {
      Taro.showToast({ title: '评价内容至少10个字', icon: 'none' })
      return
    }

    if (!orderId || !userInfo?.id) return

    setSubmitting(true)
    try {
      const res = await Network.request<{
        code: number
        msg: string
        data: any
      }>({
        url: '/api/review/create',
        method: 'POST',
        data: {
          orderId,
          userId: userInfo.id,
          merchantId: orderInfo?.merchantId,
          rating,
          content: content.trim(),
          tags: selectedTags,
          isAnonymous
        }
      })

      console.log('[Review] Submit response:', res.data)

      if (res.data?.code === 200) {
        Taro.showToast({ title: '评价成功', icon: 'success' })
        setTimeout(() => {
          Taro.navigateBack()
        }, 1500)
      } else {
        Taro.showToast({ title: res.data?.msg || '评价失败', icon: 'none' })
      }
    } catch (error) {
      console.error('Submit review error:', error)
      Taro.showToast({ title: '评价失败', icon: 'none' })
    } finally {
      setSubmitting(false)
    }
  }

  const renderStars = () => {
    return (
      <View className="flex items-center justify-center gap-2">
        {[1, 2, 3, 4, 5].map((star) => (
          <View 
            key={star} 
            onClick={() => setRating(star)}
          >
            <Star size={28} color={star <= rating ? "#FFD700" : "#d1d5db"} />
          </View>
        ))}
      </View>
    )
  }

  const getRatingText = () => {
    const texts: Record<number, string> = {
      1: '非常差',
      2: '比较差',
      3: '一般般',
      4: '比较好',
      5: '非常好'
    }
    return texts[rating] || ''
  }

  return (
    <View className="min-h-screen bg-zinc-50">
      <ScrollView scrollY className="h-screen">
        {/* 订单信息 */}
        {orderInfo && (
          <Card className="m-4">
            <CardContent className="p-4">
              <View className="flex items-center gap-3">
                <View className="w-12 h-12 bg-teal-100 rounded-lg flex items-center justify-center">
                  <Store size={24} color="#14B8A6" />
                </View>
                <View className="flex-1">
                  <Text className="text-slate-800 font-medium block">{orderInfo.merchantName}</Text>
                  <Text className="text-slate-400 text-xs">订单号：{orderInfo.orderNo}</Text>
                </View>
              </View>
            </CardContent>
          </Card>
        )}

        {/* 评分 */}
        <Card className="mx-4 mb-4">
          <CardContent className="p-4">
            <Text className="text-zinc-800 font-medium block mb-4">服务评分</Text>
            {renderStars()}
            <Text className="text-teal-500 text-center text-sm mt-2 block">{getRatingText()}</Text>
          </CardContent>
        </Card>

        {/* 快捷标签 */}
        <Card className="mx-4 mb-4">
          <CardContent className="p-4">
            <Text className="text-zinc-800 font-medium block mb-3">快捷标签</Text>
            <View className="flex flex-wrap gap-2">
              {quickTags.map((tag) => (
                <View
                  key={tag}
                  className={`px-3 py-2 rounded-full border ${
                    selectedTags.includes(tag)
                      ? 'border-teal-500 bg-teal-50'
                      : 'border-slate-200 bg-white'
                  }`}
                  onClick={() => toggleTag(tag)}
                >
                  <Text
                    className={`text-sm ${
                      selectedTags.includes(tag) ? 'text-teal-500' : 'text-slate-600'
                    }`}
                  >
                    {tag}
                  </Text>
                </View>
              ))}
            </View>
          </CardContent>
        </Card>

        {/* 评价内容 */}
        <Card className="mx-4 mb-4">
          <CardContent className="p-4">
            <Text className="text-zinc-800 font-medium block mb-3">评价内容</Text>
            <Textarea
              className="min-h-[120px] text-sm"
              placeholder="分享你的消费体验，帮助其他用户做出选择~"
              maxlength={500}
              value={content}
              onInput={(e) => setContent(e.detail.value)}
            />
            <View className="flex justify-between items-center mt-2">
              <Text className="text-xs text-zinc-400">{content.length}/500</Text>
            </View>
          </CardContent>
        </Card>

        {/* 匿名评价 */}
        <Card className="mx-4 mb-4">
          <CardContent className="p-4">
            <View 
              className="flex items-center justify-between"
              onClick={() => setIsAnonymous(!isAnonymous)}
            >
              <View>
                <Text className="text-zinc-800 block">匿名评价</Text>
                <Text className="text-zinc-400 text-xs">开启后，其他用户将看不到你的昵称</Text>
              </View>
              <View className={`w-10 h-6 rounded-full flex items-center ${isAnonymous ? 'bg-teal-500' : 'bg-slate-200'}`}>
                <View className={`w-5 h-5 rounded-full bg-white shadow ${isAnonymous ? 'ml-auto mr-1' : 'ml-1'}`} />
              </View>
            </View>
          </CardContent>
        </Card>

        {/* 提交按钮 */}
        <View className="px-4 py-6">
          <Button
            className="w-full bg-teal-500 text-white py-3"
            disabled={submitting || !content.trim()}
            onClick={handleSubmit}
          >
            {submitting ? '提交中...' : '提交评价'}
          </Button>
        </View>

        {/* 底部留白 */}
        <View className="h-10" />
      </ScrollView>
    </View>
  )
}

export default ReviewPage
