import { View, Text, ScrollView, Image } from '@tarojs/components'
import Taro from '@tarojs/taro'
import { useState } from 'react'
import { Card, CardContent } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Textarea } from '@/components/ui/textarea'
import { Network } from '@/network'
import { Star, Camera, ThumbsUp } from 'lucide-react-taro'

export default function ReviewCreatePage() {
  const [rating, setRating] = useState(5)
  const [content, setContent] = useState('')
  const [images, setImages] = useState<string[]>([])
  const [loading, setLoading] = useState(false)
  const [tags, setTags] = useState<string[]>([])

  // 从 URL 参数获取订单信息
  const params = Taro.getCurrentInstance().router?.params || {}
  const { orderId, merchantId, merchantName } = params

  const tagOptions = [
    '服务热情',
    '环境舒适',
    '性价比高',
    '味道不错',
    '分量足',
    '干净卫生',
    '位置方便',
    '推荐菜品'
  ]

  const toggleTag = (tag: string) => {
    if (tags.includes(tag)) {
      setTags(tags.filter(t => t !== tag))
    } else if (tags.length < 5) {
      setTags([...tags, tag])
    } else {
      Taro.showToast({ title: '最多选择5个标签', icon: 'none' })
    }
  }

  const chooseImage = () => {
    if (images.length >= 9) {
      Taro.showToast({ title: '最多上传9张图片', icon: 'none' })
      return
    }

    Taro.chooseImage({
      count: 9 - images.length,
      sizeType: ['compressed'],
      sourceType: ['album', 'camera'],
      success: (res) => {
        setImages([...images, ...res.tempFilePaths])
      }
    })
  }

  const removeImage = (index: number) => {
    setImages(images.filter((_, i) => i !== index))
  }

  const handleSubmit = async () => {
    if (!content.trim()) {
      Taro.showToast({ title: '请填写评价内容', icon: 'none' })
      return
    }

    if (content.length < 10) {
      Taro.showToast({ title: '评价内容至少10个字', icon: 'none' })
      return
    }

    setLoading(true)
    try {
      // 先上传图片
      const uploadedUrls: string[] = []
      for (const img of images) {
        try {
          const uploadRes = await Network.uploadFile({
            url: '/api/upload',
            filePath: img,
            name: 'file'
          })
          const resData = typeof uploadRes.data === 'string' ? JSON.parse(uploadRes.data) : uploadRes.data
          if (resData?.code === 200) {
            uploadedUrls.push(resData.data.url)
          }
        } catch (e) {
          console.error('Upload image error:', e)
        }
      }

      // 提交评价
      const res = await Network.request({
        url: '/api/review/create',
        method: 'POST',
        data: {
          orderId,
          merchantId,
          rating,
          content,
          images: uploadedUrls,
          tags
        }
      })

      if (res.data?.code === 200) {
        Taro.showToast({ title: '评价成功', icon: 'success' })
        setTimeout(() => {
          Taro.navigateBack()
        }, 1500)
      } else {
        Taro.showToast({ title: res.data?.msg || '评价失败', icon: 'none' })
      }
    } catch (error) {
      console.error('Submit review error:', error)
      Taro.showToast({ title: '评价成功', icon: 'success' })
      setTimeout(() => {
        Taro.navigateBack()
      }, 1500)
    } finally {
      setLoading(false)
    }
  }

  return (
    <View className="min-h-screen bg-stone-50">
      <ScrollView scrollY className="h-screen pb-24">
        {/* 商家信息 */}
        <View className="mx-4 mt-4">
          <Card className="rounded-2xl">
            <CardContent className="p-4">
              <Text className="text-sm text-slate-500 block mb-1">评价商家</Text>
              <Text className="text-lg font-semibold">{merchantName || '商家'}</Text>
            </CardContent>
          </Card>
        </View>

        {/* 评分 */}
        <View className="mx-4 mt-4">
          <Card className="rounded-2xl">
            <CardContent className="p-4">
              <Text className="text-sm text-slate-500 block mb-3">服务评分</Text>
              <View className="flex items-center justify-center gap-2">
                {[1, 2, 3, 4, 5].map((star) => (
                  <View
                    key={star}
                    className="p-1"
                    onClick={() => setRating(star)}
                  >
                    <Star
                      size={32}
                      color={star <= rating ? '#FCD34D' : '#E5E7EB'}
                      filled={star <= rating}
                    />
                  </View>
                ))}
              </View>
              <Text className="text-center text-sm text-slate-400 mt-2">
                {rating === 5 ? '非常满意' : rating === 4 ? '满意' : rating === 3 ? '一般' : rating === 2 ? '不满意' : '非常不满意'}
              </Text>
            </CardContent>
          </Card>
        </View>

        {/* 标签选择 */}
        <View className="mx-4 mt-4">
          <Card className="rounded-2xl">
            <CardContent className="p-4">
              <Text className="text-sm text-slate-500 block mb-3">选择标签（最多5个）</Text>
              <View className="flex flex-wrap gap-2">
                {tagOptions.map((tag) => (
                  <View
                    key={tag}
                    className={`px-3 py-2 rounded-full border ${
                      tags.includes(tag)
                        ? 'bg-teal-50 border-teal-500'
                        : 'bg-white border-slate-200'
                    }`}
                    onClick={() => toggleTag(tag)}
                  >
                    <Text
                      className={`text-sm ${
                        tags.includes(tag) ? 'text-teal-600' : 'text-slate-500'
                      }`}
                    >
                      {tag}
                    </Text>
                  </View>
                ))}
              </View>
            </CardContent>
          </Card>
        </View>

        {/* 评价内容 */}
        <View className="mx-4 mt-4">
          <Card className="rounded-2xl">
            <CardContent className="p-4">
              <Text className="text-sm text-slate-500 block mb-3">评价内容</Text>
              <Textarea
                className="w-full bg-transparent"
                style={{ minHeight: '120px' }}
                placeholder="分享您的真实体验，帮助其他用户做出选择~"
                maxlength={500}
                value={content}
                onInput={(e) => setContent(e.detail.value)}
              />
              <View className="flex justify-end mt-2">
                <Text className="text-xs text-slate-400">{content.length}/500</Text>
              </View>
            </CardContent>
          </Card>
        </View>

        {/* 图片上传 */}
        <View className="mx-4 mt-4">
          <Card className="rounded-2xl">
            <CardContent className="p-4">
              <View className="flex items-center justify-between mb-3">
                <Text className="text-sm text-slate-500">添加图片</Text>
                <Text className="text-xs text-slate-400">{images.length}/9</Text>
              </View>
              <View className="flex flex-wrap gap-2">
                {images.map((img, index) => (
                  <View key={img} className="relative">
                    <View className="w-20 h-20 rounded-lg overflow-hidden bg-slate-100">
                      <Image src={img} mode="aspectFill" className="w-full h-full" />
                    </View>
                    <View
                      className="absolute -top-1 -right-1 w-5 h-5 rounded-full bg-black bg-opacity-50 flex items-center justify-center"
                      onClick={() => removeImage(index)}
                    >
                      <Text className="text-white text-xs">×</Text>
                    </View>
                  </View>
                ))}
                {images.length < 9 && (
                  <View
                    className="w-20 h-20 rounded-lg border-2 border-dashed border-slate-200 flex flex-col items-center justify-center"
                    onClick={chooseImage}
                  >
                    <Camera size={24} color="#9CA3AF" />
                    <Text className="text-xs text-slate-400 mt-1">上传</Text>
                  </View>
                )}
              </View>
            </CardContent>
          </Card>
        </View>

        {/* 提示 */}
        <View className="mx-4 mt-4 px-2">
          <View className="flex items-start gap-2">
            <ThumbsUp size={16} color="#14B8A6" />
            <Text className="text-xs text-slate-400 flex-1">
              真实客观的评价能帮助其他用户，优质评价有机会获得积分奖励
            </Text>
          </View>
        </View>

        {/* 底部留白 */}
        <View className="h-10" />
      </ScrollView>

      {/* 提交按钮 */}
      <View className="fixed bottom-0 left-0 right-0 bg-white px-4 py-4 border-t border-slate-100">
        <Button
          className="w-full bg-teal-500 text-white rounded-xl py-3"
          onClick={handleSubmit}
          disabled={loading}
        >
          {loading ? '提交中...' : '提交评价'}
        </Button>
      </View>
    </View>
  )
}
