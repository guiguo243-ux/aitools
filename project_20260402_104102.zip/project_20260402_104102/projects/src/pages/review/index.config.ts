export default typeof definePageConfig === 'function'
  ? definePageConfig({ navigationBarTitleText: '发表评价' })
  : { navigationBarTitleText: '发表评价' }
