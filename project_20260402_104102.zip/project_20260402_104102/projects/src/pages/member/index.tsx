import { useState, useEffect } from 'react';
import Taro from '@tarojs/taro';
import { View, Text, ScrollView } from '@tarojs/components';
import { Network } from '@/network';
import { Crown, Gift, TrendingUp, ChevronRight, Award } from 'lucide-react-taro';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import './index.css';

interface MemberLevel {
  id: number;
  level: number;
  name: string;
  min_points: number;
  max_points: number | null;
  icon: string | null;
  color: string;
  benefits: string;
  discount: number;
  points_multiplier: number;
}

interface UserMemberInfo {
  level: number;
  levelName: string;
  levelIcon: string | null;
  levelColor: string;
  points: number;
  nextLevel: string | null;
  nextLevelPoints: number | null;
  progress: number;
  benefits: Array<{
    id: string;
    level: number;
    name: string;
    description: string;
    benefit_type: string;
    benefit_value: string;
  }>;
  discount: number;
  pointsMultiplier: number;
}

interface GrowthRecord {
  id: string;
  growth_value: number;
  type: string;
  description: string;
  created_at: string;
}

export default function MemberPage() {
  const [levels, setLevels] = useState<MemberLevel[]>([]);
  const [memberInfo, setMemberInfo] = useState<UserMemberInfo | null>(null);
  const [growthRecords, setGrowthRecords] = useState<GrowthRecord[]>([]);
  const [activeTab, setActiveTab] = useState<'overview' | 'levels' | 'records'>('overview');
  const [loading, setLoading] = useState(true);

  const userId = Taro.getStorageSync('userId') || 'test-user-001';

  useEffect(() => {
    loadData();
  }, [userId]);

  const loadData = async () => {
    setLoading(true);
    try {
      const [levelsRes, memberRes, recordsRes] = await Promise.all([
        Network.request({ url: '/api/member/levels' }),
        Network.request({ url: `/api/member/user-info?userId=${userId}` }),
        Network.request({ url: `/api/member/growth-records?userId=${userId}&pageSize=20` }),
      ]);

      if (levelsRes.data?.data) {
        setLevels(levelsRes.data.data);
      }

      if (memberRes.data?.data) {
        setMemberInfo(memberRes.data.data);
      }

      if (recordsRes.data?.data?.records) {
        setGrowthRecords(recordsRes.data.data.records);
      }
    } catch (error) {
      console.error('加载会员数据失败:', error);
    } finally {
      setLoading(false);
    }
  };

  const getTypeText = (type: string) => {
    const map: Record<string, string> = {
      consume: '消费获得',
      exchange: '积分兑换',
      refund: '退款扣除',
      admin: '系统调整',
      task: '任务奖励',
    };
    return map[type] || type;
  };

  const getTypeIcon = (type: string) => {
    const icons: Record<string, any> = {
      consume: TrendingUp,
      exchange: Gift,
      task: Award,
    };
    return icons[type] || TrendingUp;
  };

  if (loading) {
    return (
      <View className="member-page loading-page">
        <Text className="loading-text">加载中...</Text>
      </View>
    );
  }

  return (
    <View className="member-page">
      {/* 顶部会员卡片 */}
      <View className="member-header" style={{ backgroundColor: memberInfo?.levelColor || '#10b981' }}>
        <View className="member-card">
          <View className="member-info">
            <View className="level-badge">
              <Crown size={24} color="#fff" className="mr-2" />
              <Text className="level-name">{memberInfo?.levelName || '普通会员'}</Text>
            </View>
            <View className="points-info">
              <Text className="points-label">成长值</Text>
              <Text className="points-value">{memberInfo?.points || 0}</Text>
            </View>
          </View>

          {/* 进度条 */}
          {memberInfo?.nextLevel && (
            <View className="progress-section">
              <View className="progress-bar">
                <View className="progress-fill" style={{ width: `${memberInfo.progress}%` }} />
              </View>
              <Text className="progress-text">
                距离 {memberInfo.nextLevel} 还差 {(memberInfo.nextLevelPoints || 0) - memberInfo.points} 成长值
              </Text>
            </View>
          )}

          {/* 会员特权 */}
          <View className="privileges">
            <View className="privilege-item">
              <Text className="privilege-value">{(memberInfo?.discount || 1) * 10}折</Text>
              <Text className="privilege-label">专属折扣</Text>
            </View>
            <View className="privilege-item">
              <Text className="privilege-value">{(memberInfo?.pointsMultiplier || 1) * 100}%</Text>
              <Text className="privilege-label">积分加成</Text>
            </View>
            <View className="privilege-item">
              <Text className="privilege-value">{memberInfo?.benefits?.length || 0}</Text>
              <Text className="privilege-label">专属权益</Text>
            </View>
          </View>
        </View>
      </View>

      {/* Tab切换 */}
      <View className="tab-container">
        <View
          className={`tab-item ${activeTab === 'overview' ? 'active' : ''}`}
          onClick={() => setActiveTab('overview')}
        >
          <Text className="tab-text">会员权益</Text>
        </View>
        <View
          className={`tab-item ${activeTab === 'levels' ? 'active' : ''}`}
          onClick={() => setActiveTab('levels')}
        >
          <Text className="tab-text">等级规则</Text>
        </View>
        <View
          className={`tab-item ${activeTab === 'records' ? 'active' : ''}`}
          onClick={() => setActiveTab('records')}
        >
          <Text className="tab-text">成长记录</Text>
        </View>
      </View>

      <ScrollView scrollY className="content-scroll">
        {/* 会员权益 */}
        {activeTab === 'overview' && (
          <View className="benefits-section">
            <Text className="section-title">我的权益</Text>
            <View className="benefits-list">
              {memberInfo?.benefits?.map((benefit) => (
                <Card key={benefit.id} className="benefit-card">
                  <CardContent className="benefit-content">
                    <Gift size={24} color={memberInfo.levelColor} />
                    <View className="benefit-info">
                      <Text className="benefit-name">{benefit.name}</Text>
                      <Text className="benefit-desc">{benefit.description}</Text>
                    </View>
                    <ChevronRight size={16} color="#999" />
                  </CardContent>
                </Card>
              ))}
            </View>
          </View>
        )}

        {/* 等级规则 */}
        {activeTab === 'levels' && (
          <View className="levels-section">
            <Text className="section-title">会员等级</Text>
            <View className="levels-list">
              {levels.map((level) => (
                <Card
                  key={level.id}
                  className={`level-card ${memberInfo?.level === level.level ? 'current' : ''}`}
                >
                  <CardContent className="level-content">
                    <View className="level-header">
                      <View className="level-icon" style={{ backgroundColor: level.color }}>
                        <Crown size={20} color="#fff" />
                      </View>
                      <View className="level-info">
                        <Text className="level-title">{level.name}</Text>
                        <Text className="level-range">
                          成长值 {level.min_points}
                          {level.max_points ? ` - ${level.max_points}` : '+'}
                        </Text>
                      </View>
                      {memberInfo?.level === level.level && (
                        <Badge className="current-badge">当前等级</Badge>
                      )}
                    </View>
                    <View className="level-benefits">
                      <View className="benefit-tag">
                        <Text className="tag-text">全场{level.discount * 10}折</Text>
                      </View>
                      <View className="benefit-tag">
                        <Text className="tag-text">积分{level.points_multiplier * 100}%加成</Text>
                      </View>
                    </View>
                  </CardContent>
                </Card>
              ))}
            </View>
          </View>
        )}

        {/* 成长记录 */}
        {activeTab === 'records' && (
          <View className="records-section">
            <Text className="section-title">成长记录</Text>
            <View className="records-list">
              {growthRecords.length === 0 ? (
                <View className="empty-state">
                  <Text className="empty-text">暂无成长记录</Text>
                </View>
              ) : (
                growthRecords.map((record) => {
                  const Icon = getTypeIcon(record.type);
                  return (
                    <View key={record.id} className="record-item">
                      <View className="record-icon">
                        <Icon size={20} color={record.growth_value > 0 ? '#10b981' : '#ef4444'} />
                      </View>
                      <View className="record-info">
                        <Text className="record-type">{getTypeText(record.type)}</Text>
                        <Text className="record-desc">{record.description || '-'}</Text>
                        <Text className="record-time">
                          {new Date(record.created_at).toLocaleString('zh-CN')}
                        </Text>
                      </View>
                      <Text className={`record-value ${record.growth_value > 0 ? 'positive' : 'negative'}`}>
                        {record.growth_value > 0 ? '+' : ''}{record.growth_value}
                      </Text>
                    </View>
                  );
                })
              )}
            </View>
          </View>
        )}
      </ScrollView>
    </View>
  );
}
