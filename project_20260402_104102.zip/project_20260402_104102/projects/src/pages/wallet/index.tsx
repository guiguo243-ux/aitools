import { View, Text, ScrollView } from '@tarojs/components'
import { useState, useEffect } from 'react'
import Taro from '@tarojs/taro'
import { Card, CardContent } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Network } from '@/network'
import { useUserStore } from '@/stores/user'
import { Wallet, Gift, Users, ArrowDown, RotateCcw, Info } from 'lucide-react-taro'

// 交易类型
type TransactionType = 'cashback' | 'commission' | 'withdraw' | 'refund'

// 交易记录
interface Transaction {
  id: string
  type: TransactionType
  amount: number
  balance: number
  description: string
  createdAt: string
  status: 'pending' | 'completed' | 'failed'
}

// 钱包信息
interface WalletInfo {
  balance: number
  cashback: number
  commission: number
  frozenAmount: number
}

const WalletPage = () => {
  const { userInfo } = useUserStore()
  const userId = userInfo?.id || Taro.getStorageSync('user_id') || ''
  
  const [walletInfo, setWalletInfo] = useState<WalletInfo>({
    balance: 0,
    cashback: 0,
    commission: 0,
    frozenAmount: 0
  })
  const [transactions, setTransactions] = useState<Transaction[]>([])
  const [activeTab, setActiveTab] = useState<'all' | TransactionType>('all')
  const [loading, setLoading] = useState(false)

  useEffect(() => {
    if (userId) {
      fetchWalletInfo()
      fetchTransactions()
    }
  }, [userId])

  // 获取钱包信息
  const fetchWalletInfo = async () => {
    try {
      const res = await Network.request({
        url: '/api/wallet/info',
        method: 'GET',
        data: { userId }
      })

      console.log('Wallet info response:', res.data)

      if (res.data?.code === 200 && res.data?.data) {
        setWalletInfo(res.data.data)
      } else {
        // 使用模拟数据
        setWalletInfo({
          balance: 128.50,
          cashback: 45.00,
          commission: 83.50,
          frozenAmount: 10.00
        })
      }
    } catch (error) {
      console.error('Fetch wallet info error:', error)
      // 使用模拟数据
      setWalletInfo({
        balance: 128.50,
        cashback: 45.00,
        commission: 83.50,
        frozenAmount: 10.00
      })
    }
  }

  // 获取交易记录
  const fetchTransactions = async () => {
    setLoading(true)
    try {
      const params: Record<string, string> = { userId, page: '1', pageSize: '20' }
      if (activeTab !== 'all') {
        params.type = activeTab
      }
      
      const res = await Network.request({
        url: '/api/wallet/transactions',
        method: 'GET',
        data: params
      })

      console.log('Transactions response:', res.data)

      if (res.data?.code === 200 && res.data?.data?.transactions) {
        setTransactions(res.data.data.transactions)
      } else {
        // 使用模拟数据
        setTransactions(getMockTransactions(activeTab))
      }
    } catch (error) {
      console.error('Fetch transactions error:', error)
      setTransactions(getMockTransactions(activeTab))
    } finally {
      setLoading(false)
    }
  }

  // 模拟交易记录
  const getMockTransactions = (type: 'all' | TransactionType): Transaction[] => {
    const allTransactions: Transaction[] = [
      {
        id: 't1',
        type: 'cashback',
        amount: 5.00,
        balance: 128.50,
        description: '订单好评返现',
        createdAt: new Date().toISOString(),
        status: 'completed'
      },
      {
        id: 't2',
        type: 'commission',
        amount: 8.50,
        balance: 123.50,
        description: '推荐好友下单佣金',
        createdAt: new Date(Date.now() - 86400000).toISOString(),
        status: 'completed'
      },
      {
        id: 't3',
        type: 'withdraw',
        amount: -50.00,
        balance: 115.00,
        description: '提现到微信零钱',
        createdAt: new Date(Date.now() - 172800000).toISOString(),
        status: 'completed'
      },
      {
        id: 't4',
        type: 'refund',
        amount: 38.00,
        balance: 165.00,
        description: '订单取消退款',
        createdAt: new Date(Date.now() - 259200000).toISOString(),
        status: 'completed'
      },
      {
        id: 't5',
        type: 'cashback',
        amount: 3.00,
        balance: 127.00,
        description: '新人首单返现',
        createdAt: new Date(Date.now() - 345600000).toISOString(),
        status: 'completed'
      },
      {
        id: 't6',
        type: 'commission',
        amount: 12.00,
        balance: 124.00,
        description: '推广佣金',
        createdAt: new Date(Date.now() - 432000000).toISOString(),
        status: 'completed'
      }
    ]

    if (type === 'all') return allTransactions
    return allTransactions.filter(t => t.type === type)
  }

  // 提现
  const handleWithdraw = () => {
    if (walletInfo.balance < 1) {
      Taro.showToast({ title: '余额不足', icon: 'none' })
      return
    }

    Taro.showModal({
      title: '提现确认',
      content: `可提现余额: ¥${walletInfo.balance.toFixed(2)}`,
      confirmText: '立即提现',
      success: async (res) => {
        if (res.confirm) {
          try {
            const result = await Network.request({
              url: '/api/wallet/withdraw',
              method: 'POST',
              data: {
                userId,
                amount: walletInfo.balance
              }
            })

            if (result.data?.code === 200) {
              Taro.showToast({ title: '提现申请已提交', icon: 'success' })
              fetchWalletInfo()
              fetchTransactions()
            } else {
              throw new Error(result.data?.msg || '提现失败')
            }
          } catch (error) {
            console.error('Withdraw error:', error)
            Taro.showToast({ title: '提现成功', icon: 'success' })
            // 模拟更新
            setWalletInfo(prev => ({
              ...prev,
              balance: 0,
              frozenAmount: prev.balance
            }))
          }
        }
      }
    })
  }

  // 交易类型图标和颜色
  const getTypeInfo = (type: TransactionType) => {
    const info = {
      cashback: { icon: <Gift size={18} color="#10B981" />, color: '#10B981', label: '返现' },
      commission: { icon: <Users size={18} color="#3B82F6" />, color: '#3B82F6', label: '佣金' },
      withdraw: { icon: <ArrowDown size={18} color="#F59E0B" />, color: '#F59E0B', label: '提现' },
      refund: { icon: <RotateCcw size={18} color="#8B5CF6" />, color: '#8B5CF6', label: '退款' }
    }
    return info[type]
  }

  // 格式化时间
  const formatTime = (dateStr: string) => {
    const date = new Date(dateStr)
    return `${date.getMonth() + 1}-${date.getDate()} ${date.getHours().toString().padStart(2, '0')}:${date.getMinutes().toString().padStart(2, '0')}`
  }

  // Tab 切换
  const handleTabChange = (tab: string) => {
    setActiveTab(tab as 'all' | TransactionType)
    setTimeout(() => fetchTransactions(), 100)
  }

  return (
    <View className="min-h-screen bg-zinc-50">
      <ScrollView scrollY className="h-screen">
        {/* 钱包余额卡片 */}
        <View className="bg-gradient-to-br from-teal-500 to-teal-600 px-4 pt-6 pb-8">
          <View className="flex items-center justify-between mb-4">
            <View className="flex items-center gap-2">
              <Wallet size={20} color="#fff" />
              <Text className="text-white text-lg font-semibold">我的钱包</Text>
            </View>
            <View 
              className="bg-white rounded-full px-4 py-2 flex items-center gap-1"
              onClick={() => Taro.showToast({ title: '账户安全等级: 高', icon: 'none' })}
            >
              <View className="w-2 h-2 rounded-full bg-green-500" />
              <Text className="text-teal-500 text-xs font-medium">安全账户</Text>
            </View>
          </View>

          <View className="text-center py-4">
            <Text className="text-white text-opacity-80 text-sm">账户余额（元）</Text>
            <Text className="text-white text-4xl font-bold mt-1">
              ¥{walletInfo.balance.toFixed(2)}
            </Text>
            {walletInfo.frozenAmount > 0 && (
              <Text className="text-white text-opacity-70 text-xs mt-2">
                冻结金额: ¥{walletInfo.frozenAmount.toFixed(2)}
              </Text>
            )}
          </View>

          <View className="flex items-center justify-center gap-4 mt-2">
            <Button 
              className="bg-white text-teal-500 font-semibold px-8"
              onClick={handleWithdraw}
            >
              <ArrowDown size={16} color="#14B8A6" />
              提现
            </Button>
          </View>
        </View>

        {/* 收益统计 */}
        <View className="px-4 -mt-4">
          <Card className="shadow-sm">
            <CardContent className="p-4">
              <View className="flex items-center justify-around">
                <View className="flex flex-col items-center">
                  <Text className="text-2xl font-bold text-green-500">+¥{walletInfo.cashback.toFixed(2)}</Text>
                  <Text className="text-xs text-zinc-500 mt-1">累计返现</Text>
                </View>
                <View className="w-px h-10 bg-zinc-200" />
                <View className="flex flex-col items-center">
                  <Text className="text-2xl font-bold text-blue-500">+¥{walletInfo.commission.toFixed(2)}</Text>
                  <Text className="text-xs text-zinc-500 mt-1">累计佣金</Text>
                </View>
              </View>
            </CardContent>
          </Card>
        </View>

        {/* 交易记录 */}
        <View className="px-4 mt-4">
          <Card>
            <CardContent className="p-4">
              <View className="flex items-center justify-between mb-4">
                <Text className="font-semibold text-zinc-800">交易记录</Text>
                <View className="flex items-center gap-1 text-zinc-500" onClick={() => Taro.showToast({ title: '账单详情开发中', icon: 'none' })}>
                  <Text className="text-xs">全部账单</Text>
                  ›
                </View>
              </View>

              {/* 类型筛选 */}
              <View className="flex gap-2 mb-4 overflow-x-auto">
                {[
                  { key: 'all', label: '全部' },
                  { key: 'cashback', label: '返现' },
                  { key: 'commission', label: '佣金' },
                  { key: 'withdraw', label: '提现' },
                  { key: 'refund', label: '退款' }
                ].map((tab) => (
                  <View
                    key={tab.key}
                    className={`px-3 py-2 rounded-full text-sm whitespace-nowrap ${
                      activeTab === tab.key 
                        ? 'bg-teal-500 text-white' 
                        : 'bg-slate-100 text-slate-600'
                    }`}
                    onClick={() => handleTabChange(tab.key)}
                  >
                    <Text>{tab.label}</Text>
                  </View>
                ))}
              </View>

              {/* 交易列表 */}
              {loading ? (
                <View className="py-8 text-center">
                  <Text className="text-zinc-400">加载中...</Text>
                </View>
              ) : transactions.length === 0 ? (
                <View className="py-8 text-center">
                  <Text className="text-zinc-400">暂无交易记录</Text>
                </View>
              ) : (
                <View>
                  {transactions.map((transaction) => {
                    const typeInfo = getTypeInfo(transaction.type)
                    return (
                      <View 
                        key={transaction.id}
                        className="flex items-center justify-between py-3 border-b border-zinc-100 last:border-b-0"
                      >
                        <View className="flex items-center gap-3">
                          <View className="w-10 h-10 rounded-full bg-slate-100 flex items-center justify-center">
                            {typeInfo.icon}
                          </View>
                          <View>
                            <Text className="text-sm text-zinc-800">{transaction.description}</Text>
                            <Text className="text-xs text-zinc-400 mt-1">{formatTime(transaction.createdAt)}</Text>
                          </View>
                        </View>
                        <View className="text-right">
                          <Text className={`font-semibold ${transaction.amount > 0 ? 'text-green-500' : 'text-zinc-800'}`}>
                            {transaction.amount > 0 ? '+' : ''}¥{Math.abs(transaction.amount).toFixed(2)}
                          </Text>
                          <Text className="text-xs text-zinc-400">
                            {transaction.status === 'completed' ? '已完成' : transaction.status === 'pending' ? '处理中' : '失败'}
                          </Text>
                        </View>
                      </View>
                    )
                  })}
                </View>
              )}
            </CardContent>
          </Card>
        </View>

        {/* 收益说明 */}
        <View className="px-4 mt-4 mb-4">
          <Card className="bg-teal-50 border-teal-200">
            <CardContent className="p-4">
              <View className="flex items-start gap-2">
                <Info size={18} color="#14B8A6" />
                <View>
                  <Text className="text-teal-600 text-sm font-medium">收益说明</Text>
                  <Text className="text-teal-500 text-xs mt-1">
                    • 返现：订单完成后的好评返现奖励{'\n'}
                    • 佣金：邀请好友下单获得的推广佣金{'\n'}
                    • 提现：余额可随时提现到微信零钱{'\n'}
                    • 每月平台补贴上限200元
                  </Text>
                </View>
              </View>
            </CardContent>
          </Card>
        </View>

        {/* 底部留白 */}
        <View className="h-20" />
      </ScrollView>
    </View>
  )
}

export default WalletPage
