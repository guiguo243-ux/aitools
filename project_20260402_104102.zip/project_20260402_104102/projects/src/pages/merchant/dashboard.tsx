import { useState, useEffect } from 'react'
import { View, Text } from '@tarojs/components'
import Taro from '@tarojs/taro'
import { TrendingUp, ShoppingCart, Check, Users, ChartBarBig } from 'lucide-react-taro'

import { Network } from '@/network'
import { useUserStore } from '@/stores/user'
import { Card, CardContent } from '@/components/ui/card'

interface DashboardData {
  todayRevenue: number
  todayOrders: number
  todayVerified: number
  newCustomers: number
  monthRevenue: number
  monthOrders: number
  monthVerified: number
  revenueTrend: { date: string; amount: number }[]
  topProducts: { name: string; sales: number }[]
}

export default function MerchantDashboardPage() {
  const { userInfo } = useUserStore()
  const [loading, setLoading] = useState(true)
  const [data, setData] = useState<DashboardData | null>(null)

  useEffect(() => {
    loadMerchantAndData()
  }, [])

  const loadMerchantAndData = async () => {
    if (!userInfo?.id) return

    try {
      // 获取商家信息
      const statusRes = await Network.request({
        url: `/api/merchant/status?userId=${userInfo.id}`
      })

      if (statusRes.data.code === 200 && statusRes.data.data?.id) {
        await loadDashboard(statusRes.data.data.id)
      } else {
        Taro.showToast({ title: '请先申请商家入驻', icon: 'none' })
        setTimeout(() => Taro.navigateBack(), 1500)
      }
    } catch (error) {
      console.error('Load merchant error:', error)
    } finally {
      setLoading(false)
    }
  }

  const loadDashboard = async (mId: string) => {
    try {
      const res = await Network.request({
        url: `/api/merchant/dashboard?merchantId=${mId}`
      })

      if (res.data.code === 200) {
        setData(res.data.data)
      }
    } catch (error) {
      console.error('Load dashboard error:', error)
      // 使用模拟数据
      setData({
        todayRevenue: 2580,
        todayOrders: 23,
        todayVerified: 18,
        newCustomers: 5,
        monthRevenue: 68900,
        monthOrders: 486,
        monthVerified: 420,
        revenueTrend: [
          { date: '周一', amount: 2100 },
          { date: '周二', amount: 2400 },
          { date: '周三', amount: 1980 },
          { date: '周四', amount: 2600 },
          { date: '周五', amount: 3100 },
          { date: '周六', amount: 4200 },
          { date: '周日', amount: 3800 }
        ],
        topProducts: [
          { name: '招牌套餐A', sales: 86 },
          { name: '单人套餐', sales: 54 },
          { name: '双人套餐', sales: 42 },
          { name: '儿童套餐', sales: 38 },
          { name: '商务套餐', sales: 26 }
        ]
      })
    }
  }

  if (loading) {
    return (
      <View className="min-h-screen bg-gray-50 flex items-center justify-center">
        <Text className="text-gray-400">加载中...</Text>
      </View>
    )
  }

  if (!data) {
    return (
      <View className="min-h-screen bg-gray-50 flex items-center justify-center">
        <Text className="text-gray-400">暂无数据</Text>
      </View>
    )
  }

  return (
    <View className="min-h-screen bg-gray-50">
      {/* 今日数据 */}
      <View className="bg-gradient-to-r from-teal-500 to-teal-400 px-4 py-4">
        <Text className="text-white text-sm opacity-80">今日营业额</Text>
        <Text className="text-white text-3xl font-bold mt-1">¥{data.todayRevenue.toLocaleString()}</Text>
        <View className="flex items-center mt-2">
          <TrendingUp size={16} color="#ffffff" />
          <Text className="text-white text-xs ml-1">较昨日增长 12%</Text>
        </View>
      </View>

      {/* 核心指标 */}
      <View className="px-4 py-4 -mt-4">
        <Card>
          <CardContent className="p-4">
            <View className="grid grid-cols-3 gap-4">
              <View className="text-center">
                <ShoppingCart size={24} color="#14B8A6" />
                <Text className="text-xl font-bold mt-2">{data.todayOrders}</Text>
                <Text className="text-xs text-gray-500">今日订单</Text>
              </View>
              <View className="text-center">
                <Check size={24} color="#10b981" />
                <Text className="text-xl font-bold mt-2">{data.todayVerified}</Text>
                <Text className="text-xs text-gray-500">已核销</Text>
              </View>
              <View className="text-center">
                <Users size={24} color="#6b7280" />
                <Text className="text-xl font-bold mt-2">{data.newCustomers}</Text>
                <Text className="text-xs text-gray-500">新客数</Text>
              </View>
            </View>
          </CardContent>
        </Card>
      </View>

      {/* 本月汇总 */}
      <View className="px-4 pb-4">
        <Card>
          <CardContent className="p-4">
            <Text className="text-base font-medium mb-3">本月汇总</Text>
            <View className="space-y-3">
              <View className="flex justify-between items-center">
                <Text className="text-gray-500">本月营业额</Text>
                <Text className="text-lg font-bold text-teal-500">¥{data.monthRevenue.toLocaleString()}</Text>
              </View>
              <View className="flex justify-between items-center">
                <Text className="text-gray-500">本月订单数</Text>
                <Text className="font-medium">{data.monthOrders} 单</Text>
              </View>
              <View className="flex justify-between items-center">
                <Text className="text-gray-500">本月核销数</Text>
                <Text className="font-medium">{data.monthVerified} 单</Text>
              </View>
            </View>
          </CardContent>
        </Card>
      </View>

      {/* 营业趋势 */}
      <View className="px-4 pb-4">
        <Card>
          <CardContent className="p-4">
            <View className="flex items-center justify-between mb-3">
              <Text className="text-base font-medium">本周营业趋势</Text>
              <ChartBarBig size={20} color="#14B8A6" />
            </View>
            <View className="flex items-end justify-between h-32 px-2">
              {data.revenueTrend.map((item, index) => {
                const maxAmount = Math.max(...data.revenueTrend.map(t => t.amount))
                const height = (item.amount / maxAmount) * 100
                return (
                  <View key={index} className="flex flex-col items-center">
                    <View 
                      className="w-6 bg-teal-400 rounded-t"
                      style={{ height: `${height}%`, minHeight: '8px' }}
                    />
                    <Text className="text-xs text-gray-400 mt-2">{item.date}</Text>
                  </View>
                )
              })}
            </View>
          </CardContent>
        </Card>
      </View>

      {/* 热销商品 */}
      <View className="px-4 pb-4">
        <Card>
          <CardContent className="p-4">
            <Text className="text-base font-medium mb-3">热销商品 TOP5</Text>
            {data.topProducts.map((product, index) => (
              <View
                key={index}
                className="flex items-center justify-between py-2 border-b border-gray-100 last:border-0"
              >
                <View className="flex items-center">
                  <View
                    className={`w-5 h-5 rounded-full flex items-center justify-center text-xs text-white ${
                      index === 0 ? 'bg-teal-500' : index === 1 ? 'bg-teal-400' : index === 2 ? 'bg-teal-300' : 'bg-gray-300'
                    }`}
                  >
                    {index + 1}
                  </View>
                  <Text className="ml-2">{product.name}</Text>
                </View>
                <Text className="text-gray-500">{product.sales} 份</Text>
              </View>
            ))}
          </CardContent>
        </Card>
      </View>
    </View>
  )
}
