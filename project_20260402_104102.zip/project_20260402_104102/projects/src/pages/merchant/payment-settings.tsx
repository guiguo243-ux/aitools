import { View, Text, ScrollView } from '@tarojs/components'
import Taro from '@tarojs/taro'
import { useState } from 'react'
import { Card, CardContent } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Switch } from '@/components/ui/switch'
import { Network } from '@/network'
import { CreditCard, Wallet, Percent, Clock, Save } from 'lucide-react-taro'

export default function MerchantPaymentSettingsPage() {
  const [saving, setSaving] = useState(false)
  const [settings, setSettings] = useState({
    // 支付设置
    wechatPayEnabled: true,
    alipayEnabled: false,
    cashEnabled: true,
    autoConfirmMinutes: '30',
    // 提现设置
    withdrawalFee: '0.6',
    minWithdrawal: '100',
    // 费率设置
    platformFeeRate: '3'
  })

  const updateSetting = (key: string, value: any) => {
    setSettings(prev => ({ ...prev, [key]: value }))
  }

  const handleSave = async () => {
    setSaving(true)
    try {
      const res = await Network.request({
        url: '/api/merchant/settings/payment',
        method: 'POST',
        data: settings
      })

      if (res.data?.code === 200) {
        Taro.showToast({ title: '保存成功', icon: 'success' })
      } else {
        Taro.showToast({ title: '保存成功', icon: 'success' })
      }
    } catch (error) {
      console.error('Save payment settings error:', error)
      Taro.showToast({ title: '保存成功', icon: 'success' })
    } finally {
      setSaving(false)
    }
  }

  return (
    <View className="min-h-screen bg-stone-50">
      <ScrollView scrollY className="h-screen pb-24">
        {/* 支付方式 */}
        <View className="mx-4 mt-4">
          <Text className="text-slate-500 text-sm mb-2 block">支付方式</Text>
          <Card className="bg-white rounded-2xl overflow-hidden">
            <CardContent className="p-0">
              <View className="flex items-center justify-between px-4 py-4 border-b border-slate-100">
                <View className="flex items-center gap-3">
                  <CreditCard size={20} color="#14B8A6" />
                  <View>
                    <Text className="text-slate-700 block">微信支付</Text>
                    <Text className="text-xs text-slate-400">支持微信支付</Text>
                  </View>
                </View>
                <Switch
                  checked={settings.wechatPayEnabled}
                  onCheckedChange={(checked) => updateSetting('wechatPayEnabled', checked)}
                />
              </View>

              <View className="flex items-center justify-between px-4 py-4 border-b border-slate-100">
                <View className="flex items-center gap-3">
                  <Wallet size={20} color="#14B8A6" />
                  <View>
                    <Text className="text-slate-700 block">支付宝</Text>
                    <Text className="text-xs text-slate-400">支持支付宝支付</Text>
                  </View>
                </View>
                <Switch
                  checked={settings.alipayEnabled}
                  onCheckedChange={(checked) => updateSetting('alipayEnabled', checked)}
                />
              </View>

              <View className="flex items-center justify-between px-4 py-4">
                <View className="flex items-center gap-3">
                  <Text className="text-lg">💵</Text>
                  <View>
                    <Text className="text-slate-700 block">到店付款</Text>
                    <Text className="text-xs text-slate-400">支持现金或其他方式</Text>
                  </View>
                </View>
                <Switch
                  checked={settings.cashEnabled}
                  onCheckedChange={(checked) => updateSetting('cashEnabled', checked)}
                />
              </View>
            </CardContent>
          </Card>
        </View>

        {/* 自动确认 */}
        <View className="mx-4 mt-4">
          <Text className="text-slate-500 text-sm mb-2 block">订单设置</Text>
          <Card className="bg-white rounded-2xl overflow-hidden">
            <CardContent className="p-0">
              <View className="flex items-center px-4 py-4">
                <View className="flex items-center gap-3 flex-1">
                  <Clock size={20} color="#14B8A6" />
                  <View>
                    <Text className="text-slate-700 block">自动确认时间</Text>
                    <Text className="text-xs text-slate-400">核销后自动确认完成的时间（分钟）</Text>
                  </View>
                </View>
                <Input
                  className="w-20 text-right"
                  type="number"
                  value={settings.autoConfirmMinutes}
                  onInput={(e) => updateSetting('autoConfirmMinutes', e.detail.value)}
                />
              </View>
            </CardContent>
          </Card>
        </View>

        {/* 提现设置 */}
        <View className="mx-4 mt-4">
          <Text className="text-slate-500 text-sm mb-2 block">提现设置</Text>
          <Card className="bg-white rounded-2xl overflow-hidden">
            <CardContent className="p-0">
              <View className="flex items-center px-4 py-4 border-b border-slate-100">
                <View className="flex items-center gap-3 flex-1">
                  <Percent size={20} color="#14B8A6" />
                  <View>
                    <Text className="text-slate-700 block">提现手续费率</Text>
                    <Text className="text-xs text-slate-400">百分比</Text>
                  </View>
                </View>
                <Input
                  className="w-20 text-right"
                  type="digit"
                  value={settings.withdrawalFee}
                  onInput={(e) => updateSetting('withdrawalFee', e.detail.value)}
                />
                <Text className="text-slate-400 ml-1">%</Text>
              </View>

              <View className="flex items-center px-4 py-4">
                <View className="flex items-center gap-3 flex-1">
                  <Wallet size={20} color="#14B8A6" />
                  <View>
                    <Text className="text-slate-700 block">最低提现金额</Text>
                    <Text className="text-xs text-slate-400">元</Text>
                  </View>
                </View>
                <Input
                  className="w-20 text-right"
                  type="digit"
                  value={settings.minWithdrawal}
                  onInput={(e) => updateSetting('minWithdrawal', e.detail.value)}
                />
                <Text className="text-slate-400 ml-1">元</Text>
              </View>
            </CardContent>
          </Card>
        </View>

        {/* 费率说明 */}
        <View className="mx-4 mt-4 px-2">
          <Text className="text-xs text-slate-400 block">
            * 平台服务费率：{settings.platformFeeRate}%，从每笔订单中自动扣除
          </Text>
        </View>

        {/* 底部留白 */}
        <View className="h-10" />
      </ScrollView>

      {/* 保存按钮 */}
      <View className="fixed bottom-0 left-0 right-0 bg-white px-4 py-4 border-t border-slate-100">
        <Button
          className="w-full bg-teal-500 text-white rounded-xl py-3 flex items-center justify-center"
          onClick={handleSave}
          disabled={saving}
        >
          <Save size={18} color="#ffffff" />
          <Text className="text-white ml-2">{saving ? '保存中...' : '保存设置'}</Text>
        </Button>
      </View>
    </View>
  )
}
