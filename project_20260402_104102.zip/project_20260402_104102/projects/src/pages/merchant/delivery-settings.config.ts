export default definePageConfig({
  navigationBarTitleText: '配送设置'
})
