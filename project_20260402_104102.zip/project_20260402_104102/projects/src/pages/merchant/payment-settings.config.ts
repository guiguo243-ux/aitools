export default definePageConfig({
  navigationBarTitleText: '支付设置'
})
