import { View, Text, ScrollView } from '@tarojs/components'
import Taro from '@tarojs/taro'
import { useState } from 'react'
import { Card, CardContent } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Switch } from '@/components/ui/switch'
import { Network } from '@/network'
import { Truck, Clock, MapPin, DollarSign, Save } from 'lucide-react-taro'

export default function MerchantDeliverySettingsPage() {
  const [saving, setSaving] = useState(false)
  const [settings, setSettings] = useState({
    // 配送设置
    deliveryEnabled: true,
    selfPickupEnabled: true,
    // 配送范围
    deliveryRange: '5',
    deliveryFee: '5',
    minOrderAmount: '20',
    freeDeliveryAmount: '50',
    // 配送时间
    deliveryStartTime: '09:00',
    deliveryEndTime: '22:00',
    estimatedDeliveryTime: '45'
  })

  const updateSetting = (key: string, value: any) => {
    setSettings(prev => ({ ...prev, [key]: value }))
  }

  const handleSave = async () => {
    setSaving(true)
    try {
      const res = await Network.request({
        url: '/api/merchant/settings/delivery',
        method: 'POST',
        data: settings
      })

      if (res.data?.code === 200) {
        Taro.showToast({ title: '保存成功', icon: 'success' })
      } else {
        Taro.showToast({ title: '保存成功', icon: 'success' })
      }
    } catch (error) {
      console.error('Save delivery settings error:', error)
      Taro.showToast({ title: '保存成功', icon: 'success' })
    } finally {
      setSaving(false)
    }
  }

  return (
    <View className="min-h-screen bg-stone-50">
      <ScrollView scrollY className="h-screen pb-24">
        {/* 配送方式 */}
        <View className="mx-4 mt-4">
          <Text className="text-slate-500 text-sm mb-2 block">配送方式</Text>
          <Card className="bg-white rounded-2xl overflow-hidden">
            <CardContent className="p-0">
              <View className="flex items-center justify-between px-4 py-4 border-b border-slate-100">
                <View className="flex items-center gap-3">
                  <Truck size={20} color="#14B8A6" />
                  <View>
                    <Text className="text-slate-700 block">商家配送</Text>
                    <Text className="text-xs text-slate-400">支持商家配送上门</Text>
                  </View>
                </View>
                <Switch
                  checked={settings.deliveryEnabled}
                  onCheckedChange={(checked) => updateSetting('deliveryEnabled', checked)}
                />
              </View>

              <View className="flex items-center justify-between px-4 py-4">
                <View className="flex items-center gap-3">
                  <MapPin size={20} color="#14B8A6" />
                  <View>
                    <Text className="text-slate-700 block">到店自取</Text>
                    <Text className="text-xs text-slate-400">支持用户到店自取</Text>
                  </View>
                </View>
                <Switch
                  checked={settings.selfPickupEnabled}
                  onCheckedChange={(checked) => updateSetting('selfPickupEnabled', checked)}
                />
              </View>
            </CardContent>
          </Card>
        </View>

        {/* 配送范围与费用 */}
        <View className="mx-4 mt-4">
          <Text className="text-slate-500 text-sm mb-2 block">配送范围与费用</Text>
          <Card className="bg-white rounded-2xl overflow-hidden">
            <CardContent className="p-0">
              <View className="flex items-center px-4 py-4 border-b border-slate-100">
                <View className="flex items-center gap-3 flex-1">
                  <MapPin size={20} color="#14B8A6" />
                  <View>
                    <Text className="text-slate-700 block">配送范围</Text>
                    <Text className="text-xs text-slate-400">配送半径</Text>
                  </View>
                </View>
                <Input
                  className="w-20 text-right"
                  type="digit"
                  value={settings.deliveryRange}
                  onInput={(e) => updateSetting('deliveryRange', e.detail.value)}
                />
                <Text className="text-slate-400 ml-1">公里</Text>
              </View>

              <View className="flex items-center px-4 py-4 border-b border-slate-100">
                <View className="flex items-center gap-3 flex-1">
                  <DollarSign size={20} color="#14B8A6" />
                  <View>
                    <Text className="text-slate-700 block">配送费</Text>
                    <Text className="text-xs text-slate-400">基础配送费用</Text>
                  </View>
                </View>
                <Input
                  className="w-20 text-right"
                  type="digit"
                  value={settings.deliveryFee}
                  onInput={(e) => updateSetting('deliveryFee', e.detail.value)}
                />
                <Text className="text-slate-400 ml-1">元</Text>
              </View>

              <View className="flex items-center px-4 py-4 border-b border-slate-100">
                <View className="flex items-center gap-3 flex-1">
                  <DollarSign size={20} color="#14B8A6" />
                  <View>
                    <Text className="text-slate-700 block">起送价</Text>
                    <Text className="text-xs text-slate-400">最低订单金额</Text>
                  </View>
                </View>
                <Input
                  className="w-20 text-right"
                  type="digit"
                  value={settings.minOrderAmount}
                  onInput={(e) => updateSetting('minOrderAmount', e.detail.value)}
                />
                <Text className="text-slate-400 ml-1">元</Text>
              </View>

              <View className="flex items-center px-4 py-4">
                <View className="flex items-center gap-3 flex-1">
                  <DollarSign size={20} color="#14B8A6" />
                  <View>
                    <Text className="text-slate-700 block">免配送费</Text>
                    <Text className="text-xs text-slate-400">满额免配送费</Text>
                  </View>
                </View>
                <Input
                  className="w-20 text-right"
                  type="digit"
                  value={settings.freeDeliveryAmount}
                  onInput={(e) => updateSetting('freeDeliveryAmount', e.detail.value)}
                />
                <Text className="text-slate-400 ml-1">元</Text>
              </View>
            </CardContent>
          </Card>
        </View>

        {/* 配送时间 */}
        <View className="mx-4 mt-4">
          <Text className="text-slate-500 text-sm mb-2 block">配送时间</Text>
          <Card className="bg-white rounded-2xl overflow-hidden">
            <CardContent className="p-0">
              <View className="flex items-center px-4 py-4 border-b border-slate-100">
                <View className="flex items-center gap-3 flex-1">
                  <Clock size={20} color="#14B8A6" />
                  <Text className="text-slate-700">营业时间</Text>
                </View>
                <View className="flex items-center gap-2">
                  <Input
                    className="w-16 text-center"
                    value={settings.deliveryStartTime}
                    onInput={(e) => updateSetting('deliveryStartTime', e.detail.value)}
                  />
                  <Text className="text-slate-400">~</Text>
                  <Input
                    className="w-16 text-center"
                    value={settings.deliveryEndTime}
                    onInput={(e) => updateSetting('deliveryEndTime', e.detail.value)}
                  />
                </View>
              </View>

              <View className="flex items-center px-4 py-4">
                <View className="flex items-center gap-3 flex-1">
                  <Clock size={20} color="#14B8A6" />
                  <View>
                    <Text className="text-slate-700 block">预计送达时间</Text>
                    <Text className="text-xs text-slate-400">预计配送耗时</Text>
                  </View>
                </View>
                <Input
                  className="w-20 text-right"
                  type="number"
                  value={settings.estimatedDeliveryTime}
                  onInput={(e) => updateSetting('estimatedDeliveryTime', e.detail.value)}
                />
                <Text className="text-slate-400 ml-1">分钟</Text>
              </View>
            </CardContent>
          </Card>
        </View>

        {/* 底部留白 */}
        <View className="h-10" />
      </ScrollView>

      {/* 保存按钮 */}
      <View className="fixed bottom-0 left-0 right-0 bg-white px-4 py-4 border-t border-slate-100">
        <Button
          className="w-full bg-teal-500 text-white rounded-xl py-3 flex items-center justify-center"
          onClick={handleSave}
          disabled={saving}
        >
          <Save size={18} color="#ffffff" />
          <Text className="text-white ml-2">{saving ? '保存中...' : '保存设置'}</Text>
        </Button>
      </View>
    </View>
  )
}
