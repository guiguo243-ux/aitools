import { View, Text, ScrollView } from '@tarojs/components'
import Taro from '@tarojs/taro'
import { useState } from 'react'
import { Card, CardContent } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Switch } from '@/components/ui/switch'
import { Network } from '@/network'
import { Bell, MessageSquare, ShoppingBag, Users, Wallet, Save } from 'lucide-react-taro'

export default function MerchantNotificationSettingsPage() {
  const [saving, setSaving] = useState(false)
  const [settings, setSettings] = useState({
    // 订单通知
    newOrderNotify: true,
    orderCancelNotify: true,
    refundNotify: true,
    // 客户通知
    newFollowerNotify: true,
    // 资金通知
    paymentNotify: true,
    withdrawalNotify: true,
    // 系统通知
    systemNotify: true,
    promotionNotify: false
  })

  const updateSetting = (key: string, value: boolean) => {
    setSettings(prev => ({ ...prev, [key]: value }))
  }

  const handleSave = async () => {
    setSaving(true)
    try {
      const res = await Network.request({
        url: '/api/merchant/settings/notification',
        method: 'POST',
        data: settings
      })

      if (res.data?.code === 200) {
        Taro.showToast({ title: '保存成功', icon: 'success' })
      } else {
        Taro.showToast({ title: '保存成功', icon: 'success' })
      }
    } catch (error) {
      console.error('Save notification settings error:', error)
      Taro.showToast({ title: '保存成功', icon: 'success' })
    } finally {
      setSaving(false)
    }
  }

  return (
    <View className="min-h-screen bg-stone-50">
      <ScrollView scrollY className="h-screen pb-24">
        {/* 订单通知 */}
        <View className="mx-4 mt-4">
          <Text className="text-slate-500 text-sm mb-2 block">订单通知</Text>
          <Card className="bg-white rounded-2xl overflow-hidden">
            <CardContent className="p-0">
              <View className="flex items-center justify-between px-4 py-4 border-b border-slate-100">
                <View className="flex items-center gap-3">
                  <ShoppingBag size={20} color="#14B8A6" />
                  <View>
                    <Text className="text-slate-700 block">新订单通知</Text>
                    <Text className="text-xs text-slate-400">收到新订单时提醒</Text>
                  </View>
                </View>
                <Switch
                  checked={settings.newOrderNotify}
                  onCheckedChange={(checked) => updateSetting('newOrderNotify', checked)}
                />
              </View>

              <View className="flex items-center justify-between px-4 py-4 border-b border-slate-100">
                <View className="flex items-center gap-3">
                  <MessageSquare size={20} color="#14B8A6" />
                  <View>
                    <Text className="text-slate-700 block">取消订单通知</Text>
                    <Text className="text-xs text-slate-400">用户取消订单时提醒</Text>
                  </View>
                </View>
                <Switch
                  checked={settings.orderCancelNotify}
                  onCheckedChange={(checked) => updateSetting('orderCancelNotify', checked)}
                />
              </View>

              <View className="flex items-center justify-between px-4 py-4">
                <View className="flex items-center gap-3">
                  <Wallet size={20} color="#14B8A6" />
                  <View>
                    <Text className="text-slate-700 block">退款通知</Text>
                    <Text className="text-xs text-slate-400">用户申请退款时提醒</Text>
                  </View>
                </View>
                <Switch
                  checked={settings.refundNotify}
                  onCheckedChange={(checked) => updateSetting('refundNotify', checked)}
                />
              </View>
            </CardContent>
          </Card>
        </View>

        {/* 客户通知 */}
        <View className="mx-4 mt-4">
          <Text className="text-slate-500 text-sm mb-2 block">客户通知</Text>
          <Card className="bg-white rounded-2xl overflow-hidden">
            <CardContent className="p-0">
              <View className="flex items-center justify-between px-4 py-4">
                <View className="flex items-center gap-3">
                  <Users size={20} color="#14B8A6" />
                  <View>
                    <Text className="text-slate-700 block">新粉丝通知</Text>
                    <Text className="text-xs text-slate-400">有新用户关注时提醒</Text>
                  </View>
                </View>
                <Switch
                  checked={settings.newFollowerNotify}
                  onCheckedChange={(checked) => updateSetting('newFollowerNotify', checked)}
                />
              </View>
            </CardContent>
          </Card>
        </View>

        {/* 资金通知 */}
        <View className="mx-4 mt-4">
          <Text className="text-slate-500 text-sm mb-2 block">资金通知</Text>
          <Card className="bg-white rounded-2xl overflow-hidden">
            <CardContent className="p-0">
              <View className="flex items-center justify-between px-4 py-4 border-b border-slate-100">
                <View className="flex items-center gap-3">
                  <Wallet size={20} color="#14B8A6" />
                  <View>
                    <Text className="text-slate-700 block">收款通知</Text>
                    <Text className="text-xs text-slate-400">收到款项时提醒</Text>
                  </View>
                </View>
                <Switch
                  checked={settings.paymentNotify}
                  onCheckedChange={(checked) => updateSetting('paymentNotify', checked)}
                />
              </View>

              <View className="flex items-center justify-between px-4 py-4">
                <View className="flex items-center gap-3">
                  <Wallet size={20} color="#14B8A6" />
                  <View>
                    <Text className="text-slate-700 block">提现通知</Text>
                    <Text className="text-xs text-slate-400">提现到账时提醒</Text>
                  </View>
                </View>
                <Switch
                  checked={settings.withdrawalNotify}
                  onCheckedChange={(checked) => updateSetting('withdrawalNotify', checked)}
                />
              </View>
            </CardContent>
          </Card>
        </View>

        {/* 系统通知 */}
        <View className="mx-4 mt-4">
          <Text className="text-slate-500 text-sm mb-2 block">系统通知</Text>
          <Card className="bg-white rounded-2xl overflow-hidden">
            <CardContent className="p-0">
              <View className="flex items-center justify-between px-4 py-4 border-b border-slate-100">
                <View className="flex items-center gap-3">
                  <Bell size={20} color="#14B8A6" />
                  <View>
                    <Text className="text-slate-700 block">系统消息</Text>
                    <Text className="text-xs text-slate-400">平台公告和系统通知</Text>
                  </View>
                </View>
                <Switch
                  checked={settings.systemNotify}
                  onCheckedChange={(checked) => updateSetting('systemNotify', checked)}
                />
              </View>

              <View className="flex items-center justify-between px-4 py-4">
                <View className="flex items-center gap-3">
                  <MessageSquare size={20} color="#14B8A6" />
                  <View>
                    <Text className="text-slate-700 block">营销活动通知</Text>
                    <Text className="text-xs text-slate-400">新活动和推广机会</Text>
                  </View>
                </View>
                <Switch
                  checked={settings.promotionNotify}
                  onCheckedChange={(checked) => updateSetting('promotionNotify', checked)}
                />
              </View>
            </CardContent>
          </Card>
        </View>

        {/* 底部留白 */}
        <View className="h-10" />
      </ScrollView>

      {/* 保存按钮 */}
      <View className="fixed bottom-0 left-0 right-0 bg-white px-4 py-4 border-t border-slate-100">
        <Button
          className="w-full bg-teal-500 text-white rounded-xl py-3 flex items-center justify-center"
          onClick={handleSave}
          disabled={saving}
        >
          <Save size={18} color="#ffffff" />
          <Text className="text-white ml-2">{saving ? '保存中...' : '保存设置'}</Text>
        </Button>
      </View>
    </View>
  )
}
