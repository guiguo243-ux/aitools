import { View, Text, ScrollView } from '@tarojs/components'
import { useState, useEffect } from 'react'
import Taro, { useRouter } from '@tarojs/taro'
import { Star, Share2, Heart, MapPin, Phone, Clock, Flame, Ticket, Store, Utensils, Navigation } from 'lucide-react-taro'
import { Network } from '@/network'
import { Card, CardContent } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import { Separator } from '@/components/ui/separator'
import { useUserStore } from '@/stores/user'
import './index.css'

interface Product {
  id: string
  name: string
  description: string
  price: number
  original_price: number
  sales_count: number
}

interface MerchantDetail {
  id: string
  name: string
  category: string
  cover_image: string
  rating: string
  address: string
  district: string
  description: string
  region: string
  phone: string
  business_hours: string
  view_count: number
  latitude: string | null
  longitude: string | null
  products: Product[]
}

// Mock数据作为fallback
const getMockMerchant = (id: string): MerchantDetail => ({
  id,
  name: '老厦门沙茶面',
  category: '餐饮美食',
  cover_image: '',
  rating: '4.8',
  address: '厦门市思明区中山路123号',
  district: '思明区',
  description: '正宗厦门沙茶面，传承三代老字号，汤底浓郁，配料新鲜。招牌沙茶面、花生汤、海蛎煎深受食客喜爱。',
  region: 'island_inside',
  phone: '0592-12345678',
  business_hours: '08:00-22:00',
  view_count: 1256,
  latitude: '24.4795',
  longitude: '118.0894',
  products: [
    { id: 'p1', name: '招牌沙茶面', description: '浓郁沙茶汤底，配料丰富', price: 28, original_price: 35, sales_count: 1520 },
    { id: 'p2', name: '海蛎煎', description: '新鲜海蛎，外酥里嫩', price: 18, original_price: 22, sales_count: 890 },
    { id: 'p3', name: '花生汤', description: '香甜软糯，清热解暑', price: 8, original_price: 10, sales_count: 2100 },
  ]
})

const MerchantDetailPage = () => {
  const router = useRouter()
  const { id } = router.params

  const [merchant, setMerchant] = useState<MerchantDetail | null>(null)
  const [loading, setLoading] = useState(true)
  const [isFavorited, setIsFavorited] = useState(false)

  const { userInfo, isLoggedIn } = useUserStore()
  const userId = userInfo?.id || Taro.getStorageSync('user_id') || ''

  useEffect(() => {
    loadMerchantDetail()
  }, [id])

  useEffect(() => {
    if (userId && id) {
      checkFavorite()
    }
  }, [userId, id])

  const loadMerchantDetail = async () => {
    if (!id) return

    setLoading(true)
    try {
      const res = await Network.request({
        url: `/api/merchant/detail/${id}`,
        method: 'GET'
      })

      console.log('Merchant detail response:', res.data)

      if (res.data?.code === 200 && res.data?.data) {
        setMerchant(res.data.data)
      } else {
        // 使用mock数据
        console.log('Using mock data for merchant')
        setMerchant(getMockMerchant(id))
      }
    } catch (error) {
      console.error('Load merchant detail error:', error)
      // 使用mock数据
      setMerchant(getMockMerchant(id))
    } finally {
      setLoading(false)
    }
  }

  const checkFavorite = async () => {
    try {
      const res = await Network.request({
        url: '/api/favorite/check',
        method: 'GET',
        data: { userId, merchantId: id }
      })
      if (res.data?.code === 200) {
        setIsFavorited(res.data.data?.isFavorited || false)
      }
    } catch (error) {
      console.error('Check favorite error:', error)
    }
  }

  // 分享功能 - 点击触发分享
  const handleShare = () => {
    // 小程序端使用 showShareMenu
    if (Taro.getEnv() === Taro.ENV_TYPE.WEAPP) {
      Taro.showShareMenu({
        withShareTicket: true
      })
    } else {
      // H5端复制链接
      const shareUrl = window.location.href
      Taro.setClipboardData({
        data: shareUrl,
        success: () => {
          Taro.showToast({ title: '链接已复制', icon: 'success' })
        }
      })
    }
  }

  // 收藏功能
  const handleFavorite = async () => {
    if (!isLoggedIn) {
      Taro.navigateTo({ url: '/pages/login/index' })
      return
    }

    try {
      if (isFavorited) {
        await Network.request({
          url: '/api/favorite/remove',
          method: 'DELETE',
          data: { userId, merchantId: id }
        })
        setIsFavorited(false)
        Taro.showToast({ title: '已取消收藏', icon: 'success' })
      } else {
        await Network.request({
          url: '/api/favorite/add',
          method: 'POST',
          data: { userId, merchantId: id }
        })
        setIsFavorited(true)
        Taro.showToast({ title: '收藏成功', icon: 'success' })
      }
    } catch (error) {
      console.error('Favorite error:', error)
      Taro.showToast({ title: '操作失败', icon: 'none' })
    }
  }

  // 拨打电话
  const handleCall = () => {
    if (merchant?.phone) {
      Taro.makePhoneCall({
        phoneNumber: merchant.phone
      })
    } else {
      Taro.showToast({
        title: '暂无联系电话',
        icon: 'none'
      })
    }
  }

  // 一键导航功能
  const handleNavigate = () => {
    if (!merchant) return

    // 检查是否有经纬度
    if (merchant.latitude && merchant.longitude) {
      const latitude = parseFloat(merchant.latitude)
      const longitude = parseFloat(merchant.longitude)

      if (Number.isNaN(latitude) || Number.isNaN(longitude)) {
        Taro.showToast({ title: '位置信息无效', icon: 'none' })
        return
      }

      Taro.openLocation({
        latitude,
        longitude,
        name: merchant.name,
        address: merchant.address || '',
        scale: 18
      })
    } else {
      // 没有经纬度时，尝试使用地址搜索
      Taro.chooseLocation({
        success: (res) => {
          console.log('Choose location:', res)
        },
        fail: () => {
          Taro.showToast({
            title: '暂无位置信息，请手动导航',
            icon: 'none'
          })
        }
      })
    }
  }

  // 立即预约
  const handleReserve = () => {
    if (!isLoggedIn) {
      Taro.navigateTo({ url: '/pages/login/index' })
      return
    }

    // 跳转到订单确认页
    Taro.navigateTo({
      url: `/pages/order-confirm/index?merchantId=${id}&region=${merchant?.region || 'island_inside'}`
    })
  }

  // 领取优惠券
  const handleClaimCoupon = () => {
    if (!isLoggedIn) {
      Taro.navigateTo({ url: '/pages/login/index' })
      return
    }
    Taro.showToast({ title: '优惠券已领取', icon: 'success' })
  }

  // 点击商品
  const handleProductClick = (product: Product) => {
    if (!isLoggedIn) {
      Taro.navigateTo({ url: '/pages/login/index' })
      return
    }

    // 跳转到订单确认页，带上商品信息
    Taro.navigateTo({
      url: `/pages/order-confirm/index?merchantId=${id}&productId=${product.id}&region=${merchant?.region || 'island_inside'}`
    })
  }

  if (loading) {
    return (
      <View className="flex items-center justify-center h-screen bg-zinc-50">
        <Text className="text-zinc-400">加载中...</Text>
      </View>
    )
  }

  if (!merchant) {
    return (
      <View className="flex flex-col items-center justify-center h-screen bg-zinc-50">
        <Store size={48} color="#9ca3af" />
        <Text className="text-zinc-400 mt-3">商家不存在</Text>
        <Button
          className="mt-4 bg-teal-500 text-white"
          onClick={() => Taro.navigateBack()}
        >
          返回
        </Button>
      </View>
    )
  }

  return (
    <View className="flex flex-col min-h-screen bg-zinc-50">
      <ScrollView scrollY className="flex-1">
        {/* 商家封面 */}
        <View className="relative">
          <View className="w-full h-48 bg-gradient-to-br from-teal-100 to-teal-50 flex items-center justify-center">
            <Store size={64} color="#14B8A6" />
          </View>
          <View className="absolute bottom-0 left-0 right-0 p-4" style={{ backgroundColor: 'rgba(0,0,0,0.6)' }}>
            <Text className="text-white text-xl font-bold block">{merchant.name}</Text>
            <View className="flex items-center gap-2 mt-1">
              <View className="flex items-center gap-1">
                <Star size={14} color="#fbbf24" />
                <Text className="text-white text-sm">{merchant.rating || '4.5'}</Text>
              </View>
              <Badge variant="secondary" className="text-xs text-white" style={{ backgroundColor: 'rgba(255,255,255,0.2)' }}>
                {merchant.region === 'island_inside' ? '岛内' : '岛外'}
              </Badge>
              <Text className="text-white text-xs">{merchant.view_count || 0}人浏览</Text>
            </View>
          </View>
        </View>

        {/* 商家信息 */}
        <View className="bg-white px-4 py-4 -mt-2 rounded-t-2xl">
          <View className="flex items-center justify-between mb-3">
            <Text className="text-lg font-semibold text-zinc-800">商家信息</Text>
            <View className="flex items-center gap-2">
              <Button size="sm" variant="ghost" onClick={handleShare}>
                <Share2 size={20} color="#6b7280" />
              </Button>
              <Button size="sm" variant="ghost" onClick={handleFavorite}>
                <View className={`w-8 h-8 rounded-full flex items-center justify-center ${isFavorited ? 'bg-teal-50' : ''}`}>
                  <Heart size={20} color={isFavorited ? '#14B8A6' : '#6b7280'} />
                </View>
              </Button>
            </View>
          </View>

          <View className="flex flex-col gap-2">
            <View className="flex items-start gap-2" onClick={handleNavigate}>
              <MapPin size={16} color="#6b7280" className="flex-shrink-0 mt-1" />
              <Text className="text-sm text-zinc-600 flex-1">{merchant.address || '暂无地址信息'}</Text>
              {merchant.latitude && merchant.longitude && (
                <View className="flex items-center gap-1 bg-teal-50 px-2 py-1 rounded-full">
                  <Navigation size={12} color="#14B8A6" />
                  <Text className="text-xs text-teal-500">导航</Text>
                </View>
              )}
            </View>
            <View className="flex items-center gap-2">
              <Phone size={16} color="#6b7280" />
              <Text className="text-sm text-zinc-600">{merchant.phone || '暂无电话'}</Text>
            </View>
            <View className="flex items-center gap-2">
              <Clock size={16} color="#6b7280" />
              <Text className="text-sm text-zinc-600">{merchant.business_hours || '营业时间待更新'}</Text>
            </View>
          </View>

          <Separator className="my-4" />

          <Text className="text-sm text-zinc-600">{merchant.description || '暂无商家介绍'}</Text>
        </View>

        {/* 限时优惠 */}
        <View className="bg-white px-4 py-4 mt-2">
          <View className="flex items-center gap-2 mb-3">
            <Flame size={20} color="#14B8A6" />
            <Text className="text-base font-semibold text-zinc-800">限时优惠</Text>
          </View>

          <Card className="bg-gradient-to-r from-teal-500 to-teal-400 border-0">
            <CardContent className="p-3 flex items-center justify-between">
              <View>
                <Text className="text-white font-semibold block">新人专享</Text>
                <Text className="text-white text-opacity-80 text-xs">首单立减10元</Text>
              </View>
              <Button size="sm" className="bg-white text-teal-500" onClick={handleClaimCoupon}>
                立即领取
              </Button>
            </CardContent>
          </Card>
        </View>

        {/* 商品/服务列表 */}
        <View className="bg-white px-4 py-4 mt-2">
          <View className="flex items-center justify-between mb-3">
            <Text className="text-base font-semibold text-zinc-800">热门服务</Text>
          </View>

          {merchant.products && merchant.products.length > 0 ? (
            <View className="flex flex-col gap-3">
              {merchant.products.map((product) => (
                <Card key={product.id} onClick={() => handleProductClick(product)}>
                  <CardContent className="p-3 flex items-center gap-3">
                    <View className="w-20 h-20 bg-teal-50 rounded-lg flex items-center justify-center">
                      <Utensils size={32} color="#14B8A6" />
                    </View>
                    <View className="flex-1">
                      <Text className="text-sm font-medium text-zinc-800 block">{product.name}</Text>
                      <Text className="text-xs text-zinc-500 block mt-1 truncate">{product.description}</Text>
                      <View className="flex items-center justify-between mt-2">
                        <View className="flex items-baseline">
                          <Text className="text-teal-500 font-bold">¥{product.price}</Text>
                          {product.original_price > product.price && (
                            <Text className="text-xs text-zinc-400 line-through ml-1">¥{product.original_price}</Text>
                          )}
                        </View>
                        <Badge variant="secondary" className="text-xs">已售{product.sales_count || 0}</Badge>
                      </View>
                    </View>
                  </CardContent>
                </Card>
              ))}
            </View>
          ) : (
            <View className="flex flex-col items-center justify-center py-8">
              <Text className="text-zinc-400 text-sm">暂无商品</Text>
            </View>
          )}
        </View>

        {/* 底部留白 */}
        <View className="h-24" />
      </ScrollView>

      {/* 底部操作栏 */}
      <View className="bg-white border-t border-zinc-200 px-4 py-3 flex items-center gap-3">
        <Button variant="outline" className="flex-1" onClick={handleCall}>
          <Phone size={18} color="#14B8A6" />
          <Text className="ml-1 text-teal-500">电话</Text>
        </Button>
        <Button variant="outline" className="flex-1" onClick={handleNavigate}>
          <Navigation size={18} color="#14B8A6" />
          <Text className="ml-1 text-teal-500">导航</Text>
        </Button>
        <Button className="flex-1 bg-teal-500" onClick={handleReserve}>
          <Ticket size={18} color="#ffffff" />
          <Text className="ml-1 text-white">立即预约</Text>
        </Button>
      </View>
    </View>
  )
}

// 小程序分享配置
export const onShareAppMessage = () => {
  // 这里需要从当前页面状态获取商家信息
  // 由于 Taro 的限制，这里返回基本配置
  return {
    title: '发现一家好店，快来看看吧！',
    path: '/pages/index/index'
  }
}

export default MerchantDetailPage
