import { useState, useEffect } from 'react'
import { View, Text, Picker } from '@tarojs/components'
import Taro, { useRouter } from '@tarojs/taro'

import { Network } from '@/network'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'

const CATEGORIES = ['套餐', '单品', '饮品', '小吃', '甜点', '其他']

export default function ProductEditPage() {
  const router = useRouter()
  const { productId, merchantId } = router.params
  const isEdit = !!productId

  const [submitting, setSubmitting] = useState(false)
  const [formData, setFormData] = useState({
    name: '',
    category: '套餐',
    price: '',
    originalPrice: '',
    stock: '',
    description: '',
    coverImage: ''
  })

  useEffect(() => {
    if (isEdit) {
      loadProduct()
    }
  }, [productId])

  const loadProduct = async () => {
    try {
      const res = await Network.request({
        url: `/api/merchant/product/detail?productId=${productId}`
      })

      if (res.data.code === 200 && res.data.data) {
        const product = res.data.data
        setFormData({
          name: product.name,
          category: product.category,
          price: String(product.price),
          originalPrice: product.originalPrice ? String(product.originalPrice) : '',
          stock: String(product.stock),
          description: product.description || '',
          coverImage: product.coverImage || ''
        })
      }
    } catch (error) {
      console.error('Load product error:', error)
    }
  }

  const handleInput = (field: string, value: string) => {
    setFormData({ ...formData, [field]: value })
  }

  const handleCategoryChange = (e) => {
    setFormData({ ...formData, category: CATEGORIES[e.detail.value] })
  }

  const uploadImage = async () => {
    try {
      const res = await Taro.chooseImage({
        count: 1,
        sizeType: ['compressed'],
        sourceType: ['album', 'camera']
      })

      if (res.tempFilePaths && res.tempFilePaths[0]) {
        Taro.showLoading({ title: '上传中...' })
        
        const uploadRes = await Network.uploadFile({
          url: '/api/upload/image',
          filePath: res.tempFilePaths[0],
          name: 'file'
        })

        Taro.hideLoading()

        const data = JSON.parse(uploadRes.data)
        if (data.code === 200 && data.data?.url) {
          setFormData({ ...formData, coverImage: data.data.url })
          Taro.showToast({ title: '上传成功', icon: 'success' })
        }
      }
    } catch (error) {
      Taro.hideLoading()
      console.error('Upload error:', error)
    }
  }

  const handleSubmit = async () => {
    if (!formData.name.trim()) {
      Taro.showToast({ title: '请输入商品名称', icon: 'none' })
      return
    }
    if (!formData.price || parseFloat(formData.price) <= 0) {
      Taro.showToast({ title: '请输入正确的价格', icon: 'none' })
      return
    }
    if (!formData.stock || parseInt(formData.stock) < 0) {
      Taro.showToast({ title: '请输入正确的库存', icon: 'none' })
      return
    }

    setSubmitting(true)
    try {
      const url = isEdit ? '/api/merchant/product/update' : '/api/merchant/product/create'
      const res = await Network.request({
        url,
        method: 'POST',
        data: {
          productId,
          merchantId,
          ...formData,
          price: parseFloat(formData.price),
          originalPrice: formData.originalPrice ? parseFloat(formData.originalPrice) : undefined,
          stock: parseInt(formData.stock)
        }
      })

      if (res.data.code === 200) {
        Taro.showToast({ title: isEdit ? '更新成功' : '添加成功', icon: 'success' })
        setTimeout(() => Taro.navigateBack(), 1500)
      } else {
        Taro.showToast({ title: res.data.msg, icon: 'none' })
      }
    } catch (error) {
      Taro.showToast({ title: '操作失败', icon: 'none' })
    } finally {
      setSubmitting(false)
    }
  }

  const categoryIndex = CATEGORIES.indexOf(formData.category)

  return (
    <View className="min-h-screen bg-gray-50 pb-20">
      {/* 商品图片 */}
      <View className="bg-white mt-4">
        <View className="px-4 py-3 border-b border-gray-100">
          <Text className="text-base font-medium">商品图片</Text>
        </View>
        <View className="px-4 py-4">
          <View 
            className="w-24 h-24 bg-gray-50 rounded-lg flex flex-col items-center justify-center border-2 border-dashed border-gray-200"
            onClick={uploadImage}
          >
            {formData.coverImage ? (
              <View className="w-full h-full relative">
                <View className="absolute inset-0 bg-cover bg-center rounded-lg" style={{ backgroundImage: `url(${formData.coverImage})` }} />
              </View>
            ) : (
              <>
                🖼️
                <Text className="text-xs text-gray-400 mt-1">添加图片</Text>
              </>
            )}
          </View>
        </View>
      </View>

      {/* 基本信息 */}
      <View className="bg-white mt-4">
        <View className="px-4 py-3 border-b border-gray-100">
          <Text className="text-base font-medium">基本信息</Text>
        </View>

        <View className="flex items-center px-4 py-4 border-b border-gray-100">
          <Text className="text-gray-500 w-20">商品名称</Text>
          <Input
            className="flex-1 text-right"
            placeholder="请输入商品名称"
            value={formData.name}
            onInput={(e) => handleInput('name', e.detail.value)}
          />
        </View>

        <Picker mode="selector" range={CATEGORIES} onChange={handleCategoryChange} value={categoryIndex >= 0 ? categoryIndex : 0}>
          <View className="flex items-center justify-between px-4 py-4 border-b border-gray-100">
            <Text className="text-gray-500 w-20">商品分类</Text>
            <Text className="text-gray-700">{formData.category}</Text>
          </View>
        </Picker>

        <View className="flex items-center px-4 py-4 border-b border-gray-100">
          <Text className="text-gray-500 w-20">售价</Text>
          <View className="flex-1 flex items-center justify-end">
            <Text className="text-teal-500 mr-1">¥</Text>
            <Input
              className="text-right"
              style={{ width: '100px' }}
              placeholder="0.00"
              type="digit"
              value={formData.price}
              onInput={(e) => handleInput('price', e.detail.value)}
            />
          </View>
        </View>

        <View className="flex items-center px-4 py-4 border-b border-gray-100">
          <Text className="text-gray-500 w-20">原价</Text>
          <View className="flex-1 flex items-center justify-end">
            <Text className="text-gray-400 mr-1">¥</Text>
            <Input
              className="text-right"
              style={{ width: '100px' }}
              placeholder="选填"
              type="digit"
              value={formData.originalPrice}
              onInput={(e) => handleInput('originalPrice', e.detail.value)}
            />
          </View>
        </View>

        <View className="flex items-center px-4 py-4 border-b border-gray-100">
          <Text className="text-gray-500 w-20">库存</Text>
          <Input
            className="flex-1 text-right"
            placeholder="请输入库存数量"
            type="number"
            value={formData.stock}
            onInput={(e) => handleInput('stock', e.detail.value)}
          />
        </View>

        <View className="px-4 py-4">
          <Text className="text-gray-500 w-20 block mb-2">商品描述</Text>
          <Input
            className="w-full bg-gray-50 rounded-lg p-3"
            style={{ minHeight: '80px' }}
            placeholder="请输入商品描述..."
            value={formData.description}
            onInput={(e) => handleInput('description', e.detail.value)}
          />
        </View>
      </View>

      {/* 提交按钮 */}
      <View className="fixed bottom-0 left-0 right-0 bg-white px-4 py-4 border-t border-gray-100">
        <Button
          className="w-full bg-teal-500 text-white rounded-xl py-3"
          onClick={handleSubmit}
          disabled={submitting}
        >
          {submitting ? '提交中...' : isEdit ? '保存修改' : '添加商品'}
        </Button>
      </View>
    </View>
  )
}
