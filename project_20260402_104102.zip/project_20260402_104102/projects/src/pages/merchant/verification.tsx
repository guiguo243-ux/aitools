import { useState, useEffect } from 'react'
import { View, Text, ScrollView } from '@tarojs/components'
import Taro from '@tarojs/taro'
import { Smartphone, User, MapPin, Clock, Check, X } from 'lucide-react-taro'

import { Network } from '@/network'
import { useUserStore } from '@/stores/user'
import { Button } from '@/components/ui/button'

interface Order {
  id: string
  orderNo: string
  userName: string
  userRegion: string
  totalPrice: number
  status: 'paid' | 'verified' | 'expired'
  verifyCode: string
  createdAt: string
  verifiedAt?: string
  items: { name: string; quantity: number; price: number }[]
}

export default function MerchantVerificationPage() {
  const { userInfo } = useUserStore()
  const [activeTab, setActiveTab] = useState<'pending' | 'history'>('pending')
  const [pendingOrders, setPendingOrders] = useState<Order[]>([])
  const [historyOrders, setHistoryOrders] = useState<Order[]>([])
  const [loading, setLoading] = useState(true)
  const [merchantId, setMerchantId] = useState<string>('')

  useEffect(() => {
    loadMerchantAndOrders()
  }, [])

  const loadMerchantAndOrders = async () => {
    if (!userInfo?.id) return

    try {
      const statusRes = await Network.request({
        url: `/api/merchant/status?userId=${userInfo.id}`
      })

      if (statusRes.data.code === 200 && statusRes.data.data?.id) {
        setMerchantId(statusRes.data.data.id)
        await loadOrders(statusRes.data.data.id)
      } else {
        Taro.showToast({ title: '请先申请商家入驻', icon: 'none' })
        setTimeout(() => Taro.navigateBack(), 1500)
      }
    } catch (error) {
      console.error('Load merchant error:', error)
      // 模拟数据
      setPendingOrders([
        {
          id: 'O001',
          orderNo: '20240315001',
          userName: '张**',
          userRegion: 'siming',
          totalPrice: 128,
          status: 'paid',
          verifyCode: '886621',
          createdAt: '2024-03-15 14:30:00',
          items: [
            { name: '招牌双人套餐', quantity: 1, price: 128 }
          ]
        },
        {
          id: 'O002',
          orderNo: '20240315002',
          userName: '李**',
          userRegion: 'huli',
          totalPrice: 68,
          status: 'paid',
          verifyCode: '773388',
          createdAt: '2024-03-15 15:20:00',
          items: [
            { name: '单人精选套餐', quantity: 1, price: 68 }
          ]
        }
      ])
      setHistoryOrders([
        {
          id: 'O003',
          orderNo: '20240314001',
          userName: '王**',
          userRegion: 'jimei',
          totalPrice: 188,
          status: 'verified',
          verifyCode: '556677',
          createdAt: '2024-03-14 12:00:00',
          verifiedAt: '2024-03-14 12:30:00',
          items: [
            { name: '招牌双人套餐', quantity: 1, price: 128 },
            { name: '饮品', quantity: 2, price: 30 }
          ]
        }
      ])
    } finally {
      setLoading(false)
    }
  }

  const loadOrders = async (mId: string) => {
    try {
      const [pendingRes, historyRes] = await Promise.all([
        Network.request({ url: `/api/merchant/orders/pending?merchantId=${mId}` }),
        Network.request({ url: `/api/merchant/orders/history?merchantId=${mId}` })
      ])

      if (pendingRes.data.code === 200) {
        setPendingOrders(pendingRes.data.data || [])
      }
      if (historyRes.data.code === 200) {
        setHistoryOrders(historyRes.data.data || [])
      }
    } catch (error) {
      console.error('Load orders error:', error)
    }
  }

  const handleVerify = (order: Order) => {
    Taro.showModal({
      title: '确认核销',
      content: `订单号: ${order.orderNo}\n金额: ¥${order.totalPrice}\n确认核销此订单？`,
      success: async (res) => {
        if (res.confirm) {
          try {
            const result = await Network.request({
              url: '/api/merchant/order/verify',
              method: 'POST',
              data: { 
                orderId: order.id, 
                merchantId,
                verifyCode: order.verifyCode 
              }
            })

            if (result.data.code === 200) {
              Taro.showToast({ title: '核销成功', icon: 'success' })
              // 移动到历史记录
              setPendingOrders(pendingOrders.filter(o => o.id !== order.id))
              setHistoryOrders([{ ...order, status: 'verified', verifiedAt: new Date().toISOString() }, ...historyOrders])
            } else {
              Taro.showToast({ title: result.data.msg, icon: 'none' })
            }
          } catch (error) {
            Taro.showToast({ title: '核销失败', icon: 'none' })
          }
        }
      }
    })
  }

  const openScanner = () => {
    Taro.scanCode({
      success: (res) => {
        // 解析二维码内容
        const code = res.result
        // 查找匹配订单
        const order = pendingOrders.find(o => o.verifyCode === code || o.orderNo === code)
        if (order) {
          handleVerify(order)
        } else {
          Taro.showToast({ title: '未找到匹配订单', icon: 'none' })
        }
      },
      fail: () => {
        Taro.showToast({ title: '扫码取消', icon: 'none' })
      }
    })
  }

  const formatTime = (timeStr: string) => {
    return timeStr?.replace('T', ' ').split('.')[0] || timeStr
  }

  const regionLabels: Record<string, string> = {
    siming: '思明区',
    huli: '湖里区',
    jimei: '集美区',
    haicang: '海沧区',
    tongan: '同安区',
    xiangan: '翔安区'
  }

  if (loading) {
    return (
      <View className="min-h-screen bg-gray-50 flex items-center justify-center">
        <Text className="text-gray-400">加载中...</Text>
      </View>
    )
  }

  return (
    <View className="min-h-screen bg-gray-50">
      {/* 扫码按钮 */}
      <View className="bg-gradient-to-r from-teal-500 to-teal-400 px-4 py-6">
        <View 
          className="bg-white rounded-xl p-4 flex items-center justify-center gap-3"
          onClick={openScanner}
        >
          <Smartphone size={24} color="#14B8A6" />
          <Text className="text-teal-500 font-medium">扫描核销码</Text>
        </View>
      </View>

      {/* Tab 切换 */}
      <View className="bg-white flex border-b border-gray-200">
        <View 
          className={`flex-1 py-3 text-center ${activeTab === 'pending' ? 'border-b-2 border-teal-500' : ''}`}
          onClick={() => setActiveTab('pending')}
        >
          <Text className={activeTab === 'pending' ? 'text-teal-500 font-medium' : 'text-gray-500'}>
            待核销 ({pendingOrders.length})
          </Text>
        </View>
        <View 
          className={`flex-1 py-3 text-center ${activeTab === 'history' ? 'border-b-2 border-teal-500' : ''}`}
          onClick={() => setActiveTab('history')}
        >
          <Text className={activeTab === 'history' ? 'text-teal-500 font-medium' : 'text-gray-500'}>
            核销记录
          </Text>
        </View>
      </View>

      {/* 订单列表 */}
      <ScrollView scrollY className="h-[calc(100vh-200px)] px-4 py-4">
        {activeTab === 'pending' ? (
          pendingOrders.length > 0 ? (
            <View className="space-y-3">
              {pendingOrders.map((order) => (
                <View key={order.id} className="bg-white rounded-xl p-4">
                  <View className="flex justify-between items-start mb-3">
                    <View>
                      <Text className="font-medium">{order.orderNo}</Text>
                      <View className="flex items-center gap-2 mt-1">
                        <User size={14} color="#6b7280" />
                        <Text className="text-sm text-gray-500">{order.userName}</Text>
                        <MapPin size={14} color="#6b7280" />
                        <Text className="text-sm text-gray-500">{regionLabels[order.userRegion] || order.userRegion}</Text>
                      </View>
                    </View>
                    <Text className="text-teal-500 font-bold">¥{order.totalPrice}</Text>
                  </View>

                  <View className="bg-gray-50 rounded-lg p-3 mb-3">
                    {order.items.map((item, idx) => (
                      <View key={idx} className="flex justify-between text-sm">
                        <Text>{item.name} x{item.quantity}</Text>
                        <Text>¥{item.price}</Text>
                      </View>
                    ))}
                  </View>

                  <View className="flex items-center justify-between">
                    <View className="flex items-center gap-1 text-gray-400">
                      <Clock size={14} color="#9ca3af" />
                      <Text className="text-xs">{formatTime(order.createdAt)}</Text>
                    </View>
                    <View className="flex items-center gap-2">
                      <View className="bg-teal-50 px-3 py-1 rounded">
                        <Text className="text-teal-500 font-mono">{order.verifyCode}</Text>
                      </View>
                      <Button
                        size="sm"
                        className="bg-teal-500 text-white rounded-lg"
                        onClick={() => handleVerify(order)}
                      >
                        核销
                      </Button>
                    </View>
                  </View>
                </View>
              ))}
            </View>
          ) : (
            <View className="text-center py-20">
              <Check size={48} color="#9ca3af" />
              <Text className="text-gray-400 mt-4">暂无待核销订单</Text>
            </View>
          )
        ) : (
          historyOrders.length > 0 ? (
            <View className="space-y-3">
              {historyOrders.map((order) => (
                <View key={order.id} className="bg-white rounded-xl p-4 opacity-70">
                  <View className="flex justify-between items-start mb-2">
                    <View>
                      <Text className="font-medium">{order.orderNo}</Text>
                      <View className="flex items-center gap-1 mt-1">
                        <Check size={14} color="#10b981" />
                        <Text className="text-xs text-green-500">已核销</Text>
                      </View>
                    </View>
                    <Text className="text-gray-500 font-medium">¥{order.totalPrice}</Text>
                  </View>

                  <View className="flex items-center justify-between text-xs text-gray-400">
                    <Text>核销时间: {formatTime(order.verifiedAt || '')}</Text>
                    <Text>核销码: {order.verifyCode}</Text>
                  </View>
                </View>
              ))}
            </View>
          ) : (
            <View className="text-center py-20">
              <X size={48} color="#9ca3af" />
              <Text className="text-gray-400 mt-4">暂无核销记录</Text>
            </View>
          )
        )}
      </ScrollView>
    </View>
  )
}
