import { useState } from 'react'
import { View, Text, Picker } from '@tarojs/components'
import Taro from '@tarojs/taro'
import { Network } from '@/network'
import { useUserStore } from '@/stores/user'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Card, CardContent } from '@/components/ui/card'
import { Store, FileText, MapPin, Phone, Clock, ImagePlus } from 'lucide-react-taro'

const REGIONS = [
  { label: '思明区', value: 'siming', type: 'island' },
  { label: '湖里区', value: 'huli', type: 'island' },
  { label: '集美区', value: 'jimei', type: 'outside' },
  { label: '海沧区', value: 'haicang', type: 'outside' },
  { label: '同安区', value: 'tongan', type: 'outside' },
  { label: '翔安区', value: 'xiangan', type: 'outside' }
]

const CATEGORIES = [
  '美食餐饮', '生活服务', '休闲娱乐', '美容美发', 
  '健身运动', '教育培训', '亲子乐园', '其他'
]

export default function MerchantApplyPage() {
  const { userInfo } = useUserStore()
  const [submitting, setSubmitting] = useState(false)
  const [formData, setFormData] = useState({
    name: '',
    category: '',
    region: '',
    address: '',
    phone: '',
    businessHours: '09:00-21:00',
    description: '',
    licenseUrl: '',
    coverUrl: ''
  })

  const handleInput = (field: string, value: string) => {
    setFormData({ ...formData, [field]: value })
  }

  const handleCategoryChange = (e) => {
    setFormData({ ...formData, category: CATEGORIES[e.detail.value] })
  }

  const handleRegionChange = (e) => {
    setFormData({ ...formData, region: REGIONS[e.detail.value].value })
  }

  const uploadImage = async (field: string) => {
    try {
      const res = await Taro.chooseImage({
        count: 1,
        sizeType: ['compressed'],
        sourceType: ['album', 'camera']
      })

      if (res.tempFilePaths && res.tempFilePaths[0]) {
        Taro.showLoading({ title: '上传中...' })
        
        const uploadRes = await Network.uploadFile({
          url: '/api/upload/image',
          filePath: res.tempFilePaths[0],
          name: 'file'
        })

        Taro.hideLoading()

        const data = JSON.parse(uploadRes.data)
        if (data.code === 200 && data.data?.url) {
          setFormData({ ...formData, [field]: data.data.url })
          Taro.showToast({ title: '上传成功', icon: 'success' })
        }
      }
    } catch (error) {
      Taro.hideLoading()
      console.error('Upload error:', error)
    }
  }

  const handleSubmit = async () => {
    // 表单验证
    if (!formData.name.trim()) {
      Taro.showToast({ title: '请输入店铺名称', icon: 'none' })
      return
    }
    if (!formData.category) {
      Taro.showToast({ title: '请选择经营类目', icon: 'none' })
      return
    }
    if (!formData.region) {
      Taro.showToast({ title: '请选择所在区域', icon: 'none' })
      return
    }
    if (!formData.address.trim()) {
      Taro.showToast({ title: '请输入详细地址', icon: 'none' })
      return
    }
    if (!formData.phone.trim()) {
      Taro.showToast({ title: '请输入联系电话', icon: 'none' })
      return
    }

    setSubmitting(true)
    try {
      const res = await Network.request({
        url: '/api/merchant/apply',
        method: 'POST',
        data: {
          userId: userInfo?.id,
          ...formData
        }
      })

      if (res.data.code === 200) {
        Taro.showToast({ title: '提交成功', icon: 'success' })
        setTimeout(() => {
          Taro.navigateBack()
        }, 1500)
      } else {
        Taro.showToast({ title: res.data.msg, icon: 'none' })
      }
    } catch (error) {
      Taro.showToast({ title: '提交失败', icon: 'none' })
    } finally {
      setSubmitting(false)
    }
  }

  const regionLabel = REGIONS.find(r => r.value === formData.region)?.label || '请选择'
  const categoryIndex = CATEGORIES.indexOf(formData.category)

  return (
    <View className="min-h-screen bg-stone-50 pb-24">
      {/* 基本信息 */}
      <Card className="mt-4 mx-4 rounded-2xl overflow-hidden">
        <CardContent className="p-0">
          <View className="px-4 py-3 border-b border-slate-100">
            <Text className="text-base font-semibold text-slate-800">基本信息</Text>
          </View>

          {/* 店铺名称 */}
          <View className="flex items-center px-4 py-4 border-b border-slate-100">
            <Store size={18} color="#14B8A6" />
            <Text className="text-slate-500 w-20 ml-2">店铺名称</Text>
            <Input
              className="flex-1 text-right"
              placeholder="请输入店铺名称"
              value={formData.name}
              onInput={(e) => handleInput('name', e.detail.value)}
            />
          </View>

          {/* 经营类目 */}
          <Picker mode="selector" range={CATEGORIES} onChange={handleCategoryChange} value={categoryIndex >= 0 ? categoryIndex : 0}>
            <View className="flex items-center justify-between px-4 py-4 border-b border-slate-100">
              <View className="flex items-center">
                <FileText size={18} color="#14B8A6" />
                <Text className="text-slate-500 w-20 ml-2">经营类目</Text>
              </View>
              <View className="flex items-center">
                <Text className={formData.category ? 'text-slate-700' : 'text-slate-400'}>
                  {formData.category || '请选择'}
                </Text>
                <Text className="text-slate-300 ml-1">›</Text>
              </View>
            </View>
          </Picker>

          {/* 所在区域 */}
          <Picker mode="selector" range={REGIONS.map(r => r.label)} onChange={handleRegionChange}>
            <View className="flex items-center justify-between px-4 py-4 border-b border-slate-100">
              <View className="flex items-center">
                <MapPin size={18} color="#14B8A6" />
                <Text className="text-slate-500 w-20 ml-2">所在区域</Text>
              </View>
              <View className="flex items-center">
                <Text className={formData.region ? 'text-slate-700' : 'text-slate-400'}>
                  {regionLabel}
                </Text>
                <Text className="text-slate-300 ml-1">›</Text>
              </View>
            </View>
          </Picker>

          {/* 详细地址 */}
          <View className="flex items-center px-4 py-4 border-b border-slate-100">
            <MapPin size={18} color="#14B8A6" />
            <Text className="text-slate-500 w-20 ml-2">详细地址</Text>
            <Input
              className="flex-1 text-right"
              placeholder="请输入详细地址"
              value={formData.address}
              onInput={(e) => handleInput('address', e.detail.value)}
            />
          </View>

          {/* 联系电话 */}
          <View className="flex items-center px-4 py-4 border-b border-slate-100">
            <Phone size={18} color="#14B8A6" />
            <Text className="text-slate-500 w-20 ml-2">联系电话</Text>
            <Input
              className="flex-1 text-right"
              placeholder="请输入联系电话"
              type="number"
              value={formData.phone}
              onInput={(e) => handleInput('phone', e.detail.value)}
            />
          </View>

          {/* 营业时间 */}
          <View className="flex items-center px-4 py-4">
            <Clock size={18} color="#14B8A6" />
            <Text className="text-slate-500 w-20 ml-2">营业时间</Text>
            <Input
              className="flex-1 text-right"
              placeholder="如: 09:00-21:00"
              value={formData.businessHours}
              onInput={(e) => handleInput('businessHours', e.detail.value)}
            />
          </View>
        </CardContent>
      </Card>

      {/* 店铺简介 */}
      <Card className="mt-4 mx-4 rounded-2xl overflow-hidden">
        <CardContent className="p-0">
          <View className="px-4 py-3 border-b border-slate-100">
            <Text className="text-base font-semibold text-slate-800">店铺简介</Text>
          </View>
          <View className="px-4 py-3">
            <View className="bg-slate-50 rounded-xl p-3">
              <Input
                className="w-full bg-transparent"
                style={{ minHeight: '80px' }}
                placeholder="请输入店铺简介，展示给用户看..."
                value={formData.description}
                onInput={(e) => handleInput('description', e.detail.value)}
              />
            </View>
          </View>
        </CardContent>
      </Card>

      {/* 资质照片 */}
      <Card className="mt-4 mx-4 rounded-2xl overflow-hidden">
        <CardContent className="p-0">
          <View className="px-4 py-3 border-b border-slate-100">
            <Text className="text-base font-semibold text-slate-800">资质照片</Text>
          </View>
          <View className="px-4 py-4">
            <View className="flex gap-4">
              {/* 营业执照 */}
              <View className="flex-1">
                <View 
                  className="aspect-square bg-slate-50 rounded-xl flex flex-col items-center justify-center border-2 border-dashed border-slate-200"
                  onClick={() => uploadImage('licenseUrl')}
                >
                  {formData.licenseUrl ? (
                    <View className="w-full h-full relative">
                      <View className="absolute inset-0 bg-cover bg-center rounded-xl" style={{ backgroundImage: `url(${formData.licenseUrl})` }} />
                    </View>
                  ) : (
                    <>
                      <ImagePlus size={32} color="#9ca3af" />
                      <Text className="text-xs text-slate-400 mt-2">营业执照</Text>
                    </>
                  )}
                </View>
                <Text className="text-xs text-slate-400 text-center mt-2">营业执照</Text>
              </View>

              {/* 店铺封面 */}
              <View className="flex-1">
                <View 
                  className="aspect-square bg-slate-50 rounded-xl flex flex-col items-center justify-center border-2 border-dashed border-slate-200"
                  onClick={() => uploadImage('coverUrl')}
                >
                  {formData.coverUrl ? (
                    <View className="w-full h-full relative">
                      <View className="absolute inset-0 bg-cover bg-center rounded-xl" style={{ backgroundImage: `url(${formData.coverUrl})` }} />
                    </View>
                  ) : (
                    <>
                      <ImagePlus size={32} color="#9ca3af" />
                      <Text className="text-xs text-slate-400 mt-2">店铺封面</Text>
                    </>
                  )}
                </View>
                <Text className="text-xs text-slate-400 text-center mt-2">店铺封面</Text>
              </View>
            </View>
          </View>
        </CardContent>
      </Card>

      {/* 提交按钮 */}
      <View style={{ position: 'fixed', bottom: 0, left: 0, right: 0, backgroundColor: '#fff', padding: '16px', borderTop: '1px solid #e5e5e5' }}>
        <Button
          className="w-full bg-teal-500 text-white rounded-full py-3"
          onClick={handleSubmit}
          disabled={submitting}
        >
          {submitting ? '提交中...' : '提交申请'}
        </Button>
      </View>
    </View>
  )
}
