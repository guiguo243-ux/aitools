export default typeof definePageConfig === 'function'
  ? definePageConfig({
      navigationBarTitleText: '商家详情'
    })
  : { navigationBarTitleText: '商家详情' }
