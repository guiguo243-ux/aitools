import { View, Text } from '@tarojs/components'
import Taro from '@tarojs/taro'
import { useEffect, useState } from 'react'

import { Network } from '@/network'
import { useUserStore } from '@/stores/user'
import { Card, CardContent } from '@/components/ui/card'
import { Store, ChartBarBig, Package, ScanLine, Settings, ChevronRight, CircleCheck, Clock, CircleX, Plus } from 'lucide-react-taro'
import UserGuide, { GUIDE_STEPS, shouldShowGuide } from '@/components/user-guide'

interface MerchantInfo {
  id: string
  name: string
  status: 'pending' | 'approved' | 'rejected'
}

export default function MerchantPortalPage() {
  const { userInfo, isLoggedIn } = useUserStore()
  const [merchant, setMerchant] = useState<MerchantInfo | null>(null)
  const [loading, setLoading] = useState(true)
  const [showGuide, setShowGuide] = useState(false)

  useEffect(() => {
    if (!isLoggedIn) {
      Taro.navigateTo({ url: '/pages/login/index' })
      return
    }
    checkMerchantStatus()
    
    // 检查是否需要显示商家引导
    const needGuide = shouldShowGuide('merchant')
    if (needGuide) {
      setTimeout(() => setShowGuide(true), 1000)
    }
  }, [isLoggedIn])

  const checkMerchantStatus = async () => {
    if (!userInfo?.id) return

    try {
      const res = await Network.request({
        url: `/api/merchant/status?userId=${userInfo.id}`
      })

      if (res.data.code === 200 && res.data.data) {
        setMerchant(res.data.data)
      }
    } catch (error) {
      console.error('Check merchant status error:', error)
    } finally {
      setLoading(false)
    }
  }

  const menuItems = [
    {
      icon: <Store size={20} color="#3B82F6" />,
      title: '商家入驻',
      desc: '申请入驻成为商家',
      path: '/pages/merchant/apply',
      bgColor: 'bg-blue-50'
    },
    {
      icon: <ChartBarBig size={20} color="#10B981" />,
      title: '数据看板',
      desc: '营业额、订单统计',
      path: '/pages/merchant/dashboard',
      bgColor: 'bg-emerald-50'
    },
    {
      icon: <Package size={20} color="#F59E0B" />,
      title: '商品管理',
      desc: '添加、编辑商品',
      path: '/pages/merchant/products',
      bgColor: 'bg-teal-50'
    },
    {
      icon: <ScanLine size={20} color="#14B8A6" />,
      title: '订单核销',
      desc: '扫描核销订单',
      path: '/pages/merchant/verification',
      bgColor: 'bg-teal-50'
    },
    {
      icon: <Settings size={20} color="#8B5CF6" />,
      title: '店铺设置',
      desc: '营业信息管理',
      path: '/pages/merchant/settings',
      bgColor: 'bg-violet-50'
    }
  ]

  const handleNavigate = (path: string) => {
    // 非商家只能进入入驻页面
    if (!merchant && !path.includes('apply')) {
      Taro.showToast({ title: '请先申请商家入驻', icon: 'none' })
      return
    }

    // 商家审核中
    if (merchant?.status === 'pending' && !path.includes('apply')) {
      Taro.showToast({ title: '入驻审核中，请耐心等待', icon: 'none' })
      return
    }

    Taro.navigateTo({ url: path })
  }

  if (loading) {
    return (
      <View className="min-h-screen bg-stone-50 flex items-center justify-center">
        <Text className="text-slate-400">加载中...</Text>
      </View>
    )
  }

  return (
    <View className="min-h-screen bg-stone-50">
      {/* 商家状态卡片 */}
      <View className="bg-gradient-to-br from-teal-500 to-teal-600 px-4 py-6">
        <Text className="text-white text-xl font-bold block mb-4">商家中心</Text>
        {merchant ? (
          <Card className="backdrop-blur border-0" style={{ backgroundColor: 'rgba(255,255,255,0.2)' }}>
            <CardContent className="p-4 flex items-center gap-3">
              <View className="w-12 h-12 rounded-xl flex items-center justify-center" style={{ backgroundColor: 'rgba(255,255,255,0.3)' }}>
                <Store size={24} color="#fff" />
              </View>
              <View className="flex-1">
                <Text className="text-white font-semibold text-base">{merchant.name}</Text>
                <View className="flex items-center gap-1 mt-1">
                  {merchant.status === 'approved' ? (
                    <>
                      <CircleCheck size={14} color="#86efac" />
                      <Text className="text-green-200 text-xs">已认证商家</Text>
                    </>
                  ) : merchant.status === 'pending' ? (
                    <>
                      <Clock size={14} color="#fcd34d" />
                      <Text className="text-yellow-300 text-xs">审核中</Text>
                    </>
                  ) : (
                    <>
                      <CircleX size={14} color="#fca5a5" />
                      <Text className="text-teal-200 text-xs">审核未通过</Text>
                    </>
                  )}
                </View>
              </View>
            </CardContent>
          </Card>
        ) : (
          <Card className="backdrop-blur border-0" style={{ backgroundColor: 'rgba(255,255,255,0.2)' }}>
            <CardContent className="p-4">
              <Text className="text-white text-sm">暂未入驻，立即申请成为商家享受平台流量扶持</Text>
            </CardContent>
          </Card>
        )}
      </View>

      {/* 功能菜单 */}
      <View className="px-4 py-4">
        <Text className="text-slate-500 text-sm mb-3 block">常用功能</Text>
        <Card className="bg-white rounded-2xl overflow-hidden">
          <CardContent className="p-0">
            {menuItems.map((item, index) => (
              <View
                key={item.title}
                className={`flex items-center px-4 py-4 ${index !== menuItems.length - 1 ? 'border-b border-slate-100' : ''}`}
                onClick={() => handleNavigate(item.path)}
              >
                <View className={`w-10 h-10 rounded-xl flex items-center justify-center mr-3 ${item.bgColor}`}>
                  {item.icon}
                </View>
                <View className="flex-1">
                  <Text className="text-base font-medium text-slate-800">{item.title}</Text>
                  <Text className="text-xs text-slate-400">{item.desc}</Text>
                </View>
                <ChevronRight size={18} color="#cbd5e1" />
              </View>
            ))}
          </CardContent>
        </Card>
      </View>

      {/* 快捷入口 */}
      <View className="px-4 py-2">
        <Text className="text-slate-500 text-sm mb-3 block">快捷操作</Text>
        <View className="grid grid-cols-2 gap-3">
          <Card 
            className="bg-white overflow-hidden"
            onClick={() => handleNavigate('/pages/merchant/verification?mode=scan')}
          >
            <CardContent className="p-4 flex flex-col items-center">
              <View className="w-12 h-12 rounded-xl bg-teal-50 flex items-center justify-center mb-2">
                <ScanLine size={24} color="#14B8A6" />
              </View>
              <Text className="text-sm font-medium text-slate-700">扫码核销</Text>
            </CardContent>
          </Card>
          <Card 
            className="bg-white overflow-hidden"
            onClick={() => handleNavigate('/pages/merchant/products?action=add')}
          >
            <CardContent className="p-4 flex flex-col items-center">
              <View className="w-12 h-12 rounded-xl bg-teal-50 flex items-center justify-center mb-2">
                <Plus size={24} color="#14B8A6" />
              </View>
              <Text className="text-sm font-medium text-slate-700">添加商品</Text>
            </CardContent>
          </Card>
        </View>
      </View>
      
      {/* 商家端新手引导 */}
      {showGuide && (
        <UserGuide
          guideKey="merchant"
          steps={GUIDE_STEPS.MERCHANT}
          onComplete={() => setShowGuide(false)}
          onSkip={() => setShowGuide(false)}
        />
      )}
    </View>
  )
}
