export default typeof definePageConfig === 'function'
  ? definePageConfig({ navigationBarTitleText: '商品编辑' })
  : { navigationBarTitleText: '商品编辑' }
