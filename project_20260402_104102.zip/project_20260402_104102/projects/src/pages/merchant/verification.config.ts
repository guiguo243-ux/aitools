export default typeof definePageConfig === 'function'
  ? definePageConfig({ navigationBarTitleText: '订单核销' })
  : { navigationBarTitleText: '订单核销' }
