import { useState, useEffect } from 'react'
import { View, Text, Image, ScrollView } from '@tarojs/components'
import Taro from '@tarojs/taro'
import { Eye, EyeOff, Pencil, Trash2, Plus } from 'lucide-react-taro'

import { Network } from '@/network'
import { useUserStore } from '@/stores/user'
import { Button } from '@/components/ui/button'

interface Product {
  id: string
  name: string
  price: number
  originalPrice?: number
  stock: number
  sales: number
  status: 'active' | 'inactive'
  coverImage: string
  category: string
}

export default function MerchantProductsPage() {
  const { userInfo } = useUserStore()
  const [products, setProducts] = useState<Product[]>([])
  const [loading, setLoading] = useState(true)
  const [merchantId, setMerchantId] = useState<string>('')

  useEffect(() => {
    loadMerchantAndProducts()
  }, [])

  const loadMerchantAndProducts = async () => {
    if (!userInfo?.id) return

    try {
      const statusRes = await Network.request({
        url: `/api/merchant/status?userId=${userInfo.id}`
      })

      if (statusRes.data.code === 200 && statusRes.data.data?.id) {
        setMerchantId(statusRes.data.data.id)
        await loadProducts(statusRes.data.data.id)
      } else {
        Taro.showToast({ title: '请先申请商家入驻', icon: 'none' })
        setTimeout(() => Taro.navigateBack(), 1500)
      }
    } catch (error) {
      console.error('Load merchant error:', error)
      // 模拟数据
      setProducts([
        {
          id: 'P001',
          name: '招牌双人套餐',
          price: 128,
          originalPrice: 158,
          stock: 50,
          sales: 86,
          status: 'active',
          coverImage: 'https://picsum.photos/200/200',
          category: '套餐'
        },
        {
          id: 'P002',
          name: '单人精选套餐',
          price: 68,
          originalPrice: 88,
          stock: 30,
          sales: 54,
          status: 'active',
          coverImage: 'https://picsum.photos/200/200',
          category: '套餐'
        },
        {
          id: 'P003',
          name: '儿童欢乐套餐',
          price: 48,
          stock: 20,
          sales: 38,
          status: 'inactive',
          coverImage: 'https://picsum.photos/200/200',
          category: '套餐'
        }
      ])
    } finally {
      setLoading(false)
    }
  }

  const loadProducts = async (mId: string) => {
    try {
      const res = await Network.request({
        url: `/api/merchant/products?merchantId=${mId}`
      })

      if (res.data.code === 200) {
        setProducts(res.data.data || [])
      }
    } catch (error) {
      console.error('Load products error:', error)
    }
  }

  const toggleProductStatus = async (productId: string, currentStatus: string) => {
    try {
      const res = await Network.request({
        url: '/api/merchant/product/toggle',
        method: 'POST',
        data: { productId, status: currentStatus === 'active' ? 'inactive' : 'active' }
      })

      if (res.data.code === 200) {
        setProducts(products.map(p => 
          p.id === productId ? { ...p, status: currentStatus === 'active' ? 'inactive' : 'active' } : p
        ))
        Taro.showToast({ title: '操作成功', icon: 'success' })
      }
    } catch (error) {
      Taro.showToast({ title: '操作失败', icon: 'none' })
    }
  }

  const deleteProduct = (productId: string) => {
    Taro.showModal({
      title: '确认删除',
      content: '删除后无法恢复，确定要删除吗？',
      success: async (res) => {
        if (res.confirm) {
          try {
            const result = await Network.request({
              url: '/api/merchant/product/delete',
              method: 'POST',
              data: { productId }
            })

            if (result.data.code === 200) {
              setProducts(products.filter(p => p.id !== productId))
              Taro.showToast({ title: '删除成功', icon: 'success' })
            }
          } catch (error) {
            Taro.showToast({ title: '删除失败', icon: 'none' })
          }
        }
      }
    })
  }

  const goToAddProduct = () => {
    Taro.navigateTo({ url: `/pages/merchant/product-edit?merchantId=${merchantId}` })
  }

  const goToEditProduct = (productId: string) => {
    Taro.navigateTo({ url: `/pages/merchant/product-edit?productId=${productId}&merchantId=${merchantId}` })
  }

  if (loading) {
    return (
      <View className="min-h-screen bg-gray-50 flex items-center justify-center">
        <Text className="text-gray-400">加载中...</Text>
      </View>
    )
  }

  return (
    <View className="min-h-screen bg-gray-50 pb-20">
      {/* 商品列表 */}
      <ScrollView scrollY className="h-screen px-4 py-4">
        {products.length > 0 ? (
          <View className="space-y-3">
            {products.map((product) => (
              <View key={product.id} className="bg-white rounded-xl p-4">
                <View className="flex gap-3">
                  <Image
                    src={product.coverImage || ''}
                    className="w-20 h-20 rounded-lg"
                    mode="aspectFill"
                    onError={() => {
                      console.log('Product image load failed:', product.id)
                    }}
                  />
                  <View className="flex-1">
                    <View className="flex items-center gap-2">
                      <Text className="font-medium">{product.name}</Text>
                      {product.status === 'inactive' && (
                        <Text className="text-xs bg-gray-200 text-gray-500 px-2 py-1 rounded">已下架</Text>
                      )}
                    </View>
                    <View className="flex items-baseline gap-2 mt-1">
                      <Text className="text-teal-500 font-bold">¥{product.price}</Text>
                      {product.originalPrice && (
                        <Text className="text-xs text-gray-400 line-through">¥{product.originalPrice}</Text>
                      )}
                    </View>
                    <View className="flex items-center gap-4 mt-2">
                      <Text className="text-xs text-gray-500">库存 {product.stock}</Text>
                      <Text className="text-xs text-gray-500">销量 {product.sales}</Text>
                    </View>
                  </View>
                </View>

                {/* 操作按钮 */}
                <View className="flex items-center justify-end gap-4 mt-3 pt-3 border-t border-gray-100">
                  <View 
                    className="flex items-center gap-1"
                    onClick={() => toggleProductStatus(product.id, product.status)}
                  >
                    {product.status === 'active' ? (
                      <>
                        <EyeOff size={16} color="#6b7280" />
                        <Text className="text-xs text-gray-500">下架</Text>
                      </>
                    ) : (
                      <>
                        <Eye size={16} color="#10b981" />
                        <Text className="text-xs text-green-500">上架</Text>
                      </>
                    )}
                  </View>
                  <View 
                    className="flex items-center gap-1"
                    onClick={() => goToEditProduct(product.id)}
                  >
                    <Pencil size={16} color="#3b82f6" />
                    <Text className="text-xs text-blue-500">编辑</Text>
                  </View>
                  <View 
                    className="flex items-center gap-1"
                    onClick={() => deleteProduct(product.id)}
                  >
                    <Trash2 size={16} color="#14B8A6" />
                    <Text className="text-xs text-teal-500">删除</Text>
                  </View>
                </View>
              </View>
            ))}
          </View>
        ) : (
          <View className="text-center py-20">
            <Eye size={48} color="#9ca3af" />
            <Text className="text-gray-400 block mb-4 mt-3">暂无商品</Text>
            <Text className="text-sm text-gray-400">点击下方按钮添加您的第一个商品</Text>
          </View>
        )}
      </ScrollView>

      {/* 添加商品按钮 */}
      <View className="fixed bottom-0 left-0 right-0 bg-white px-4 py-4 border-t border-gray-100">
        <Button
          className="w-full bg-teal-500 text-white rounded-xl py-3 flex items-center justify-center"
          onClick={goToAddProduct}
        >
          <Plus size={18} color="#ffffff" />
          <Text className="text-white ml-1">添加商品</Text>
        </Button>
      </View>
    </View>
  )
}
