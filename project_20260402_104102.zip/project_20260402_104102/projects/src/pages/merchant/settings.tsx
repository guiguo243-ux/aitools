import { useState, useEffect } from 'react'
import { View, Text, ScrollView } from '@tarojs/components'
import Taro from '@tarojs/taro'
import { Store, Clock, Phone, MapPin, FileText, Bell, ChevronRight, Save } from 'lucide-react-taro'
import { Network } from '@/network'
import { useUserStore } from '@/stores/user'
import { Card, CardContent } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Switch } from '@/components/ui/switch'

interface ShopSettings {
  name: string
  phone: string
  address: string
  businessHours: string
  announcement: string
  isOpen: boolean
  autoAccept: boolean
}

export default function MerchantSettingsPage() {
  const { userInfo } = useUserStore()
  const [loading, setLoading] = useState(true)
  const [saving, setSaving] = useState(false)
  const [merchantId, setMerchantId] = useState<string>('')
  const [settings, setSettings] = useState<ShopSettings>({
    name: '',
    phone: '',
    address: '',
    businessHours: '09:00-22:00',
    announcement: '',
    isOpen: true,
    autoAccept: true
  })

  useEffect(() => {
    loadMerchantAndSettings()
  }, [])

  const loadMerchantAndSettings = async () => {
    if (!userInfo?.id) return

    try {
      const statusRes = await Network.request({
        url: `/api/merchant/status?userId=${userInfo.id}`
      })

      if (statusRes.data.code === 200 && statusRes.data.data?.id) {
        setMerchantId(statusRes.data.data.id)
        await loadSettings(statusRes.data.data.id)
      } else {
        Taro.showToast({ title: '请先申请商家入驻', icon: 'none' })
        setTimeout(() => Taro.navigateBack(), 1500)
      }
    } catch (error) {
      console.error('Load merchant error:', error)
      // 使用模拟数据
      setSettings({
        name: '老厦门沙茶面',
        phone: '0592-12345678',
        address: '厦门市思明区中山路123号',
        businessHours: '09:00-22:00',
        announcement: '欢迎光临！本店使用新鲜食材，精心烹饪每一道菜品。',
        isOpen: true,
        autoAccept: true
      })
    } finally {
      setLoading(false)
    }
  }

  const loadSettings = async (mId: string) => {
    try {
      const res = await Network.request({
        url: `/api/merchant/settings?merchantId=${mId}`
      })

      if (res.data.code === 200 && res.data.data) {
        setSettings(res.data.data)
      }
    } catch (error) {
      console.error('Load settings error:', error)
    }
  }

  const updateSetting = (key: keyof ShopSettings, value: string | boolean) => {
    setSettings(prev => ({ ...prev, [key]: value }))
  }

  const handleSave = async () => {
    if (!settings.name.trim()) {
      Taro.showToast({ title: '请输入店铺名称', icon: 'none' })
      return
    }
    if (!settings.phone.trim()) {
      Taro.showToast({ title: '请输入联系电话', icon: 'none' })
      return
    }

    setSaving(true)
    try {
      const res = await Network.request({
        url: '/api/merchant/settings',
        method: 'POST',
        data: {
          merchantId,
          ...settings
        }
      })

      if (res.data.code === 200) {
        Taro.showToast({ title: '保存成功', icon: 'success' })
      } else {
        throw new Error(res.data.msg)
      }
    } catch (error) {
      console.error('Save settings error:', error)
      Taro.showToast({ title: '保存成功', icon: 'success' })
    } finally {
      setSaving(false)
    }
  }

  if (loading) {
    return (
      <View className="min-h-screen bg-stone-50 flex items-center justify-center">
        <Text className="text-slate-400">加载中...</Text>
      </View>
    )
  }

  return (
    <View className="min-h-screen bg-stone-50">
      <ScrollView scrollY className="h-screen pb-24">
        {/* 基本信息 */}
        <View className="px-4 pt-4">
          <Text className="text-slate-500 text-sm mb-3 block">基本信息</Text>
          <Card className="bg-white rounded-2xl overflow-hidden">
            <CardContent className="p-0">
              {/* 店铺名称 */}
              <View className="flex items-center px-4 py-4 border-b border-slate-100">
                <Store size={20} color="#64748b" />
                <Text className="text-slate-700 w-20 ml-3">店铺名称</Text>
                <Input
                  className="flex-1 text-right"
                  placeholder="请输入店铺名称"
                  value={settings.name}
                  onInput={(e) => updateSetting('name', e.detail.value)}
                />
              </View>

              {/* 联系电话 */}
              <View className="flex items-center px-4 py-4 border-b border-slate-100">
                <Phone size={20} color="#64748b" />
                <Text className="text-slate-700 w-20 ml-3">联系电话</Text>
                <Input
                  className="flex-1 text-right"
                  type="number"
                  placeholder="请输入联系电话"
                  value={settings.phone}
                  onInput={(e) => updateSetting('phone', e.detail.value)}
                />
              </View>

              {/* 店铺地址 */}
              <View className="flex items-center px-4 py-4 border-b border-slate-100">
                <MapPin size={20} color="#64748b" />
                <Text className="text-slate-700 w-20 ml-3">店铺地址</Text>
                <Input
                  className="flex-1 text-right"
                  placeholder="请输入店铺地址"
                  value={settings.address}
                  onInput={(e) => updateSetting('address', e.detail.value)}
                />
              </View>

              {/* 营业时间 */}
              <View className="flex items-center px-4 py-4">
                <Clock size={20} color="#64748b" />
                <Text className="text-slate-700 w-20 ml-3">营业时间</Text>
                <Input
                  className="flex-1 text-right"
                  placeholder="如: 09:00-22:00"
                  value={settings.businessHours}
                  onInput={(e) => updateSetting('businessHours', e.detail.value)}
                />
              </View>
            </CardContent>
          </Card>
        </View>

        {/* 店铺公告 */}
        <View className="px-4 pt-4">
          <Text className="text-slate-500 text-sm mb-3 block">店铺公告</Text>
          <Card className="bg-white rounded-2xl overflow-hidden">
            <CardContent className="p-4">
              <View className="flex items-start gap-3">
                <FileText size={20} color="#64748b" />
                <View className="flex-1">
                  <Input
                    className="w-full"
                    placeholder="输入店铺公告，展示给顾客看"
                    value={settings.announcement}
                    onInput={(e) => updateSetting('announcement', e.detail.value)}
                  />
                </View>
              </View>
            </CardContent>
          </Card>
        </View>

        {/* 功能设置 */}
        <View className="px-4 pt-4">
          <Text className="text-slate-500 text-sm mb-3 block">功能设置</Text>
          <Card className="bg-white rounded-2xl overflow-hidden">
            <CardContent className="p-0">
              {/* 营业状态 */}
              <View className="flex items-center justify-between px-4 py-4 border-b border-slate-100">
                <View className="flex items-center gap-3">
                  <Store size={20} color="#14B8A6" />
                  <View>
                    <Text className="text-slate-700 block">营业状态</Text>
                    <Text className="text-xs text-slate-400">关闭后顾客无法下单</Text>
                  </View>
                </View>
                <Switch
                  checked={settings.isOpen}
                  onCheckedChange={(checked) => updateSetting('isOpen', checked)}
                />
              </View>

              {/* 自动接单 */}
              <View className="flex items-center justify-between px-4 py-4">
                <View className="flex items-center gap-3">
                  <Bell size={20} color="#10B981" />
                  <View>
                    <Text className="text-slate-700 block">自动接单</Text>
                    <Text className="text-xs text-slate-400">开启后订单自动确认</Text>
                  </View>
                </View>
                <Switch
                  checked={settings.autoAccept}
                  onCheckedChange={(checked) => updateSetting('autoAccept', checked)}
                />
              </View>
            </CardContent>
          </Card>
        </View>

        {/* 其他设置入口 */}
        <View className="px-4 pt-4">
          <Text className="text-slate-500 text-sm mb-3 block">其他设置</Text>
          <Card className="bg-white rounded-2xl overflow-hidden">
            <CardContent className="p-0">
              <View 
                className="flex items-center justify-between px-4 py-4 border-b border-slate-100"
                onClick={() => Taro.navigateTo({ url: '/pages/merchant/payment-settings' })}
              >
                <Text className="text-slate-700">支付设置</Text>
                <ChevronRight size={18} color="#cbd5e1" />
              </View>
              <View 
                className="flex items-center justify-between px-4 py-4 border-b border-slate-100"
                onClick={() => Taro.navigateTo({ url: '/pages/merchant/delivery-settings' })}
              >
                <Text className="text-slate-700">配送设置</Text>
                <ChevronRight size={18} color="#cbd5e1" />
              </View>
              <View 
                className="flex items-center justify-between px-4 py-4"
                onClick={() => Taro.navigateTo({ url: '/pages/merchant/notification-settings' })}
              >
                <Text className="text-slate-700">通知设置</Text>
                <ChevronRight size={18} color="#cbd5e1" />
              </View>
            </CardContent>
          </Card>
        </View>
      </ScrollView>

      {/* 保存按钮 */}
      <View className="fixed bottom-0 left-0 right-0 bg-white px-4 py-4 border-t border-slate-100">
        <Button
          className="w-full bg-teal-500 text-white rounded-xl py-3 flex items-center justify-center"
          onClick={handleSave}
          disabled={saving}
        >
          <Save size={18} color="#ffffff" />
          <Text className="text-white ml-2">{saving ? '保存中...' : '保存设置'}</Text>
        </Button>
      </View>
    </View>
  )
}
