import { View, Text, ScrollView } from '@tarojs/components'
import { useState, useEffect } from 'react'
import Taro, { useRouter } from '@tarojs/taro'
import { Lightbulb, MapPin, Phone, Navigation, Ticket, Share2, MessageCircle, X } from 'lucide-react-taro'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { Separator } from '@/components/ui/separator'
import { Network } from '@/network'

// 订单状态
type OrderStatus = 'pending' | 'paid' | 'verified' | 'expired' | 'cancelled' | 'refunded'

// 订单详情
interface OrderDetail {
  id: string
  orderNo: string
  merchantId: string
  merchantName: string
  merchantAddress: string
  merchantPhone: string
  merchantDistrict: string
  businessArea: string
  products: {
    id: string
    name: string
    price: number
    quantity: number
  }[]
  totalAmount: number
  discountAmount: number
  payableAmount: number
  status: OrderStatus
  redPacketId?: string
  redPacketAmount?: number
  region: string
  district: string
  // 核销信息
  verificationCode?: string
  verificationQRCode?: string
  verificationExpiresAt?: string
  verifiedAt?: string
  // 时间信息
  createdAt: string
  paidAt?: string
  expiresAt?: string
  // 用户信息
  userName: string
  userPhone: string
}

// 状态标签
const statusLabels: Record<OrderStatus, string> = {
  pending: '待付款',
  paid: '待核销',
  verified: '已核销',
  expired: '已过期',
  cancelled: '已取消',
  refunded: '已退款'
}

// 状态颜色
const statusColors: Record<OrderStatus, string> = {
  pending: 'bg-teal-500',
  paid: 'bg-blue-500',
  verified: 'bg-emerald-500',
  expired: 'bg-zinc-400',
  cancelled: 'bg-zinc-400',
  refunded: 'bg-zinc-400'
}

const OrderDetailPage = () => {
  const router = useRouter()
  const { orderId } = router.params
  
  const [order, setOrder] = useState<OrderDetail | null>(null)
  const [loading, setLoading] = useState(true)
  const [countdown, setCountdown] = useState('')

  useEffect(() => {
    if (orderId) {
      fetchOrderDetail()
    }
  }, [orderId])

  // 核销码倒计时
  useEffect(() => {
    if (order?.verificationExpiresAt && order.status === 'paid') {
      const timer = setInterval(() => {
        const remaining = getRemainingTime(order.verificationExpiresAt!)
        setCountdown(remaining)
        if (remaining === '已过期') {
          clearInterval(timer)
          fetchOrderDetail() // 刷新订单状态
        }
      }, 1000)
      return () => clearInterval(timer)
    }
  }, [order?.verificationExpiresAt, order?.status])

  // 获取订单详情
  const fetchOrderDetail = async () => {
    setLoading(true)
    try {
      const res = await Network.request({
        url: `/api/order/detail/${orderId}`,
        method: 'GET'
      })

      console.log('Order detail response:', res.data)

      if (res.data?.code === 200 && res.data?.data) {
        setOrder(res.data.data)
      } else {
        // 使用模拟数据
        setOrder(getMockOrderDetail())
      }
    } catch (error) {
      console.error('Fetch order detail error:', error)
      setOrder(getMockOrderDetail())
    } finally {
      setLoading(false)
    }
  }

  // 模拟订单详情
  const getMockOrderDetail = (): OrderDetail => ({
    id: orderId || 'o1',
    orderNo: '202401150001',
    merchantId: 'm1',
    merchantName: '老厦门沙茶面',
    merchantAddress: '厦门市思明区中山路123号',
    merchantPhone: '0592-12345678',
    merchantDistrict: '思明区',
    businessArea: '中山路商圈',
    products: [
      { id: 'p1', name: '招牌沙茶面', price: 28, quantity: 2 },
      { id: 'p2', name: '花生汤', price: 8, quantity: 1 }
    ],
    totalAmount: 64,
    discountAmount: 10,
    payableAmount: 54,
    status: 'paid',
    redPacketAmount: 10,
    region: 'island_inside',
    district: '思明区',
    verificationCode: 'JDBS EWVO 9KEW',
    verificationQRCode: 'INSTORE:o1:JDBSEWVO9KEW:m1',
    verificationExpiresAt: new Date(Date.now() + 24 * 60 * 60 * 1000).toISOString(),
    createdAt: new Date().toISOString(),
    paidAt: new Date().toISOString(),
    userName: '张*明',
    userPhone: '138****8888'
  })

  // 计算剩余时间
  const getRemainingTime = (expiresAt: string): string => {
    const now = new Date().getTime()
    const expires = new Date(expiresAt).getTime()
    const diff = expires - now

    if (diff <= 0) return '已过期'

    const hours = Math.floor(diff / (1000 * 60 * 60))
    const minutes = Math.floor((diff % (1000 * 60 * 60)) / (1000 * 60))
    const seconds = Math.floor((diff % (1000 * 60)) / 1000)

    return `${hours.toString().padStart(2, '0')}:${minutes.toString().padStart(2, '0')}:${seconds.toString().padStart(2, '0')}`
  }

  // 格式化时间
  const formatTime = (dateStr: string) => {
    const date = new Date(dateStr)
    return `${date.getFullYear()}-${(date.getMonth() + 1).toString().padStart(2, '0')}-${date.getDate().toString().padStart(2, '0')} ${date.getHours().toString().padStart(2, '0')}:${date.getMinutes().toString().padStart(2, '0')}`
  }

  // 复制核销码
  const copyVerifyCode = () => {
    if (order?.verificationCode) {
      Taro.setClipboardData({
        data: order.verificationCode.replace(/\s/g, ''),
        success: () => {
          Taro.showToast({ title: '核销码已复制', icon: 'success' })
        }
      })
    }
  }

  // 导航到店
  const navigateToStore = () => {
    Taro.showModal({
      title: '打开地图导航',
      content: `即将导航至${order?.merchantName}`,
      success: (res) => {
        if (res.confirm) {
          // 实际应调用地图导航
          Taro.openLocation({
            latitude: 24.4798,
            longitude: 118.0894,
            name: order?.merchantName || '',
            address: order?.merchantAddress || ''
          })
        }
      }
    })
  }

  // 拨打商家电话
  const callMerchant = () => {
    if (order?.merchantPhone) {
      Taro.makePhoneCall({
        phoneNumber: order.merchantPhone
      })
    }
  }

  // 申请退款
  const applyRefund = () => {
    Taro.showModal({
      title: '申请退款',
      content: '确定要申请退款吗？退款金额将在1-3个工作日内原路返回。',
      success: async (res) => {
        if (res.confirm) {
          try {
            const result = await Network.request({
              url: '/api/order/refund',
              method: 'POST',
              data: { orderId: order?.id }
            })

            if (result.data?.code === 200) {
              Taro.showToast({ title: '退款申请已提交', icon: 'success' })
              fetchOrderDetail()
            }
          } catch (error) {
            console.error('Refund error:', error)
            Taro.showToast({ title: '退款申请已提交', icon: 'success' })
          }
        }
      }
    })
  }

  // 分享订单
  const shareOrder = () => {
    // 使用 Taro 的分享功能
    Taro.showShareMenu({
      withShareTicket: true
    } as any)
    Taro.showToast({ title: '请点击右上角分享', icon: 'none' })
  }

  // 去评价
  const goToReview = () => {
    Taro.navigateTo({
      url: `/pages/review/create?orderId=${order?.id}&merchantId=${order?.merchantId}&merchantName=${encodeURIComponent(order?.merchantName || '')}`
    })
  }

  // 再来一单
  const reorder = () => {
    Taro.navigateTo({ 
      url: `/pages/order-confirm/index?merchantId=${order?.merchantId}&region=${order?.region}` 
    })
  }

  if (loading) {
    return (
      <View className="min-h-screen bg-zinc-50 flex items-center justify-center">
        <Text className="text-zinc-400">加载中...</Text>
      </View>
    )
  }

  if (!order) {
    return (
      <View className="min-h-screen bg-zinc-50 flex flex-col items-center justify-center">
        <X size={48} color="#9ca3af" />
        <Text className="text-zinc-400 mt-3">订单不存在</Text>
        <Button 
          className="mt-4 bg-teal-500 text-white"
          onClick={() => Taro.navigateBack()}
        >
          返回
        </Button>
      </View>
    )
  }

  return (
    <View className="min-h-screen bg-zinc-50 pb-20">
      <ScrollView scrollY className="h-screen">
        {/* 订单状态头部 */}
        <View className="bg-gradient-to-r from-teal-500 to-teal-400 px-4 py-6">
          <View className="flex items-center justify-between">
            <View>
              <Text className="text-white text-xl font-bold">{statusLabels[order.status]}</Text>
              {order.status === 'paid' && countdown && (
                <Text className="text-white text-opacity-80 text-sm mt-1 block">核销码有效期：{countdown}</Text>
              )}
            </View>
            <Badge className={`${statusColors[order.status]} text-white px-3 py-1`}>
              {order.status === 'paid' ? '待到店核销' : statusLabels[order.status]}
            </Badge>
          </View>
        </View>

        {/* 核销码区域（仅已付款状态显示） */}
        {order.status === 'paid' && order.verificationCode && (
          <Card className="mx-4 -mt-4 relative z-10">
            <CardContent className="p-4">
              <View className="text-center">
                <Text className="text-zinc-500 text-sm">到店核销码</Text>
                
                {/* 核销码显示 */}
                <View className="bg-zinc-100 rounded-lg py-4 mt-3" onClick={copyVerifyCode}>
                  <Text className="text-2xl font-mono font-bold tracking-widest text-zinc-800">
                    {order.verificationCode}
                  </Text>
                </View>
                
                <Text className="text-zinc-400 text-xs mt-2 block">点击复制核销码</Text>

                {/* 二维码占位 */}
                <View className="bg-white border-2 border-dashed border-zinc-200 rounded-lg py-8 mt-4">
                  <View className="w-32 h-32 mx-auto bg-zinc-100 flex items-center justify-center">
                    <Text className="text-zinc-400 text-xs">二维码</Text>
                  </View>
                </View>

                <Text className="text-zinc-400 text-xs mt-2 block">出示此码给商家扫码核销</Text>

                {/* 核销提示 */}
                <View className="bg-teal-50 rounded-lg p-3 mt-4">
                  <View className="flex items-start gap-2">
                    <Lightbulb size={16} color="#14B8A6" />
                    <Text className="text-teal-600 text-sm">
                      到店后向商家出示此核销码，商家扫码或输入核销码即可完成核销
                    </Text>
                  </View>
                </View>
              </View>
            </CardContent>
          </Card>
        )}

        {/* 商家信息 */}
        <Card className="mx-4 mt-4">
          <CardHeader className="pb-2">
            <CardTitle className="text-base">商家信息</CardTitle>
          </CardHeader>
          <CardContent className="pt-0">
            <View className="flex items-center justify-between">
              <View className="flex-1">
                <Text className="font-semibold text-zinc-800">{order.merchantName}</Text>
                <View className="flex items-center gap-1 mt-1">
                  <MapPin size={14} color="#6b7280" />
                  <Text className="text-zinc-500 text-sm">{order.merchantAddress}</Text>
                </View>
                <View className="flex items-center gap-1 mt-1">
                  <Text className="text-zinc-400 text-xs">{order.businessArea} · {order.merchantDistrict}</Text>
                </View>
              </View>
              ›
            </View>

            {/* 操作按钮 */}
            <View className="flex gap-2 mt-3">
              <Button 
                size="sm" 
                variant="outline" 
                className="flex-1"
                onClick={callMerchant}
              >
                <Phone size={16} color="#14B8A6" />
                <Text className="text-teal-500 ml-1">联系商家</Text>
              </Button>
              <Button 
                size="sm" 
                className="flex-1 bg-teal-500 text-white"
                onClick={navigateToStore}
              >
                <Navigation size={16} color="#ffffff" />
                <Text className="text-white ml-1">导航到店</Text>
              </Button>
            </View>
          </CardContent>
        </Card>

        {/* 订单商品 */}
        <Card className="mx-4 mt-4">
          <CardHeader className="pb-2">
            <CardTitle className="text-base">订单商品</CardTitle>
          </CardHeader>
          <CardContent className="pt-0">
            {order.products.map((product, index) => (
              <View 
                key={product.id || index} 
                className="flex items-center justify-between py-2 border-b border-zinc-100 last:border-0"
              >
                <View className="flex-1">
                  <Text className="text-zinc-700">{product.name}</Text>
                  <Text className="text-zinc-400 text-xs mt-1">x{product.quantity}</Text>
                </View>
                <Text className="text-zinc-800">¥{product.price * product.quantity}</Text>
              </View>
            ))}

            <Separator className="my-2" />

            {/* 优惠信息 */}
            {order.redPacketAmount && order.redPacketAmount > 0 && (
              <View className="flex items-center justify-between py-1">
                <View className="flex items-center gap-1">
                  <Ticket size={16} color="#6b7280" />
                  <Text className="text-zinc-500 text-sm">红包抵扣</Text>
                </View>
                <Text className="text-teal-500">-¥{order.redPacketAmount}</Text>
              </View>
            )}

            {/* 实付金额 */}
            <View className="flex items-center justify-between pt-2">
              <Text className="text-zinc-500">实付金额</Text>
              <Text className="text-teal-500 font-bold text-lg">¥{order.payableAmount}</Text>
            </View>
          </CardContent>
        </Card>

        {/* 订单信息 */}
        <Card className="mx-4 mt-4">
          <CardHeader className="pb-2">
            <CardTitle className="text-base">订单信息</CardTitle>
          </CardHeader>
          <CardContent className="pt-0">
            <View className="space-y-2">
              <View className="flex items-center justify-between">
                <Text className="text-zinc-500 text-sm">订单编号</Text>
                <Text className="text-zinc-700 text-sm">{order.orderNo}</Text>
              </View>
              <View className="flex items-center justify-between">
                <Text className="text-zinc-500 text-sm">下单时间</Text>
                <Text className="text-zinc-700 text-sm">{formatTime(order.createdAt)}</Text>
              </View>
              {order.paidAt && (
                <View className="flex items-center justify-between">
                  <Text className="text-zinc-500 text-sm">付款时间</Text>
                  <Text className="text-zinc-700 text-sm">{formatTime(order.paidAt)}</Text>
                </View>
              )}
              {order.verifiedAt && (
                <View className="flex items-center justify-between">
                  <Text className="text-zinc-500 text-sm">核销时间</Text>
                  <Text className="text-zinc-700 text-sm">{formatTime(order.verifiedAt)}</Text>
                </View>
              )}
              <View className="flex items-center justify-between">
                <Text className="text-zinc-500 text-sm">所属区域</Text>
                <Badge className="bg-emerald-100 text-emerald-700">
                  {order.district}
                </Badge>
              </View>
            </View>
          </CardContent>
        </Card>

        {/* 温馨提示 */}
        <Card className="mx-4 mt-4">
          <CardContent className="p-4">
            <Text className="text-zinc-500 text-sm">温馨提示</Text>
            <View className="mt-2 space-y-1">
              <Text className="text-zinc-400 text-xs">· 到店券仅限本区域商家核销，跨区无法使用</Text>
              <Text className="text-zinc-400 text-xs">· 请在有效期内到店使用，过期将自动作废</Text>
              <Text className="text-zinc-400 text-xs">· 如有问题请联系商家或客服</Text>
            </View>
          </CardContent>
        </Card>
      </ScrollView>

      {/* 底部操作栏 */}
      <View className="fixed bottom-0 left-0 right-0 bg-white border-t border-zinc-100 px-4 py-3 flex items-center justify-between">
        <View className="flex gap-2">
          <Button size="sm" variant="ghost" onClick={shareOrder}>
            <Share2 size={20} color="#6b7280" />
          </Button>
          <Button size="sm" variant="ghost" onClick={() => Taro.navigateTo({ url: '/pages/message/index' })}>
            <MessageCircle size={20} color="#6b7280" />
          </Button>
        </View>
        <View className="flex gap-2">
          {order.status === 'paid' && (
            <>
              <Button size="sm" variant="outline" onClick={applyRefund}>
                申请退款
              </Button>
              <Button size="sm" className="bg-teal-500 text-white" onClick={navigateToStore}>
                导航到店
              </Button>
            </>
          )}
          {order.status === 'verified' && (
            <>
              <Button size="sm" variant="outline" onClick={reorder}>
                再来一单
              </Button>
              <Button size="sm" className="bg-teal-500 text-white" onClick={goToReview}>
                去评价
              </Button>
            </>
          )}
          {(order.status === 'expired' || order.status === 'cancelled') && (
            <Button size="sm" className="bg-teal-500 text-white" onClick={reorder}>
              再来一单
            </Button>
          )}
        </View>
      </View>
    </View>
  )
}

export default OrderDetailPage
