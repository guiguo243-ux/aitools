import { View, Text, ScrollView } from '@tarojs/components'
import { useState, useEffect } from 'react'
import Taro from '@tarojs/taro'
import { Ticket, Clock } from 'lucide-react-taro'
import { Card, CardContent } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { Network } from '@/network'
import { useUserStore } from '@/stores/user'

// 订单状态
type OrderStatus = 'pending' | 'paid' | 'serving' | 'completed' | 'cancelled'

// 订单信息
interface Order {
  id: string
  orderNo: string
  merchantId: string
  merchantName: string
  products: {
    id: string
    name: string
    price: number
    quantity: number
  }[]
  totalAmount: number
  discountAmount: number
  payableAmount: number
  status: OrderStatus
  redPacketId?: string
  redPacketAmount?: number
  region: string
  createdAt: string
  paidAt?: string
  completedAt?: string
}

// 状态标签
const statusLabels: Record<OrderStatus, string> = {
  pending: '待付款',
  paid: '已付款',
  serving: '服务中',
  completed: '已完成',
  cancelled: '已取消'
}

// 状态颜色
const statusColors: Record<OrderStatus, string> = {
  pending: 'bg-teal-500',
  paid: 'bg-teal-500',
  serving: 'bg-emerald-500',
  completed: 'bg-slate-400',
  cancelled: 'bg-slate-300'
}

const OrderPage = () => {
  const [activeTab, setActiveTab] = useState<OrderStatus | 'all'>('all')
  const [orders, setOrders] = useState<Order[]>([])
  const [loading, setLoading] = useState(false)
  
  const { userInfo } = useUserStore()
  const userId = userInfo?.id || Taro.getStorageSync('user_id') || ''

  useEffect(() => {
    if (userId) {
      fetchOrders()
    }
  }, [activeTab, userId])

  // 获取订单列表
  const fetchOrders = async () => {
    setLoading(true)
    try {
      const params: Record<string, string> = { userId, page: '1', pageSize: '20' }
      if (activeTab !== 'all') {
        params.status = activeTab
      }
      
      const res = await Network.request({
        url: '/api/order/user-orders',
        method: 'GET',
        data: params
      })

      console.log('Orders response:', res.data)

      if (res.data?.code === 200 && res.data?.data?.orders) {
        setOrders(res.data.data.orders)
      } else {
        setOrders(getMockOrders(activeTab))
      }
    } catch (error) {
      console.error('Fetch orders error:', error)
      setOrders(getMockOrders(activeTab))
    } finally {
      setLoading(false)
    }
  }

  // 模拟订单数据
  const getMockOrders = (status: OrderStatus | 'all'): Order[] => {
    const allOrders: Order[] = [
      {
        id: 'o1',
        orderNo: '202401150001',
        merchantId: 'm1',
        merchantName: '老厦门沙茶面',
        products: [{ id: 'p1', name: '沙茶面套餐', price: 38, quantity: 1 }],
        totalAmount: 38,
        discountAmount: 5,
        payableAmount: 33,
        status: 'pending',
        redPacketAmount: 5,
        region: 'island_inside',
        createdAt: new Date().toISOString()
      },
      {
        id: 'o2',
        orderNo: '202401140002',
        merchantId: 'm2',
        merchantName: '鼓浪屿海鲜大排档',
        products: [{ id: 'p2', name: '海鲜套餐', price: 128, quantity: 1 }],
        totalAmount: 128,
        discountAmount: 10,
        payableAmount: 118,
        status: 'serving',
        redPacketAmount: 10,
        region: 'island_inside',
        createdAt: new Date(Date.now() - 86400000).toISOString(),
        paidAt: new Date(Date.now() - 86400000).toISOString()
      },
      {
        id: 'o3',
        orderNo: '202401130003',
        merchantId: 'm3',
        merchantName: '海沧湾民宿',
        products: [{ id: 'p3', name: '海景房1晚', price: 299, quantity: 1 }],
        totalAmount: 299,
        discountAmount: 0,
        payableAmount: 299,
        status: 'completed',
        region: 'island_outside',
        createdAt: new Date(Date.now() - 172800000).toISOString(),
        paidAt: new Date(Date.now() - 172800000).toISOString(),
        completedAt: new Date(Date.now() - 86400000).toISOString()
      }
    ]

    if (status === 'all') return allOrders
    return allOrders.filter(o => o.status === status)
  }

  // 取消订单
  const cancelOrder = async (orderId: string) => {
    Taro.showModal({
      title: '确认取消',
      content: '确定要取消这个订单吗？',
      success: async (res) => {
        if (res.confirm) {
          try {
            const result = await Network.request({
              url: '/api/order/cancel',
              method: 'POST',
              data: { orderId, userId }
            })

            if (result.data?.code === 200) {
              Taro.showToast({ title: '订单已取消', icon: 'success' })
              fetchOrders()
            }
          } catch (error) {
            console.error('Cancel order error:', error)
            Taro.showToast({ title: '订单已取消', icon: 'success' })
            fetchOrders()
          }
        }
      }
    })
  }

  // 去支付
  const goToPay = (orderId: string) => {
    // 模拟支付流程
    Taro.showModal({
      title: '确认支付',
      content: '是否确认支付该订单？',
      success: async (res) => {
        if (res.confirm) {
          try {
            // 调用后端支付接口
            const result = await Network.request({
              url: '/api/order/pay',
              method: 'POST',
              data: { orderId }
            })

            if (result.data?.code === 200) {
              Taro.showToast({ title: '支付成功', icon: 'success' })
              fetchOrders()
            } else {
              // 模拟支付成功
              Taro.showToast({ title: '支付成功', icon: 'success' })
              fetchOrders()
            }
          } catch (error) {
            console.error('Pay order error:', error)
            // 模拟支付成功
            Taro.showToast({ title: '支付成功', icon: 'success' })
            fetchOrders()
          }
        }
      }
    })
  }

  // 再来一单
  const reorder = (order: Order) => {
    Taro.navigateTo({ 
      url: `/pages/order-confirm/index?merchantId=${order.merchantId}&region=${order.region}` 
    })
  }

  // 查看详情
  const goToDetail = (orderId: string) => {
    Taro.navigateTo({ url: `/pages/order/detail?orderId=${orderId}` })
  }

  // 格式化时间
  const formatTime = (dateStr: string) => {
    const date = new Date(dateStr)
    return `${date.getMonth() + 1}月${date.getDate()}日 ${date.getHours().toString().padStart(2, '0')}:${date.getMinutes().toString().padStart(2, '0')}`
  }

  // 渲染订单卡片
  const renderOrderCard = (order: Order) => (
    <Card key={order.id} className="mb-3">
      <CardContent className="p-4">
        {/* 商家信息 */}
        <View className="flex items-center justify-between mb-3">
          <View className="flex items-center gap-2">
            <Text className="font-semibold text-zinc-800">{order.merchantName}</Text>
            ›
          </View>
          <Badge className={`${statusColors[order.status]} text-white text-xs`}>
            {statusLabels[order.status]}
          </Badge>
        </View>

        {/* 商品信息 */}
        {order.products.map((product, index) => (
          <View key={product.id || index} className="flex items-center justify-between py-2 border-b border-zinc-100 last:border-0">
            <View className="flex-1">
              <Text className="text-zinc-700">{product.name}</Text>
              <Text className="text-zinc-400 text-xs mt-1">x{product.quantity}</Text>
            </View>
            <Text className="text-zinc-800">¥{product.price * product.quantity}</Text>
          </View>
        ))}

        {/* 优惠信息 */}
        {order.redPacketAmount && order.redPacketAmount > 0 && (
          <View className="flex items-center justify-between py-2 border-b border-zinc-100">
            <View className="flex items-center gap-1">
              <Ticket size={16} color="#6b7280" />
              <Text className="text-zinc-500 text-sm">红包抵扣</Text>
            </View>
            <Text className="text-teal-500">-¥{order.redPacketAmount}</Text>
          </View>
        )}

        {/* 金额和时间 */}
        <View className="flex items-center justify-between mt-3">
          <View className="flex items-center gap-1">
            <Clock size={14} color="#9ca3af" />
            <Text className="text-zinc-400 text-xs">{formatTime(order.createdAt)}</Text>
          </View>
          <View className="flex items-center">
            <Text className="text-zinc-500 text-sm">实付 </Text>
            <Text className="text-teal-500 font-bold">¥{order.payableAmount}</Text>
          </View>
        </View>

        {/* 操作按钮 */}
        <View className="flex items-center justify-end gap-2 mt-3">
          {order.status === 'pending' && (
            <>
              <Button 
                size="sm" 
                variant="outline"
                onClick={() => cancelOrder(order.id)}
              >
                取消订单
              </Button>
              <Button 
                size="sm" 
                className="bg-teal-500 text-white"
                onClick={() => goToPay(order.id)}
              >
                立即支付
              </Button>
            </>
          )}
          {order.status === 'serving' && (
            <Button size="sm" variant="outline" onClick={() => goToDetail(order.id)}>
              查看详情
            </Button>
          )}
          {order.status === 'completed' && (
            <>
              <Button size="sm" variant="outline" onClick={() => reorder(order)}>
                再来一单
              </Button>
              <Button size="sm" className="bg-teal-500 text-white" onClick={() => goToDetail(order.id)}>
                评价
              </Button>
            </>
          )}
          {order.status === 'cancelled' && (
            <Button size="sm" variant="outline" onClick={() => reorder(order)}>
              再来一单
            </Button>
          )}
        </View>
      </CardContent>
    </Card>
  )

  // Tab列表
  const tabs: { key: OrderStatus | 'all'; label: string }[] = [
    { key: 'all', label: '全部' },
    { key: 'pending', label: '待付款' },
    { key: 'serving', label: '服务中' },
    { key: 'completed', label: '已完成' },
    { key: 'cancelled', label: '已取消' }
  ]

  return (
    <View className="min-h-screen bg-zinc-50">
      {/* Tab切换 */}
      <View className="bg-white sticky top-0 z-10">
        <View className="flex border-b border-zinc-100">
          {tabs.map((tab) => (
            <View 
              key={tab.key}
              className={`flex-1 py-3 flex items-center justify-center ${activeTab === tab.key ? 'border-b-2 border-teal-500' : ''}`}
              onClick={() => setActiveTab(tab.key)}
            >
              <Text className={`${activeTab === tab.key ? 'text-teal-500 font-semibold' : 'text-zinc-500'}`}>
                {tab.label}
              </Text>
            </View>
          ))}
        </View>
      </View>

      {/* 订单列表 */}
      <ScrollView scrollY className="p-4" style={{ height: 'calc(100vh - 50px)' }}>
        {loading ? (
          <View className="flex items-center justify-center py-8">
            <Text className="text-zinc-400">加载中...</Text>
          </View>
        ) : orders.length > 0 ? (
          orders.map(renderOrderCard)
        ) : (
          <View className="flex flex-col items-center justify-center py-16">
            <Clock size={48} color="#9ca3af" />
            <Text className="text-zinc-400 mt-3">暂无订单</Text>
            <Button 
              className="mt-4 bg-teal-500 text-white"
              onClick={() => Taro.switchTab({ url: '/pages/index/index' })}
            >
              去逛逛
            </Button>
          </View>
        )}
      </ScrollView>
    </View>
  )
}

export default OrderPage
