import { View, Text, ScrollView } from '@tarojs/components'
import { useState } from 'react'
import Taro, { useDidShow } from '@tarojs/taro'
import { Network } from '@/network'
import { Card, CardContent } from '@/components/ui/card'
import { UtensilsCrossed, House, Gamepad2, Heart, Dumbbell, GraduationCap, Stethoscope, Car, ChevronRight, ShoppingBag, MapPin, Star } from 'lucide-react-taro'
import './index.css'

interface Merchant {
  id: string
  name: string
  cover_image: string
  rating: string
  address: string
  district: string
  description: string
  region: string
  category_id: number
}

const categories = [
  { id: 1, name: '餐饮美食', icon: 'utensils', color: 'bg-teal-50' },
  { id: 2, name: '家政服务', icon: 'house', color: 'bg-teal-50' },
  { id: 3, name: '休闲娱乐', icon: 'gamepad', color: 'bg-teal-50' },
  { id: 4, name: '美容美发', icon: 'heart', color: 'bg-teal-50' },
  { id: 5, name: '运动健身', icon: 'dumbbell', color: 'bg-teal-50' },
  { id: 6, name: '教育培训', icon: 'graduation', color: 'bg-teal-50' },
  { id: 7, name: '医疗健康', icon: 'stethoscope', color: 'bg-teal-50' },
  { id: 8, name: '汽车服务', icon: 'car', color: 'bg-teal-50' },
]

// 获取分类图标
const getCategoryIcon = (iconName: string, size: number = 20, color: string = '#14B8A6') => {
  const iconMap: Record<string, React.ReactNode> = {
    'utensils': <UtensilsCrossed size={size} color={color} />,
    'house': <House size={size} color={color} />,
    'gamepad': <Gamepad2 size={size} color={color} />,
    'heart': <Heart size={size} color={color} />,
    'dumbbell': <Dumbbell size={size} color={color} />,
    'graduation': <GraduationCap size={size} color={color} />,
    'stethoscope': <Stethoscope size={size} color={color} />,
    'car': <Car size={size} color={color} />,
  }
  return iconMap[iconName] || <ShoppingBag size={size} color={color} />
}

const CategoryPage = () => {
  const [region, setRegion] = useState<'island_inside' | 'island_outside'>('island_inside')
  const [selectedCategory, setSelectedCategory] = useState<number | null>(null)
  const [merchants, setMerchants] = useState<Merchant[]>([])

  const loadMerchants = async () => {
    try {
      const res = await Network.request({
        url: '/api/merchant/list',
        method: 'GET',
        data: {
          region,
          categoryId: selectedCategory,
          page: 1,
          pageSize: 20
        }
      })
      if (res.data?.code === 200) {
        setMerchants(res.data.data?.merchants || [])
      }
    } catch (error) {
      console.error('Load merchants error:', error)
    }
  }

  useDidShow(() => {
    loadMerchants()
  })

  const goToMerchantDetail = (merchantId: string) => {
    Taro.navigateTo({
      url: `/pages/merchant/detail?id=${merchantId}`
    })
  }

  return (
    <View className="min-h-screen bg-stone-50">
      {/* 区域切换 */}
      <View className="bg-white px-4 py-3 sticky top-0 z-10 shadow-sm">
        <View className="flex gap-2">
          <View
            className={`flex-1 py-3 rounded-xl text-center ${
              region === 'island_inside'
                ? 'bg-teal-500 shadow-lg shadow-teal-500'
                : 'bg-slate-100'
            }`}
            onClick={() => {
              setRegion('island_inside')
              loadMerchants()
            }}
          >
            <Text className={region === 'island_inside' ? 'text-white font-semibold' : 'text-slate-500'}>
              岛内
            </Text>
          </View>
          <View
            className={`flex-1 py-3 rounded-xl text-center ${
              region === 'island_outside'
                ? 'bg-teal-500 shadow-lg shadow-teal-500'
                : 'bg-slate-100'
            }`}
            onClick={() => {
              setRegion('island_outside')
              loadMerchants()
            }}
          >
            <Text className={region === 'island_outside' ? 'text-white font-semibold' : 'text-slate-500'}>
              岛外
            </Text>
          </View>
        </View>
      </View>

      <ScrollView scrollY className="h-[calc(100vh-100px)]">
        {/* 分类列表 */}
        <View className="p-4">
          <View className="flex items-center gap-2 mb-3">
            <View className="w-1 h-5 bg-gradient-to-b from-teal-500 to-teal-600 rounded-full" />
            <Text className="text-base font-bold text-slate-800">全部分类</Text>
          </View>

          <View className="grid grid-cols-2 gap-3">
            {categories.map((cat) => (
              <Card 
                key={cat.id}
                className={`overflow-hidden ${selectedCategory === cat.id ? 'ring-2 ring-teal-500 shadow-lg' : ''}`}
                onClick={() => {
                  setSelectedCategory(cat.id)
                  loadMerchants()
                }}
              >
                <CardContent className="p-4 flex items-center gap-3">
                  <View className={`w-10 h-10 ${cat.color} rounded-xl flex items-center justify-center`}>
                    {getCategoryIcon(cat.icon, 20, '#14B8A6')}
                  </View>
                  <View className="flex-1">
                    <Text className="text-sm font-semibold text-slate-800 block">{cat.name}</Text>
                    <Text className="text-xs text-slate-400">点击查看</Text>
                  </View>
                  <ChevronRight size={18} color="#cbd5e1" />
                </CardContent>
              </Card>
            ))}
          </View>
        </View>

        {/* 商家列表 */}
        {selectedCategory && (
          <View className="px-4 pb-4">
            <View className="flex items-center justify-between mb-3">
              <View className="flex items-center gap-2">
                <View className="w-1 h-5 bg-gradient-to-b from-teal-500 to-teal-600 rounded-full" />
                <Text className="text-base font-bold text-slate-800">
                  {categories.find(c => c.id === selectedCategory)?.name || '商家列表'}
                </Text>
              </View>
              <Text className="text-xs text-slate-400">{merchants.length} 家商家</Text>
            </View>

            {merchants.length === 0 ? (
              <View className="flex flex-col items-center justify-center py-8 bg-white rounded-2xl shadow-sm">
                <ShoppingBag size={48} color="#cbd5e1" />
                <Text className="text-slate-400 text-sm mt-3">暂无商家</Text>
              </View>
            ) : (
              <View className="flex flex-col gap-3">
                {merchants.map((merchant) => (
                  <Card 
                    key={merchant.id} 
                    className="overflow-hidden shadow-lg shadow-slate-200 rounded-2xl"
                    onClick={() => goToMerchantDetail(merchant.id)}
                  >
                    <CardContent className="p-3 flex items-center gap-3">
                      <View className="w-12 h-12 bg-gradient-to-br from-teal-100 to-teal-50 rounded-xl flex items-center justify-center">
                        {getCategoryIcon(categories.find(c => c.id === merchant.category_id)?.icon || 'utensils', 24, '#14B8A6')}
                      </View>
                      <View className="flex-1 min-w-0">
                        <Text className="text-sm font-semibold text-slate-800 truncate block">{merchant.name}</Text>
                        <View className="flex items-center gap-1 mt-1">
                          <MapPin size={12} color="#94a3b8" />
                          <Text className="text-xs text-slate-500 truncate">{merchant.address}</Text>
                        </View>
                      </View>
                      <View className="flex items-center gap-1">
                        <Star size={14} color="#fbbf24" />
                        <Text className="text-sm font-semibold text-amber-500">{merchant.rating}</Text>
                      </View>
                    </CardContent>
                  </Card>
                ))}
              </View>
            )}
          </View>
        )}
      </ScrollView>
    </View>
  )
}

export default CategoryPage
