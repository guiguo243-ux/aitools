export default typeof definePageConfig === 'function'
  ? definePageConfig({ navigationBarTitleText: '协议详情' })
  : { navigationBarTitleText: '协议详情' }
