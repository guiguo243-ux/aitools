export default typeof definePageConfig === 'function'
  ? definePageConfig({ navigationBarTitleText: '退款申请' })
  : { navigationBarTitleText: '退款申请' }
