import { useState, useEffect } from 'react'
import { View, Text, ScrollView } from '@tarojs/components'
import Taro, { useRouter } from '@tarojs/taro'

import { Network } from '@/network'
import { useUserStore } from '@/stores/user'
import { Button } from '@/components/ui/button'
import { Textarea } from '@/components/ui/textarea'
import { CircleAlert, Check, Clock } from 'lucide-react-taro'

const REFUND_REASONS = [
  '不想买了',
  '商家联系不上',
  '商家拒绝服务',
  '服务与描述不符',
  '其他原因'
]

const STATUS_MAP: Record<string, { label: string; color: string }> = {
  pending: { label: '审核中', color: 'text-teal-500' },
  approved: { label: '已通过', color: 'text-green-500' },
  rejected: { label: '已拒绝', color: 'text-teal-500' },
  refunded: { label: '已退款', color: 'text-blue-500' },
  cancelled: { label: '已取消', color: 'text-gray-400' }
}

export default function RefundPage() {
  const router = useRouter()
  const { userInfo, isLoggedIn } = useUserStore()
  const [step, setStep] = useState<'form' | 'detail'>('form')
  const [orderId, setOrderId] = useState('')
  const [reason, setReason] = useState('')
  const [customReason, setCustomReason] = useState('')
  const [refund, setRefund] = useState<any>(null)
  const [submitting, setSubmitting] = useState(false)

  useEffect(() => {
    if (router.params.orderId) {
      setOrderId(router.params.orderId)
    }
    if (router.params.refundId) {
      loadRefundDetail(router.params.refundId as string)
      setStep('detail')
    }
  }, [router.params])

  const loadRefundDetail = async (refundId: string) => {
    try {
      const res = await Network.request({
        url: `/api/refund/detail/${refundId}`
      })

      if (res.data.code === 200) {
        setRefund(res.data.data)
      }
    } catch (error) {
      console.error('Load refund detail error:', error)
    }
  }

  const handleSubmit = async () => {
    if (!isLoggedIn || !userInfo?.id) {
      Taro.navigateTo({ url: '/pages/login/index' })
      return
    }

    if (!orderId) {
      Taro.showToast({ title: '订单ID不能为空', icon: 'none' })
      return
    }

    const finalReason = reason === '其他原因' ? customReason : reason
    if (!finalReason) {
      Taro.showToast({ title: '请选择或填写退款原因', icon: 'none' })
      return
    }

    setSubmitting(true)
    try {
      const res = await Network.request({
        url: '/api/refund/request',
        method: 'POST',
        data: {
          orderId,
          userId: userInfo.id,
          reason: finalReason
        }
      })

      if (res.data.code === 200) {
        Taro.showToast({ title: '申请成功', icon: 'success' })
        if (res.data.data?.refundId) {
          loadRefundDetail(res.data.data.refundId)
          setStep('detail')
        }
      } else {
        Taro.showToast({ title: res.data.msg, icon: 'none' })
      }
    } catch (error) {
      Taro.showToast({ title: '申请失败', icon: 'none' })
    } finally {
      setSubmitting(false)
    }
  }

  const handleCancel = async () => {
    if (!refund?.id || !userInfo?.id) return

    try {
      const res = await Network.request({
        url: '/api/refund/cancel',
        method: 'POST',
        data: {
          refundId: refund.id,
          userId: userInfo.id
        }
      })

      if (res.data.code === 200) {
        Taro.showToast({ title: '已取消', icon: 'success' })
        loadRefundDetail(refund.id)
      } else {
        Taro.showToast({ title: res.data.msg, icon: 'none' })
      }
    } catch (error) {
      Taro.showToast({ title: '取消失败', icon: 'none' })
    }
  }

  const formatDate = (dateStr: string) => {
    if (!dateStr) return ''
    return new Date(dateStr).toLocaleString('zh-CN')
  }

  if (step === 'detail' && refund) {
    const statusInfo = STATUS_MAP[refund.status] || STATUS_MAP.pending

    return (
      <View className="min-h-screen bg-gray-50">
        <ScrollView scrollY className="h-screen px-4 py-4">
          {/* 状态卡片 */}
          <View className="bg-white rounded-xl p-6 mb-4">
            <View className="flex items-center justify-center mb-4">
              {refund.status === 'pending' ? (
                <Clock size={40} color="#f59e0b" />
              ) : refund.status === 'refunded' || refund.status === 'approved' ? (
                <Check size={40} color="#22c55e" />
              ) : (
                <CircleAlert size={40} color="#ef4444" />
              )}
            </View>
            <Text className={`block text-center text-lg font-medium ${statusInfo.color}`}>
              {statusInfo.label}
            </Text>
            <Text className="block text-center text-sm text-gray-500 mt-2">
              退款金额：¥{refund.amount}
            </Text>
          </View>

          {/* 详情信息 */}
          <View className="bg-white rounded-xl p-4 mb-4">
            <Text className="block text-base font-medium mb-3">退款信息</Text>
            <View className="space-y-2">
              <View className="flex justify-between">
                <Text className="text-gray-500">退款单号</Text>
                <Text className="text-gray-700">{refund.id}</Text>
              </View>
              <View className="flex justify-between">
                <Text className="text-gray-500">订单编号</Text>
                <Text className="text-gray-700">{refund.order_id}</Text>
              </View>
              <View className="flex justify-between">
                <Text className="text-gray-500">申请时间</Text>
                <Text className="text-gray-700">{formatDate(refund.created_at)}</Text>
              </View>
              <View className="flex justify-between">
                <Text className="text-gray-500">退款原因</Text>
                <Text className="text-gray-700">{refund.reason}</Text>
              </View>
            </View>
          </View>

          {/* 取消按钮 */}
          {refund.status === 'pending' && (
            <Button
              className="w-full bg-gray-200 text-gray-700 rounded-xl py-3"
              onClick={handleCancel}
            >
              取消退款申请
            </Button>
          )}
        </ScrollView>
      </View>
    )
  }

  return (
    <View className="min-h-screen bg-gray-50">
      <ScrollView scrollY className="h-screen px-4 py-4">
        {/* 退款须知 */}
        <View className="bg-teal-50 rounded-xl p-4 mb-4">
          <View className="flex items-start gap-2">
            <CircleAlert size={18} color="#14B8A6" />
            <View className="flex-1">
              <Text className="text-sm text-teal-800 font-medium">退款须知</Text>
              <Text className="text-xs text-teal-700 mt-1">
                1. 仅支持未核销或已支付订单退款{'\n'}
                2. 退款金额将原路返回{'\n'}
                3. 审核通过后1-3个工作日到账
              </Text>
            </View>
          </View>
        </View>

        {/* 订单信息 */}
        {orderId && (
          <View className="bg-white rounded-xl p-4 mb-4">
            <Text className="text-sm text-gray-500">订单编号</Text>
            <Text className="text-base">{orderId}</Text>
          </View>
        )}

        {/* 退款原因 */}
        <View className="bg-white rounded-xl p-4 mb-4">
          <Text className="block text-base font-medium mb-3">退款原因</Text>
          <View className="space-y-2">
            {REFUND_REASONS.map((r) => (
              <View
                key={r}
                className={`p-3 rounded-lg border ${reason === r ? 'border-blue-500 bg-blue-50' : 'border-gray-200'}`}
                onClick={() => setReason(r)}
              >
                <Text className={reason === r ? 'text-blue-500' : 'text-gray-700'}>{r}</Text>
              </View>
            ))}
          </View>
        </View>

        {/* 其他原因输入 */}
        {reason === '其他原因' && (
          <View className="bg-white rounded-xl p-4 mb-4">
            <Textarea
              className="w-full bg-gray-50 rounded-lg p-3"
              style={{ minHeight: '80px' }}
              placeholder="请详细描述您的退款原因..."
              value={customReason}
              onInput={(e) => setCustomReason(e.detail.value)}
            />
          </View>
        )}

        {/* 提交按钮 */}
        <Button
          className="w-full bg-blue-500 text-white rounded-xl py-3"
          onClick={handleSubmit}
          disabled={submitting || !reason}
        >
          {submitting ? '提交中...' : '提交退款申请'}
        </Button>
      </ScrollView>
    </View>
  )
}
