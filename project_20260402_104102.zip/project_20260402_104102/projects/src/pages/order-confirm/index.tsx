import { View, Text, ScrollView } from '@tarojs/components'
import { MapPin, Gift, MessageSquare, ChevronRight, X, Check, Info } from 'lucide-react-taro'
import { useState, useEffect } from 'react'
import Taro from '@tarojs/taro'
import { Card, CardContent } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { Network } from '@/network'
import { useUserStore } from '@/stores/user'
import UserGuide, { GUIDE_STEPS, shouldShowGuide } from '@/components/user-guide'

// 商品信息
interface Product {
  id: string
  name: string
  price: number
  originalPrice?: number
  quantity: number
  image?: string
  category: string
}

// 红包信息
interface RedPacket {
  id: string
  type: 'red_packet' | 'coupon'
  amount: number
  minSpend: number
  source: string
  region: string | null
  expireAt: string
}

// 地址信息
interface Address {
  id: string
  name: string
  phone: string
  province: string
  city: string
  district: string
  detail: string
  isDefault: boolean
}

const OrderConfirmPage = () => {
  // 获取用户信息
  const { userInfo } = useUserStore()
  const userId = userInfo?.id || Taro.getStorageSync('user_id') || ''
  
  // 获取路由参数
  const params = Taro.getCurrentInstance().router?.params || {}
  const merchantId = params.merchantId || 'm1'
  const region = params.region || 'island_inside'

  // 商品信息（模拟）
  const [product] = useState<Product>({
    id: 'p1',
    name: '老厦门沙茶面套餐',
    price: 38,
    originalPrice: 48,
    quantity: 1,
    category: '美食'
  })

  // 地址信息
  const [address, setAddress] = useState<Address>({
    id: 'a1',
    name: '张先生',
    phone: '138****8888',
    province: '福建省',
    city: '厦门市',
    district: '思明区',
    detail: '软件园二期望海路10号',
    isDefault: true
  })

  // 可用红包列表
  const [redPackets, setRedPackets] = useState<RedPacket[]>([])
  // 选中的红包
  const [selectedRedPacket, setSelectedRedPacket] = useState<RedPacket | null>(null)
  // 是否显示红包选择弹窗
  const [showRedPacketPicker, setShowRedPacketPicker] = useState(false)
  // 备注
  const [remark] = useState('')
  // 提交中
  const [submitting, setSubmitting] = useState(false)
  // 是否显示引导
  const [showGuide, setShowGuide] = useState(false)

  useEffect(() => {
    fetchRedPackets()
    
    // 检查是否需要显示订单流程引导
    const needGuide = shouldShowGuide('order')
    if (needGuide) {
      setTimeout(() => setShowGuide(true), 800)
    }
    
    // 监听地址选择事件
    Taro.eventCenter.on('addressSelected', (selectedAddress: Address) => {
      setAddress(selectedAddress)
    })
    
    return () => {
      Taro.eventCenter.off('addressSelected')
    }
  }, [])

  // 跳转到地址选择页面
  const goToAddressSelect = () => {
    Taro.navigateTo({ url: '/pages/address/index?selectMode=true' })
  }

  // 获取可用红包
  const fetchRedPackets = async () => {
    try {
      const res = await Network.request({
        url: '/api/referral/red-packets',
        method: 'GET',
        data: { userId, status: 'unused' }
      })

      console.log('Red packets response:', res.data)

      if (res.data?.code === 200) {
        const packets = res.data.data || []
        // 过滤出可用的红包（金额满足或区域匹配）
        const usablePackets = packets.filter((p: RedPacket) => {
          // 无门槛或满足最低消费
          if (p.minSpend > product.price * product.quantity) return false
          // 区域匹配或无区域限制
          if (p.region && p.region !== region) return false
          return true
        })
        setRedPackets(usablePackets)
      } else {
        // 模拟数据
        setRedPackets(getMockRedPackets())
      }
    } catch (error) {
      console.error('Fetch red packets error:', error)
      setRedPackets(getMockRedPackets())
    }
  }

  // 模拟红包数据
  const getMockRedPackets = (): RedPacket[] => [
    { id: '1', type: 'red_packet', amount: 5, minSpend: 0, source: 'register', region: null, expireAt: new Date(Date.now() + 7 * 24 * 60 * 60 * 1000).toISOString() },
    { id: '2', type: 'coupon', amount: 10, minSpend: 30, source: 'referral', region: 'island_inside', expireAt: new Date(Date.now() + 15 * 24 * 60 * 60 * 1000).toISOString() },
    { id: '3', type: 'red_packet', amount: 3, minSpend: 0, source: 'first_location', region: null, expireAt: new Date(Date.now() + 3 * 24 * 60 * 60 * 1000).toISOString() },
  ]

  // 计算金额
  const calculateAmount = () => {
    const productTotal = product.price * product.quantity
    const discount = product.originalPrice ? (product.originalPrice - product.price) * product.quantity : 0
    const redPacketDiscount = selectedRedPacket ? selectedRedPacket.amount : 0
    const payableAmount = Math.max(0, productTotal - redPacketDiscount)

    return {
      productTotal,
      discount,
      redPacketDiscount,
      payableAmount
    }
  }

  const amounts = calculateAmount()

  // 选择红包
  const selectRedPacket = (packet: RedPacket) => {
    if (selectedRedPacket?.id === packet.id) {
      setSelectedRedPacket(null)
    } else {
      setSelectedRedPacket(packet)
    }
    setShowRedPacketPicker(false)
  }

  // 移除红包
  const removeRedPacket = () => {
    setSelectedRedPacket(null)
  }

  // 提交订单并发起支付
  const submitOrder = async () => {
    if (submitting) return
    
    setSubmitting(true)
    try {
      // 1. 创建订单
      const createRes = await Network.request<{
        code: number
        msg: string
        data: {
          id: string
          orderNo: string
          payableAmount: number
          status: string
          merchantName: string
        } | null
      }>({
        url: '/api/order/create-v2',
        method: 'POST',
        data: {
          userId,
          merchantId,
          products: [product],
          addressId: address.id,
          redPacketId: selectedRedPacket?.id,
          remark,
          region,
          totalAmount: amounts.productTotal,
          discountAmount: amounts.redPacketDiscount,
          payableAmount: amounts.payableAmount
        }
      })

      console.log('[OrderConfirm] Create order response:', createRes.data)

      if (createRes.data?.code !== 200 || !createRes.data.data) {
        throw new Error(createRes.data?.msg || '创建订单失败')
      }

      const orderData = createRes.data.data

      // 2. 发起支付
      const paymentRes = await Network.request<{
        code: number
        msg: string
        data: {
          success: boolean
          paymentId: string
          paymentParams: {
            timeStamp: string
            nonceStr: string
            package: string
            signType: string
            paySign: string
          }
        } | null
      }>({
        url: '/api/payment/create',
        method: 'POST',
        data: {
          orderId: orderData.id,
          userId,
          amount: orderData.payableAmount,
          orderNo: orderData.orderNo,
          body: `厦门本地生活-${orderData.merchantName || '订单'}`
        }
      })

      console.log('[OrderConfirm] Payment response:', paymentRes.data)

      if (paymentRes.data?.code !== 200 || !paymentRes.data.data?.success) {
        throw new Error(paymentRes.data?.msg || '创建支付失败')
      }

      // 3. 调用微信支付
      const paymentParams = paymentRes.data.data.paymentParams
      
      // 检测平台
      const isWeapp = Taro.getEnv() === Taro.ENV_TYPE.WEAPP

      if (isWeapp && paymentParams) {
        // 小程序环境：调用真实支付
        try {
          await Taro.requestPayment({
            timeStamp: paymentParams.timeStamp,
            nonceStr: paymentParams.nonceStr,
            package: paymentParams.package,
            signType: paymentParams.signType as 'MD5' | 'RSA',
            paySign: paymentParams.paySign
          })
          
          // 支付成功
          Taro.showToast({ title: '支付成功', icon: 'success' })
          setTimeout(() => {
            Taro.redirectTo({ url: `/pages/order/detail?orderId=${orderData.id}` })
          }, 1500)
        } catch (payError: any) {
          // 用户取消支付或支付失败
          if (payError.errMsg?.includes('cancel')) {
            Taro.showToast({ title: '已取消支付', icon: 'none' })
          } else {
            Taro.showToast({ title: '支付失败', icon: 'none' })
          }
          // 跳转到订单列表
          setTimeout(() => {
            Taro.redirectTo({ url: '/pages/order/index' })
          }, 1500)
        }
      } else {
        // H5/开发环境：模拟支付
        Taro.showModal({
          title: '模拟支付',
          content: `订单金额：¥${orderData.payableAmount}\n\n确认支付？`,
          success: async (res) => {
            if (res.confirm) {
              // 调用模拟支付成功接口
              await Network.request({
                url: '/api/payment/mock-success',
                method: 'POST',
                data: { orderId: orderData.id }
              })
              
              Taro.showToast({ title: '支付成功', icon: 'success' })
              setTimeout(() => {
                Taro.redirectTo({ url: `/pages/order/detail?orderId=${orderData.id}` })
              }, 1500)
            } else {
              Taro.showToast({ title: '已取消支付', icon: 'none' })
              setTimeout(() => {
                Taro.redirectTo({ url: '/pages/order/index' })
              }, 1500)
            }
          }
        })
      }
    } catch (error) {
      console.error('[OrderConfirm] Submit order error:', error)
      Taro.showToast({ 
        title: error instanceof Error ? error.message : '下单失败', 
        icon: 'none' 
      })
    } finally {
      setSubmitting(false)
    }
  }

  // 红包来源标签
  const sourceLabels: Record<string, string> = {
    register: '新人注册礼',
    first_location: '定位奖励',
    first_ai_chat: 'AI对话奖励',
    referral_bind_referee: '邀请好友奖励',
    referral_bind_referrer: '好友注册奖励',
    stay_5min: '下单挽留券',
    good_review: '好评返现',
    group_buy: '组队拼单奖励',
  }

  // 区域标签
  const regionLabels: Record<string, string> = {
    island_inside: '仅限岛内',
    island_outside: '仅限岛外',
  }

  return (
    <View className="min-h-screen bg-zinc-50">
      <ScrollView scrollY className="h-[calc(100vh-80px)]">
        {/* 收货地址 */}
        <Card className="m-4 active:opacity-80" onClick={goToAddressSelect}>
          <CardContent className="p-4">
            <View className="flex items-start gap-3">
              <MapPin size={20} color="#14B8A6" />
              <View className="flex-1">
                <View className="flex items-center gap-2 mb-1">
                  <Text className="font-semibold text-slate-800">{address.name}</Text>
                  <Text className="text-slate-500">{address.phone}</Text>
                </View>
                <Text className="text-sm text-slate-600">
                  {address.province}{address.city}{address.district}{address.detail}
                </Text>
              </View>
              <ChevronRight size={20} color="#cbd5e1" />
            </View>
          </CardContent>
        </Card>

        {/* 商品信息 */}
        <Card className="mx-4 mb-4">
          <CardContent className="p-4">
            <View className="flex gap-3">
              <View className="w-20 h-20 bg-teal-50 rounded-lg flex items-center justify-center">
                <Text className="text-sm text-slate-600">{product.category}</Text>
              </View>
              <View className="flex-1">
                <Text className="font-semibold text-zinc-800 mb-1">{product.name}</Text>
                <View className="flex items-center gap-2 mb-2">
                  <Text className="text-teal-500 font-bold">¥{product.price}</Text>
                  {product.originalPrice && (
                    <Text className="text-slate-400 text-sm line-through">¥{product.originalPrice}</Text>
                  )}
                </View>
                <View className="flex items-center gap-2">
                  <Badge variant="secondary" className="text-xs">x{product.quantity}</Badge>
                  {product.originalPrice && (
                    <Badge className="bg-teal-100 text-teal-600 text-xs">
                      省¥{(product.originalPrice - product.price) * product.quantity}
                    </Badge>
                  )}
                </View>
              </View>
            </View>
          </CardContent>
        </Card>

        {/* 红包选择 */}
        <Card className="mx-4 mb-4">
          <CardContent className="p-4">
            <View 
              className="flex items-center justify-between"
              onClick={() => redPackets.length > 0 && setShowRedPacketPicker(true)}
            >
              <View className="flex items-center gap-2">
                <Gift size={18} color="#14B8A6" />
                <Text className="text-slate-700">红包/优惠券</Text>
                {redPackets.length > 0 && (
                  <Badge className="bg-teal-500 text-white text-xs">{redPackets.length}张可用</Badge>
                )}
              </View>
              <View className="flex items-center gap-1">
                {selectedRedPacket ? (
                  <View className="flex items-center gap-1">
                    <Text className="text-teal-500 font-semibold">-¥{selectedRedPacket.amount}</Text>
                    <View onClick={(e) => { e.stopPropagation(); removeRedPacket() }}>
                      <X size={16} color="#71717a" />
                    </View>
                  </View>
                ) : redPackets.length > 0 ? (
                  <Text className="text-zinc-400 text-sm">{redPackets.length}张可用</Text>
                ) : (
                  <Text className="text-zinc-400 text-sm">暂无可用</Text>
                )}
                ›
              </View>
            </View>

            {/* 已选红包展示 */}
            {selectedRedPacket && (
              <View className="mt-3 p-3 bg-teal-50 rounded-lg flex items-center justify-between">
                <View>
                  <Text className="text-slate-800 font-medium">{sourceLabels[selectedRedPacket.source] || '红包'}</Text>
                  {selectedRedPacket.region && (
                    <Text className="text-teal-500 text-xs">{regionLabels[selectedRedPacket.region]}</Text>
                  )}
                </View>
                <Text className="text-teal-500 font-bold">-¥{selectedRedPacket.amount}</Text>
              </View>
            )}
          </CardContent>
        </Card>

        {/* 备注 */}
        <Card className="mx-4 mb-4">
          <CardContent className="p-4">
            <View className="flex items-center gap-2 mb-2">
              <MessageSquare size={18} color="#14B8A6" />
              <Text className="text-slate-700">备注</Text>
            </View>
            <View className="bg-zinc-50 rounded-lg p-3">
              <Text 
                className="text-sm text-zinc-600"
                onClick={() => {
                  Taro.showModal({
                    title: '备注',
                    content: '请使用输入框添加备注',
                    showCancel: false
                  })
                }}
              >
                {remark || '点击添加备注（选填）'}
              </Text>
            </View>
          </CardContent>
        </Card>

        {/* 金额明细 */}
        <Card className="mx-4 mb-4">
          <CardContent className="p-4">
            <View className="space-y-2">
              <View className="flex items-center justify-between">
                <Text className="text-zinc-500">商品金额</Text>
                <Text className="text-zinc-800">¥{amounts.productTotal}</Text>
              </View>
              {amounts.discount > 0 && (
                <View className="flex items-center justify-between">
                  <Text className="text-zinc-500">优惠金额</Text>
                  <Text className="text-teal-500">-¥{amounts.discount}</Text>
                </View>
              )}
              {amounts.redPacketDiscount > 0 && (
                <View className="flex items-center justify-between">
                  <Text className="text-zinc-500">红包抵扣</Text>
                  <Text className="text-teal-500">-¥{amounts.redPacketDiscount}</Text>
                </View>
              )}
              <View className="border-t border-zinc-100 pt-2 mt-2">
                <View className="flex items-center justify-between">
                  <Text className="font-semibold text-zinc-800">实付金额</Text>
                  <Text className="text-xl font-bold text-teal-500">¥{amounts.payableAmount}</Text>
                </View>
              </View>
            </View>
          </CardContent>
        </Card>

        {/* 温馨提示 */}
        <View className="mx-4 mb-4 p-3 bg-teal-50 rounded-lg">
          <View className="flex items-start gap-2">
            <Info size={18} color="#14B8A6" />
            <View>
              <Text className="text-teal-600 text-sm font-medium">温馨提示</Text>
              <Text className="text-teal-500 text-xs mt-1">
                • 岛内用户仅可使用岛内红包，岛外用户仅可使用岛外红包{'\n'}
                • 新人红包、推荐奖励、优惠活动可叠加使用{'\n'}
                • 订单完成后可获得好评返现
              </Text>
            </View>
          </View>
        </View>
      </ScrollView>

      {/* 底部支付栏 */}
      <View style={{ position: 'fixed', bottom: 0, left: 0, right: 0, backgroundColor: '#fff', borderTop: '1px solid #e5e5e5', padding: '12px 16px', display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
        <View>
          <Text className="text-zinc-500 text-sm">实付金额</Text>
          <Text className="text-xl font-bold text-teal-500">¥{amounts.payableAmount}</Text>
        </View>
        <Button 
          style={{ backgroundColor: '#FF6B35', color: '#fff', paddingLeft: '32px', paddingRight: '32px' }}
          onClick={submitOrder}
          disabled={submitting}
        >
          {submitting ? '提交中...' : '提交订单'}
        </Button>
      </View>

      {/* 红包选择弹窗 */}
      {showRedPacketPicker && (
        <View 
          style={{ position: 'fixed', top: 0, left: 0, right: 0, bottom: 0, backgroundColor: 'rgba(0,0,0,0.5)', display: 'flex', alignItems: 'flex-end', zIndex: 1000 }}
          onClick={() => setShowRedPacketPicker(false)}
        >
          <View 
            style={{ width: '100%', backgroundColor: '#fff', borderRadius: '16px 16px 0 0', maxHeight: '60vh' }}
            onClick={(e) => e.stopPropagation()}
          >
            {/* 弹窗头部 */}
            <View style={{ padding: '16px', borderBottom: '1px solid #f4f4f5', display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
              <Text style={{ fontSize: '16px', fontWeight: '600' }}>选择红包</Text>
              <View onClick={() => setShowRedPacketPicker(false)}>
                <X size={20} color="#27272a" />
              </View>
            </View>

            {/* 红包列表 */}
            <ScrollView scrollY style={{ maxHeight: '50vh', padding: '16px' }}>
              {redPackets.map((packet) => (
                <View 
                  key={packet.id}
                  style={{ 
                    marginBottom: '12px',
                    padding: '12px',
                    borderRadius: '8px',
                    border: selectedRedPacket?.id === packet.id ? '2px solid #FF6B35' : '1px solid #e5e5e5',
                    backgroundColor: selectedRedPacket?.id === packet.id ? '#FFF7ED' : '#fff'
                  }}
                  onClick={() => selectRedPacket(packet)}
                >
                  <View style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
                    <View>
                      <View style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
                        <Text style={{ color: '#FF6B35', fontSize: '24px', fontWeight: 'bold' }}>¥{packet.amount}</Text>
                        {packet.minSpend > 0 && (
                          <Text style={{ color: '#71717a', fontSize: '12px' }}>满{packet.minSpend}可用</Text>
                        )}
                      </View>
                      <Text style={{ color: '#27272A', fontSize: '14px', marginTop: '4px' }}>{sourceLabels[packet.source] || '红包'}</Text>
                      <View style={{ display: 'flex', alignItems: 'center', gap: '8px', marginTop: '4px' }}>
                        <Text style={{ color: '#A1A1AA', fontSize: '12px' }}>
                          {new Date(packet.expireAt).toLocaleDateString()}到期
                        </Text>
                        {packet.region && (
                          <Badge className="bg-teal-100 text-teal-600 text-xs">{regionLabels[packet.region]}</Badge>
                        )}
                      </View>
                    </View>
                    {selectedRedPacket?.id === packet.id && (
                      <Check size={20} color="#14B8A6" />
                    )}
                  </View>
                </View>
              ))}
            </ScrollView>
          </View>
        </View>
      )}
      
      {/* 订单流程引导 */}
      {showGuide && (
        <UserGuide
          guideKey="order"
          steps={GUIDE_STEPS.ORDER}
          onComplete={() => setShowGuide(false)}
          onSkip={() => setShowGuide(false)}
        />
      )}
    </View>
  )
}

export default OrderConfirmPage
