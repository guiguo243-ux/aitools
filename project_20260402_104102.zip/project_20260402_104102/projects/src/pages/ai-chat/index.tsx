import { View, Text, ScrollView } from '@tarojs/components'
import { useState, useEffect } from 'react'
import Taro, { useRouter } from '@tarojs/taro'
import { Network } from '@/network'
import { Card, CardContent } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { User, Bot, Store, Star, Send } from 'lucide-react-taro'
import './index.css'

interface Message {
  id: string
  role: 'user' | 'assistant'
  content: string
  recommendations?: any[]
}

const aiPrompts = [
  '帮我推荐岛内的餐厅',
  '附近有什么好玩的地方？',
  '我想找家政服务',
  '哪家美容店比较好？'
]

const AICHatPage = () => {
  const router = useRouter()
  const { region = 'island_inside', sessionId } = router.params

  const [messages, setMessages] = useState<Message[]>([])
  const [inputValue, setInputValue] = useState('')
  const [loading, setLoading] = useState(false)
  const [currentSessionId, setCurrentSessionId] = useState(sessionId || '')

  // 欢迎消息
  useEffect(() => {
    const welcomeMessage: Message = {
      id: 'welcome',
      role: 'assistant',
      content: `您好！我是您的厦门本地生活AI导购助手。\n\n我专门服务${region === 'island_inside' ? '岛内（思明、湖里）' : '岛外（集美、海沧、同安、翔安）'}的用户。\n\n告诉我您的需求，我来为您精准推荐！\n\n例如：\n• 帮我推荐岛内的餐厅\n• 附近有什么好玩的地方？\n• 我想找家政服务`
    }
    setMessages([welcomeMessage])
  }, [region])

  // 发送消息
  const sendMessage = async (content: string) => {
    if (!content.trim() || loading) return

    const userMessage: Message = {
      id: `user_${Date.now()}`,
      role: 'user',
      content: content.trim()
    }

    setMessages(prev => [...prev, userMessage])
    setInputValue('')
    setLoading(true)

    // 获取用户ID
    let userId = Taro.getStorageSync('user_id')
    if (!userId) {
      userId = '550e8400-e29b-41d4-a716-446655440001'
      Taro.setStorageSync('user_id', userId)
    }

    try {
      const res = await Network.request({
        url: '/api/ai-guide/chat',
        method: 'POST',
        data: {
          userId,
          message: content.trim(),
          region,
          sessionId: currentSessionId
        }
      })

      console.log('AI chat response:', res.data)

      if (res.data?.code === 200) {
        const data = res.data.data
        setCurrentSessionId(data.sessionId)

        const aiMessage: Message = {
          id: `ai_${Date.now()}`,
          role: 'assistant',
          content: data.content,
          recommendations: data.recommendations
        }
        setMessages(prev => [...prev, aiMessage])
      } else {
        // 错误提示
        const errorMessage: Message = {
          id: `error_${Date.now()}`,
          role: 'assistant',
          content: '抱歉，我遇到了一些问题，请稍后再试。'
        }
        setMessages(prev => [...prev, errorMessage])
      }
    } catch (error) {
      console.error('Send message error:', error)
      const errorMessage: Message = {
        id: `error_${Date.now()}`,
        role: 'assistant',
        content: '抱歉，网络似乎不太顺畅，请稍后再试。'
      }
      setMessages(prev => [...prev, errorMessage])
    } finally {
      setLoading(false)
    }
  }

  // 点击快捷问题
  const handlePromptClick = (prompt: string) => {
    sendMessage(prompt)
  }

  // 跳转商家详情
  const goToMerchantDetail = (merchantId: string) => {
    Taro.navigateTo({
      url: `/pages/merchant/detail?id=${merchantId}`
    })
  }

  return (
    <View className="flex flex-col h-screen bg-stone-50">
      {/* 消息列表 */}
      <ScrollView 
        scrollY 
        className="flex-1 px-4 py-4"
        scrollIntoView={messages.length > 0 ? messages[messages.length - 1].id : ''}
      >
        {messages.map((msg) => (
          <View 
            key={msg.id} 
            id={msg.id}
            className={`flex gap-2 mb-4 ${msg.role === 'user' ? 'flex-row-reverse' : ''}`}
          >
            {/* 头像 */}
            <View className="flex-shrink-0">
              {msg.role === 'user' ? (
                <View className="w-8 h-8 bg-teal-100 rounded-full flex items-center justify-center">
                  <User size={18} color="#14B8A6" />
                </View>
              ) : (
                <View className="w-8 h-8 bg-teal-500 rounded-full flex items-center justify-center">
                  <Bot size={18} color="#fff" />
                </View>
              )}
            </View>

            {/* 消息内容 */}
            <View className={`flex-1 max-w-[80%] ${msg.role === 'user' ? 'items-end' : 'items-start'}`}>
              <View 
                className={`rounded-2xl px-3 py-2 ${
                  msg.role === 'user' 
                    ? 'bg-teal-500 text-white rounded-tr-none' 
                    : 'bg-white text-slate-800 rounded-tl-none shadow-sm'
                }`}
              >
                <Text className={`text-sm whitespace-pre-wrap ${msg.role === 'user' ? 'text-white' : 'text-slate-700'}`}>
                  {msg.content}
                </Text>
              </View>

              {/* 推荐商家 */}
              {msg.recommendations && msg.recommendations.length > 0 && (
                <View className="mt-2 flex flex-col gap-2">
                  {msg.recommendations.map((merchant: any) => (
                    <Card 
                      key={merchant.id} 
                      className="bg-white shadow-sm"
                      onClick={() => goToMerchantDetail(merchant.id)}
                    >
                      <CardContent className="p-2 flex items-center gap-2">
                        <View className="w-12 h-12 bg-teal-50 rounded-lg flex items-center justify-center">
                          <Store size={24} color="#14B8A6" />
                        </View>
                        <View className="flex-1 min-w-0">
                          <Text className="text-sm font-medium text-slate-800 truncate block">
                            {merchant.name}
                          </Text>
                          <View className="flex items-center gap-1">
                            <Star size={12} color="#fbbf24" />
                            <Text className="text-xs text-slate-500">{merchant.rating}</Text>
                          </View>
                        </View>
                        <Text className="text-slate-400">›</Text>
                      </CardContent>
                    </Card>
                  ))}
                </View>
              )}
            </View>
          </View>
        ))}

        {/* 加载中 */}
        {loading && (
          <View className="flex gap-2 mb-4">
            <View className="w-8 h-8 bg-teal-500 rounded-full flex items-center justify-center">
              <Bot size={18} color="#fff" />
            </View>
            <View className="bg-white rounded-2xl rounded-tl-none px-3 py-2 shadow-sm">
              <Text className="text-sm text-slate-400">思考中...</Text>
            </View>
          </View>
        )}

        {/* 底部留白 */}
        <View className="h-4" />
      </ScrollView>

      {/* 快捷问题 */}
      {messages.length <= 2 && (
        <View className="px-4 pb-2">
          <View className="flex flex-wrap gap-2">
            {aiPrompts.map((prompt, index) => (
              <Badge 
                key={index}
                variant="outline"
                className="bg-white border-teal-200 text-teal-600"
                onClick={() => handlePromptClick(prompt)}
              >
                {prompt}
              </Badge>
            ))}
          </View>
        </View>
      )}

      {/* 输入框 */}
      <View className="bg-white border-t border-slate-200 px-4 py-3 flex items-center gap-2">
        <View className="flex-1 bg-slate-100 rounded-full px-4 py-2 flex items-center">
          <Input
            className="flex-1 bg-transparent text-sm"
            placeholder="输入您的需求..."
            value={inputValue}
            onInput={(e) => setInputValue(e.detail.value)}
            onConfirm={() => sendMessage(inputValue)}
            confirmType="send"
          />
        </View>
        <Button 
          size="icon"
          className="w-10 h-10 bg-teal-500 rounded-full"
          onClick={() => sendMessage(inputValue)}
          disabled={loading || !inputValue.trim()}
        >
          <Send size={18} color="#fff" />
        </Button>
      </View>
    </View>
  )
}

export default AICHatPage
