export default typeof definePageConfig === 'function'
  ? definePageConfig({
      navigationBarTitleText: 'AI导购'
    })
  : { navigationBarTitleText: 'AI导购' }
