import { useState, useEffect } from 'react'
import { View, Text, Image } from '@tarojs/components'
import Taro from '@tarojs/taro'
import { Camera, MapPin } from 'lucide-react-taro'

import { Network } from '@/network'
import { useUserStore } from '@/stores/user'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'

const REGIONS = [
  { label: '思明区', value: 'siming' },
  { label: '湖里区', value: 'huli' },
  { label: '集美区', value: 'jimei' },
  { label: '海沧区', value: 'haicang' },
  { label: '同安区', value: 'tongan' },
  { label: '翔安区', value: 'xiangan' }
]

export default function EditProfilePage() {
  const { userInfo, updateUserInfo, isLoggedIn } = useUserStore()
  const [nickname, setNickname] = useState('')
  const [region, setRegion] = useState('')
  const [saving, setSaving] = useState(false)

  useEffect(() => {
    if (!isLoggedIn) {
      Taro.navigateTo({ url: '/pages/login/index' })
      return
    }

    setNickname(userInfo?.nickname || '')
    setRegion(userInfo?.region || '')
  }, [isLoggedIn, userInfo])

  const handleSave = async () => {
    if (!userInfo?.id) return

    if (!nickname.trim()) {
      Taro.showToast({ title: '请输入昵称', icon: 'none' })
      return
    }

    setSaving(true)
    try {
      const res = await Network.request({
        url: '/api/auth/profile',
        method: 'PUT',
        data: {
          userId: userInfo.id,
          nickname,
          region
        }
      })

      if (res.data.code === 200) {
        updateUserInfo({ nickname, region })
        Taro.showToast({ title: '保存成功', icon: 'success' })
        setTimeout(() => Taro.navigateBack(), 1500)
      } else {
        Taro.showToast({ title: res.data.msg, icon: 'none' })
      }
    } catch (error) {
      Taro.showToast({ title: '保存失败', icon: 'none' })
    } finally {
      setSaving(false)
    }
  }

  const handleAvatarUpload = async () => {
    try {
      const res = await Taro.chooseImage({
        count: 1,
        sizeType: ['compressed'],
        sourceType: ['album', 'camera']
      })

      if (res.tempFilePaths && res.tempFilePaths[0]) {
        Taro.showLoading({ title: '上传中...' })
        
        const uploadRes = await Network.uploadFile({
          url: '/api/upload/avatar',
          filePath: res.tempFilePaths[0],
          name: 'file'
        })

        Taro.hideLoading()

        const data = JSON.parse(uploadRes.data)
        if (data.code === 200 && data.data?.url) {
          updateUserInfo({ avatar: data.data.url })
          Taro.showToast({ title: '上传成功', icon: 'success' })
        } else {
          Taro.showToast({ title: '上传失败', icon: 'none' })
        }
      }
    } catch (error) {
      Taro.hideLoading()
      console.error('Upload avatar error:', error)
    }
  }

  const showRegionPicker = () => {
    Taro.showActionSheet({
      itemList: REGIONS.map(r => r.label),
      success: (res) => {
        setRegion(REGIONS[res.tapIndex].value)
      }
    })
  }

  if (!isLoggedIn) {
    return null
  }

  const regionLabel = REGIONS.find(r => r.value === region)?.label || '未设置'

  return (
    <View className="min-h-screen bg-gray-50">
      {/* 头像 */}
      <View className="bg-white mt-4">
        <View 
          className="flex items-center justify-between px-4 py-4 border-b border-gray-100"
          onClick={handleAvatarUpload}
        >
          <Text className="text-base">头像</Text>
          <View className="flex items-center gap-2">
            <Image
              src={userInfo?.avatar || ''}
              className="w-12 h-12 rounded-full"
              mode="aspectFill"
              onError={() => {
                console.log('Avatar image load failed')
              }}
            />
            <View className="relative">
              <Camera size={18} color="#6b7280" />
            </View>
          </View>
        </View>
      </View>

      {/* 基本信息 */}
      <View className="bg-white mt-4">
        {/* 昵称 */}
        <View className="flex items-center px-4 py-4 border-b border-gray-100">
          <Text className="text-base w-16">昵称</Text>
          <Input
            className="flex-1 text-right"
            placeholder="请输入昵称"
            value={nickname}
            onInput={(e) => setNickname(e.detail.value)}
          />
        </View>

        {/* 手机号 */}
        <View className="flex items-center justify-between px-4 py-4 border-b border-gray-100">
          <Text className="text-base">手机号</Text>
          <Text className="text-gray-500">{userInfo?.phone || '未绑定'}</Text>
        </View>

        {/* 所在区域 */}
        <View 
          className="flex items-center justify-between px-4 py-4"
          onClick={showRegionPicker}
        >
          <View className="flex items-center gap-2">
            <MapPin size={18} color="#6b7280" />
            <Text className="text-base">所在区域</Text>
          </View>
          <View className="flex items-center gap-2">
            <Text className="text-gray-500">{regionLabel}</Text>
            <Text className="text-gray-400">›</Text>
          </View>
        </View>
      </View>

      {/* 提示 */}
      <View className="px-4 py-3">
        <Text className="text-xs text-gray-400">
          区域设置将影响您看到的优惠券和推荐商家
        </Text>
      </View>

      {/* 保存按钮 */}
      <View className="px-4 mt-4">
        <Button
          className="w-full bg-teal-500 text-white rounded-xl py-3"
          onClick={handleSave}
          disabled={saving}
        >
          {saving ? '保存中...' : '保存'}
        </Button>
      </View>
    </View>
  )
}
