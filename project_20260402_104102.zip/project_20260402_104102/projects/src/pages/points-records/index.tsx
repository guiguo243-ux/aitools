import { View, Text, ScrollView } from '@tarojs/components'
import { useState, useEffect } from 'react'
import Taro from '@tarojs/taro'
import { Network } from '@/network'
import { useUserStore } from '@/stores/user'
import { Coins, Clock, Gift } from 'lucide-react-taro'
import './index.css'

interface PointsRecord {
  id: string
  points: number
  type: string
  description: string
  balance_after: number
  created_at: string
}

interface ExchangeRecord {
  id: string
  product_name: string
  points_cost: number
  quantity: number
  status: string
  receiver_name?: string
  tracking_no?: string
  created_at: string
}

const typeLabels: Record<string, { label: string; icon: string; color: string }> = {
  register: { label: '注册奖励', icon: 'gift', color: 'green' },
  daily_sign: { label: '每日签到', icon: 'calendar', color: 'blue' },
  order: { label: '消费奖励', icon: 'shopping', color: 'orange' },
  referral: { label: '邀请好友', icon: 'users', color: 'purple' },
  review: { label: '评价奖励', icon: 'star', color: 'yellow' },
  exchange: { label: '积分兑换', icon: 'package', color: 'red' },
  task: { label: '任务奖励', icon: 'check', color: 'teal' },
  ai_chat: { label: 'AI对话', icon: 'bot', color: 'indigo' },
}

const PointsRecordsPage = () => {
  const { userInfo } = useUserStore()
  const userId = userInfo?.id || Taro.getStorageSync('user_id') || ''

  const [activeTab, setActiveTab] = useState<'points' | 'exchange'>('points')
  const [pointsRecords, setPointsRecords] = useState<PointsRecord[]>([])
  const [exchangeRecords, setExchangeRecords] = useState<ExchangeRecord[]>([])
  const [loading, setLoading] = useState(false)
  const [page, setPage] = useState(1)
  const [hasMore, setHasMore] = useState(true)

  useEffect(() => {
    if (userId) {
      if (activeTab === 'points') {
        fetchPointsRecords()
      } else {
        fetchExchangeRecords()
      }
    }
  }, [activeTab, userId])

  const fetchPointsRecords = async (pageNum = 1) => {
    if (loading) return
    setLoading(true)
    try {
      const res = await Network.request({
        url: '/api/points-shop/points-records',
        method: 'GET',
        data: { userId, page: pageNum, pageSize: 20 },
      })

      if (res.data?.code === 200) {
        const newRecords = res.data.data?.records || []
        if (pageNum === 1) {
          setPointsRecords(newRecords)
        } else {
          setPointsRecords([...pointsRecords, ...newRecords])
        }
        setHasMore(newRecords.length >= 20)
        setPage(pageNum)
      }
    } catch (error) {
      console.error('Fetch points records error:', error)
    } finally {
      setLoading(false)
    }
  }

  const fetchExchangeRecords = async (pageNum = 1) => {
    if (loading) return
    setLoading(true)
    try {
      const res = await Network.request({
        url: '/api/points-shop/exchange-records',
        method: 'GET',
        data: { userId, page: pageNum, pageSize: 20 },
      })

      if (res.data?.code === 200) {
        const newRecords = res.data.data?.records || []
        if (pageNum === 1) {
          setExchangeRecords(newRecords)
        } else {
          setExchangeRecords([...exchangeRecords, ...newRecords])
        }
        setHasMore(newRecords.length >= 20)
        setPage(pageNum)
      }
    } catch (error) {
      console.error('Fetch exchange records error:', error)
    } finally {
      setLoading(false)
    }
  }

  const loadMore = () => {
    if (!hasMore || loading) return
    const nextPage = page + 1
    if (activeTab === 'points') {
      fetchPointsRecords(nextPage)
    } else {
      fetchExchangeRecords(nextPage)
    }
  }

  const getTypeInfo = (type: string) => {
    return typeLabels[type] || { label: type, icon: 'circle', color: 'gray' }
  }

  const getStatusLabel = (status: string) => {
    const labels: Record<string, { label: string; color: string }> = {
      pending: { label: '待发货', color: 'orange' },
      shipped: { label: '已发货', color: 'blue' },
      completed: { label: '已完成', color: 'green' },
      cancelled: { label: '已取消', color: 'gray' },
    }
    return labels[status] || { label: status, color: 'gray' }
  }

  const formatDate = (dateStr: string) => {
    const date = new Date(dateStr)
    return `${date.getMonth() + 1}-${date.getDate()} ${date.getHours()}:${String(date.getMinutes()).padStart(2, '0')}`
  }

  return (
    <View className="points-records-page">
      {/* Tab 切换 */}
      <View className="tabs-wrapper">
        <View
          className={`tab-item ${activeTab === 'points' ? 'active' : ''}`}
          onClick={() => setActiveTab('points')}
        >
          <Text>积分明细</Text>
        </View>
        <View
          className={`tab-item ${activeTab === 'exchange' ? 'active' : ''}`}
          onClick={() => setActiveTab('exchange')}
        >
          <Text>兑换记录</Text>
        </View>
      </View>

      {/* 积分明细列表 */}
      {activeTab === 'points' && (
        <ScrollView
          scrollY
          className="records-list"
          onScrollToLower={loadMore}
        >
          {pointsRecords.length === 0 && !loading ? (
            <View className="empty-state">
              <Clock size={48} color="#d1d5db" />
              <Text>暂无积分记录</Text>
            </View>
          ) : (
            pointsRecords.map((record) => {
              const typeInfo = getTypeInfo(record.type)
              const isIncome = record.points > 0
              return (
                <View key={record.id} className="record-item">
                  <View className="record-icon">
                    <Coins size={20} color={isIncome ? '#10b981' : '#ef4444'} />
                  </View>
                  <View className="record-info">
                    <Text className="record-title">{record.description || typeInfo.label}</Text>
                    <Text className="record-time">{formatDate(record.created_at)}</Text>
                  </View>
                  <View className="record-points">
                    <Text className={`points-value ${isIncome ? 'income' : 'expense'}`}>
                      {isIncome ? '+' : ''}{record.points}
                    </Text>
                    <Text className="balance-after">余额: {record.balance_after}</Text>
                  </View>
                </View>
              )
            })
          )}
          {loading && (
            <View className="loading-more">
              <Text>加载中...</Text>
            </View>
          )}
        </ScrollView>
      )}

      {/* 兑换记录列表 */}
      {activeTab === 'exchange' && (
        <ScrollView
          scrollY
          className="records-list"
          onScrollToLower={loadMore}
        >
          {exchangeRecords.length === 0 && !loading ? (
            <View className="empty-state">
              <Gift size={48} color="#d1d5db" />
              <Text>暂无兑换记录</Text>
            </View>
          ) : (
            exchangeRecords.map((record) => {
              const statusInfo = getStatusLabel(record.status)
              return (
                <View key={record.id} className="exchange-item">
                  <View className="exchange-header">
                    <Text className="exchange-name">{record.product_name}</Text>
                    <View className={`status-badge ${statusInfo.color}`}>
                      <Text>{statusInfo.label}</Text>
                    </View>
                  </View>
                  <View className="exchange-info">
                    <View className="info-row">
                      <Text className="info-label">消耗积分</Text>
                      <Text className="info-value">{record.points_cost} 积分</Text>
                    </View>
                    <View className="info-row">
                      <Text className="info-label">兑换时间</Text>
                      <Text className="info-value">{formatDate(record.created_at)}</Text>
                    </View>
                    {record.tracking_no && (
                      <View className="info-row">
                        <Text className="info-label">物流单号</Text>
                        <Text className="info-value tracking">{record.tracking_no}</Text>
                      </View>
                    )}
                  </View>
                </View>
              )
            })
          )}
          {loading && (
            <View className="loading-more">
              <Text>加载中...</Text>
            </View>
          )}
        </ScrollView>
      )}
    </View>
  )
}

export default PointsRecordsPage
