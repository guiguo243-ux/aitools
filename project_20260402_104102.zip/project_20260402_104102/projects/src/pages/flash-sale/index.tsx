import { useState, useEffect } from 'react';
import Taro from '@tarojs/taro';
import { View, Text, Image, ScrollView } from '@tarojs/components';
import { Network } from '@/network';
import { Zap } from 'lucide-react-taro';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import './index.css';

interface FlashSaleActivity {
  id: string;
  title: string;
  product_id: string;
  product_name: string;
  product_image: string | null;
  original_price: number;
  flash_price: number;
  stock: number;
  sold_count: number;
  limit_per_user: number;
  start_time: string;
  end_time: string;
  realStatus: string;
  discount: number;
  progress: number;
  remainingStock: number;
  countdown?: {
    type: string;
    hours: number;
    minutes: number;
    seconds: number;
  };
}

interface TimeSlot {
  id: string;
  start_time: string;
  end_time: string;
  title: string;
  status: string;
  isActive: boolean;
  isPast: boolean;
}

export default function FlashSalePage() {
  const [timeSlots, setTimeSlots] = useState<TimeSlot[]>([]);
  const [activities, setActivities] = useState<FlashSaleActivity[]>([]);
  const [selectedSlot, setSelectedSlot] = useState<string>('all');
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadData();
  }, [selectedSlot]);

  const loadData = async () => {
    setLoading(true);
    try {
      const [slotsRes, activitiesRes] = await Promise.all([
        Network.request({ url: '/api/flash-sale/time-slots' }),
        Network.request({ 
          url: `/api/flash-sale/activities?status=ongoing${selectedSlot !== 'all' ? `&timeSlot=${selectedSlot}` : ''}` 
        }),
      ]);

      if (slotsRes.data?.data) {
        setTimeSlots(slotsRes.data.data);
      }

      if (activitiesRes.data?.data?.list) {
        setActivities(activitiesRes.data.list);
      }
    } catch (error) {
      console.error('加载秒杀数据失败:', error);
    } finally {
      setLoading(false);
    }
  };

  const formatPrice = (price: number) => {
    return price.toFixed(2);
  };

  const formatTime = (time: string) => {
    return time.slice(0, 5);
  };

  const handleBuy = async (activityId: string) => {
    const userId = Taro.getStorageSync('userId') || 'test-user-001';
    
    try {
      const res = await Network.request({
        url: '/api/flash-sale/order',
        method: 'POST',
        data: { activityId, userId, quantity: 1 },
      });

      if (res.data?.code === 200) {
        Taro.showToast({ title: '抢购成功！', icon: 'success' });
        loadData();
      } else {
        Taro.showToast({ title: res.data?.msg || '抢购失败', icon: 'none' });
      }
    } catch (error) {
      Taro.showToast({ title: '网络错误', icon: 'none' });
    }
  };

  const renderCountdown = (countdown?: FlashSaleActivity['countdown']) => {
    if (!countdown) return null;

    const pad = (n: number) => n.toString().padStart(2, '0');
    
    return (
      <View className="countdown-row">
        <Text className="countdown-label">
          {countdown.type === 'start' ? '距开始' : '距结束'}
        </Text>
        <View className="countdown-timer">
          <View className="time-block">
            <Text className="time-value">{pad(countdown.hours)}</Text>
          </View>
          <Text className="time-sep">:</Text>
          <View className="time-block">
            <Text className="time-value">{pad(countdown.minutes)}</Text>
          </View>
          <Text className="time-sep">:</Text>
          <View className="time-block">
            <Text className="time-value">{pad(countdown.seconds)}</Text>
          </View>
        </View>
      </View>
    );
  };

  if (loading) {
    return (
      <View className="fs-page loading-page">
        <Text className="loading-text">加载中...</Text>
      </View>
    );
  }

  return (
    <View className="fs-page">
      {/* 时段选择 */}
      <View className="time-slots">
        <ScrollView scrollX className="slots-scroll">
          <View
            className={`slot-item ${selectedSlot === 'all' ? 'active' : ''}`}
            onClick={() => setSelectedSlot('all')}
          >
            <Text className="slot-title">全部</Text>
          </View>
          {timeSlots.map((slot) => (
            <View
              key={slot.id}
              className={`slot-item ${selectedSlot === slot.id ? 'active' : ''} ${slot.isPast ? 'past' : ''}`}
              onClick={() => setSelectedSlot(slot.id)}
            >
              <Text className="slot-time">{formatTime(slot.start_time)}</Text>
              <Text className="slot-title">{slot.title}</Text>
              <View className={`slot-status ${slot.status}`}>
                <Text className="status-text">
                  {slot.status === 'ongoing' ? '进行中' : slot.status === 'ended' ? '已结束' : '即将开始'}
                </Text>
              </View>
            </View>
          ))}
        </ScrollView>
      </View>

      {/* 活动列表 */}
      <ScrollView scrollY className="content-scroll">
        {activities.length === 0 ? (
          <View className="empty-state">
            <Zap size={48} color="#ccc" />
            <Text className="empty-text">暂无秒杀活动</Text>
            <Text className="empty-hint">敬请期待更多优惠</Text>
          </View>
        ) : (
          <View className="activities-list">
            {activities.map((activity) => (
              <Card key={activity.id} className="activity-card">
                <CardContent className="activity-content">
                  <View className="product-section">
                    {activity.product_image ? (
                      <Image
                        src={activity.product_image}
                        className="product-image"
                        mode="aspectFill"
                      />
                    ) : (
                      <View className="product-image-placeholder">
                        <Text className="placeholder-text">暂无图片</Text>
                      </View>
                    )}
                    <View className="product-info">
                      <Text className="product-title">{activity.title}</Text>
                      <Text className="product-desc">{activity.product_name}</Text>
                      <View className="price-row">
                        <Text className="flash-price">¥{formatPrice(activity.flash_price)}</Text>
                        <Text className="original-price">¥{formatPrice(activity.original_price)}</Text>
                        <Badge className="discount-badge">
                          {activity.discount}折
                        </Badge>
                      </View>
                      <View className="stock-row">
                        <View className="progress-bar">
                          <View 
                            className="progress-fill" 
                            style={{ width: `${Math.min(100, activity.progress)}%` }}
                          />
                        </View>
                        <Text className="stock-text">已抢{activity.progress}%</Text>
                      </View>
                    </View>
                  </View>

                  {renderCountdown(activity.countdown)}

                  <View className="action-row">
                    <View className="limit-info">
                      <Text className="limit-text">限购{activity.limit_per_user}件</Text>
                      <Text className="remaining-text">剩余{activity.remainingStock}件</Text>
                    </View>
                    <Button
                      className={`buy-btn ${activity.realStatus === 'ended' || activity.remainingStock === 0 ? 'disabled' : ''}`}
                      disabled={activity.realStatus === 'ended' || activity.remainingStock === 0}
                      onClick={() => handleBuy(activity.id)}
                    >
                      {activity.realStatus === 'upcoming' 
                        ? '即将开始' 
                        : activity.realStatus === 'ended' 
                          ? '已结束' 
                          : activity.remainingStock === 0 
                            ? '已抢光' 
                            : '立即抢购'}
                    </Button>
                  </View>
                </CardContent>
              </Card>
            ))}
          </View>
        )}
      </ScrollView>
    </View>
  );
}
