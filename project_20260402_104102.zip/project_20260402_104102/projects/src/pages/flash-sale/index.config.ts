export default typeof definePageConfig === 'function'
  ? definePageConfig({ navigationBarTitleText: '限时秒杀' })
  : { navigationBarTitleText: '限时秒杀' }
