import { useState, useEffect } from 'react'
import { View, Text, Image } from '@tarojs/components'
import Taro from '@tarojs/taro'
import { Search, X, Flame, Clock, Star, MapPin } from 'lucide-react-taro'
import { Network } from '@/network'
import { useUserStore } from '@/stores/user'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'

interface Merchant {
  id: string
  name: string
  description: string
  address: string
  rating: number
  region: string
  cover_image: string
}

export default function SearchPage() {
  const { userInfo } = useUserStore()
  const [keyword, setKeyword] = useState('')
  const [hotSearches, setHotSearches] = useState<string[]>([])
  const [searchHistory, setSearchHistory] = useState<string[]>([])
  const [results, setResults] = useState<Merchant[]>([])
  const [searching, setSearching] = useState(false)
  const [showResults, setShowResults] = useState(false)

  useEffect(() => {
    loadInitData()
  }, [])

  const loadInitData = async () => {
    try {
      const [hotRes, historyRes] = await Promise.all([
        Network.request({ url: '/api/search/hot' }),
        userInfo?.id ? Network.request({ url: `/api/search/history?userId=${userInfo?.id}` }) : Promise.resolve({ data: { data: [] } })
      ])

      setHotSearches(hotRes.data.data || [])
      setSearchHistory(historyRes.data.data || [])
    } catch (error) {
      console.error('Load init data error:', error)
    }
  }

  const handleSearch = async (kw: string) => {
    if (!kw.trim()) return

    setKeyword(kw)
    setSearching(true)
    setShowResults(true)

    try {
      const res = await Network.request({
        url: `/api/search/merchants?keyword=${encodeURIComponent(kw)}&region=${userInfo?.region || ''}`
      })

      if (res.data.code === 200) {
        setResults(res.data.data.merchants || [])
      }

      // 保存搜索历史
      if (userInfo?.id) {
        await Network.request({
          url: '/api/search/history',
          method: 'POST',
          data: { userId: userInfo.id, keyword: kw }
        })
      }
    } catch (error) {
      console.error('Search error:', error)
    } finally {
      setSearching(false)
    }
  }

  const clearHistory = async () => {
    if (!userInfo?.id) return

    try {
      await Network.request({
        url: `/api/search/history?userId=${userInfo?.id}`,
        method: 'DELETE'
      })
      setSearchHistory([])
    } catch (error) {
      console.error('Clear history error:', error)
    }
  }

  const goToMerchant = (merchantId: string) => {
    Taro.navigateTo({ url: `/pages/merchant-detail/index?id=${merchantId}` })
  }

  return (
    <View className="min-h-screen bg-gray-50">
      {/* 搜索框 */}
      <View className="bg-white px-4 py-3 sticky top-0 z-10">
        <View className="flex items-center gap-2">
          <View className="flex-1 bg-gray-100 rounded-full px-4 py-2 flex items-center gap-2">
            <Search size={18} color="#6b7280" />
            <Input
              className="flex-1 text-sm"
              placeholder="搜索商家、美食、服务..."
              value={keyword}
              onInput={(e) => setKeyword(e.detail.value)}
              onConfirm={() => handleSearch(keyword)}
            />
            {keyword && (
              <View onClick={() => { setKeyword(''); setShowResults(false) }}>
                <X size={18} color="#9ca3af" />
              </View>
            )}
          </View>
          <Button
            size="sm"
            className="bg-teal-500 text-white rounded-full px-4"
            onClick={() => handleSearch(keyword)}
          >
            搜索
          </Button>
        </View>
      </View>

      {showResults ? (
        /* 搜索结果 */
        <View className="px-4 py-4">
          {searching ? (
            <View className="text-center py-8">
              <Text className="text-gray-400">搜索中...</Text>
            </View>
          ) : results.length > 0 ? (
            <View className="space-y-3">
              {results.map((merchant) => (
                <View
                  key={merchant.id}
                  className="bg-white rounded-xl p-4 flex gap-3"
                  onClick={() => goToMerchant(merchant.id)}
                >
                  <Image
                    src={merchant.cover_image || ''}
                    className="w-24 h-24 rounded-lg"
                    mode="aspectFill"
                    onError={() => {
                      console.log('Search image load failed:', merchant.id)
                    }}
                  />
                  <View className="flex-1">
                    <Text className="block text-base font-medium mb-1">{merchant.name}</Text>
                    <Text className="block text-sm text-gray-500 mb-2 line-clamp-2">
                      {merchant.description}
                    </Text>
                    <View className="flex items-center gap-2">
                      <View className="flex items-center gap-1">
                        <Star size={12} color="#14B8A6" />
                        <Text className="text-xs text-teal-500">{merchant.rating}</Text>
                      </View>
                      <View className="flex items-center gap-1">
                        <MapPin size={12} color="#9ca3af" />
                        <Text className="text-xs text-gray-400">{merchant.address}</Text>
                      </View>
                    </View>
                  </View>
                </View>
              ))}
            </View>
          ) : (
            <View className="text-center py-8">
              <Text className="text-gray-400">未找到相关商家</Text>
            </View>
          )}
        </View>
      ) : (
        /* 热门搜索和搜索历史 */
        <View className="px-4 py-4">
          {/* 热门搜索 */}
          <View className="mb-6">
            <View className="flex items-center gap-2 mb-3">
              <Flame size={20} color="#14B8A6" />
              <Text className="text-base font-medium">热门搜索</Text>
            </View>
            <View className="flex flex-wrap gap-2">
              {hotSearches.map((tag, index) => (
                <View
                  key={index}
                  className="bg-white rounded-full px-4 py-2"
                  onClick={() => handleSearch(tag)}
                >
                  <Text className="text-sm text-gray-700">{tag}</Text>
                </View>
              ))}
            </View>
          </View>

          {/* 搜索历史 */}
          {searchHistory.length > 0 && (
            <View>
              <View className="flex items-center justify-between mb-3">
                <View className="flex items-center gap-2">
                  <Clock size={20} color="#6b7280" />
                  <Text className="text-base font-medium">搜索历史</Text>
                </View>
                <Text className="text-sm text-gray-400" onClick={clearHistory}>
                  清空
                </Text>
              </View>
              <View className="flex flex-wrap gap-2">
                {searchHistory.map((item, index) => (
                  <View
                    key={index}
                    className="bg-white rounded-full px-4 py-2"
                    onClick={() => handleSearch(item)}
                  >
                    <Text className="text-sm text-gray-500">{item}</Text>
                  </View>
                ))}
              </View>
            </View>
          )}
        </View>
      )}
    </View>
  )
}
