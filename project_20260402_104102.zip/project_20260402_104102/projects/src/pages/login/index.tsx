import { View, Text } from '@tarojs/components'
import { useState, useEffect } from 'react'
import Taro from '@tarojs/taro'
import { Card, CardContent } from '@/components/ui/card'
import { Input } from '@/components/ui/input'
import { Network } from '@/network'
import { useUserStore } from '@/stores/user'
import { ArrowLeft, MessageCircle, User } from 'lucide-react-taro'
import './index.css'

const LoginPage = () => {
  const [loginType, setLoginType] = useState<'phone' | 'wechat'>('wechat')
  const [phone, setPhone] = useState('')
  const [smsCode, setSmsCode] = useState('')
  const [countdown, setCountdown] = useState(0)
  const [loading, setLoading] = useState(false)
  
  const { login } = useUserStore()

  // 检测平台
  const isWeapp = Taro.getEnv() === Taro.ENV_TYPE.WEAPP

  // 倒计时
  useEffect(() => {
    if (countdown > 0) {
      const timer = setTimeout(() => setCountdown(countdown - 1), 1000)
      return () => clearTimeout(timer)
    }
  }, [countdown])

  // 发送验证码
  const sendSmsCode = async () => {
    if (!phone || !/^1[3-9]\d{9}$/.test(phone)) {
      Taro.showToast({ title: '请输入正确的手机号', icon: 'none' })
      return
    }

    if (countdown > 0) return

    try {
      const res = await Network.request<{ code: number; msg: string }>({
        url: '/api/auth/send-code',
        method: 'POST',
        data: { phone }
      })

      if (res.data?.code === 200) {
        Taro.showToast({ title: '验证码已发送', icon: 'success' })
        setCountdown(60)
      } else {
        Taro.showToast({ title: res.data?.msg || '发送失败', icon: 'none' })
      }
    } catch (error) {
      console.error('Send sms code error:', error)
      Taro.showToast({ title: '发送失败', icon: 'none' })
    }
  }

  // 手机号登录
  const handlePhoneLogin = async () => {
    if (!phone || !/^1[3-9]\d{9}$/.test(phone)) {
      Taro.showToast({ title: '请输入正确的手机号', icon: 'none' })
      return
    }

    if (!smsCode || smsCode.length !== 6) {
      Taro.showToast({ title: '请输入6位验证码', icon: 'none' })
      return
    }

    setLoading(true)
    try {
      const res = await Network.request<{
        code: number
        msg: string
        data: {
          success: boolean
          token?: string
          user?: any
        } | null
      }>({
        url: '/api/auth/phone-login',
        method: 'POST',
        data: { phone, code: smsCode }
      })

      console.log('[Login] Phone login response:', res.data)

      if (res.data?.code === 200 && res.data.data?.success) {
        login(res.data.data.token!, res.data.data.user)
        Taro.showToast({ title: '登录成功', icon: 'success' })
        setTimeout(() => {
          Taro.switchTab({ url: '/pages/index/index' })
        }, 1500)
      } else {
        Taro.showToast({ title: res.data?.msg || '登录失败', icon: 'none' })
      }
    } catch (error) {
      console.error('Phone login error:', error)
      Taro.showToast({ title: '登录失败', icon: 'none' })
    } finally {
      setLoading(false)
    }
  }

  // 微信登录
  const handleWeappLogin = async () => {
    if (!isWeapp) {
      // H5/开发环境：模拟登录
      await handleMockLogin()
      return
    }

    setLoading(true)
    try {
      // 获取微信登录凭证
      const { code } = await Taro.login()
      
      const res = await Network.request<{
        code: number
        msg: string
        data: {
          success: boolean
          token?: string
          user?: any
        } | null
      }>({
        url: '/api/auth/weapp-login',
        method: 'POST',
        data: { code }
      })

      console.log('[Login] Weapp login response:', res.data)

      if (res.data?.code === 200 && res.data.data?.success) {
        login(res.data.data.token!, res.data.data.user)
        Taro.showToast({ title: '登录成功', icon: 'success' })
        setTimeout(() => {
          Taro.switchTab({ url: '/pages/index/index' })
        }, 1500)
      } else {
        Taro.showToast({ title: res.data?.msg || '登录失败', icon: 'none' })
      }
    } catch (error) {
      console.error('Weapp login error:', error)
      Taro.showToast({ title: '登录失败', icon: 'none' })
    } finally {
      setLoading(false)
    }
  }

  // 模拟登录（开发环境）
  const handleMockLogin = async () => {
    setLoading(true)
    try {
      const res = await Network.request<{
        code: number
        msg: string
        data: {
          success: boolean
          token?: string
          user?: any
        } | null
      }>({
        url: '/api/auth/mock-login',
        method: 'POST',
        data: {}
      })

      console.log('[Login] Mock login response:', res.data)

      if (res.data?.code === 200 && res.data.data?.success) {
        // 保存用户ID到本地存储
        Taro.setStorageSync('user_id', res.data.data.user.id)
        login(res.data.data.token!, res.data.data.user)
        Taro.showToast({ title: '登录成功', icon: 'success' })
        setTimeout(() => {
          Taro.switchTab({ url: '/pages/index/index' })
        }, 1500)
      } else {
        Taro.showToast({ title: res.data?.msg || '登录失败', icon: 'none' })
      }
    } catch (error) {
      console.error('Mock login error:', error)
      Taro.showToast({ title: '登录失败', icon: 'none' })
    } finally {
      setLoading(false)
    }
  }

  // 返回
  const goBack = () => {
    Taro.navigateBack()
  }

  return (
    <View className="min-h-screen bg-gradient-to-b from-slate-50 via-stone-50 to-stone-50">
      {/* 渐变顶部 */}
      <View className="bg-gradient-to-br from-teal-500 to-teal-600 px-4 pt-12 pb-16 rounded-b-[40px]">
        {/* 返回按钮 */}
        <View onClick={goBack} className="inline-flex items-center gap-1 mb-8">
          <View className="w-8 h-8 rounded-full flex items-center justify-center" style={{ backgroundColor: 'rgba(255,255,255,0.2)' }}>
            <ArrowLeft size={18} color="#fff" />
          </View>
          <Text className="text-white text-sm">返回</Text>
        </View>

        {/* Logo区域 */}
        <View className="flex flex-col items-center">
          <View className="w-20 h-20 rounded-2xl bg-white shadow-xl shadow-teal-500 flex items-center justify-center mb-4">
            <Text className="text-teal-500 text-3xl font-bold">厦</Text>
          </View>
          <Text className="text-white text-2xl font-bold">厦门本地生活</Text>
          <Text className="text-white text-sm mt-2" style={{ opacity: 0.7 }}>AI智能导购 · 发现好店</Text>
        </View>
      </View>

      {/* 登录表单卡片 */}
      <View className="px-4 -mt-6">
        <Card className="bg-white backdrop-blur border-0 shadow-2xl shadow-slate-200 rounded-2xl overflow-hidden">
          <CardContent className="p-6">
            {/* 登录方式切换 */}
            <View className="flex mb-6 bg-slate-100 rounded-2xl p-1">
              <View
                className={`flex-1 text-center py-3 rounded-xl transition-all ${
                  loginType === 'wechat' ? 'bg-white shadow-md' : ''
                }`}
                onClick={() => setLoginType('wechat')}
              >
                <Text className={loginType === 'wechat' ? 'text-teal-600 font-semibold' : 'text-slate-400'}>
                  {isWeapp ? '微信登录' : '快捷登录'}
                </Text>
              </View>
              <View
                className={`flex-1 text-center py-3 rounded-xl transition-all ${
                  loginType === 'phone' ? 'bg-white shadow-md' : ''
                }`}
                onClick={() => setLoginType('phone')}
              >
                <Text className={loginType === 'phone' ? 'text-teal-600 font-semibold' : 'text-slate-400'}>
                  手机号登录
                </Text>
              </View>
            </View>

            {/* 微信登录 */}
            {loginType === 'wechat' && (
              <View className="flex flex-col items-center py-6">
                <View
                  className="w-full py-4 bg-gradient-to-r from-teal-500 to-teal-600 rounded-2xl flex items-center justify-center shadow-lg shadow-teal-500"
                  onClick={handleWeappLogin}
                >
                  {loading ? (
                    <Text className="text-white font-semibold">登录中...</Text>
                  ) : (
                    <View className="flex items-center gap-2">
                      <MessageCircle size={22} color="#fff" />
                      <Text className="text-white font-semibold text-lg">
                        {isWeapp ? '微信一键登录' : '模拟登录'}
                      </Text>
                    </View>
                  )}
                </View>
                {!isWeapp && (
                  <Text className="text-xs text-slate-400 mt-4 text-center">
                    开发环境将使用模拟账号登录
                  </Text>
                )}
              </View>
            )}

            {/* 手机号登录 */}
            {loginType === 'phone' && (
              <View className="space-y-4">
                {/* 手机号输入 */}
                <View className="bg-slate-50 rounded-2xl px-4 py-4">
                  <View className="flex items-center gap-3">
                    <View className="w-10 h-10 rounded-xl bg-teal-100 flex items-center justify-center">
                      <User size={20} color="#14B8A6" />
                    </View>
                    <Input
                      className="flex-1 bg-transparent text-base"
                      type="number"
                      placeholder="请输入手机号"
                      maxlength={11}
                      value={phone}
                      onInput={(e) => setPhone(e.detail.value)}
                    />
                  </View>
                </View>

                {/* 验证码输入 */}
                <View className="bg-slate-50 rounded-2xl px-4 py-4">
                  <View className="flex items-center gap-3">
                    <View className="w-10 h-10 rounded-xl bg-teal-100 flex items-center justify-center">
                      <MessageCircle size={20} color="#14B8A6" />
                    </View>
                    <Input
                      className="flex-1 bg-transparent text-base"
                      type="number"
                      placeholder="请输入验证码"
                      maxlength={6}
                      value={smsCode}
                      onInput={(e) => setSmsCode(e.detail.value)}
                    />
                    <View
                      className={`px-4 py-2 rounded-xl ${countdown > 0 ? 'bg-slate-200' : 'bg-gradient-to-r from-teal-500 to-teal-600'}`}
                      onClick={sendSmsCode}
                    >
                      <Text className={`text-sm font-medium ${countdown > 0 ? 'text-slate-400' : 'text-white'}`}>
                        {countdown > 0 ? `${countdown}s` : '获取验证码'}
                      </Text>
                    </View>
                  </View>
                </View>

                {/* 登录按钮 */}
                <View
                  className="w-full py-4 bg-gradient-to-r from-teal-500 to-teal-600 rounded-2xl flex items-center justify-center shadow-lg shadow-teal-500 mt-6"
                  onClick={handlePhoneLogin}
                >
                  {loading ? (
                    <Text className="text-white font-semibold text-lg">登录中...</Text>
                  ) : (
                    <Text className="text-white font-semibold text-lg">登录</Text>
                  )}
                </View>

                <Text className="text-xs text-slate-400 text-center block mt-2">
                  首次登录将自动注册账号
                </Text>
              </View>
            )}
          </CardContent>
        </Card>
      </View>

      {/* 用户协议 */}
      <View className="px-6 py-6">
        <Text className="text-slate-400 text-xs text-center block leading-relaxed">
          登录即代表同意
          <Text className="text-teal-500 underline" onClick={() => Taro.navigateTo({ url: '/pages/settings/agreement?type=user' })}>
            《用户协议》
          </Text>
          和
          <Text className="text-teal-500 underline" onClick={() => Taro.navigateTo({ url: '/pages/settings/agreement?type=privacy' })}>
            《隐私政策》
          </Text>
        </Text>
      </View>

      {/* 其他登录方式 */}
      <View className="px-4 pb-8">
        <View className="flex items-center gap-4 mb-6">
          <View className="flex-1 h-px bg-slate-200" />
          <Text className="text-slate-400 text-xs">其他登录方式</Text>
          <View className="flex-1 h-px bg-slate-200" />
        </View>
        <View className="flex items-center justify-center gap-8">
          <View className="flex flex-col items-center gap-2" onClick={() => setLoginType('wechat')}>
            <View className="w-14 h-14 rounded-2xl bg-gradient-to-br from-teal-400 to-teal-500 flex items-center justify-center shadow-lg shadow-teal-500">
              <MessageCircle size={26} color="#fff" />
            </View>
            <Text className="text-slate-500 text-xs">微信</Text>
          </View>
          <View className="flex flex-col items-center gap-2" onClick={() => setLoginType('phone')}>
            <View className="w-14 h-14 rounded-2xl bg-gradient-to-br from-teal-400 to-teal-500 flex items-center justify-center shadow-lg shadow-teal-500">
              <User size={26} color="#fff" />
            </View>
            <Text className="text-slate-500 text-xs">手机</Text>
          </View>
        </View>
      </View>
    </View>
  )
}

export default LoginPage
