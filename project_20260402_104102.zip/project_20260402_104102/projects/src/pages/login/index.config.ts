export default typeof definePageConfig === 'function'
  ? definePageConfig({ navigationBarTitleText: '登录', navigationBarBackgroundColor: '#14B8A6', navigationBarTextStyle: 'white' })
  : { navigationBarTitleText: '登录', navigationBarBackgroundColor: '#14B8A6', navigationBarTextStyle: 'white' }
