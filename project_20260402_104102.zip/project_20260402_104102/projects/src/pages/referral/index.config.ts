export default typeof definePageConfig === 'function'
  ? definePageConfig({ navigationBarTitleText: '邀请好友' })
  : { navigationBarTitleText: '邀请好友' }
