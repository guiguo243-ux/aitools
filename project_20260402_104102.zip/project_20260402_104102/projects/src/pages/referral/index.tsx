import { View, Text, ScrollView } from '@tarojs/components'
import { useState, useEffect } from 'react'
import Taro from '@tarojs/taro'
import { Users, Copy, Gift, Share2, Smartphone, Clock, TrendingUp } from 'lucide-react-taro'
import { Card, CardContent } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Avatar, AvatarImage, AvatarFallback } from '@/components/ui/avatar'
import { Network } from '@/network'
import { useUserStore } from '@/stores/user'

// 邀请记录
interface InviteRecord {
  id: string
  nickname: string
  avatar: string
  reward: number
  createdAt: string
  status: 'registered' | 'first_order'
}

const ReferralPage = () => {
  const [referralCode, setReferralCode] = useState('RUSER0001')
  const [totalReferrals, setTotalReferrals] = useState(0)
  const [totalRewards, setTotalRewards] = useState(0)
  const [inviteRecords, setInviteRecords] = useState<InviteRecord[]>([])

  // 获取用户ID
  const { userInfo } = useUserStore()
  const userId = userInfo?.id || Taro.getStorageSync('user_id') || ''
  const userRegion = userInfo?.region || 'island_inside'

  useEffect(() => {
    fetchReferralData()
  }, [])

  const fetchReferralData = async () => {
    try {
      // 并行请求
      const [statsRes, recordsRes] = await Promise.all([
        Network.request({
          url: '/api/referral/stats',
          method: 'GET',
          data: { userId }
        }),
        Network.request({
          url: '/api/referral/invite-records',
          method: 'GET',
          data: { userId }
        })
      ])

      console.log('Stats response:', statsRes.data)
      console.log('Records response:', recordsRes.data)

      if (statsRes.data?.code === 200) {
        setReferralCode(statsRes.data.data?.referralCode || 'RUSER0001')
        setTotalReferrals(statsRes.data.data?.totalReferrals || 0)
        setTotalRewards(statsRes.data.data?.totalRewards || 0)
      }

      if (recordsRes.data?.code === 200) {
        setInviteRecords(recordsRes.data.data || [])
      }
    } catch (error) {
      console.error('Fetch referral data error:', error)
      // 使用模拟数据
      setReferralCode('RUSER0001')
      setTotalReferrals(5)
      setTotalRewards(25)
      setInviteRecords(getMockInviteRecords())
    }
  }

  // 模拟邀请记录
  const getMockInviteRecords = (): InviteRecord[] => [
    { id: '1', nickname: '小明', avatar: '', reward: 6, createdAt: new Date().toISOString(), status: 'registered' },
    { id: '2', nickname: '小红', avatar: '', reward: 9, createdAt: new Date(Date.now() - 86400000).toISOString(), status: 'first_order' },
    { id: '3', nickname: '小刚', avatar: '', reward: 6, createdAt: new Date(Date.now() - 172800000).toISOString(), status: 'registered' },
  ]

  const copyReferralCode = () => {
    Taro.setClipboardData({
      data: referralCode,
      success: () => {
        Taro.showToast({ title: '邀请码已复制', icon: 'success' })
      }
    })
  }

  const generatePoster = async () => {
    Taro.showLoading({ title: '生成中...' })
    try {
      const res = await Network.request({
        url: '/api/poster/generate',
        method: 'POST',
        data: { userId, type: 'new_user_invite', region: userRegion }
      })

      console.log('Poster response:', res.data)

      if (res.data?.code === 200) {
        Taro.hideLoading()
        Taro.showToast({ title: '海报已生成', icon: 'success' })
        // 这里可以跳转到海报预览页面
      } else {
        throw new Error('生成失败')
      }
    } catch (error) {
      Taro.hideLoading()
      console.error('Generate poster error:', error)
      Taro.showToast({ title: '生成失败，请重试', icon: 'none' })
    }
  }

  const formatDate = (dateStr: string) => {
    const date = new Date(dateStr)
    return `${date.getMonth() + 1}月${date.getDate()}日`
  }

  // 配置分享
  Taro.useShareAppMessage(() => {
    return {
      title: '我在厦门AI生活平台领到了新人红包，你也来试试！',
      path: `pages/index/index?scene=r=${userId}`,
    }
  })

  return (
    <View className="min-h-screen bg-zinc-50">
      <ScrollView scrollY className="h-screen">
        {/* 顶部统计卡片 */}
        <View className="bg-gradient-to-br from-teal-500 to-teal-600 px-4 pt-6 pb-8">
          <View className="flex items-center justify-center mb-4">
            <View className="w-20 h-20 rounded-full flex items-center justify-center" style={{ backgroundColor: 'rgba(255,255,255,0.2)' }}>
              <Users size={40} color="#ffffff" />
            </View>
          </View>
          
          <View className="flex items-center justify-around">
            <View className="flex flex-col items-center">
              <Text className="text-white text-3xl font-bold">{totalReferrals}</Text>
              <Text className="text-white text-opacity-80 text-sm">邀请人数</Text>
            </View>
            <View className="w-px h-10" style={{ backgroundColor: 'rgba(255,255,255,0.2)' }} />
            <View className="flex flex-col items-center">
              <Text className="text-white text-3xl font-bold">¥{totalRewards}</Text>
              <Text className="text-white text-opacity-80 text-sm">累计奖励</Text>
            </View>
          </View>
        </View>

        {/* 邀请码卡片 */}
        <View className="px-4 -mt-4">
          <Card className="shadow-sm">
            <CardContent className="p-4">
              <View className="flex items-center justify-between">
                <View>
                  <Text className="text-zinc-500 text-sm">我的邀请码</Text>
                  <Text className="text-2xl font-bold text-zinc-800 mt-1">{referralCode}</Text>
                </View>
                <Button 
                  size="sm" 
                  variant="outline"
                  className="border-teal-500 text-teal-500"
                  onClick={copyReferralCode}
                >
                  <Copy size={16} color="#14B8A6" />
                  <Text className="ml-1">复制</Text>
                </Button>
              </View>
            </CardContent>
          </Card>
        </View>

        {/* 奖励规则 */}
        <View className="px-4 mt-4">
          <Card>
            <CardContent className="p-4">
              <View className="flex items-center gap-2 mb-3">
                <Gift size={20} color="#14B8A6" />
                <Text className="font-semibold text-zinc-800">邀请奖励</Text>
              </View>
              
              <View className="space-y-3">
                <View className="flex items-start gap-3 bg-teal-50 rounded-lg p-3">
                  <View className="w-8 h-8 rounded-full bg-teal-100 flex items-center justify-center flex-shrink-0">
                    <Text className="text-teal-500 font-bold">1</Text>
                  </View>
                  <View>
                    <Text className="text-zinc-800 font-medium">好友扫码注册</Text>
                    <Text className="text-zinc-500 text-sm">您得4元红包+5元券，好友得6元红包</Text>
                  </View>
                </View>
                
                <View className="flex items-start gap-3 bg-teal-50 rounded-lg p-3">
                  <View className="w-8 h-8 rounded-full bg-teal-100 flex items-center justify-center flex-shrink-0">
                    <Text className="text-teal-500 font-bold">2</Text>
                  </View>
                  <View>
                    <Text className="text-zinc-800 font-medium">好友首单成交</Text>
                    <Text className="text-zinc-500 text-sm">您再得3元返现+8元券</Text>
                  </View>
                </View>
                
                <View className="flex items-start gap-3 bg-blue-50 rounded-lg p-3">
                  <View className="w-8 h-8 rounded-full bg-blue-100 flex items-center justify-center flex-shrink-0">
                    <Text className="text-blue-500 font-bold">3</Text>
                  </View>
                  <View>
                    <Text className="text-zinc-800 font-medium">组队拼单</Text>
                    <Text className="text-zinc-500 text-sm">2-3人拼单，各得7元券</Text>
                  </View>
                </View>
              </View>
            </CardContent>
          </Card>
        </View>

        {/* 分享按钮 */}
        <View className="px-4 mt-4 flex gap-3">
          <Button 
            className="flex-1 bg-teal-500 text-white"
            onClick={() => {
              // 触发小程序分享菜单
              Taro.showShareMenu({
                withShareTicket: true
              })
            }}
          >
            <Share2 size={18} color="#ffffff" />
            <Text className="ml-1">分享给好友</Text>
          </Button>
          
          <Button 
            variant="outline"
            className="flex-1 border-teal-500 text-teal-500"
            onClick={generatePoster}
          >
            <Smartphone size={18} color="#14B8A6" />
            <Text className="ml-1">生成海报</Text>
          </Button>
        </View>

        {/* 邀请记录 */}
        <View className="px-4 mt-4">
          <Card>
            <CardContent className="p-4">
              <View className="flex items-center justify-between mb-3">
                <View className="flex items-center gap-2">
                  <Clock size={18} color="#6b7280" />
                  <Text className="font-semibold text-zinc-800">邀请记录</Text>
                </View>
                <View className="flex items-center">
                  <Text className="text-zinc-400 text-sm">查看全部</Text>
                  ›
                </View>
              </View>

              {inviteRecords.length > 0 ? (
                inviteRecords.map((record) => (
                  <View 
                    key={record.id}
                    className="flex items-center justify-between py-3 border-b border-zinc-100 last:border-0"
                  >
                    <View className="flex items-center gap-3">
                      <Avatar className="w-10 h-10">
                        <AvatarImage src={record.avatar} />
                        <AvatarFallback>{record.nickname.charAt(0)}</AvatarFallback>
                      </Avatar>
                      <View>
                        <Text className="text-zinc-800">{record.nickname}</Text>
                        <Text className="text-zinc-400 text-xs">
                          {formatDate(record.createdAt)} 
                          {record.status === 'first_order' ? ' · 已下单' : ' · 已注册'}
                        </Text>
                      </View>
                    </View>
                    <Text className="text-teal-500 font-semibold">+¥{record.reward}</Text>
                  </View>
                ))
              ) : (
                <View className="flex flex-col items-center justify-center py-8">
                  <Users size={48} color="#9ca3af" />
                  <Text className="text-zinc-400 mt-2">暂无邀请记录</Text>
                  <Text className="text-zinc-300 text-sm mt-1">分享给好友开始赚钱吧</Text>
                </View>
              )}
            </CardContent>
          </Card>
        </View>

        {/* 榜单入口 */}
        <View className="px-4 mt-4 mb-8">
          <Card className="bg-gradient-to-r from-teal-500 to-teal-600 border-0">
            <CardContent className="p-4 flex items-center justify-between" onClick={() => Taro.navigateTo({ url: '/pages/ranking/index' })}>
              <View className="flex items-center gap-3">
                <View className="w-10 h-10 rounded-full flex items-center justify-center" style={{ backgroundColor: 'rgba(255,255,255,0.2)' }}>
                  <TrendingUp size={20} color="#ffffff" />
                </View>
                <View>
                  <Text className="text-white font-semibold block">推广达人榜</Text>
                  <Text className="text-white text-opacity-80 text-xs">本周TOP10额外奖励</Text>
                </View>
              </View>
              <Text className="text-white text-xl">›</Text>
            </CardContent>
          </Card>
        </View>
      </ScrollView>
    </View>
  )
}

export default ReferralPage
