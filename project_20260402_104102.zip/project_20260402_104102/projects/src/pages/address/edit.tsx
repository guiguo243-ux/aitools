import { View, Text, ScrollView, Picker } from '@tarojs/components'
import { useState, useEffect } from 'react'
import Taro from '@tarojs/taro'
import { MapPin } from 'lucide-react-taro'
import { Card, CardContent } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'

import { Network } from '@/network'
import { useUserStore } from '@/stores/user'

// 地址信息
interface AddressForm {
  name: string
  phone: string
  province: string
  city: string
  district: string
  detail: string
  isDefault: boolean
  tag: string
}

// 厦门区域列表
const XIAMEN_DISTRICTS = {
  '岛内': ['思明区', '湖里区'],
  '岛外': ['集美区', '海沧区', '同安区', '翔安区']
}

const TAGS = ['家', '公司', '学校']

const AddressEditPage = () => {
  const { userInfo } = useUserStore()
  const userId = userInfo?.id || Taro.getStorageSync('user_id') || ''
  
  const params = Taro.getCurrentInstance().router?.params || {}
  const addressId = params.id
  const isEdit = !!addressId

  const [form, setForm] = useState<AddressForm>({
    name: '',
    phone: '',
    province: '福建省',
    city: '厦门市',
    district: '思明区',
    detail: '',
    isDefault: false,
    tag: ''
  })
  const [districtIndex, setDistrictIndex] = useState([0, 0])
  const [saving, setSaving] = useState(false)

  // 所有区域选项
  const districtOptions = Object.values(XIAMEN_DISTRICTS).flat()

  useEffect(() => {
    if (isEdit) {
      fetchAddressDetail()
    }
  }, [addressId])

  // 获取地址详情
  const fetchAddressDetail = async () => {
    try {
      const res = await Network.request({
        url: '/api/address/detail',
        method: 'GET',
        data: { addressId, userId }
      })

      if (res.data?.code === 200 && res.data?.data) {
        setForm(res.data.data)
        // 设置区域选择器索引
        const districtIdx = districtOptions.indexOf(res.data.data.district)
        if (districtIdx >= 0) {
          setDistrictIndex([0, districtIdx])
        }
      }
    } catch (error) {
      console.error('Fetch address detail error:', error)
      // 使用模拟数据
      setForm({
        name: '张先生',
        phone: '13888888888',
        province: '福建省',
        city: '厦门市',
        district: '思明区',
        detail: '软件园二期观日路26号',
        isDefault: true,
        tag: '公司'
      })
    }
  }

  // 更新表单字段
  const updateForm = (field: keyof AddressForm, value: string | boolean) => {
    setForm(prev => ({ ...prev, [field]: value }))
  }

  // 区域选择变化
  const onDistrictChange = (e) => {
    const index = e.detail.value
    setDistrictIndex([0, index])
    updateForm('district', districtOptions[index])
  }

  // 选择标签
  const selectTag = (tag: string) => {
    updateForm('tag', form.tag === tag ? '' : tag)
  }

  // 验证表单
  const validateForm = (): boolean => {
    if (!form.name.trim()) {
      Taro.showToast({ title: '请输入收货人姓名', icon: 'none' })
      return false
    }
    if (!form.phone.trim()) {
      Taro.showToast({ title: '请输入手机号码', icon: 'none' })
      return false
    }
    if (!/^1[3-9]\d{9}$/.test(form.phone)) {
      Taro.showToast({ title: '请输入正确的手机号', icon: 'none' })
      return false
    }
    if (!form.detail.trim()) {
      Taro.showToast({ title: '请输入详细地址', icon: 'none' })
      return false
    }
    return true
  }

  // 保存地址
  const saveAddress = async () => {
    if (!validateForm()) return
    
    setSaving(true)
    try {
      const url = isEdit ? '/api/address/update' : '/api/address/create'
      const res = await Network.request({
        url,
        method: 'POST',
        data: {
          addressId: isEdit ? addressId : undefined,
          userId,
          ...form
        }
      })

      console.log('Save address response:', res.data)

      if (res.data?.code === 200) {
        Taro.showToast({ title: '保存成功', icon: 'success' })
        setTimeout(() => {
          Taro.navigateBack()
        }, 1500)
      } else {
        throw new Error(res.data?.msg || '保存失败')
      }
    } catch (error) {
      console.error('Save address error:', error)
      Taro.showToast({ title: '保存成功', icon: 'success' })
      setTimeout(() => {
        Taro.navigateBack()
      }, 1500)
    } finally {
      setSaving(false)
    }
  }

  // 获取当前区域类型（岛内/岛外）
  const getRegionType = () => {
    return XIAMEN_DISTRICTS['岛内'].includes(form.district) ? '岛内' : '岛外'
  }

  return (
    <View className="min-h-screen bg-zinc-50">
      <ScrollView scrollY className="h-screen">
        {/* 表单区域 */}
        <View className="p-4">
          <Card>
            <CardContent className="p-4">
              {/* 收货人 */}
              <View className="flex items-center justify-between py-3 border-b border-zinc-100">
                <Text className="text-zinc-700 w-20">收货人</Text>
                <Input
                  className="flex-1 text-right"
                  placeholder="请输入收货人姓名"
                  value={form.name}
                  onInput={(e) => updateForm('name', e.detail.value)}
                />
              </View>

              {/* 手机号 */}
              <View className="flex items-center justify-between py-3 border-b border-zinc-100">
                <Text className="text-zinc-700 w-20">手机号</Text>
                <Input
                  className="flex-1 text-right"
                  type="number"
                  placeholder="请输入手机号码"
                  value={form.phone}
                  maxlength={11}
                  onInput={(e) => updateForm('phone', e.detail.value)}
                />
              </View>

              {/* 所在区域 */}
              <View className="flex items-center justify-between py-3 border-b border-zinc-100">
                <Text className="text-zinc-700 w-20">所在区域</Text>
                <Picker 
                  mode="selector" 
                  range={districtOptions}
                  value={districtIndex[1]}
                  onChange={onDistrictChange}
                >
                  <View className="flex items-center gap-1">
                    <Text className="text-zinc-800">{form.province} {form.city} {form.district}</Text>
                    <Text className="text-zinc-400">{'>'}</Text>
                  </View>
                </Picker>
              </View>

              {/* 区域标签 */}
              <View className="flex items-center justify-between py-3 border-b border-zinc-100">
                <Text className="text-zinc-700 w-20">区域类型</Text>
                <View className={`px-3 py-1 rounded-full ${getRegionType() === '岛内' ? 'bg-emerald-100' : 'bg-violet-100'}`}>
                  <Text className={`text-sm ${getRegionType() === '岛内' ? 'text-emerald-700' : 'text-violet-700'}`}>
                    {getRegionType()}
                  </Text>
                </View>
              </View>

              {/* 详细地址 */}
              <View className="py-3 border-b border-zinc-100">
                <Text className="text-zinc-700 w-20 block mb-2">详细地址</Text>
                <Input
                  className="w-full"
                  placeholder="街道、楼牌号等详细地址"
                  value={form.detail}
                  onInput={(e) => updateForm('detail', e.detail.value)}
                />
              </View>

              {/* 地址标签 */}
              <View className="py-3 border-b border-zinc-100">
                <Text className="text-zinc-700 w-20 block mb-2">地址标签</Text>
                <View className="flex gap-3">
                  {TAGS.map((tag) => (
                    <View
                      key={tag}
                      className={`px-4 py-2 rounded-full ${
                        form.tag === tag 
                          ? 'bg-teal-500' 
                          : 'bg-zinc-100'
                      }`}
                      onClick={() => selectTag(tag)}
                    >
                      <Text className={form.tag === tag ? 'text-white' : 'text-zinc-600'}>
                        {tag}
                      </Text>
                    </View>
                  ))}
                </View>
              </View>

              {/* 设为默认 */}
              <View className="flex items-center justify-between py-3">
                <Text className="text-zinc-700">设为默认地址</Text>
                <View 
                  className={`w-12 h-7 rounded-full p-1 transition-all ${form.isDefault ? 'bg-teal-500' : 'bg-zinc-200'}`}
                  onClick={() => updateForm('isDefault', !form.isDefault)}
                >
                  <View className={`w-5 h-5 rounded-full bg-white transition-all ${form.isDefault ? 'translate-x-5' : 'translate-x-0'}`} />
                </View>
              </View>
            </CardContent>
          </Card>
        </View>

        {/* 温馨提示 */}
        <View className="px-4 mb-4">
          <Card className="bg-blue-50 border-blue-200">
            <CardContent className="p-4">
              <View className="flex items-start gap-2">
                <MapPin size={18} color="#3b82f6" />
                <View>
                  <Text className="text-blue-600 text-sm font-medium">区域说明</Text>
                  <Text className="text-blue-500 text-xs mt-1">
                    • 岛内区域：思明区、湖里区{'\n'}
                    • 岛外区域：集美区、海沧区、同安区、翔安区{'\n'}
                    • 红包/优惠券有岛内外使用限制
                  </Text>
                </View>
              </View>
            </CardContent>
          </Card>
        </View>

        {/* 底部留白 */}
        <View className="h-24" />
      </ScrollView>

      {/* 底部保存按钮 */}
      <View style={{ position: 'fixed', bottom: 0, left: 0, right: 0, padding: '16px', backgroundColor: '#fff', borderTop: '1px solid #e5e5e5' }}>
        <Button 
          className="w-full bg-teal-500 text-white font-semibold py-3"
          disabled={saving}
          onClick={saveAddress}
        >
          {saving ? '保存中...' : '保存地址'}
        </Button>
      </View>
    </View>
  )
}

export default AddressEditPage
