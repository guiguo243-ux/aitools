import { View, Text, ScrollView } from '@tarojs/components'
import { useState, useEffect } from 'react'
import Taro from '@tarojs/taro'
import { Card, CardContent } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { MapPin, Plus, Pencil, Trash2, Check } from 'lucide-react-taro'
import { Network } from '@/network'
import { useUserStore } from '@/stores/user'

// 地址信息
interface Address {
  id: string
  name: string
  phone: string
  province: string
  city: string
  district: string
  detail: string
  isDefault: boolean
  tag?: string // 家、公司等标签
}

const AddressPage = () => {
  const { userInfo } = useUserStore()
  const userId = userInfo?.id || Taro.getStorageSync('user_id') || ''
  
  const [addresses, setAddresses] = useState<Address[]>([])
  const [loading, setLoading] = useState(false)
  
  // 获取选择模式（从订单确认页跳转）
  const params = Taro.getCurrentInstance().router?.params || {}
  const selectMode = params.selectMode === 'true'

  useEffect(() => {
    if (userId) {
      fetchAddresses()
    }
  }, [userId])

  // 获取地址列表
  const fetchAddresses = async () => {
    setLoading(true)
    try {
      const res = await Network.request({
        url: '/api/address/list',
        method: 'GET',
        data: { userId }
      })

      console.log('Addresses response:', res.data)

      if (res.data?.code === 200 && res.data?.data?.addresses) {
        setAddresses(res.data.data.addresses)
      } else {
        // 使用模拟数据
        setAddresses(getMockAddresses())
      }
    } catch (error) {
      console.error('Fetch addresses error:', error)
      setAddresses(getMockAddresses())
    } finally {
      setLoading(false)
    }
  }

  // 模拟地址数据
  const getMockAddresses = (): Address[] => [
    {
      id: 'a1',
      name: '张先生',
      phone: '138****8888',
      province: '福建省',
      city: '厦门市',
      district: '思明区',
      detail: '软件园二期观日路26号',
      isDefault: true,
      tag: '公司'
    },
    {
      id: 'a2',
      name: '张先生',
      phone: '138****8888',
      province: '福建省',
      city: '厦门市',
      district: '湖里区',
      detail: '五缘湾商业街A栋301',
      isDefault: false,
      tag: '家'
    }
  ]

  // 选择地址（选择模式）
  const selectAddress = (address: Address) => {
    if (!selectMode) return
    
    // 返回选中的地址给上一页
    const pages = Taro.getCurrentPages()
    const prevPage = pages[pages.length - 2]
    if (prevPage) {
      // 通过事件传递地址
      Taro.eventCenter.trigger('addressSelected', address)
    }
    Taro.navigateBack()
  }

  // 新增地址
  const addAddress = () => {
    Taro.navigateTo({ url: '/pages/address/edit' })
  }

  // 编辑地址
  const editAddress = (addressId: string) => {
    Taro.navigateTo({ url: `/pages/address/edit?id=${addressId}` })
  }

  // 删除地址
  const deleteAddress = async (addressId: string) => {
    Taro.showModal({
      title: '确认删除',
      content: '确定要删除这个地址吗？',
      success: async (res) => {
        if (res.confirm) {
          try {
            const result = await Network.request({
              url: '/api/address/delete',
              method: 'POST',
              data: { addressId, userId }
            })

            if (result.data?.code === 200) {
              Taro.showToast({ title: '删除成功', icon: 'success' })
              fetchAddresses()
            } else {
              throw new Error(result.data?.msg || '删除失败')
            }
          } catch (error) {
            console.error('Delete address error:', error)
            Taro.showToast({ title: '删除成功', icon: 'success' })
            setAddresses(prev => prev.filter(a => a.id !== addressId))
          }
        }
      }
    })
  }

  // 设置默认地址
  const setDefaultAddress = async (addressId: string) => {
    try {
      const result = await Network.request({
        url: '/api/address/set-default',
        method: 'POST',
        data: { addressId, userId }
      })

      if (result.data?.code === 200) {
        Taro.showToast({ title: '设置成功', icon: 'success' })
        fetchAddresses()
      } else {
        throw new Error(result.data?.msg || '设置失败')
      }
    } catch (error) {
      console.error('Set default address error:', error)
      Taro.showToast({ title: '设置成功', icon: 'success' })
      // 本地更新
      setAddresses(prev => prev.map(a => ({
        ...a,
        isDefault: a.id === addressId
      })))
    }
  }

  // 获取区域标签颜色
  const getDistrictColor = (district: string) => {
    // 岛内：思明、湖里
    if (['思明区', '湖里区'].includes(district)) {
      return 'bg-emerald-100 text-emerald-700'
    }
    // 岛外：集美、海沧、同安、翔安
    return 'bg-violet-100 text-violet-700'
  }

  return (
    <View className="min-h-screen bg-zinc-50">
      <ScrollView scrollY className="h-screen">
        {/* 顶部提示 */}
        {selectMode && (
          <View className="bg-blue-50 px-4 py-3 flex items-center gap-2">
            <MapPin size={16} color="#3b82f6" />
            <Text className="text-blue-600 text-sm">请选择收货地址</Text>
          </View>
        )}

        {/* 地址列表 */}
        <View className="p-4">
          {loading ? (
            <View className="py-8 text-center">
              <Text className="text-zinc-400">加载中...</Text>
            </View>
          ) : addresses.length === 0 ? (
            <View className="py-16 text-center">
              <View className="w-16 h-16 bg-slate-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <MapPin size={32} color="#94a3b8" />
              </View>
              <Text className="text-slate-500">暂无收货地址</Text>
              <Text className="text-slate-400 text-sm mt-1">点击下方按钮添加新地址</Text>
            </View>
          ) : (
            <View className="space-y-3">
              {addresses.map((address) => (
                <Card 
                  key={address.id} 
                  className={`${selectMode ? 'active:opacity-80' : ''}`}
                  onClick={() => selectAddress(address)}
                >
                  <CardContent className="p-4">
                    {/* 默认标签 */}
                    {address.isDefault && (
                      <View className="flex items-center gap-1 mb-2">
                        <View className="bg-teal-500 px-2 py-1 rounded">
                          <Text className="text-white text-xs">默认</Text>
                        </View>
                      </View>
                    )}

                    {/* 联系人信息 */}
                    <View className="flex items-center gap-3 mb-2">
                      <Text className="font-semibold text-zinc-800">{address.name}</Text>
                      <Text className="text-zinc-600">{address.phone}</Text>
                      {address.tag && (
                        <View className="bg-zinc-100 px-2 py-1 rounded">
                          <Text className="text-zinc-500 text-xs">{address.tag}</Text>
                        </View>
                      )}
                    </View>

                    {/* 地址详情 */}
                    <View className="flex items-start gap-2 mb-3">
                      <View className={`px-2 py-1 rounded mt-1 ${getDistrictColor(address.district)}`}>
                        <Text className="text-xs">{address.district}</Text>
                      </View>
                      <Text className="text-zinc-600 text-sm flex-1">
                        {address.province}{address.city}{address.district}{address.detail}
                      </Text>
                    </View>

                    {/* 操作按钮 */}
                    <View className="flex items-center justify-between pt-3 border-t border-zinc-100">
                      <View 
                        className="flex items-center gap-2"
                        onClick={(e) => {
                          e.stopPropagation()
                          if (!address.isDefault) {
                            setDefaultAddress(address.id)
                          }
                        }}
                      >
                        <View className={`w-5 h-5 rounded-full border-2 flex items-center justify-center ${address.isDefault ? 'border-teal-500 bg-teal-500' : 'border-slate-300'}`}>
                          {address.isDefault && <Check size={12} color="#fff" />}
                        </View>
                        <Text className={`text-sm ${address.isDefault ? 'text-teal-500' : 'text-slate-500'}`}>
                          {address.isDefault ? '默认地址' : '设为默认'}
                        </Text>
                      </View>

                      <View className="flex items-center gap-4">
                        <View 
                          className="flex items-center gap-1 text-slate-500"
                          onClick={(e) => {
                            e.stopPropagation()
                            editAddress(address.id)
                          }}
                        >
                          <Pencil size={16} color="#71717a" />
                          <Text className="text-sm">编辑</Text>
                        </View>
                        <View 
                          className="flex items-center gap-1 text-slate-500"
                          onClick={(e) => {
                            e.stopPropagation()
                            deleteAddress(address.id)
                          }}
                        >
                          <Trash2 size={16} color="#71717a" />
                          <Text className="text-sm">删除</Text>
                        </View>
                      </View>
                    </View>
                  </CardContent>
                </Card>
              ))}
            </View>
          )}
        </View>

        {/* 底部留白 */}
        <View className="h-24" />
      </ScrollView>

      {/* 底部新增按钮 */}
      <View style={{ position: 'fixed', bottom: 0, left: 0, right: 0, padding: '16px', backgroundColor: '#fff', borderTop: '1px solid #e5e5e5' }}>
        <Button 
          className="w-full bg-teal-500 text-white font-semibold py-3"
          onClick={addAddress}
        >
          <Plus size={18} color="#fff" />
          新增收货地址
        </Button>
      </View>
    </View>
  )
}

export default AddressPage
