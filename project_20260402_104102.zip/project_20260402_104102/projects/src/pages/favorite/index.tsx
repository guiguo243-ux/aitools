import { useState, useEffect } from 'react'
import { View, Text, Image, ScrollView } from '@tarojs/components'
import Taro from '@tarojs/taro'
import { Heart, Store, Star, MapPin } from 'lucide-react-taro'

import { Network } from '@/network'
import { useUserStore } from '@/stores/user'
import { Button } from '@/components/ui/button'

interface Merchant {
  id: string
  name: string
  description: string
  address: string
  rating: number
  region: string
  cover_image: string
}

export default function FavoritePage() {
  const { userInfo, isLoggedIn } = useUserStore()
  const [favorites, setFavorites] = useState<Merchant[]>([])
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    if (isLoggedIn) {
      loadFavorites()
    } else {
      setLoading(false)
    }
  }, [isLoggedIn])

  const loadFavorites = async () => {
    if (!userInfo?.id) return

    try {
      const res = await Network.request({
        url: `/api/favorite/list?userId=${userInfo?.id}`
      })

      if (res.data.code === 200) {
        setFavorites(res.data.data.merchants || [])
      }
    } catch (error) {
      console.error('Load favorites error:', error)
    } finally {
      setLoading(false)
    }
  }

  const goToMerchant = (merchantId: string) => {
    Taro.navigateTo({ url: `/pages/merchant/detail?id=${merchantId}` })
  }

  const goToLogin = () => {
    Taro.navigateTo({ url: '/pages/login/index' })
  }

  if (!isLoggedIn) {
    return (
      <View className="min-h-screen bg-gray-50 flex flex-col items-center justify-center px-6">
        <Heart size={48} color="#9ca3af" />
        <Text className="text-gray-500 mt-4 mb-4">登录后查看收藏的商家</Text>
        <Button className="bg-teal-500 text-white rounded-full px-8" onClick={goToLogin}>
          去登录
        </Button>
      </View>
    )
  }

  if (loading) {
    return (
      <View className="min-h-screen bg-gray-50 flex items-center justify-center">
        <Text className="text-gray-400">加载中...</Text>
      </View>
    )
  }

  return (
    <View className="min-h-screen bg-gray-50">
      {favorites.length > 0 ? (
        <ScrollView scrollY className="h-screen px-4 py-4">
          <View className="space-y-3">
            {favorites.map((merchant) => (
              <View
                key={merchant.id}
                className="bg-white rounded-xl p-4 flex gap-3"
                onClick={() => goToMerchant(merchant.id)}
              >
                <Image
                  src={merchant.cover_image || ''}
                  className="w-24 h-24 rounded-lg"
                  mode="aspectFill"
                  onError={() => {
                    console.log('Favorite image load failed:', merchant.id)
                  }}
                />
                <View className="flex-1">
                  <View className="flex items-center gap-2 mb-1">
                    <Store size={16} color="#6b7280" />
                    <Text className="text-base font-medium">{merchant.name}</Text>
                  </View>
                  <Text className="block text-sm text-gray-500 mb-2 line-clamp-2">
                    {merchant.description}
                  </Text>
                  <View className="flex items-center gap-3">
                    <View className="flex items-center gap-1">
                      <Star size={14} color="#14B8A6" />
                      <Text className="text-xs text-teal-500">{merchant.rating}</Text>
                    </View>
                    <View className="flex items-center gap-1">
                      <MapPin size={14} color="#9ca3af" />
                      <Text className="text-xs text-gray-400">{merchant.region}</Text>
                    </View>
                  </View>
                </View>
              </View>
            ))}
          </View>
        </ScrollView>
      ) : (
        <View className="flex flex-col items-center justify-center h-full">
          <Heart size={48} color="#9ca3af" />
          <Text className="text-gray-500 mt-4">暂无收藏</Text>
          <Text className="text-sm text-gray-400 mt-2">去发现喜欢的商家吧</Text>
          <Button
            className="mt-4 bg-teal-500 text-white rounded-full px-6"
            onClick={() => Taro.switchTab({ url: '/pages/index/index' })}
          >
            去逛逛
          </Button>
        </View>
      )}
    </View>
  )
}
