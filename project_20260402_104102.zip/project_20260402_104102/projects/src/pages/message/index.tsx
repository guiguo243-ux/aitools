import { View, Text, ScrollView } from '@tarojs/components'
import { useState, useEffect } from 'react'
import Taro from '@tarojs/taro'
import { Card, CardContent } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import { Network } from '@/network'
import { useUserStore } from '@/stores/user'
import { Sparkles, MessageSquare, Bell, ChevronRight, Tag, Receipt, Megaphone } from 'lucide-react-taro'
import './index.css'

// 消息类型
interface Message {
  id: string
  user_id: string
  type: 'system' | 'order' | 'promotion' | 'activity'
  title: string
  content: string
  data?: Record<string, any>
  status: 'unread' | 'read'
  created_at: string
  read_at?: string
}

// 对话类型
interface Conversation {
  id: string
  user_id: string
  title: string
  last_message: string
  last_time: string
  unread: number
}

const MessagePage = () => {
  const [conversations, setConversations] = useState<Conversation[]>([])
  const [messages, setMessages] = useState<Message[]>([])
  const [unreadCount, setUnreadCount] = useState(0)
  const [activeTab, setActiveTab] = useState<'chat' | 'notification'>('chat')
  
  const { isLoggedIn, userInfo } = useUserStore()

  useEffect(() => {
    if (isLoggedIn && userInfo) {
      loadData()
    }
  }, [isLoggedIn, userInfo, activeTab])

  const loadData = async () => {
    if (!userInfo?.id) return

    try {
      if (activeTab === 'chat') {
        // 加载对话历史
        const res = await Network.request<{ code: number; data: Conversation[] }>({
          url: '/api/message/conversations',
          data: { userId: userInfo.id }
        })
        
        if (res.data?.code === 200) {
          setConversations(res.data.data || [])
        }
      } else {
        // 加载系统消息
        const [msgRes, countRes] = await Promise.all([
          Network.request<{ code: number; data: { messages: Message[]; total: number; unreadCount: number } }>({
            url: '/api/message/list',
            data: { userId: userInfo.id, page: 1, pageSize: 20 }
          }),
          Network.request<{ code: number; data: { count: number } }>({
            url: '/api/message/unread-count',
            data: { userId: userInfo.id }
          })
        ])

        if (msgRes.data?.code === 200) {
          setMessages(msgRes.data.data.messages || [])
          setUnreadCount(msgRes.data.data.unreadCount || 0)
        }

        if (countRes.data?.code === 200) {
          setUnreadCount(countRes.data.data.count || 0)
        }
      }
    } catch (error) {
      console.error('Load data error:', error)
      // 使用模拟数据
      if (activeTab === 'chat') {
        setConversations(getMockConversations())
      } else {
        setMessages(getMockMessages())
      }
    }
  }

  const getMockConversations = (): Conversation[] => [
    {
      id: '1',
      user_id: userInfo?.id || '',
      title: '帮我推荐岛内的餐厅',
      last_message: '为您推荐思明区的老厦门沙茶面，评分4.9...',
      last_time: new Date(Date.now() - 3600000).toISOString(),
      unread: 1
    },
    {
      id: '2',
      user_id: userInfo?.id || '',
      title: '岛外有什么好玩的地方',
      last_message: '集美区有集美学村、鳌园等景点...',
      last_time: new Date(Date.now() - 86400000).toISOString(),
      unread: 0
    }
  ]

  const getMockMessages = (): Message[] => [
    {
      id: '1',
      user_id: userInfo?.id || '',
      type: 'promotion',
      title: '优惠券到账',
      content: '恭喜您获得5元新人红包，快去使用吧！',
      status: 'unread',
      created_at: new Date(Date.now() - 3600000).toISOString()
    },
    {
      id: '2',
      user_id: userInfo?.id || '',
      type: 'order',
      title: '订单支付成功',
      content: '您的订单 ORD202401150001 已支付成功，请到店核销。',
      status: 'read',
      created_at: new Date(Date.now() - 86400000).toISOString(),
      read_at: new Date(Date.now() - 43200000).toISOString()
    },
    {
      id: '3',
      user_id: userInfo?.id || '',
      type: 'system',
      title: '系统升级通知',
      content: '系统将于今晚22:00-23:00进行维护升级，届时部分功能可能无法使用。',
      status: 'read',
      created_at: new Date(Date.now() - 172800000).toISOString(),
      read_at: new Date(Date.now() - 129600000).toISOString()
    }
  ]

  const goToAIChat = (sessionId?: string) => {
    Taro.navigateTo({
      url: `/pages/ai-chat/index${sessionId ? `?sessionId=${sessionId}` : ''}`
    })
  }

  const markAllRead = async () => {
    if (!userInfo?.id) return
    
    try {
      await Network.request({
        url: '/api/message/mark-all-read',
        method: 'POST',
        data: { userId: userInfo.id }
      })
      
      setUnreadCount(0)
      setMessages(prev => prev.map(m => ({ ...m, status: 'read' as const })))
      Taro.showToast({ title: '已全部已读', icon: 'success' })
    } catch (error) {
      console.error('Mark all read error:', error)
    }
  }

  const formatTime = (time: string) => {
    const date = new Date(time)
    const now = new Date()
    const diff = now.getTime() - date.getTime()
    
    if (diff < 3600000) {
      return `${Math.floor(diff / 60000)}分钟前`
    } else if (diff < 86400000) {
      return `${Math.floor(diff / 3600000)}小时前`
    } else if (diff < 604800000) {
      return `${Math.floor(diff / 86400000)}天前`
    } else {
      return date.toLocaleDateString()
    }
  }

  const getMessageTypeLabel = (type: string) => {
    const labels: Record<string, string> = {
      system: '系统',
      order: '订单',
      promotion: '活动',
      activity: '通知'
    }
    return labels[type] || '消息'
  }

  const getMessageTypeColor = (type: string) => {
    const colors: Record<string, string> = {
      system: 'bg-slate-100 text-slate-600',
      order: 'bg-teal-50 text-teal-600',
      promotion: 'bg-teal-50 text-teal-600',
      activity: 'bg-emerald-50 text-emerald-600'
    }
    return colors[type] || 'bg-slate-100 text-slate-600'
  }

  const getMessageTypeIcon = (type: string) => {
    const icons: Record<string, React.ReactNode> = {
      system: <Bell size={16} color="#64748b" />,
      order: <Receipt size={16} color="#14B8A6" />,
      promotion: <Tag size={16} color="#f59e0b" />,
      activity: <Megaphone size={16} color="#10b981" />
    }
    return icons[type] || <Bell size={16} color="#64748b" />
  }

  // 未登录状态
  if (!isLoggedIn) {
    return (
      <View className="min-h-screen bg-stone-50 flex flex-col items-center justify-center">
        <View className="w-20 h-20 rounded-full bg-teal-50 flex items-center justify-center mb-4">
          <MessageSquare size={40} color="#14B8A6" />
        </View>
        <Text className="text-slate-400">登录后查看消息</Text>
        <Button 
          className="mt-4 bg-teal-500 text-white rounded-full px-8"
          onClick={() => Taro.navigateTo({ url: '/pages/login/index' })}
        >
          去登录
        </Button>
      </View>
    )
  }

  return (
    <View className="min-h-screen bg-stone-50">
      {/* Tab 切换 */}
      <View className="bg-white px-4 py-3 flex items-center justify-between sticky top-0 z-10 shadow-sm">
        <View className="flex gap-6">
          <View 
            className={`pb-2 ${activeTab === 'chat' ? 'border-b-2 border-teal-500' : ''}`}
            onClick={() => setActiveTab('chat')}
          >
            <Text className={activeTab === 'chat' ? 'text-teal-500 font-semibold' : 'text-slate-500'}>
              AI对话
            </Text>
          </View>
          <View 
            className={`pb-2 flex items-center gap-1 ${activeTab === 'notification' ? 'border-b-2 border-teal-500' : ''}`}
            onClick={() => setActiveTab('notification')}
          >
            <Text className={activeTab === 'notification' ? 'text-teal-500 font-semibold' : 'text-slate-500'}>
              通知
            </Text>
            {unreadCount > 0 && (
              <Badge className="bg-teal-500 text-white text-xs px-2">{unreadCount}</Badge>
            )}
          </View>
        </View>
        {activeTab === 'notification' && unreadCount > 0 && (
          <View onClick={markAllRead}>
            <Text className="text-xs text-teal-500">全部已读</Text>
          </View>
        )}
      </View>

      <ScrollView scrollY className="h-[calc(100vh-100px)]">
        {/* AI对话列表 */}
        {activeTab === 'chat' && (
          <View>
            {/* AI对话入口 */}
            <View className="p-4">
              <Card 
                className="bg-gradient-to-r from-teal-500 to-teal-600 border-0 shadow-xl shadow-teal-200 overflow-hidden"
                onClick={() => goToAIChat()}
              >
                <CardContent className="p-4 flex items-center gap-3">
                  <View className="w-12 h-12 rounded-2xl flex items-center justify-center" style={{ backgroundColor: 'rgba(255,255,255,0.2)' }}>
                    <Sparkles size={28} color="#fff" />
                  </View>
                  <View className="flex-1">
                    <Text className="text-white text-lg font-bold block">AI导购助手</Text>
                    <Text className="text-white text-xs" style={{ opacity: 0.9 }}>点击开始智能对话</Text>
                  </View>
                  <ChevronRight size={20} color="#fff" />
                </CardContent>
              </Card>
            </View>

            {/* 对话历史 */}
            <View className="px-4">
              <View className="flex items-center gap-2 mb-3">
                <View className="w-1 h-5 bg-gradient-to-b from-teal-500 to-teal-600 rounded-full" />
                <Text className="text-base font-bold text-slate-800">对话历史</Text>
              </View>

              {conversations.length === 0 ? (
                <View className="flex flex-col items-center justify-center py-8 bg-white rounded-2xl shadow-sm">
                  <MessageSquare size={48} color="#cbd5e1" />
                  <Text className="text-slate-400 text-sm mt-3">暂无对话记录</Text>
                </View>
              ) : (
                <View className="flex flex-col gap-3">
                  {conversations.map((conv) => (
                    <Card 
                      key={conv.id} 
                      className="overflow-hidden shadow-lg shadow-slate-200 rounded-2xl"
                      onClick={() => goToAIChat(conv.id)}
                    >
                      <CardContent className="p-3 flex items-center gap-3">
                        <View className="w-10 h-10 bg-teal-50 rounded-full flex items-center justify-center">
                          <Sparkles size={20} color="#14B8A6" />
                        </View>
                        <View className="flex-1 min-w-0">
                          <View className="flex items-center justify-between mb-1">
                            <Text className="text-sm font-semibold text-slate-800 truncate">{conv.title}</Text>
                            <Text className="text-xs text-slate-400">{formatTime(conv.last_time)}</Text>
                          </View>
                          <Text className="text-xs text-slate-500 truncate">{conv.last_message}</Text>
                        </View>
                        {conv.unread > 0 && (
                          <Badge className="bg-teal-500 text-white text-xs px-2">{conv.unread}</Badge>
                        )}
                      </CardContent>
                    </Card>
                  ))}
                </View>
              )}
            </View>
          </View>
        )}

        {/* 系统通知列表 */}
        {activeTab === 'notification' && (
          <View className="px-4 py-4">
            {messages.length === 0 ? (
              <View className="flex flex-col items-center justify-center py-8 bg-white rounded-2xl shadow-sm">
                <Bell size={48} color="#cbd5e1" />
                <Text className="text-slate-400 text-sm mt-3">暂无通知</Text>
              </View>
            ) : (
              <View className="flex flex-col gap-3">
                {messages.map((msg) => (
                  <Card 
                    key={msg.id} 
                    className={`overflow-hidden shadow-lg shadow-slate-200 rounded-2xl ${msg.status === 'unread' ? 'bg-teal-50' : 'bg-white'}`}
                  >
                    <CardContent className="p-4">
                      <View className="flex items-center justify-between mb-2">
                        <View className="flex items-center gap-2">
                          <View className={`px-2 py-1 rounded-full ${getMessageTypeColor(msg.type)} flex items-center gap-1`}>
                            {getMessageTypeIcon(msg.type)}
                            <Text className="text-xs font-medium">{getMessageTypeLabel(msg.type)}</Text>
                          </View>
                          {msg.status === 'unread' && (
                            <View className="w-2 h-2 rounded-full bg-teal-500" />
                          )}
                        </View>
                        <Text className="text-xs text-slate-400">{formatTime(msg.created_at)}</Text>
                      </View>
                      <Text className="text-sm font-semibold text-slate-800 block mb-1">{msg.title}</Text>
                      <Text className="text-xs text-slate-500">{msg.content}</Text>
                    </CardContent>
                  </Card>
                ))}
              </View>
            )}
          </View>
        )}

        {/* 底部留白 */}
        <View className="h-20" />
      </ScrollView>
    </View>
  )
}

export default MessagePage
