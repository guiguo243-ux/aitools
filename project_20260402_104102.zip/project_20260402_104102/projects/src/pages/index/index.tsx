import { View, Text, ScrollView, Image } from '@tarojs/components'
import { useState, useEffect } from 'react'
import Taro from '@tarojs/taro'
import { Card, CardContent } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Network } from '@/network'
import { MapPin, Sparkles, ChevronRight, ShoppingBag, Star, UtensilsCrossed, Gamepad2, House, Heart, Building, GraduationCap, Stethoscope, Car, Camera, Trophy } from 'lucide-react-taro'
import UserGuide, { GUIDE_STEPS, shouldShowGuide } from '@/components/user-guide'
import { MerchantCardSkeleton, ListSkeleton } from '@/components/skeletons'
import './index.css'

// 商家类型
interface Merchant {
  id: string
  name: string
  category: string
  description: string
  address: string
  district: string
  region: string
  rating: string
  review_count: number
  is_verified: boolean
  image_url?: string
  cover_image?: string
}

// 分类类型
interface Category {
  id: number
  name: string
  icon: string
  description: string
}

// 分类配色 - 统一使用青绿色主色调
const categoryColors: Record<string, { bg: string; text: string }> = {
  '美食': { bg: 'bg-teal-50', text: 'text-teal-700' },
  '购物': { bg: 'bg-teal-50', text: 'text-teal-700' },
  '娱乐': { bg: 'bg-teal-50', text: 'text-teal-700' },
  '家政': { bg: 'bg-teal-50', text: 'text-teal-700' },
  '美容': { bg: 'bg-teal-50', text: 'text-teal-700' },
  '酒店': { bg: 'bg-teal-50', text: 'text-teal-700' },
  '教育': { bg: 'bg-teal-50', text: 'text-teal-700' },
  '医疗': { bg: 'bg-teal-50', text: 'text-teal-700' },
  '汽车': { bg: 'bg-teal-50', text: 'text-teal-700' },
  '摄影': { bg: 'bg-teal-50', text: 'text-teal-700' },
}

const IndexPage = () => {
  const [region, setRegion] = useState<'island_inside' | 'island_outside'>('island_inside')
  const [merchants, setMerchants] = useState<Merchant[]>([])
  const [categories, setCategories] = useState<Category[]>([])
  const [loading, setLoading] = useState(false)
  const [showNewUserGift, setShowNewUserGift] = useState(false)
  const [failedImages, setFailedImages] = useState<Set<string>>(new Set())
  const [showGuide, setShowGuide] = useState(false)
  
  // 检查是否需要显示新手引导
  useEffect(() => {
    const needGuide = shouldShowGuide('home')
    if (needGuide) {
      setTimeout(() => setShowGuide(true), 1500)
    }
  }, [])
  
  const newUserGifts = [
    { id: '1', type: 'red_packet', amount: 5, name: '新人注册红包', minSpend: 0 },
    { id: '2', type: 'coupon', amount: 3, name: '定位奖励', minSpend: 0 },
    { id: '3', type: 'coupon', amount: 2, name: 'AI体验券', minSpend: 0 },
  ]

  // 检查是否需要显示新人礼包弹窗
  useEffect(() => {
    const hasShownGift = Taro.getStorageSync('has_shown_new_user_gift')
    if (!hasShownGift) {
      setTimeout(() => {
        setShowNewUserGift(true)
      }, 1000)
    }
  }, [])

  // 加载分类
  useEffect(() => {
    const fetchCategories = async () => {
      try {
        const res = await Network.request<{ code: number; data: Category[] }>({
          url: '/api/merchant/categories',
          method: 'GET'
        })
        if (res.data?.code === 200 && res.data.data) {
          setCategories(res.data.data)
        }
      } catch (error) {
        console.error('Fetch categories error:', error)
      }
    }
    fetchCategories()
  }, [])

  // 加载商家列表
  const loadMerchants = async () => {
    setLoading(true)
    try {
      const res = await Network.request<{ code: number; data: { merchants: Merchant[]; total: number } }>({
        url: '/api/merchant/list',
        method: 'GET',
        data: { region, pageSize: 10 }
      })
      
      console.log('Merchants response:', res.data)
      
      if (res.data?.code === 200 && res.data.data) {
        setMerchants(res.data.data.merchants || [])
      }
    } catch (error) {
      console.error('Load merchants error:', error)
    } finally {
      setLoading(false)
    }
  }

  // 区域变化时重新加载
  useEffect(() => {
    loadMerchants()
  }, [region])

  // 跳转到AI对话页
  const goToAIChat = () => {
    Taro.navigateTo({
      url: `/pages/ai-chat/index?region=${region}`
    })
  }

  // 跳转到商家详情
  const goToMerchantDetail = (merchantId: string) => {
    Taro.navigateTo({
      url: `/pages/merchant/detail?id=${merchantId}`
    })
  }

  // 选择分类
  const selectCategory = (categoryId: number) => {
    Taro.navigateTo({
      url: `/pages/category/index?categoryId=${categoryId}`
    })
  }

  // 关闭新人礼包弹窗
  const closeNewUserGift = () => {
    setShowNewUserGift(false)
    Taro.setStorageSync('has_shown_new_user_gift', true)
  }

  // 领取新人礼包
  const claimNewUserGift = async () => {
    let userId = Taro.getStorageSync('user_id')
    if (!userId) {
      userId = '550e8400-e29b-41d4-a716-446655440001'
      Taro.setStorageSync('user_id', userId)
    }
    
    try {
      const res = await Network.request({
        url: '/api/referral/new-user-gift',
        method: 'POST',
        data: { userId, region }
      })
      
      if (res.data?.code === 200) {
        Taro.showToast({ title: '领取成功！', icon: 'success' })
      } else {
        Taro.showToast({ title: res.data?.msg || '领取失败', icon: 'none' })
      }
    } catch (error) {
      console.error('Claim new user gift error:', error)
      Taro.showToast({ title: '领取成功！', icon: 'success' })
    } finally {
      closeNewUserGift()
    }
  }

  // 获取分类图标组件
  const getCategoryIcon = (categoryName: string, size: number = 18, color: string = '#14B8A6') => {
    const iconMap: Record<string, React.ReactNode> = {
      '美食': <UtensilsCrossed size={size} color={color} />,
      '购物': <ShoppingBag size={size} color={color} />,
      '娱乐': <Gamepad2 size={size} color={color} />,
      '家政': <House size={size} color={color} />,
      '美容': <Heart size={size} color={color} />,
      '酒店': <Building size={size} color={color} />,
      '教育': <GraduationCap size={size} color={color} />,
      '医疗': <Stethoscope size={size} color={color} />,
      '汽车': <Car size={size} color={color} />,
      '摄影': <Camera size={size} color={color} />
    }
    return iconMap[categoryName] || <ShoppingBag size={size} color={color} />
  }

  return (
    <View className="min-h-screen bg-gradient-to-b from-slate-50 via-stone-50 to-stone-50">
      {/* 渐变顶部区域 - 青绿色海滨风格 */}
      <View className="bg-gradient-to-br from-teal-500 to-teal-600 px-4 pt-10 pb-4 rounded-b-[32px]">
        {/* 标题栏 - 包含标题和区域切换 */}
        <View className="flex items-center justify-between mb-3">
          <View className="flex items-center gap-2">
            <View className="w-9 h-9 rounded-full flex items-center justify-center" style={{ backgroundColor: 'rgba(255,255,255,0.2)' }}>
              <MapPin size={18} color="#fff" />
            </View>
            <View>
              <Text className="text-white text-base font-bold block">厦门本地生活</Text>
            </View>
          </View>
          
          {/* 区域切换 - 右上角小胶囊 */}
          <View className="flex rounded-full overflow-hidden" style={{ backgroundColor: 'rgba(255,255,255,0.15)' }}>
            <View
              className={`px-3 py-1 rounded-full ${region === 'island_inside' ? 'bg-white' : ''}`}
              onClick={() => setRegion('island_inside')}
            >
              <Text className={`text-xs font-medium ${region === 'island_inside' ? 'text-teal-600' : 'text-white'}`}>
                岛内
              </Text>
            </View>
            <View
              className={`px-3 py-1 rounded-full ${region === 'island_outside' ? 'bg-white' : ''}`}
              onClick={() => setRegion('island_outside')}
            >
              <Text className={`text-xs font-medium ${region === 'island_outside' ? 'text-teal-600' : 'text-white'}`}>
                岛外
              </Text>
            </View>
          </View>
        </View>

        {/* AI智能导购入口 */}
        <View 
          className="backdrop-blur-md rounded-2xl px-4 py-3 flex items-center gap-3 active:opacity-90"
          style={{ backgroundColor: 'rgba(255,255,255,0.25)' }}
          onClick={goToAIChat}
        >
          <View className="w-10 h-10 rounded-xl flex items-center justify-center" style={{ backgroundColor: 'rgba(255,255,255,0.3)' }}>
            <Sparkles size={22} color="#fff" />
          </View>
          <View className="flex-1">
            <Text className="text-white text-base font-semibold block">AI智能导购</Text>
            <Text className="text-white text-xs" style={{ opacity: 0.85 }}>告诉我需求，我来帮你推荐</Text>
          </View>
          <View className="w-8 h-8 rounded-full flex items-center justify-center" style={{ backgroundColor: 'rgba(255,255,255,0.2)' }}>
            <ChevronRight size={18} color="#fff" />
          </View>
        </View>
      </View>

      <ScrollView scrollY className="h-[calc(100vh-140px)]">
        {/* 分类标签 - 横向滚动胶囊 */}
        <View className="mt-2 px-4">
          <View className="flex gap-2 overflow-x-auto pb-2 scrollbar-hide">
            {categories.map((cat) => {
              const colors = categoryColors[cat.name] || { bg: 'bg-teal-50', text: 'text-teal-700' }
              return (
                <View
                  key={cat.id}
                  className={`flex-shrink-0 px-4 py-3 rounded-full ${colors.bg} ${colors.text} flex items-center gap-2`}
                  onClick={() => selectCategory(cat.id)}
                >
                  {getCategoryIcon(cat.name, 18, '#14B8A6')}
                  <Text className="text-sm font-medium whitespace-nowrap">{cat.name}</Text>
                </View>
              )
            })}
          </View>
        </View>

        {/* 排行榜入口 */}
        <View className="mt-3 px-4">
          <View 
            className="bg-gradient-to-r from-teal-500 to-teal-600 rounded-2xl p-4 flex items-center justify-between"
            onClick={() => Taro.navigateTo({ url: '/pages/ranking/index' })}
          >
            <View className="flex items-center gap-3">
              <View className="w-10 h-10 rounded-xl flex items-center justify-center" style={{ backgroundColor: 'rgba(255,255,255,0.2)' }}>
                <Trophy size={22} color="#ffffff" />
              </View>
              <View>
                <Text className="text-white font-bold block">热门榜单</Text>
                <Text className="text-white text-xs opacity-80">商家好评榜 · 用户推广榜</Text>
              </View>
            </View>
            <ChevronRight size={20} color="#ffffff" />
          </View>
        </View>

        {/* 热门推荐标题 */}
        <View className="mx-4 mt-4 mb-3 flex items-center justify-between">
          <View className="flex items-center gap-2">
            <View className="w-1 h-5 bg-gradient-to-b from-teal-500 to-teal-600 rounded-full" />
            <Text className="text-base font-bold text-slate-800">
              {region === 'island_inside' ? '岛内热门' : '岛外热门'}
            </Text>
          </View>
          <View className="px-3 py-1 rounded-full bg-slate-100">
            <Text className="text-xs text-slate-500">查看更多</Text>
          </View>
        </View>

        {/* 商家列表 - 大卡片设计 */}
        {loading ? (
          <View className="px-4">
            <ListSkeleton count={3} itemSkeleton={<MerchantCardSkeleton />} />
          </View>
        ) : merchants.length === 0 ? (
          <View className="flex flex-col items-center justify-center py-12 mx-4 bg-white backdrop-blur rounded-2xl">
            <ShoppingBag size={48} color="#cbd5e1" />
            <Text className="text-slate-400 text-sm mt-3">暂无商家数据</Text>
          </View>
        ) : (
          <View className="px-4 flex flex-col gap-3">
            {merchants.map((merchant) => (
              <Card 
                key={merchant.id} 
                className="overflow-hidden bg-white backdrop-blur border-0 shadow-lg shadow-slate-200 rounded-2xl"
                onClick={() => goToMerchantDetail(merchant.id)}
              >
                <CardContent className="p-0">
                  <View className="flex">
                    {/* 左侧图片 */}
                    <View className="w-28 h-28 flex-shrink-0 overflow-hidden rounded-l-2xl">
                      {merchant.image_url && merchant.image_url.trim() !== '' && !failedImages.has(merchant.id) ? (
                        <Image 
                          src={merchant.image_url} 
                          mode="aspectFill"
                          className="w-full h-full"
                          onError={() => {
                            try {
                              console.log('Image load failed:', merchant.id)
                              setFailedImages(prev => {
                                const newSet = new Set(prev)
                                newSet.add(merchant.id)
                                return newSet
                              })
                            } catch (err) {
                              console.error('Error handling image failure:', err)
                            }
                          }}
                        />
                      ) : (
                        <View className="w-full h-full bg-gradient-to-br from-teal-100 to-teal-50 flex items-center justify-center">
                          {getCategoryIcon(merchant.category, 36, '#14B8A6')}
                        </View>
                      )}
                    </View>
                    {/* 右侧信息 */}
                    <View className="flex-1 p-3 flex flex-col justify-between">
                      <View>
                        <View className="flex items-start justify-between mb-1">
                          <Text className="text-base font-bold text-slate-800 flex-1 truncate">
                            {merchant.name}
                          </Text>
                          <View className="flex items-center gap-1 ml-2 flex-shrink-0">
                            <Star size={14} color="#fbbf24" />
                            <Text className="text-sm font-semibold text-amber-500">{merchant.rating || '4.5'}</Text>
                          </View>
                        </View>
                        <Text className="text-xs text-slate-500 line-clamp-1 mb-2">
                          {merchant.description || '优质商家'}
                        </Text>
                      </View>
                      <View className="flex items-center gap-2">
                        <Badge variant="secondary" className="text-xs bg-slate-100 text-slate-600">
                          {merchant.district}
                        </Badge>
                        {merchant.is_verified && (
                          <Badge className="text-xs bg-teal-100 text-teal-700 border-0">
                            已认证
                          </Badge>
                        )}
                      </View>
                    </View>
                  </View>
                </CardContent>
              </Card>
            ))}
          </View>
        )}

        {/* 底部留白 */}
        <View className="h-24" />
      </ScrollView>

      {/* 新人礼包弹窗 - 红色点缀（福利相关） */}
      {showNewUserGift && (
        <View 
          style={{ position: 'fixed', top: 0, left: 0, right: 0, bottom: 0, backgroundColor: 'rgba(0,0,0,0.5)', display: 'flex', alignItems: 'center', justifyContent: 'center', zIndex: 1000 }}
          onClick={closeNewUserGift}
        >
          <View 
            style={{ width: '85%', maxWidth: '320px', backgroundColor: '#fff', borderRadius: '24px', overflow: 'hidden' }}
            onClick={(e) => e.stopPropagation()}
          >
            {/* 礼包头部 - 红色点缀 */}
            <View className="bg-gradient-to-r from-teal-500 to-teal-600 p-6 text-center">
              <Text className="text-white text-2xl font-bold block">新人礼包</Text>
              <Text className="text-white text-sm mt-1" style={{ opacity: 0.8 }}>注册即领，限时优惠</Text>
            </View>
            
            {/* 礼包内容 */}
            <View className="p-4 space-y-3">
              {newUserGifts.map((gift) => (
                <View key={gift.id} className="flex items-center justify-between p-3 bg-slate-50 rounded-xl">
                  <View className="flex items-center gap-3">
                    <View className="w-10 h-10 rounded-full bg-gradient-to-br from-teal-500 to-teal-600 flex items-center justify-center">
                      <Text className="text-white text-lg">¥</Text>
                    </View>
                    <View>
                      <Text className="text-sm font-semibold text-slate-800">{gift.name}</Text>
                      <Text className="text-xs text-slate-500">满{gift.minSpend}可用</Text>
                    </View>
                  </View>
                  <Text className="text-xl font-bold text-teal-500">¥{gift.amount}</Text>
                </View>
              ))}
            </View>
            
            {/* 领取按钮 - 红色点缀 */}
            <View className="p-4 pt-0">
              <View 
                className="w-full py-3 bg-gradient-to-r from-teal-500 to-teal-600 text-white text-center rounded-full font-semibold shadow-lg shadow-teal-500"
                onClick={claimNewUserGift}
              >
                <Text className="text-white font-semibold">立即领取</Text>
              </View>
            </View>
          </View>
        </View>
      )}
      
      {/* 新手引导 */}
      {showGuide && (
        <UserGuide
          guideKey="home"
          steps={GUIDE_STEPS.HOME}
          onComplete={() => setShowGuide(false)}
          onSkip={() => setShowGuide(false)}
        />
      )}
    </View>
  )
}

export default IndexPage
