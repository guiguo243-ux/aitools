import { useState, useEffect } from 'react';
import Taro from '@tarojs/taro';
import { View, Text, Image, ScrollView } from '@tarojs/components';
import { Network } from '@/network';
import { Users, Clock } from 'lucide-react-taro';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import './index.css';

interface GroupBuyActivity {
  id: string;
  title: string;
  product_id: string;
  product_name: string;
  product_image: string | null;
  original_price: number;
  group_price: number;
  min_people: number;
  stock: number;
  sold_count: number;
  start_time: string;
  end_time: string;
  status: string;
  description: string | null;
  activeGroups?: ActiveGroupItem[];
  discount?: number;
  progress?: number;
}

interface ActiveGroupItem {
  id: string;
  leader_name: string;
  leader_avatar: string | null;
  current_people: number;
  target_people: number;
  expire_time: string;
}

export default function GroupBuyPage() {
  const [activities, setActivities] = useState<GroupBuyActivity[]>([]);
  const [loading, setLoading] = useState(true);
  const [activeTab, setActiveTab] = useState<'all' | 'my'>('all');

  useEffect(() => {
    loadActivities();
  }, []);

  const loadActivities = async () => {
    setLoading(true);
    try {
      const res = await Network.request({ url: '/api/group-buy/activities' });
      if (res.data?.data?.list) {
        setActivities(res.data.data.list);
      }
    } catch (error) {
      console.error('加载拼团活动失败:', error);
    } finally {
      setLoading(false);
    }
  };

  const formatPrice = (price: number) => {
    return price.toFixed(2);
  };

  const getDiscount = (original: number, group: number) => {
    if (original <= 0) return 1;
    return Math.round((group / original) * 10) / 10;
  };

  const goToActivityDetail = (id: string) => {
    Taro.navigateTo({ url: `/pages/group-buy/detail?id=${id}` });
  };

  const handleJoinGroup = (groupId: string, activityId: string) => {
    Taro.navigateTo({ url: `/pages/group-buy/join?groupId=${groupId}&activityId=${activityId}` });
  };

  if (loading) {
    return (
      <View className="gb-page loading-page">
        <Text className="loading-text">加载中...</Text>
      </View>
    );
  }

  return (
    <View className="gb-page">
      {/* Tab切换 */}
      <View className="tab-container">
        <View
          className={`tab-item ${activeTab === 'all' ? 'active' : ''}`}
          onClick={() => setActiveTab('all')}
        >
          <Text className="tab-text">全部活动</Text>
        </View>
        <View
          className={`tab-item ${activeTab === 'my' ? 'active' : ''}`}
          onClick={() => setActiveTab('my')}
        >
          <Text className="tab-text">我的拼团</Text>
        </View>
      </View>

      <ScrollView scrollY className="content-scroll">
        {activeTab === 'all' && (
          <View className="activities-list">
            {activities.length === 0 ? (
              <View className="empty-state">
                <Text className="empty-text">暂无拼团活动</Text>
              </View>
            ) : (
              activities.map((activity) => (
                <Card key={activity.id} className="activity-card">
                  <CardContent className="activity-content">
                    {/* 商品图片和信息 */}
                    <View className="product-section">
                      {activity.product_image ? (
                        <Image
                          src={activity.product_image}
                          className="product-image"
                          mode="aspectFill"
                        />
                      ) : (
                        <View className="product-image-placeholder">
                          <Text className="placeholder-text">暂无图片</Text>
                        </View>
                      )}
                      <View className="product-info">
                        <Text className="product-title">{activity.title}</Text>
                        <Text className="product-desc">{activity.product_name}</Text>
                        <View className="price-row">
                          <Text className="gb-price">¥{formatPrice(activity.group_price)}</Text>
                          <Text className="original-price">¥{formatPrice(activity.original_price)}</Text>
                          <Badge className="discount-badge">
                            {getDiscount(activity.original_price, activity.group_price)}折
                          </Badge>
                        </View>
                        <View className="meta-row">
                          <View className="meta-item">
                            <Users size={14} color="#f97316" />
                            <Text className="meta-text">{activity.min_people}人团</Text>
                          </View>
                          <View className="meta-item">
                            <Clock size={14} color="#f97316" />
                            <Text className="meta-text">库存{activity.stock - activity.sold_count}</Text>
                          </View>
                        </View>
                      </View>
                    </View>

                    {/* 进行中的团 */}
                    {activity.activeGroups && activity.activeGroups.length > 0 && (
                      <View className="active-groups">
                        <Text className="groups-title">进行中的团</Text>
                        {activity.activeGroups.slice(0, 3).map((groupItem) => (
                          <View key={groupItem.id} className="gb-item">
                            <View className="gb-leader">
                              {groupItem.leader_avatar ? (
                                <Image src={groupItem.leader_avatar} className="leader-avatar" />
                              ) : (
                                <View className="leader-avatar-placeholder">
                                  <Text className="avatar-text">
                                    {groupItem.leader_name?.charAt(0) || '团'}
                                  </Text>
                                </View>
                              )}
                              <Text className="leader-name">{groupItem.leader_name}</Text>
                            </View>
                            <View className="gb-status">
                              <Text className="status-text">
                                差{groupItem.target_people - groupItem.current_people}人成团
                              </Text>
                              <Button
                                size="sm"
                                className="join-btn"
                                onClick={() => handleJoinGroup(groupItem.id, activity.id)}
                              >
                                去拼团
                              </Button>
                            </View>
                          </View>
                        ))}
                      </View>
                    )}

                    {/* 操作按钮 */}
                    <View className="action-row">
                      <Button
                        className="detail-btn"
                        variant="outline"
                        onClick={() => goToActivityDetail(activity.id)}
                      >
                        查看详情
                      </Button>
                      <Button
                        className="start-btn"
                        onClick={() => goToActivityDetail(activity.id)}
                      >
                        我要开团
                      </Button>
                    </View>
                  </CardContent>
                </Card>
              ))
            )}
          </View>
        )}

        {activeTab === 'my' && (
          <View className="empty-state">
            <Text className="empty-text">暂无拼团记录</Text>
            <Text className="empty-hint">参与拼团享受更多优惠</Text>
          </View>
        )}
      </ScrollView>
    </View>
  );
}
