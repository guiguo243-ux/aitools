export default typeof definePageConfig === 'function'
  ? definePageConfig({ navigationBarTitleText: '拼团活动' })
  : { navigationBarTitleText: '拼团活动' }
