import { View, Text, ScrollView, Image } from '@tarojs/components'
import { useState, useEffect } from 'react'
import Taro from '@tarojs/taro'
import { Network } from '@/network'
import { useUserStore } from '@/stores/user'
import { Card, CardContent } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { Gift, Package, Coins, History } from 'lucide-react-taro'
import './index.css'

interface Product {
  id: string
  name: string
  description: string
  image_url: string
  points_price: number
  original_price: number
  stock: number
  exchange_count: number
  category: string
}

interface Category {
  key: string
  name: string
}

interface PointsOverview {
  points: number
  level: number
  totalEarned: number
  totalSpent: number
  exchangeCount: number
}

const PointsShopPage = () => {
  const { userInfo, isLoggedIn } = useUserStore()
  const userId = userInfo?.id || Taro.getStorageSync('user_id') || ''
  const userRegion = userInfo?.region || 'island_inside'

  const [products, setProducts] = useState<Product[]>([])
  const [categories, setCategories] = useState<Category[]>([])
  const [activeCategory, setActiveCategory] = useState<string>('all')
  const [overview, setOverview] = useState<PointsOverview | null>(null)
  const [loading, setLoading] = useState(false)

  useEffect(() => {
    fetchProducts()
    fetchCategories()
    if (userId) {
      fetchOverview()
    }
  }, [activeCategory, userId])

  const fetchProducts = async () => {
    setLoading(true)
    try {
      const params: any = {}
      if (activeCategory && activeCategory !== 'all') {
        params.category = activeCategory
      }
      if (userRegion) {
        params.region = userRegion
      }

      const res = await Network.request({
        url: '/api/points-shop/products',
        method: 'GET',
        data: params,
      })

      if (res.data?.code === 200) {
        setProducts(res.data.data || [])
      }
    } catch (error) {
      console.error('Fetch products error:', error)
    } finally {
      setLoading(false)
    }
  }

  const fetchCategories = async () => {
    try {
      const res = await Network.request({
        url: '/api/points-shop/categories',
        method: 'GET',
      })

      if (res.data?.code === 200) {
        setCategories([{ key: 'all', name: '全部' }, ...(res.data.data || [])])
      }
    } catch (error) {
      console.error('Fetch categories error:', error)
    }
  }

  const fetchOverview = async () => {
    try {
      const res = await Network.request({
        url: '/api/points-shop/user-overview',
        method: 'GET',
        data: { userId },
      })

      if (res.data?.code === 200) {
        setOverview(res.data.data)
      }
    } catch (error) {
      console.error('Fetch overview error:', error)
    }
  }

  const handleExchange = (product: Product) => {
    if (!isLoggedIn || !userId) {
      Taro.navigateTo({ url: '/pages/login/index' })
      return
    }

    // 判断是否需要收货地址
    if (product.category === 'physical') {
      Taro.showModal({
        title: '兑换确认',
        content: `需要 ${product.points_price} 积分兑换「${product.name}」，兑换后需填写收货地址`,
        confirmText: '去兑换',
        success: (res) => {
          if (res.confirm) {
            Taro.navigateTo({
              url: `/pages/points-exchange/index?productId=${product.id}&name=${encodeURIComponent(product.name)}&points=${product.points_price}`,
            })
          }
        },
      })
    } else {
      Taro.showModal({
        title: '兑换确认',
        content: `确定花费 ${product.points_price} 积分兑换「${product.name}」？`,
        confirmText: '确认兑换',
        success: (res) => {
          if (res.confirm) {
            doExchange(product.id)
          }
        },
      })
    }
  }

  const doExchange = async (productId: string, address?: any) => {
    Taro.showLoading({ title: '兑换中...' })
    try {
      const res = await Network.request({
        url: '/api/points-shop/exchange',
        method: 'POST',
        data: {
          userId,
          productId,
          receiverName: address?.name,
          receiverPhone: address?.phone,
          receiverAddress: address?.address,
        },
      })

      Taro.hideLoading()

      if (res.data?.code === 200) {
        Taro.showToast({ title: '兑换成功', icon: 'success' })
        fetchProducts()
        fetchOverview()
      } else {
        Taro.showToast({ title: res.data?.msg || '兑换失败', icon: 'none' })
      }
    } catch (error) {
      Taro.hideLoading()
      Taro.showToast({ title: '兑换失败', icon: 'none' })
    }
  }

  const goToRecords = () => {
    Taro.navigateTo({ url: '/pages/points-records/index' })
  }

  return (
    <View className="points-shop-page">
      {/* 顶部积分概览 */}
      <View className="points-overview">
        <View className="points-header">
          <View className="points-main">
            <Coins size={20} color="#facc15" />
            <Text className="points-value">{overview?.points || 0}</Text>
            <Text className="points-label">可用积分</Text>
          </View>
          <Button
            variant="outline"
            size="sm"
            className="records-btn"
            onClick={goToRecords}
          >
            <History size={16} color="#fff" />
            积分明细
          </Button>
        </View>
        <View className="points-stats">
          <View className="stat-item">
            <Text className="stat-value">{overview?.totalEarned || 0}</Text>
            <Text className="stat-label">累计获得</Text>
          </View>
          <View className="stat-item">
            <Text className="stat-value">{overview?.totalSpent || 0}</Text>
            <Text className="stat-label">已使用</Text>
          </View>
          <View className="stat-item">
            <Text className="stat-value">{overview?.exchangeCount || 0}</Text>
            <Text className="stat-label">兑换次数</Text>
          </View>
        </View>
      </View>

      {/* 分类切换 */}
      <ScrollView scrollX className="category-scroll">
        <View className="category-tabs">
          {categories.map((cat) => (
            <View
              key={cat.key}
              className={`category-tab ${activeCategory === cat.key ? 'active' : ''}`}
              onClick={() => setActiveCategory(cat.key)}
            >
              <Text>{cat.name}</Text>
            </View>
          ))}
        </View>
      </ScrollView>

      {/* 商品列表 */}
      <ScrollView scrollY className="product-list">
        {loading ? (
          <View className="loading-state">
            <Text>加载中...</Text>
          </View>
        ) : products.length === 0 ? (
          <View className="empty-state">
            <Package size={48} color="#d1d5db" />
            <Text>暂无商品</Text>
          </View>
        ) : (
          <View className="products-grid">
            {products.map((product) => (
              <Card key={product.id} className="product-card">
                <View className="product-image-wrapper">
                  {product.image_url ? (
                    <Image
                      src={product.image_url}
                      className="product-image"
                      mode="aspectFill"
                    />
                  ) : (
                    <View className="product-image-placeholder">
                      <Gift size={32} color="#d1d5db" />
                    </View>
                  )}
                  {product.stock <= 10 && product.stock > 0 && (
                    <Badge className="stock-badge">仅剩{product.stock}件</Badge>
                  )}
                </View>
                <CardContent className="product-content">
                  <Text className="product-name">{product.name}</Text>
                  <Text className="product-desc">{product.description}</Text>
                  <View className="product-footer">
                    <View className="price-info">
                      <Text className="points-price">{product.points_price}</Text>
                      <Text className="points-unit">积分</Text>
                      {product.original_price && (
                        <Text className="original-price">¥{product.original_price}</Text>
                      )}
                    </View>
                    <Button
                      size="sm"
                      className="exchange-btn"
                      disabled={product.stock <= 0 || (overview !== null && overview.points < product.points_price) ? true : false}
                      onClick={() => handleExchange(product)}
                    >
                      {product.stock <= 0 ? '已兑完' : '兑换'}
                    </Button>
                  </View>
                </CardContent>
              </Card>
            ))}
          </View>
        )}
      </ScrollView>
    </View>
  )
}

export default PointsShopPage
