export default typeof definePageConfig === 'function'
  ? definePageConfig({ navigationBarTitleText: '我的红包' })
  : { navigationBarTitleText: '我的红包' }
