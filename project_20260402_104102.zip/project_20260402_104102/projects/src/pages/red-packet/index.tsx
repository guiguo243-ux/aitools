import { View, Text, ScrollView } from '@tarojs/components'
import { useState, useEffect } from 'react'
import Taro from '@tarojs/taro'
import { Card, CardContent } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Network } from '@/network'
import { useUserStore } from '@/stores/user'
import { MapPin, Clock, Gift } from 'lucide-react-taro'

// 红包类型
interface RedPacket {
  id: string
  type: 'red_packet' | 'coupon' | 'cashback'
  amount: number
  minSpend: number
  source: string
  region: string | null
  status: 'unused' | 'used' | 'expired'
  expireAt: string
  createdAt: string
}

const sourceLabels: Record<string, string> = {
  register: '新人注册礼',
  first_location: '首次定位奖励',
  first_ai_chat: 'AI对话奖励',
  referral_bind_referee: '邀请好友奖励',
  referral_bind_referrer: '好友注册奖励',
  stay_5min: '下单挽留券',
  good_review: '好评返现',
  group_buy: '组队拼单奖励',
}

const regionLabels: Record<string, string> = {
  island_inside: '仅限岛内',
  island_outside: '仅限岛外',
}

const RedPacketPage = () => {
  const [activeTab, setActiveTab] = useState('unused')
  const [redPackets, setRedPackets] = useState<RedPacket[]>([])
  const [loading, setLoading] = useState(false)

  // 获取用户ID
  const { userInfo } = useUserStore()
  const userId = userInfo?.id || Taro.getStorageSync('user_id') || ''

  useEffect(() => {
    if (userId) {
      fetchRedPackets()
    }
  }, [activeTab, userId])

  const fetchRedPackets = async () => {
    setLoading(true)
    try {
      const res = await Network.request({
        url: '/api/referral/red-packets',
        method: 'GET',
        data: { userId, status: activeTab }
      })
      
      console.log('Red packets response:', res.data)
      
      if (res.data?.code === 200) {
        setRedPackets(res.data.data || [])
      } else {
        // 使用模拟数据
        setRedPackets(getMockRedPackets(activeTab))
      }
    } catch (error) {
      console.error('Fetch red packets error:', error)
      setRedPackets(getMockRedPackets(activeTab))
    } finally {
      setLoading(false)
    }
  }

  // 模拟数据
  const getMockRedPackets = (status: string): RedPacket[] => {
    const allPackets: RedPacket[] = [
      {
        id: '1',
        type: 'red_packet',
        amount: 5,
        minSpend: 0,
        source: 'register',
        region: null,
        status: 'unused',
        expireAt: new Date(Date.now() + 7 * 24 * 60 * 60 * 1000).toISOString(),
        createdAt: new Date().toISOString(),
      },
      {
        id: '2',
        type: 'coupon',
        amount: 10,
        minSpend: 50,
        source: 'referral_bind_referee',
        region: 'island_inside',
        status: 'unused',
        expireAt: new Date(Date.now() + 15 * 24 * 60 * 60 * 1000).toISOString(),
        createdAt: new Date().toISOString(),
      },
      {
        id: '3',
        type: 'red_packet',
        amount: 3,
        minSpend: 0,
        source: 'first_location',
        region: 'island_outside',
        status: 'unused',
        expireAt: new Date(Date.now() + 3 * 24 * 60 * 60 * 1000).toISOString(),
        createdAt: new Date().toISOString(),
      },
      {
        id: '4',
        type: 'red_packet',
        amount: 6,
        minSpend: 0,
        source: 'referral_bind_referrer',
        region: null,
        status: 'used',
        expireAt: new Date(Date.now() + 10 * 24 * 60 * 60 * 1000).toISOString(),
        createdAt: new Date(Date.now() - 5 * 24 * 60 * 60 * 1000).toISOString(),
      },
      {
        id: '5',
        type: 'coupon',
        amount: 8,
        minSpend: 30,
        source: 'stay_5min',
        region: null,
        status: 'expired',
        expireAt: new Date(Date.now() - 1 * 24 * 60 * 60 * 1000).toISOString(),
        createdAt: new Date(Date.now() - 2 * 24 * 60 * 60 * 1000).toISOString(),
      },
    ]
    
    return allPackets.filter(p => p.status === status)
  }

  const formatDate = (dateStr: string) => {
    const date = new Date(dateStr)
    return `${date.getMonth() + 1}月${date.getDate()}日到期`
  }

  const getDaysLeft = (dateStr: string) => {
    const expireDate = new Date(dateStr)
    const now = new Date()
    const days = Math.ceil((expireDate.getTime() - now.getTime()) / (24 * 60 * 60 * 1000))
    return days
  }

  const goToUse = (packet: RedPacket) => {
    if (packet.region) {
      Taro.showModal({
        title: '区域限制',
        content: `此红包${regionLabels[packet.region]}使用，是否前往？`,
        success: (res) => {
          if (res.confirm) {
            Taro.switchTab({ url: '/pages/index/index' })
          }
        }
      })
    } else {
      Taro.switchTab({ url: '/pages/index/index' })
    }
  }

  const renderRedPacketItem = (packet: RedPacket) => {
    const daysLeft = getDaysLeft(packet.expireAt)
    const isExpiringSoon = daysLeft <= 3 && daysLeft > 0
    
    return (
      <Card key={packet.id} className="mb-3 overflow-hidden">
        <View className="flex flex-row">
          {/* 金额区域 */}
          <View className="bg-gradient-to-br from-teal-500 to-teal-400 w-28 flex flex-col items-center justify-center py-4">
            <View className="flex items-baseline">
              <Text className="text-white text-sm">¥</Text>
              <Text className="text-white text-3xl font-bold">{packet.amount}</Text>
            </View>
            {packet.minSpend > 0 && (
              <Text className="text-white text-opacity-80 text-xs mt-1">
                满{packet.minSpend}可用
              </Text>
            )}
            {packet.minSpend === 0 && (
              <Text className="text-white text-opacity-80 text-xs mt-1">
                无门槛
              </Text>
            )}
          </View>
          
          {/* 信息区域 */}
          <View className="flex-1 p-3 flex flex-col justify-between">
            <View>
              <View className="flex items-center gap-2">
                <Text className="text-base font-semibold text-zinc-800">
                  {sourceLabels[packet.source] || '红包'}
                </Text>
                {packet.region && (
                  <View className="flex items-center gap-1 bg-teal-50 px-2 py-1 rounded">
                    <MapPin size={12} color="#14B8A6" />
                    <Text className="text-teal-500 text-xs">
                      {regionLabels[packet.region]}
                    </Text>
                  </View>
                )}
              </View>
              
              <View className="flex items-center gap-1 mt-1">
                <Clock size={12} color="#9ca3af" />
                <Text className={`text-xs ${isExpiringSoon ? 'text-teal-500' : 'text-slate-400'}`}>
                  {formatDate(packet.expireAt)}
                  {isExpiringSoon && ` (${daysLeft}天后过期)`}
                </Text>
              </View>
            </View>
            
            {packet.status === 'unused' && (
              <View className="flex justify-end">
                <Button 
                  size="sm" 
                  className="bg-teal-500 text-white"
                  onClick={() => goToUse(packet)}
                >
                  立即使用
                </Button>
              </View>
            )}
            
            {packet.status === 'used' && (
              <View className="flex justify-end">
                <View className="px-3 py-1 bg-zinc-100 rounded">
                  <Text className="text-zinc-400 text-xs">已使用</Text>
                </View>
              </View>
            )}
            
            {packet.status === 'expired' && (
              <View className="flex justify-end">
                <View className="px-3 py-1 bg-zinc-100 rounded">
                  <Text className="text-zinc-400 text-xs">已过期</Text>
                </View>
              </View>
            )}
          </View>
        </View>
      </Card>
    )
  }

  const renderEmpty = (status: string) => {
    const messages = {
      unused: '暂无可用红包',
      used: '暂无已使用红包',
      expired: '暂无已过期红包',
    }
    
    return (
      <View className="flex flex-col items-center justify-center py-16">
        <Gift size={48} color="#9ca3af" />
        <Text className="text-slate-400 mt-3">{messages[status as keyof typeof messages]}</Text>
        {status === 'unused' && (
          <Button 
            className="mt-4 bg-teal-500 text-white"
            onClick={() => Taro.switchTab({ url: '/pages/index/index' })}
          >
            去逛逛
          </Button>
        )}
      </View>
    )
  }

  return (
    <View className="min-h-screen bg-zinc-50">
      {/* 统计卡片 */}
      <View className="bg-gradient-to-br from-teal-500 to-teal-400 px-4 pt-4 pb-6">
        <View className="flex items-center justify-around">
          <View className="flex flex-col items-center">
            <Text className="text-white text-2xl font-bold">
              {redPackets.filter(p => p.status === 'unused').length}
            </Text>
            <Text className="text-white text-opacity-80 text-sm">可用红包</Text>
          </View>
          <View className="flex flex-col items-center">
            <Text className="text-white text-2xl font-bold">
              ¥{redPackets.filter(p => p.status === 'unused').reduce((sum, p) => sum + p.amount, 0)}
            </Text>
            <Text className="text-white text-opacity-80 text-sm">总金额</Text>
          </View>
        </View>
      </View>

      {/* Tab切换 */}
      <View className="px-4 -mt-3">
        <Card className="shadow-sm">
          <CardContent className="p-0">
            <View className="flex border-b border-zinc-100">
              {['unused', 'used', 'expired'].map((tab) => (
                <View 
                  key={tab}
                  className={`flex-1 py-3 flex items-center justify-center ${activeTab === tab ? 'border-b-2 border-teal-500' : ''}`}
                  onClick={() => setActiveTab(tab)}
                >
                  <Text className={`${activeTab === tab ? 'text-teal-500 font-semibold' : 'text-slate-500'}`}>
                    {tab === 'unused' ? '可用' : tab === 'used' ? '已使用' : '已过期'}
                  </Text>
                </View>
              ))}
            </View>
          </CardContent>
        </Card>
      </View>

      {/* 红包列表 */}
      <ScrollView scrollY className="px-4 mt-4" style={{ height: 'calc(100vh - 180px)' }}>
        {loading ? (
          <View className="flex items-center justify-center py-8">
            <Text className="text-zinc-400">加载中...</Text>
          </View>
        ) : redPackets.length > 0 ? (
          redPackets.map(renderRedPacketItem)
        ) : (
          renderEmpty(activeTab)
        )}
        
        {/* 底部留白 */}
        <View className="h-8" />
      </ScrollView>
    </View>
  )
}

export default RedPacketPage
