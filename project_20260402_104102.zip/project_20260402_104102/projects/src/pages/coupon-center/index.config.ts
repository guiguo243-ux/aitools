export default typeof definePageConfig === 'function'
  ? definePageConfig({ navigationBarTitleText: '优惠券中心' })
  : { navigationBarTitleText: '优惠券中心' }
