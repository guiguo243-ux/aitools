import { useState, useEffect } from 'react'
import { View, Text, ScrollView } from '@tarojs/components'
import Taro from '@tarojs/taro'

import { Network } from '@/network'
import { useUserStore } from '@/stores/user'
import { Button } from '@/components/ui/button'
import { Lock, Clock, Check, Gift } from 'lucide-react-taro'

interface Coupon {
  id: string
  name: string
  amount: number
  min_amount: number
  region: string
  start_time: string
  end_time: string
  description: string
  isReceived?: boolean
}

interface UserCoupon {
  id: string
  status: string
  coupon: Coupon
}

export default function CouponCenterPage() {
  const { userInfo, isLoggedIn } = useUserStore()
  
  // 从 URL 参数读取 tab
  const params = Taro.getCurrentInstance().router?.params || {}
  const initialTab = params.tab === 'my' ? 'my' : 'available'
  
  const [activeTab, setActiveTab] = useState<'available' | 'my'>(initialTab)
  const [availableCoupons, setAvailableCoupons] = useState<Coupon[]>([])
  const [myCoupons, setMyCoupons] = useState<UserCoupon[]>([])
  const [loading, setLoading] = useState(false)

  useEffect(() => {
    if (activeTab === 'available') {
      loadAvailableCoupons()
    } else if (isLoggedIn) {
      loadMyCoupons()
    }
  }, [activeTab])

  const loadAvailableCoupons = async () => {
    setLoading(true)
    try {
      const res = await Network.request({
        url: `/api/coupon/available?userId=${userInfo?.id || ''}&region=${userInfo?.region || ''}`
      })

      if (res.data.code === 200) {
        setAvailableCoupons(res.data.data.coupons || [])
      }
    } catch (error) {
      console.error('Load available coupons error:', error)
    } finally {
      setLoading(false)
    }
  }

  const loadMyCoupons = async () => {
    if (!userInfo?.id) return

    setLoading(true)
    try {
      const res = await Network.request({
        url: `/api/coupon/my?userId=${userInfo.id}`
      })

      if (res.data.code === 200) {
        setMyCoupons(res.data.data || [])
      }
    } catch (error) {
      console.error('Load my coupons error:', error)
    } finally {
      setLoading(false)
    }
  }

  const receiveCoupon = async (couponId: string) => {
    if (!userInfo?.id) {
      Taro.navigateTo({ url: '/pages/login/index' })
      return
    }

    try {
      const res = await Network.request({
        url: '/api/coupon/receive',
        method: 'POST',
        data: { userId: userInfo.id, couponId }
      })

      if (res.data.code === 200) {
        Taro.showToast({ title: '领取成功', icon: 'success' })
        loadAvailableCoupons()
      } else {
        Taro.showToast({ title: res.data.msg, icon: 'none' })
      }
    } catch (error) {
      Taro.showToast({ title: '领取失败', icon: 'none' })
    }
  }

  const formatDate = (dateStr: string) => {
    return dateStr?.split('T')[0] || ''
  }

  const renderCouponCard = (coupon: Coupon, isReceived: boolean = false, isUsed: boolean = false) => {
    const regionLabel = coupon.region === 'island' ? '岛内可用' : 
                        coupon.region === 'outside' ? '岛外可用' : '全厦门可用'

    return (
      <View 
        key={coupon.id} 
        className={`bg-white rounded-xl overflow-hidden mb-3 ${isUsed ? 'opacity-50' : ''}`}
      >
        <View className="flex">
          <View className="bg-gradient-to-br from-teal-500 to-teal-600 w-28 flex flex-col items-center justify-center text-white py-4">
            <Text className="text-2xl font-bold">¥{coupon.amount}</Text>
            <Text className="text-xs opacity-80">满{coupon.min_amount}可用</Text>
          </View>
          <View className="flex-1 p-3">
            <Text className="block text-base font-medium mb-1">{coupon.name}</Text>
            <Text className="block text-xs text-gray-500 mb-2">{coupon.description}</Text>
            <View className="flex items-center justify-between">
              <View className="flex items-center gap-1">
                <Lock size={14} color="#9ca3af" />
                <Text className="text-xs text-gray-400">{regionLabel}</Text>
              </View>
              <View className="flex items-center gap-1">
                <Clock size={14} color="#9ca3af" />
                <Text className="text-xs text-gray-400">
                  {formatDate(coupon.start_time)}-{formatDate(coupon.end_time)}
                </Text>
              </View>
            </View>
          </View>
        </View>
        {!isUsed && (
          <View className="border-t border-dashed border-gray-200 px-4 py-2 flex justify-end">
            {isReceived ? (
              <View className="flex items-center gap-1 text-gray-400">
                <Check size={16} color="#9ca3af" />
                <Text className="text-sm">已领取</Text>
              </View>
            ) : (
              <Button
                size="sm"
                className="bg-teal-500 text-white rounded-full px-4"
                onClick={() => receiveCoupon(coupon.id)}
              >
                立即领取
              </Button>
            )}
          </View>
        )}
        {isUsed && (
          <View className="border-t border-dashed border-gray-200 px-4 py-2 flex justify-end">
            <Text className="text-sm text-gray-400">已使用</Text>
          </View>
        )}
      </View>
    )
  }

  return (
    <View className="min-h-screen bg-gray-50">
      {/* Tab 切换 */}
      <View className="bg-white sticky top-0 z-10 flex border-b border-gray-200">
        <View 
          className={`flex-1 py-3 text-center ${activeTab === 'available' ? 'border-b-2 border-teal-500' : ''}`}
          onClick={() => setActiveTab('available')}
        >
          <Text className={activeTab === 'available' ? 'text-teal-500 font-medium' : 'text-gray-500'}>
            可领取
          </Text>
        </View>
        <View 
          className={`flex-1 py-3 text-center ${activeTab === 'my' ? 'border-b-2 border-teal-500' : ''}`}
          onClick={() => setActiveTab('my')}
        >
          <Text className={activeTab === 'my' ? 'text-teal-500 font-medium' : 'text-gray-500'}>
            我的优惠券
          </Text>
        </View>
      </View>

      {/* 内容区 */}
      <ScrollView scrollY className="h-screen px-4 py-4">
        {loading ? (
          <View className="text-center py-8">
            <Text className="text-gray-400">加载中...</Text>
          </View>
        ) : activeTab === 'available' ? (
          availableCoupons.length > 0 ? (
            <View>
              {availableCoupons.map((coupon) => 
                renderCouponCard(coupon, coupon.isReceived)
              )}
            </View>
          ) : (
            <View className="text-center py-8">
              <Gift size={48} color="#9ca3af" className="mx-auto" />
              <Text className="block text-gray-500 mt-4">暂无可领取优惠券</Text>
            </View>
          )
        ) : !isLoggedIn ? (
          <View className="text-center py-8">
            <Gift size={48} color="#9ca3af" className="mx-auto" />
            <Text className="block text-gray-500 mt-4">登录后查看您的优惠券</Text>
            <Button
              className="mt-4 bg-teal-500 text-white rounded-full px-6"
              onClick={() => Taro.navigateTo({ url: '/pages/login/index' })}
            >
              去登录
            </Button>
          </View>
        ) : myCoupons.length > 0 ? (
          <View>
            {myCoupons.map((uc) => 
              renderCouponCard(uc.coupon, false, uc.status === 'used')
            )}
          </View>
        ) : (
          <View className="text-center py-8">
            <Gift size={48} color="#9ca3af" className="mx-auto" />
            <Text className="block text-gray-500 mt-4">您还没有优惠券</Text>
          </View>
        )}
      </ScrollView>
    </View>
  )
}
