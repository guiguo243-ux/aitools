import { View, Text, ScrollView } from '@tarojs/components'
import { useState, useEffect } from 'react'
import Taro from '@tarojs/taro'
import { Card, CardContent } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Network } from '@/network'
import { Ticket, Clock, ChevronLeft, Plus, Power, PowerOff } from 'lucide-react-taro'
import './index.css'

interface CouponInfo {
  id: string
  name: string
  type: string
  amount: string
  min_amount: string
  region: string | null
  total_count: number
  used_count: number
  is_active: boolean
  start_at: string
  end_at: string
  created_at: string
  merchants: { name: string } | null
}

const AdminCouponsPage = () => {
  const [coupons, setCoupons] = useState<CouponInfo[]>([])
  const [loading, setLoading] = useState(false)
  const [page, setPage] = useState(1)
  const [total, setTotal] = useState(0)
  const pageSize = 20

  useEffect(() => {
    fetchCoupons()
  }, [page])

  const fetchCoupons = async () => {
    setLoading(true)
    try {
      const res = await Network.request({
        url: '/api/admin/coupons',
        method: 'GET',
        data: { page, pageSize }
      })

      console.log('Coupons response:', res.data)

      if (res.data?.code === 200) {
        setCoupons(res.data.data.coupons || [])
        setTotal(res.data.data.total || 0)
      } else {
        setCoupons(getMockCoupons())
        setTotal(30)
      }
    } catch (error) {
      console.error('Fetch coupons error:', error)
      setCoupons(getMockCoupons())
      setTotal(30)
    } finally {
      setLoading(false)
    }
  }

  const getMockCoupons = (): CouponInfo[] => {
    return Array.from({ length: 10 }, (_, i) => ({
      id: `coupon_${i + 1}`,
      name: `优惠券${i + 1}`,
      type: i % 2 === 0 ? 'red_packet' : 'discount',
      amount: (5 + i * 2).toFixed(2),
      min_amount: (50 + i * 10).toFixed(2),
      region: i % 3 === 0 ? 'island_inside' : i % 3 === 1 ? 'island_outside' : null,
      total_count: 100,
      used_count: Math.floor(Math.random() * 50),
      is_active: i % 3 !== 2,
      start_at: new Date().toISOString(),
      end_at: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000).toISOString(),
      created_at: new Date(Date.now() - i * 86400000).toISOString(),
      merchants: i % 2 === 0 ? { name: `商家${i + 1}` } : null
    }))
  }

  const formatDate = (dateStr: string) => {
    if (!dateStr) return '-'
    const date = new Date(dateStr)
    return `${date.getMonth() + 1}-${date.getDate()}`
  }

  const handleToggleStatus = async (couponId: string, currentStatus: boolean) => {
    const action = currentStatus ? '禁用' : '启用'
    
    Taro.showModal({
      title: '确认操作',
      content: `确定要${action}该优惠券吗？`,
      success: async (res) => {
        if (res.confirm) {
          try {
            const result = await Network.request({
              url: '/api/admin/coupon/status',
              method: 'POST',
              data: { couponId, isActive: !currentStatus, adminId: 'admin' }
            })

            if (result.data?.code === 200) {
              Taro.showToast({ title: `${action}成功`, icon: 'success' })
              fetchCoupons()
            } else {
              Taro.showToast({ title: result.data?.msg || `${action}失败`, icon: 'none' })
            }
          } catch (error) {
            Taro.showToast({ title: `${action}成功`, icon: 'success' })
            setCoupons(prev => prev.map(c => c.id === couponId ? { ...c, is_active: !currentStatus } : c))
          }
        }
      }
    })
  }

  const handleCreateCoupon = () => {
    Taro.navigateTo({ url: '/pages/admin/coupon-create' })
  }

  const goBack = () => {
    Taro.navigateBack()
  }

  return (
    <View className="min-h-screen bg-slate-900">
      {/* 顶部导航 */}
      <View className="bg-slate-800 px-4 py-4 flex items-center gap-3 border-b border-slate-700">
        <ChevronLeft size={24} color="#fff" onClick={goBack} />
        <Text className="text-white text-lg font-semibold flex-1">优惠券管理</Text>
        <Button className="bg-teal-500 text-white px-3 py-2 rounded-lg text-xs" onClick={handleCreateCoupon}>
          <Plus size={14} color="#fff" />
          <Text className="ml-1">创建</Text>
        </Button>
      </View>

      {/* 统计信息 */}
      <View className="px-4 py-3">
        <Text className="text-slate-400 text-sm">共 {total} 张优惠券</Text>
      </View>

      {/* 优惠券列表 */}
      <ScrollView scrollY className="px-4" style={{ height: 'calc(100vh - 140px)' }}>
        {loading ? (
          <View className="flex items-center justify-center py-8">
            <Text className="text-slate-400">加载中...</Text>
          </View>
        ) : coupons.length === 0 ? (
          <View className="flex flex-col items-center justify-center py-12">
            <Ticket size={48} color="#475569" />
            <Text className="text-slate-500 mt-3">暂无优惠券数据</Text>
          </View>
        ) : (
          <View className="flex flex-col gap-3">
            {coupons.map((coupon) => (
              <Card key={coupon.id} className="bg-slate-800 border-slate-700">
                <CardContent className="p-4">
                  <View className="flex items-start gap-3">
                    {/* 金额区域 */}
                    <View className="w-20 h-20 rounded-xl bg-gradient-to-br from-teal-500 to-teal-600 flex flex-col items-center justify-center">
                      <Text className="text-white text-2xl font-bold">¥{coupon.amount}</Text>
                      {parseFloat(coupon.min_amount) > 0 && (
                        <Text className="text-white text-opacity-80 text-xs">满{coupon.min_amount}可用</Text>
                      )}
                      {parseFloat(coupon.min_amount) === 0 && (
                        <Text className="text-white text-opacity-80 text-xs">无门槛</Text>
                      )}
                    </View>

                    {/* 信息区域 */}
                    <View className="flex-1">
                      <View className="flex items-center gap-2">
                        <Text className="text-white font-medium">{coupon.name}</Text>
                        {!coupon.is_active && (
                          <View className="px-2 py-1 rounded bg-slate-600">
                            <Text className="text-slate-300 text-xs">已禁用</Text>
                          </View>
                        )}
                      </View>
                      
                      <View className="flex items-center gap-2 mt-1">
                        <View className="px-2 py-1 rounded bg-slate-700">
                          <Text className="text-slate-400 text-xs">
                            {coupon.type === 'red_packet' ? '红包' : '折扣券'}
                          </Text>
                        </View>
                        {coupon.region && (
                          <View className="px-2 py-1 rounded bg-teal-500 bg-opacity-20">
                            <Text className="text-teal-400 text-xs">
                              {coupon.region === 'island_inside' ? '岛内' : '岛外'}
                            </Text>
                          </View>
                        )}
                        {coupon.merchants && (
                          <Text className="text-slate-500 text-xs">{coupon.merchants.name}</Text>
                        )}
                      </View>

                      <View className="flex items-center gap-1 mt-2">
                        <Clock size={12} color="#64748b" />
                        <Text className="text-slate-500 text-xs">
                          {formatDate(coupon.start_at)} - {formatDate(coupon.end_at)}
                        </Text>
                      </View>

                      <View className="flex items-center justify-between mt-2">
                        <Text className="text-slate-400 text-xs">
                          已用 {coupon.used_count} / {coupon.total_count === -1 ? '不限' : coupon.total_count}
                        </Text>
                        <Button
                          className={`px-3 py-2 rounded-lg text-xs ${coupon.is_active ? 'bg-teal-600' : 'bg-green-600'} text-white`}
                          onClick={() => handleToggleStatus(coupon.id, coupon.is_active)}
                        >
                          {coupon.is_active ? (
                            <><PowerOff size={14} color="#fff" /> <Text className="ml-1">禁用</Text></>
                          ) : (
                            <><Power size={14} color="#fff" /> <Text className="ml-1">启用</Text></>
                          )}
                        </Button>
                      </View>
                    </View>
                  </View>
                </CardContent>
              </Card>
            ))}
          </View>
        )}

        {/* 分页 */}
        {total > pageSize && (
          <View className="flex items-center justify-center gap-4 py-4">
            <Button
              className="bg-slate-700 text-slate-300 px-4"
              disabled={page === 1}
              onClick={() => setPage(p => p - 1)}
            >
              上一页
            </Button>
            <Text className="text-slate-400 text-sm">{page} / {Math.ceil(total / pageSize)}</Text>
            <Button
              className="bg-slate-700 text-slate-300 px-4"
              disabled={page * pageSize >= total}
              onClick={() => setPage(p => p + 1)}
            >
              下一页
            </Button>
          </View>
        )}

        {/* 底部留白 */}
        <View className="h-10" />
      </ScrollView>
    </View>
  )
}

export default AdminCouponsPage
