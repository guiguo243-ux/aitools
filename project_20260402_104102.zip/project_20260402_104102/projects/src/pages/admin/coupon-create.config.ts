export default typeof definePageConfig === 'function'
  ? definePageConfig({
      navigationBarTitleText: '创建优惠券',
      navigationBarBackgroundColor: '#1e293b',
      navigationBarTextStyle: 'white'
    })
  : {
      navigationBarTitleText: '创建优惠券',
      navigationBarBackgroundColor: '#1e293b',
      navigationBarTextStyle: 'white'
    }
