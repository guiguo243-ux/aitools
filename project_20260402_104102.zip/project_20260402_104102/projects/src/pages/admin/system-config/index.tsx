import { View, Text, ScrollView } from '@tarojs/components'
import { useState, useEffect } from 'react'
import Taro from '@tarojs/taro'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Textarea } from '@/components/ui/textarea'
import { Network } from '@/network'
import { Save, Eye, EyeOff, RefreshCw, Database, CreditCard, Cloud, MessageSquare } from 'lucide-react-taro'
import './index.css'

interface ConfigItem {
  id: number
  config_key: string
  config_value: string
  config_type: string
  category: string
  description: string | null
  is_secret: boolean
}

interface ConfigGroup {
  category: string
  title: string
  icon: any
  color: string
  configs: ConfigItem[]
}

const AdminSystemConfigPage = () => {
  const [configGroups, setConfigGroups] = useState<ConfigGroup[]>([])
  const [loading, setLoading] = useState(true)
  const [saving, setSaving] = useState<string | null>(null)
  const [testing, setTesting] = useState<string | null>(null)
  const [showSecrets, setShowSecrets] = useState<Record<string, boolean>>({})

  useEffect(() => {
    // 检查登录状态
    const admin = Taro.getStorageSync('admin_info')
    if (!admin) {
      Taro.redirectTo({ url: '/pages/admin/login/index' })
      return
    }
    fetchConfigs()
  }, [])

  const fetchConfigs = async () => {
    setLoading(true)
    try {
      const res = await Network.request({ url: '/api/system-config', method: 'GET' })
      console.log('Configs:', res.data)
      
      if (res.data?.code === 200) {
        const configs = res.data.data || []
        organizeConfigs(configs)
      } else {
        // 使用默认配置
        initializeDefaultConfigs()
      }
    } catch (error) {
      console.error('Fetch configs error:', error)
      initializeDefaultConfigs()
    } finally {
      setLoading(false)
    }
  }

  const initializeDefaultConfigs = () => {
    const defaultConfigs: ConfigItem[] = [
      // 微信配置
      { id: 1, config_key: 'wechat_appid', config_value: '', config_type: 'text', category: 'wechat', description: '微信小程序 AppID', is_secret: false },
      { id: 2, config_key: 'wechat_secret', config_value: '', config_type: 'text', category: 'wechat', description: '微信小程序 Secret', is_secret: true },
      // 支付配置
      { id: 3, config_key: 'payment_mchid', config_value: '', config_type: 'text', category: 'payment', description: '微信支付商户号', is_secret: false },
      { id: 4, config_key: 'payment_api_key', config_value: '', config_type: 'text', category: 'payment', description: '微信支付 API 密钥', is_secret: true },
      { id: 5, config_key: 'payment_cert_path', config_value: '', config_type: 'text', category: 'payment', description: '支付证书路径', is_secret: false },
      // 存储配置
      { id: 6, config_key: 'storage_provider', config_value: 'tos', config_type: 'select', category: 'storage', description: '存储服务提供商', is_secret: false },
      { id: 7, config_key: 'storage_bucket', config_value: '', config_type: 'text', category: 'storage', description: '存储桶名称', is_secret: false },
      { id: 8, config_key: 'storage_region', config_value: '', config_type: 'text', category: 'storage', description: '存储区域', is_secret: false },
      { id: 9, config_key: 'storage_access_key', config_value: '', config_type: 'text', category: 'storage', description: 'Access Key', is_secret: true },
      { id: 10, config_key: 'storage_secret_key', config_value: '', config_type: 'text', category: 'storage', description: 'Secret Key', is_secret: true },
      // 数据库配置
      { id: 11, config_key: 'database_url', config_value: '', config_type: 'text', category: 'database', description: '数据库连接地址', is_secret: true },
      { id: 12, config_key: 'database_pool_size', config_value: '10', config_type: 'number', category: 'database', description: '连接池大小', is_secret: false },
    ]
    organizeConfigs(defaultConfigs)
  }

  const organizeConfigs = (configs: ConfigItem[]) => {
    const groups: ConfigGroup[] = [
      {
        category: 'wechat',
        title: '微信配置',
        icon: MessageSquare,
        color: 'text-green-500',
        configs: configs.filter(c => c.category === 'wechat')
      },
      {
        category: 'payment',
        title: '支付配置',
        icon: CreditCard,
        color: 'text-blue-500',
        configs: configs.filter(c => c.category === 'payment')
      },
      {
        category: 'storage',
        title: '对象存储',
        icon: Cloud,
        color: 'text-purple-500',
        configs: configs.filter(c => c.category === 'storage')
      },
      {
        category: 'database',
        title: '数据库配置',
        icon: Database,
        color: 'text-orange-500',
        configs: configs.filter(c => c.category === 'database')
      }
    ]
    setConfigGroups(groups)
  }

  const handleValueChange = (category: string, key: string, value: string) => {
    setConfigGroups(prev => prev.map(group => {
      if (group.category === category) {
        return {
          ...group,
          configs: group.configs.map(config => 
            config.config_key === key ? { ...config, config_value: value } : config
          )
        }
      }
      return group
    }))
  }

  const handleSave = async (category: string) => {
    setSaving(category)
    try {
      const group = configGroups.find(g => g.category === category)
      if (!group) return

      const configs = group.configs.map(c => ({
        configKey: c.config_key,
        configValue: c.config_value,
        configType: c.config_type,
        category: c.category,
        description: c.description,
        isSecret: c.is_secret
      }))

      const res = await Network.request({
        url: '/api/system-config/batch',
        method: 'POST',
        data: { configs }
      })

      console.log('Save result:', res.data)

      if (res.data?.code === 200) {
        Taro.showToast({ title: '保存成功', icon: 'success' })
      } else {
        Taro.showToast({ title: res.data?.msg || '保存失败', icon: 'none' })
      }
    } catch (error) {
      console.error('Save error:', error)
      Taro.showToast({ title: '保存失败', icon: 'none' })
    } finally {
      setSaving(null)
    }
  }

  const handleTest = async (category: string) => {
    setTesting(category)
    try {
      const res = await Network.request({
        url: `/api/system-config/test/${category}`,
        method: 'POST'
      })

      console.log('Test result:', res.data)

      if (res.data?.code === 200 && res.data?.data?.success) {
        Taro.showToast({ title: '连接成功', icon: 'success' })
      } else {
        Taro.showToast({ title: res.data?.data?.message || '连接失败', icon: 'none' })
      }
    } catch (error) {
      console.error('Test error:', error)
      Taro.showToast({ title: '测试失败', icon: 'none' })
    } finally {
      setTesting(null)
    }
  }

  const toggleShowSecret = (key: string) => {
    setShowSecrets(prev => ({ ...prev, [key]: !prev[key] }))
  }

  const renderConfigItem = (config: ConfigItem, category: string) => {
    const isPassword = config.is_secret && !showSecrets[config.config_key]

    return (
      <View key={config.config_key} className="config-item">
        <View className="config-label">
          <Text className="text-slate-300 text-sm">{config.description || config.config_key}</Text>
          {config.is_secret && (
            <View className="secret-tag">
              <Text className="text-xs text-yellow-400">密钥</Text>
            </View>
          )}
        </View>
        <View className="config-input-wrapper">
          {config.config_type === 'textarea' ? (
            <Textarea
              className="config-textarea"
              value={config.config_value}
              placeholder={`请输入${config.description || config.config_key}`}
              onInput={(e) => handleValueChange(category, config.config_key, e.detail.value)}
            />
          ) : config.config_type === 'number' ? (
            <View className="input-container">
              <Input
                type="number"
                value={config.config_value}
                placeholder={`请输入${config.description || config.config_key}`}
                onInput={(e) => handleValueChange(category, config.config_key, e.detail.value)}
              />
            </View>
          ) : config.config_type === 'select' && config.config_key === 'storage_provider' ? (
            <View className="select-container">
              {['tos', 'oss', 'cos', 's3'].map(provider => (
                <View
                  key={provider}
                  className={`select-option ${config.config_value === provider ? 'selected' : ''}`}
                  onClick={() => handleValueChange(category, config.config_key, provider)}
                >
                  <Text className={`text-sm ${config.config_value === provider ? 'text-teal-400' : 'text-slate-400'}`}>
                    {provider.toUpperCase()}
                  </Text>
                </View>
              ))}
            </View>
          ) : (
            <View className="input-container">
              <Input
                password={isPassword}
                value={config.config_value}
                placeholder={`请输入${config.description || config.config_key}`}
                onInput={(e) => handleValueChange(category, config.config_key, e.detail.value)}
              />
              {config.is_secret && (
                <View 
                  className="eye-icon"
                  onClick={() => toggleShowSecret(config.config_key)}
                >
                  {showSecrets[config.config_key] ? (
                    <EyeOff size={18} color="#64748b" />
                  ) : (
                    <Eye size={18} color="#64748b" />
                  )}
                </View>
              )}
            </View>
          )}
        </View>
      </View>
    )
  }

  if (loading) {
    return (
      <View className="min-h-screen bg-slate-900 flex items-center justify-center">
        <Text className="text-slate-400">加载中...</Text>
      </View>
    )
  }

  return (
    <View className="min-h-screen bg-slate-900">
      {/* Header */}
      <View className="header">
        <Text className="text-white text-lg font-semibold">系统配置</Text>
        <Text className="text-slate-400 text-xs mt-1">配置第三方服务参数</Text>
      </View>

      <ScrollView scrollY className="content-scroll">
        {configGroups.map(group => {
          const IconComponent = group.icon
          return (
            <View key={group.category} className="config-group">
              <Card className="bg-slate-800 border-slate-700">
                <CardHeader className="pb-2">
                  <View className="flex items-center justify-between">
                    <View className="flex items-center gap-2">
                      <IconComponent size={20} color={group.color.replace('text-', '').replace('-500', '')} />
                      <CardTitle className="text-white text-base">{group.title}</CardTitle>
                    </View>
                    <View className="flex gap-2">
                      <Button
                        size="sm"
                        variant="outline"
                        className="test-btn"
                        onClick={() => handleTest(group.category)}
                        disabled={testing === group.category}
                      >
                        {testing === group.category ? (
                          <RefreshCw size={14} color="#14B8A6" className="animate-spin" />
                        ) : (
                          <Text className="text-xs text-teal-400">测试连接</Text>
                        )}
                      </Button>
                    </View>
                  </View>
                </CardHeader>
                <CardContent className="pt-2">
                  {group.configs.map(config => renderConfigItem(config, group.category))}
                  <View className="save-btn-wrapper">
                    <Button
                      className="save-btn"
                      onClick={() => handleSave(group.category)}
                      disabled={saving === group.category}
                    >
                      {saving === group.category ? (
                        <RefreshCw size={16} color="#fff" className="animate-spin" />
                      ) : (
                        <Save size={16} color="#fff" />
                      )}
                      <Text className="text-white text-sm ml-1">
                        {saving === group.category ? '保存中' : '保存配置'}
                      </Text>
                    </Button>
                  </View>
                </CardContent>
              </Card>
            </View>
          )
        })}

        {/* 使用说明 */}
        <View className="tips-section">
          <Card className="bg-slate-800 border-slate-700">
            <CardHeader>
              <CardTitle className="text-white text-sm">配置说明</CardTitle>
            </CardHeader>
            <CardContent>
              <View className="tip-item">
                <Text className="text-slate-400 text-xs">• 微信配置用于小程序登录和支付功能</Text>
              </View>
              <View className="tip-item">
                <Text className="text-slate-400 text-xs">• 支付配置用于微信支付功能，需在微信商户平台获取</Text>
              </View>
              <View className="tip-item">
                <Text className="text-slate-400 text-xs">• 对象存储用于图片和文件上传，支持 TOS/OSS/COS/S3</Text>
              </View>
              <View className="tip-item">
                <Text className="text-slate-400 text-xs">• 所有密钥类配置都会加密存储，请妥善保管</Text>
              </View>
            </CardContent>
          </Card>
        </View>
      </ScrollView>
    </View>
  )
}

export default AdminSystemConfigPage
