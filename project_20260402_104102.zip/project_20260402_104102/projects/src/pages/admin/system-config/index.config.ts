export default typeof definePageConfig === 'function'
  ? definePageConfig({
      navigationBarTitleText: '系统配置',
      navigationBarBackgroundColor: '#1e293b',
      navigationBarTextStyle: 'white'
    })
  : {
      navigationBarTitleText: '系统配置',
      navigationBarBackgroundColor: '#1e293b',
      navigationBarTextStyle: 'white'
    }
