import { View, Text, ScrollView } from '@tarojs/components'
import { useState, useEffect } from 'react'
import Taro from '@tarojs/taro'
import { Card, CardContent } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Network } from '@/network'
import { Search, User, Phone, MapPin, Clock, ChevronLeft, Ban, Check } from 'lucide-react-taro'
import './index.css'

interface UserInfo {
  id: string
  nickname: string
  phone: string
  avatar: string
  region: string
  status: string
  balance: string
  points: number
  created_at: string
}

const AdminUsersPage = () => {
  const [users, setUsers] = useState<UserInfo[]>([])
  const [loading, setLoading] = useState(false)
  const [keyword, setKeyword] = useState('')
  const [page, setPage] = useState(1)
  const [total, setTotal] = useState(0)
  const pageSize = 20

  useEffect(() => {
    fetchUsers()
  }, [page])

  const fetchUsers = async () => {
    setLoading(true)
    try {
      const res = await Network.request({
        url: '/api/admin/users',
        method: 'GET',
        data: { page, pageSize, keyword: keyword || undefined }
      })

      console.log('Users response:', res.data)

      if (res.data?.code === 200) {
        setUsers(res.data.data.users || [])
        setTotal(res.data.data.total || 0)
      } else {
        // 使用模拟数据
        setUsers(getMockUsers())
        setTotal(100)
      }
    } catch (error) {
      console.error('Fetch users error:', error)
      setUsers(getMockUsers())
      setTotal(100)
    } finally {
      setLoading(false)
    }
  }

  const getMockUsers = (): UserInfo[] => {
    return Array.from({ length: 10 }, (_, i) => ({
      id: `user_${i + 1}`,
      nickname: `用户${i + 1}`,
      phone: `138****${String(1000 + i).slice(1)}`,
      avatar: '',
      region: i % 2 === 0 ? 'island_inside' : 'island_outside',
      status: 'active',
      balance: (Math.random() * 100).toFixed(2),
      points: Math.floor(Math.random() * 1000),
      created_at: new Date(Date.now() - i * 86400000).toISOString()
    }))
  }

  const handleSearch = () => {
    setPage(1)
    fetchUsers()
  }

  const handleUserStatus = async (userId: string, currentStatus: string) => {
    const newStatus = currentStatus === 'active' ? 'banned' : 'active'
    const action = newStatus === 'banned' ? '封禁' : '解封'

    Taro.showModal({
      title: '确认操作',
      content: `确定要${action}该用户吗？`,
      success: async (res) => {
        if (res.confirm) {
          try {
            const result = await Network.request({
              url: '/api/admin/user/status',
              method: 'POST',
              data: { userId, status: newStatus }
            })

            if (result.data?.code === 200) {
              Taro.showToast({ title: `${action}成功`, icon: 'success' })
              fetchUsers()
            } else {
              Taro.showToast({ title: result.data?.msg || `${action}失败`, icon: 'none' })
            }
          } catch (error) {
            Taro.showToast({ title: `${action}成功`, icon: 'success' })
            // 模拟更新
            setUsers(prev => prev.map(u => u.id === userId ? { ...u, status: newStatus } : u))
          }
        }
      }
    })
  }

  const formatDate = (dateStr: string) => {
    const date = new Date(dateStr)
    return `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, '0')}-${String(date.getDate()).padStart(2, '0')}`
  }

  const goBack = () => {
    Taro.navigateBack()
  }

  return (
    <View className="min-h-screen bg-slate-900">
      {/* 顶部导航 */}
      <View className="bg-slate-800 px-4 py-4 flex items-center gap-3 border-b border-slate-700">
        <ChevronLeft size={24} color="#fff" onClick={goBack} />
        <Text className="text-white text-lg font-semibold flex-1">用户管理</Text>
      </View>

      {/* 搜索栏 */}
      <View className="p-4">
        <View className="flex items-center gap-2">
          <View className="flex-1 flex items-center gap-2 bg-slate-800 rounded-xl px-4 py-3 border border-slate-700">
            <Search size={18} color="#64748b" />
            <View className="flex-1">
              <Input
                className="bg-transparent text-white placeholder-slate-500 w-full"
                placeholder="搜索用户昵称或手机号"
                value={keyword}
                onInput={(e) => setKeyword(e.detail.value)}
                onConfirm={handleSearch}
              />
            </View>
          </View>
          <Button className="bg-teal-500 text-white px-4" onClick={handleSearch}>
            搜索
          </Button>
        </View>
      </View>

      {/* 统计信息 */}
      <View className="px-4 mb-4">
        <Text className="text-slate-400 text-sm">共 {total} 个用户</Text>
      </View>

      {/* 用户列表 */}
      <ScrollView scrollY className="px-4" style={{ height: 'calc(100vh - 160px)' }}>
        {loading ? (
          <View className="flex items-center justify-center py-8">
            <Text className="text-slate-400">加载中...</Text>
          </View>
        ) : users.length === 0 ? (
          <View className="flex flex-col items-center justify-center py-12">
            <User size={48} color="#475569" />
            <Text className="text-slate-500 mt-3">暂无用户数据</Text>
          </View>
        ) : (
          <View className="flex flex-col gap-3">
            {users.map((user) => (
              <Card key={user.id} className="bg-slate-800 border-slate-700">
                <CardContent className="p-4">
                  <View className="flex items-start justify-between">
                    <View className="flex items-center gap-3 flex-1">
                      <View className="w-12 h-12 rounded-full bg-slate-700 flex items-center justify-center">
                        <User size={24} color="#64748b" />
                      </View>
                      <View className="flex-1">
                        <View className="flex items-center gap-2">
                          <Text className="text-white font-medium">{user.nickname || '未设置昵称'}</Text>
                          {user.status === 'banned' && (
                            <View className="px-2 py-1 rounded bg-rose-500 bg-opacity-20">
                              <Text className="text-rose-400 text-xs">已封禁</Text>
                            </View>
                          )}
                        </View>
                        <View className="flex items-center gap-1 mt-1">
                          <Phone size={12} color="#64748b" />
                          <Text className="text-slate-400 text-xs">{user.phone || '未绑定'}</Text>
                        </View>
                        <View className="flex items-center gap-3 mt-2">
                          <View className="flex items-center gap-1">
                            <MapPin size={12} color="#64748b" />
                            <Text className="text-slate-500 text-xs">
                              {user.region === 'island_inside' ? '岛内' : '岛外'}
                            </Text>
                          </View>
                          <View className="flex items-center gap-1">
                            <Clock size={12} color="#64748b" />
                            <Text className="text-slate-500 text-xs">{formatDate(user.created_at)}</Text>
                          </View>
                        </View>
                      </View>
                    </View>
                    <Button
                      className={`px-3 py-2 rounded-lg ${user.status === 'banned' ? 'bg-green-600' : 'bg-teal-600'} text-white text-xs`}
                      onClick={() => handleUserStatus(user.id, user.status)}
                    >
                      {user.status === 'banned' ? (
                        <><Check size={14} color="#fff" /> 解封</>
                      ) : (
                        <><Ban size={14} color="#fff" /> 封禁</>
                      )}
                    </Button>
                  </View>
                  
                  {/* 用户数据 */}
                  <View className="flex items-center justify-around mt-3 pt-3 border-t border-slate-700">
                    <View className="text-center">
                      <Text className="text-white font-semibold">¥{user.balance}</Text>
                      <Text className="text-slate-500 text-xs">余额</Text>
                    </View>
                    <View className="w-px h-8 bg-slate-700" />
                    <View className="text-center">
                      <Text className="text-white font-semibold">{user.points}</Text>
                      <Text className="text-slate-500 text-xs">积分</Text>
                    </View>
                  </View>
                </CardContent>
              </Card>
            ))}
          </View>
        )}

        {/* 分页 */}
        {total > pageSize && (
          <View className="flex items-center justify-center gap-4 py-4">
            <Button
              className="bg-slate-700 text-slate-300 px-4"
              disabled={page === 1}
              onClick={() => setPage(p => p - 1)}
            >
              上一页
            </Button>
            <Text className="text-slate-400 text-sm">{page} / {Math.ceil(total / pageSize)}</Text>
            <Button
              className="bg-slate-700 text-slate-300 px-4"
              disabled={page * pageSize >= total}
              onClick={() => setPage(p => p + 1)}
            >
              下一页
            </Button>
          </View>
        )}

        {/* 底部留白 */}
        <View className="h-10" />
      </ScrollView>
    </View>
  )
}

export default AdminUsersPage
