import { View, Text } from '@tarojs/components'
import { useState } from 'react'
import Taro from '@tarojs/taro'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Card, CardContent } from '@/components/ui/card'
import { Network } from '@/network'
import { Shield, User, Lock } from 'lucide-react-taro'
import './index.css'

const AdminLoginPage = () => {
  const [username, setUsername] = useState('')
  const [password, setPassword] = useState('')
  const [loading, setLoading] = useState(false)

  const handleLogin = async () => {
    if (!username.trim() || !password.trim()) {
      Taro.showToast({ title: '请输入用户名和密码', icon: 'none' })
      return
    }

    setLoading(true)
    try {
      const res = await Network.request({
        url: '/api/admin/login',
        method: 'POST',
        data: { username, password }
      })

      console.log('Admin login response:', res.data)

      if (res.data?.code === 200 && res.data?.data) {
        Taro.setStorageSync('admin_info', res.data.data)
        Taro.showToast({ title: '登录成功', icon: 'success' })
        setTimeout(() => {
          Taro.redirectTo({ url: '/pages/admin/dashboard/index' })
        }, 1000)
      } else {
        Taro.showToast({ title: res.data?.msg || '登录失败', icon: 'none' })
      }
    } catch (error) {
      console.error('Admin login error:', error)
      Taro.showToast({ title: '登录失败', icon: 'none' })
    } finally {
      setLoading(false)
    }
  }

  return (
    <View className="admin-login-page">
      <View className="admin-login-container">
        {/* 左侧品牌区域 - PC端显示 */}
        <View className="admin-login-brand">
          <View className="admin-brand-content">
            <View className="admin-brand-logo">
              <Shield size={48} color="#fff" />
            </View>
            <Text className="admin-brand-title">厦门本地生活</Text>
            <Text className="admin-brand-subtitle">后台管理系统</Text>
            <View className="admin-brand-features">
              <View className="admin-brand-feature">
                <Text className="admin-feature-text">AI智能导购</Text>
              </View>
              <View className="admin-brand-feature">
                <Text className="admin-feature-text">商家管理</Text>
              </View>
              <View className="admin-brand-feature">
                <Text className="admin-feature-text">数据分析</Text>
              </View>
            </View>
          </View>
        </View>

        {/* 右侧登录区域 */}
        <View className="admin-login-form-section">
          <Card className="admin-login-card">
            <CardContent className="admin-login-card-content">
              {/* 移动端Logo */}
              <View className="admin-mobile-logo">
                <View className="admin-mobile-logo-icon">
                  <Shield size={32} color="#fff" />
                </View>
                <Text className="admin-mobile-logo-text">后台管理</Text>
              </View>

              {/* 登录表单 */}
              <View className="admin-login-form">
                <View className="admin-login-header">
                  <Text className="admin-login-title">管理员登录</Text>
                  <Text className="admin-login-subtitle">请输入您的账号信息</Text>
                </View>

                {/* 用户名 */}
                <View className="admin-input-group">
                  <Text className="admin-input-label">用户名</Text>
                  <View className="admin-input-wrapper">
                    <User size={18} color="#64748b" />
                    <View className="admin-input-flex">
                      <Input
                        className="admin-input"
                        placeholder="请输入用户名"
                        value={username}
                        onInput={(e) => setUsername(e.detail.value)}
                      />
                    </View>
                  </View>
                </View>

                {/* 密码 */}
                <View className="admin-input-group">
                  <Text className="admin-input-label">密码</Text>
                  <View className="admin-input-wrapper">
                    <Lock size={18} color="#64748b" />
                    <View className="admin-input-flex">
                      <Input
                        className="admin-input"
                        placeholder="请输入密码"
                        password
                        value={password}
                        onInput={(e) => setPassword(e.detail.value)}
                      />
                    </View>
                  </View>
                </View>

                {/* 登录按钮 */}
                <Button
                  className="admin-login-btn"
                  onClick={handleLogin}
                  disabled={loading}
                >
                  <Text className="admin-login-btn-text">
                    {loading ? '登录中...' : '登录'}
                  </Text>
                </Button>

                {/* 提示 */}
                <View className="admin-login-tip">
                  <Text className="admin-tip-text">
                    默认账号: admin / admin123
                  </Text>
                </View>
              </View>
            </CardContent>
          </Card>
        </View>
      </View>
    </View>
  )
}

export default AdminLoginPage
