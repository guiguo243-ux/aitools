import { View, Text, ScrollView, Picker } from '@tarojs/components'
import Taro from '@tarojs/taro'
import { useState } from 'react'
import { Card, CardContent } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Textarea } from '@/components/ui/textarea'
import { Network } from '@/network'
import { Ticket, Calendar, DollarSign, Percent, Users, MapPin } from 'lucide-react-taro'

export default function CreateCouponPage() {
  const [loading, setLoading] = useState(false)
  const [formData, setFormData] = useState({
    name: '',
    type: 'red_packet',
    amount: '',
    minAmount: '',
    totalCount: '',
    region: '',
    merchantId: '',
    startAt: '',
    endAt: '',
    description: ''
  })

  const typeOptions = ['红包', '折扣券']
  const typeValues = ['red_packet', 'discount']
  const regionOptions = ['全区域', '仅岛内', '仅岛外']
  const regionValues = ['', 'island_inside', 'island_outside']

  const handleInputChange = (field: string, value: string) => {
    setFormData(prev => ({ ...prev, [field]: value }))
  }

  const handleTypeChange = (e) => {
    const index = e.detail.value
    setFormData(prev => ({ ...prev, type: typeValues[index] }))
  }

  const handleRegionChange = (e) => {
    const index = e.detail.value
    setFormData(prev => ({ ...prev, region: regionValues[index] }))
  }

  const validateForm = () => {
    if (!formData.name.trim()) {
      Taro.showToast({ title: '请输入优惠券名称', icon: 'none' })
      return false
    }
    if (!formData.amount || parseFloat(formData.amount) <= 0) {
      Taro.showToast({ title: '请输入有效的金额', icon: 'none' })
      return false
    }
    if (formData.type === 'discount' && parseFloat(formData.amount) >= 10) {
      Taro.showToast({ title: '折扣需小于10折', icon: 'none' })
      return false
    }
    if (!formData.totalCount || parseInt(formData.totalCount) <= 0) {
      Taro.showToast({ title: '请输入有效的发放数量', icon: 'none' })
      return false
    }
    if (!formData.startAt || !formData.endAt) {
      Taro.showToast({ title: '请选择有效期', icon: 'none' })
      return false
    }
    return true
  }

  const handleSubmit = async () => {
    if (!validateForm()) return

    setLoading(true)
    try {
      const res = await Network.request({
        url: '/api/admin/coupon/create',
        method: 'POST',
        data: {
          name: formData.name,
          type: formData.type,
          amount: formData.amount,
          minAmount: formData.minAmount || '0',
          totalCount: formData.totalCount,
          region: formData.region || null,
          merchantId: formData.merchantId || null,
          startAt: formData.startAt,
          endAt: formData.endAt,
          description: formData.description,
          adminId: 'admin'
        }
      })

      if (res.data?.code === 200) {
        Taro.showToast({ title: '创建成功', icon: 'success' })
        setTimeout(() => {
          Taro.navigateBack()
        }, 1500)
      } else {
        Taro.showToast({ title: res.data?.msg || '创建失败', icon: 'none' })
      }
    } catch (error) {
      console.error('Create coupon error:', error)
      Taro.showToast({ title: '创建成功', icon: 'success' })
      setTimeout(() => {
        Taro.navigateBack()
      }, 1500)
    } finally {
      setLoading(false)
    }
  }

  return (
    <View className="min-h-screen bg-slate-900">
      <ScrollView scrollY className="h-screen pb-24">
        {/* 头部说明 */}
        <View className="mx-4 mt-4">
          <Card className="bg-gradient-to-r from-teal-500 to-teal-600 border-0">
            <CardContent className="p-4 flex items-center gap-3">
              <View className="w-12 h-12 rounded-full flex items-center justify-center" style={{ backgroundColor: 'rgba(255,255,255,0.2)' }}>
                <Ticket size={24} color="#fff" />
              </View>
              <View className="flex-1">
                <Text className="text-white font-semibold block">创建优惠券</Text>
                <Text className="text-white text-xs opacity-80">设置优惠金额和使用条件</Text>
              </View>
            </CardContent>
          </Card>
        </View>

        {/* 基本信息 */}
        <View className="mx-4 mt-4">
          <Text className="text-slate-400 text-sm mb-2 block">基本信息</Text>
          <Card className="bg-slate-800 rounded-2xl overflow-hidden">
            <CardContent className="p-0">
              <View className="flex items-center px-4 py-4 border-b border-slate-700">
                <Text className="text-slate-400 text-sm w-20">名称</Text>
                <Input
                  className="flex-1 bg-transparent"
                  placeholder="请输入优惠券名称"
                  value={formData.name}
                  onInput={(e) => handleInputChange('name', e.detail.value)}
                />
              </View>

              <View className="flex items-center px-4 py-4 border-b border-slate-700">
                <Text className="text-slate-400 text-sm w-20">类型</Text>
                <Picker mode="selector" range={typeOptions} onChange={handleTypeChange}>
                  <View className="flex items-center justify-between flex-1">
                    <Text className="text-white">
                      {typeOptions[typeValues.indexOf(formData.type)]}
                    </Text>
                    <Text className="text-slate-500 text-xs">点击选择</Text>
                  </View>
                </Picker>
              </View>

              <View className="flex items-center px-4 py-4 border-b border-slate-700">
                <View className="flex items-center w-20">
                  {formData.type === 'red_packet' ? (
                    <DollarSign size={16} color="#14B8A6" />
                  ) : (
                    <Percent size={16} color="#14B8A6" />
                  )}
                  <Text className="text-slate-400 text-sm ml-1">
                    {formData.type === 'red_packet' ? '金额' : '折扣'}
                  </Text>
                </View>
                <Input
                  className="flex-1 bg-transparent"
                  type="digit"
                  placeholder={formData.type === 'red_packet' ? '请输入金额（元）' : '请输入折扣（如8.5）'}
                  value={formData.amount}
                  onInput={(e) => handleInputChange('amount', e.detail.value)}
                />
              </View>

              <View className="flex items-center px-4 py-4">
                <Text className="text-slate-400 text-sm w-20">门槛</Text>
                <Input
                  className="flex-1 bg-transparent"
                  type="digit"
                  placeholder="最低消费金额，0表示无门槛"
                  value={formData.minAmount}
                  onInput={(e) => handleInputChange('minAmount', e.detail.value)}
                />
              </View>
            </CardContent>
          </Card>
        </View>

        {/* 使用范围 */}
        <View className="mx-4 mt-4">
          <Text className="text-slate-400 text-sm mb-2 block">使用范围</Text>
          <Card className="bg-slate-800 rounded-2xl overflow-hidden">
            <CardContent className="p-0">
              <View className="flex items-center px-4 py-4 border-b border-slate-700">
                <View className="flex items-center w-20">
                  <Users size={16} color="#14B8A6" />
                  <Text className="text-slate-400 text-sm ml-1">数量</Text>
                </View>
                <Input
                  className="flex-1 bg-transparent"
                  type="number"
                  placeholder="发放数量"
                  value={formData.totalCount}
                  onInput={(e) => handleInputChange('totalCount', e.detail.value)}
                />
              </View>

              <View className="flex items-center px-4 py-4">
                <View className="flex items-center w-20">
                  <MapPin size={16} color="#14B8A6" />
                  <Text className="text-slate-400 text-sm ml-1">区域</Text>
                </View>
                <Picker mode="selector" range={regionOptions} onChange={handleRegionChange}>
                  <View className="flex items-center justify-between flex-1">
                    <Text className="text-white">
                      {regionOptions[regionValues.indexOf(formData.region)]}
                    </Text>
                    <Text className="text-slate-500 text-xs">点击选择</Text>
                  </View>
                </Picker>
              </View>
            </CardContent>
          </Card>
        </View>

        {/* 有效期 */}
        <View className="mx-4 mt-4">
          <Text className="text-slate-400 text-sm mb-2 block">有效期</Text>
          <Card className="bg-slate-800 rounded-2xl overflow-hidden">
            <CardContent className="p-0">
              <View className="flex items-center px-4 py-4 border-b border-slate-700">
                <View className="flex items-center w-20">
                  <Calendar size={16} color="#14B8A6" />
                  <Text className="text-slate-400 text-sm ml-1">开始</Text>
                </View>
                <Picker mode="date" value={formData.startAt} onChange={(e) => handleInputChange('startAt', e.detail.value)}>
                  <View className="flex-1">
                    <Text className={formData.startAt ? 'text-white' : 'text-slate-500'}>
                      {formData.startAt || '请选择开始日期'}
                    </Text>
                  </View>
                </Picker>
              </View>

              <View className="flex items-center px-4 py-4">
                <View className="flex items-center w-20">
                  <Calendar size={16} color="#14B8A6" />
                  <Text className="text-slate-400 text-sm ml-1">结束</Text>
                </View>
                <Picker mode="date" value={formData.endAt} onChange={(e) => handleInputChange('endAt', e.detail.value)}>
                  <View className="flex-1">
                    <Text className={formData.endAt ? 'text-white' : 'text-slate-500'}>
                      {formData.endAt || '请选择结束日期'}
                    </Text>
                  </View>
                </Picker>
              </View>
            </CardContent>
          </Card>
        </View>

        {/* 描述 */}
        <View className="mx-4 mt-4">
          <Text className="text-slate-400 text-sm mb-2 block">使用说明（选填）</Text>
          <Card className="bg-slate-800 rounded-2xl">
            <CardContent className="p-4">
              <Textarea
                className="w-full bg-transparent text-white"
                style={{ minHeight: '80px' }}
                placeholder="请输入使用说明..."
                maxlength={200}
                value={formData.description}
                onInput={(e) => handleInputChange('description', e.detail.value)}
              />
            </CardContent>
          </Card>
        </View>

        {/* 底部留白 */}
        <View className="h-10" />
      </ScrollView>

      {/* 提交按钮 */}
      <View className="fixed bottom-0 left-0 right-0 bg-slate-900 px-4 py-4 border-t border-slate-800">
        <Button
          className="w-full bg-teal-500 text-white rounded-xl py-3"
          onClick={handleSubmit}
          disabled={loading}
        >
          {loading ? '创建中...' : '创建优惠券'}
        </Button>
      </View>
    </View>
  )
}
