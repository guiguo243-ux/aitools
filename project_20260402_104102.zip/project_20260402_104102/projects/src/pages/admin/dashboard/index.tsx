import { View, Text } from '@tarojs/components'
import { useState, useEffect } from 'react'
import Taro from '@tarojs/taro'
import { Card, CardContent } from '@/components/ui/card'
import { Network } from '@/network'
import AdminLayout from '@/components/admin-layout'
import { Users, Store, ShoppingCart, Wallet, TrendingUp, TriangleAlert, ChevronRight, ChartBarBig, ChartPie } from 'lucide-react-taro'
import './index.css'

interface DashboardStats {
  totalUsers: number
  totalMerchants: number
  totalOrders: number
  todayOrders: number
  todayRevenue: string
  pendingMerchants: number
}

interface TrendData {
  date: string
  count: number
  revenue?: number
}

interface StatusDistribution {
  status: string
  count: number
  label: string
}

const AdminDashboardPage = () => {
  const [stats, setStats] = useState<DashboardStats>({
    totalUsers: 0,
    totalMerchants: 0,
    totalOrders: 0,
    todayOrders: 0,
    todayRevenue: '0',
    pendingMerchants: 0
  })
  const [orderTrend, setOrderTrend] = useState<TrendData[]>([])
  const [userTrend, setUserTrend] = useState<TrendData[]>([])
  const [statusDistribution, setStatusDistribution] = useState<StatusDistribution[]>([])
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    fetchDashboardData()
  }, [])

  const fetchDashboardData = async () => {
    setLoading(true)
    try {
      const [statsRes, orderTrendRes, userTrendRes, statusDistRes] = await Promise.all([
        Network.request({ url: '/api/admin/dashboard/stats', method: 'GET' }),
        Network.request({ url: '/api/admin/dashboard/order-trend?days=7', method: 'GET' }),
        Network.request({ url: '/api/admin/dashboard/user-trend?days=7', method: 'GET' }),
        Network.request({ url: '/api/admin/dashboard/order-status-distribution', method: 'GET' })
      ])

      if (statsRes.data?.code === 200) {
        setStats(statsRes.data.data)
      }
      if (orderTrendRes.data?.code === 200) {
        setOrderTrend(orderTrendRes.data.data || [])
      }
      if (userTrendRes.data?.code === 200) {
        setUserTrend(userTrendRes.data.data || [])
      }
      if (statusDistRes.data?.code === 200) {
        setStatusDistribution(statusDistRes.data.data || [])
      }
    } catch (error) {
      console.error('Fetch dashboard error:', error)
      setStats({
        totalUsers: 1256,
        totalMerchants: 89,
        totalOrders: 3456,
        todayOrders: 128,
        todayRevenue: '15680.00',
        pendingMerchants: 5
      })
      setOrderTrend(getMockOrderTrend())
      setUserTrend(getMockUserTrend())
      setStatusDistribution(getMockStatusDistribution())
    } finally {
      setLoading(false)
    }
  }

  const getMockOrderTrend = (): TrendData[] => [
    { date: '2024-01-01', count: 12, revenue: 1200 },
    { date: '2024-01-02', count: 18, revenue: 1800 },
    { date: '2024-01-03', count: 25, revenue: 2500 },
    { date: '2024-01-04', count: 15, revenue: 1500 },
    { date: '2024-01-05', count: 30, revenue: 3000 },
    { date: '2024-01-06', count: 22, revenue: 2200 },
    { date: '2024-01-07', count: 28, revenue: 2800 }
  ]

  const getMockUserTrend = (): TrendData[] => [
    { date: '2024-01-01', count: 5 },
    { date: '2024-01-02', count: 8 },
    { date: '2024-01-03', count: 12 },
    { date: '2024-01-04', count: 6 },
    { date: '2024-01-05', count: 15 },
    { date: '2024-01-06', count: 10 },
    { date: '2024-01-07', count: 18 }
  ]

  const getMockStatusDistribution = (): StatusDistribution[] => [
    { status: 'completed', count: 150, label: '已完成' },
    { status: 'paid', count: 30, label: '已支付' },
    { status: 'pending', count: 20, label: '待支付' },
    { status: 'cancelled', count: 10, label: '已取消' }
  ]

  const formatDate = (dateStr: string) => {
    const date = new Date(dateStr)
    return `${date.getMonth() + 1}/${date.getDate()}`
  }

  const getMaxCount = (data: TrendData[]) => {
    return Math.max(...data.map(d => d.count), 1)
  }

  const getStatusBarColor = (status: string) => {
    const colorMap: Record<string, string> = {
      completed: 'bg-emerald-500',
      paid: 'bg-blue-500',
      pending: 'bg-amber-500',
      cancelled: 'bg-stone-400'
    }
    return colorMap[status] || 'bg-stone-400'
  }

  const navigateTo = (url: string) => {
    Taro.navigateTo({ url })
  }

  if (loading) {
    return (
      <AdminLayout title="数据概览" currentPage="dashboard">
        <View className="flex items-center justify-center h-64">
          <Text className="text-stone-400">加载中...</Text>
        </View>
      </AdminLayout>
    )
  }

  return (
    <AdminLayout title="数据概览" currentPage="dashboard">
      {/* 统计卡片 */}
      <View className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-6">
        <Card className="bg-white border-stone-200 shadow-sm">
          <CardContent className="p-4 md:p-6">
            <View className="flex items-center gap-3">
              <View className="w-10 h-10 md:w-12 md:h-12 rounded-xl bg-teal-50 flex items-center justify-center">
                <Users size={20} color="#14B8A6" />
              </View>
              <View>
                <Text className="text-stone-500 text-xs md:text-sm">用户总数</Text>
                <Text className="text-stone-800 text-lg md:text-2xl font-bold">{stats.totalUsers}</Text>
              </View>
            </View>
          </CardContent>
        </Card>

        <Card className="bg-white border-stone-200 shadow-sm">
          <CardContent className="p-4 md:p-6">
            <View className="flex items-center gap-3">
              <View className="w-10 h-10 md:w-12 md:h-12 rounded-xl bg-emerald-50 flex items-center justify-center">
                <Store size={20} color="#10b981" />
              </View>
              <View>
                <Text className="text-stone-500 text-xs md:text-sm">商家总数</Text>
                <Text className="text-stone-800 text-lg md:text-2xl font-bold">{stats.totalMerchants}</Text>
              </View>
            </View>
          </CardContent>
        </Card>

        <Card className="bg-white border-stone-200 shadow-sm">
          <CardContent className="p-4 md:p-6">
            <View className="flex items-center gap-3">
              <View className="w-10 h-10 md:w-12 md:h-12 rounded-xl bg-blue-50 flex items-center justify-center">
                <ShoppingCart size={20} color="#3b82f6" />
              </View>
              <View>
                <Text className="text-stone-500 text-xs md:text-sm">订单总数</Text>
                <Text className="text-stone-800 text-lg md:text-2xl font-bold">{stats.totalOrders}</Text>
              </View>
            </View>
          </CardContent>
        </Card>

        <Card className="bg-white border-stone-200 shadow-sm">
          <CardContent className="p-4 md:p-6">
            <View className="flex items-center gap-3">
              <View className="w-10 h-10 md:w-12 md:h-12 rounded-xl bg-amber-50 flex items-center justify-center">
                <Wallet size={20} color="#f59e0b" />
              </View>
              <View>
                <Text className="text-stone-500 text-xs md:text-sm">今日营收</Text>
                <Text className="text-stone-800 text-lg md:text-2xl font-bold">¥{stats.todayRevenue}</Text>
              </View>
            </View>
          </CardContent>
        </Card>
      </View>

      {/* 今日订单 */}
      <Card className="bg-gradient-to-r from-teal-500 to-teal-600 border-0 mb-6 shadow-lg">
        <CardContent className="p-4 md:p-6">
          <View className="flex items-center justify-between">
            <View>
              <Text className="text-white text-opacity-90 text-sm">今日订单</Text>
              <Text className="text-white text-3xl md:text-4xl font-bold mt-1">{stats.todayOrders}</Text>
            </View>
            <TrendingUp size={48} color="rgba(255,255,255,0.3)" />
          </View>
        </CardContent>
      </Card>

      {/* 待处理事项 */}
      {stats.pendingMerchants > 0 && (
        <Card className="bg-amber-50 border-amber-200 mb-6">
          <CardContent className="p-4">
            <View className="flex items-center gap-3">
              <TriangleAlert size={24} color="#f59e0b" />
              <View className="flex-1">
                <Text className="text-amber-700 font-semibold">待审核商家</Text>
                <Text className="text-amber-600 text-sm">有 {stats.pendingMerchants} 个商家等待审核</Text>
              </View>
              <ChevronRight size={20} color="#f59e0b" onClick={() => navigateTo('/pages/admin/merchants/index?status=pending')} />
            </View>
          </CardContent>
        </Card>
      )}

      {/* 图表区域 */}
      <View className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {/* 订单趋势 */}
        <Card className="bg-white border-stone-200 shadow-sm">
          <CardContent className="p-4 md:p-6">
            <View className="flex items-center gap-2 mb-4">
              <ChartBarBig size={18} color="#14B8A6" />
              <Text className="text-stone-700 font-semibold">近7天订单趋势</Text>
            </View>
            {orderTrend.length > 0 ? (
              <View>
                <View className="flex items-end justify-between gap-2 h-28 mb-3">
                  {orderTrend.map((item, index) => {
                    const maxCount = getMaxCount(orderTrend)
                    const heightPercent = (item.count / maxCount) * 100
                    return (
                      <View key={index} className="flex-1 flex flex-col items-center">
                        <View 
                          className="w-full bg-teal-400 rounded-t-sm min-h-[4px]"
                          style={{ height: `${Math.max(heightPercent, 5)}%` }}
                        />
                      </View>
                    )
                  })}
                </View>
                <View className="flex justify-between gap-2">
                  {orderTrend.map((item, index) => (
                    <Text key={index} className="text-stone-400 text-xs flex-1 text-center">
                      {formatDate(item.date)}
                    </Text>
                  ))}
                </View>
                <View className="flex justify-between gap-2 mt-2">
                  {orderTrend.map((item, index) => (
                    <Text key={index} className="text-stone-600 text-xs flex-1 text-center">
                      {item.count}单
                    </Text>
                  ))}
                </View>
              </View>
            ) : (
              <View className="h-28 flex items-center justify-center">
                <Text className="text-stone-400">暂无数据</Text>
              </View>
            )}
          </CardContent>
        </Card>

        {/* 用户增长 */}
        <Card className="bg-white border-stone-200 shadow-sm">
          <CardContent className="p-4 md:p-6">
            <View className="flex items-center gap-2 mb-4">
              <TrendingUp size={18} color="#3b82f6" />
              <Text className="text-stone-700 font-semibold">近7天用户增长</Text>
            </View>
            {userTrend.length > 0 ? (
              <View>
                <View className="flex items-end justify-between gap-2 h-28 mb-3">
                  {userTrend.map((item, index) => {
                    const maxCount = getMaxCount(userTrend)
                    const heightPercent = (item.count / maxCount) * 100
                    return (
                      <View key={index} className="flex-1 flex flex-col items-center">
                        <View 
                          className="w-full bg-blue-400 rounded-t-sm min-h-[4px]"
                          style={{ height: `${Math.max(heightPercent, 5)}%` }}
                        />
                      </View>
                    )
                  })}
                </View>
                <View className="flex justify-between gap-2">
                  {userTrend.map((item, index) => (
                    <Text key={index} className="text-stone-400 text-xs flex-1 text-center">
                      {formatDate(item.date)}
                    </Text>
                  ))}
                </View>
                <View className="flex justify-between gap-2 mt-2">
                  {userTrend.map((item, index) => (
                    <Text key={index} className="text-stone-600 text-xs flex-1 text-center">
                      +{item.count}
                    </Text>
                  ))}
                </View>
              </View>
            ) : (
              <View className="h-28 flex items-center justify-center">
                <Text className="text-stone-400">暂无数据</Text>
              </View>
            )}
          </CardContent>
        </Card>
      </View>

      {/* 订单状态分布 */}
      <Card className="bg-white border-stone-200 shadow-sm mt-6">
        <CardContent className="p-4 md:p-6">
          <View className="flex items-center gap-2 mb-4">
            <ChartPie size={18} color="#8b5cf6" />
            <Text className="text-stone-700 font-semibold">订单状态分布</Text>
          </View>
          {statusDistribution.length > 0 ? (
            <View className="space-y-3">
              {statusDistribution.map((item, index) => {
                const totalCount = statusDistribution.reduce((sum, d) => sum + d.count, 0)
                const percent = totalCount > 0 ? ((item.count / totalCount) * 100).toFixed(1) : '0'
                return (
                  <View key={index} className="flex items-center gap-3">
                    <View className={`w-3 h-3 rounded-sm ${getStatusBarColor(item.status)}`} />
                    <Text className="text-stone-600 text-sm flex-1">{item.label}</Text>
                    <Text className="text-stone-500 text-sm">{item.count}</Text>
                    <Text className="text-stone-400 text-xs w-14 text-right">{percent}%</Text>
                  </View>
                )
              })}
            </View>
          ) : (
            <View className="h-24 flex items-center justify-center">
              <Text className="text-stone-400">暂无数据</Text>
            </View>
          )}
        </CardContent>
      </Card>
    </AdminLayout>
  )
}

export default AdminDashboardPage
