import { View, Text, ScrollView } from '@tarojs/components'
import { useState, useEffect } from 'react'
import Taro from '@tarojs/taro'
import { Card, CardContent } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Network } from '@/network'
import { ShoppingCart, Clock, ChevronLeft, Eye, X, Check } from 'lucide-react-taro'
import './index.css'

interface OrderInfo {
  id: string
  order_no: string
  total_amount: string
  pay_amount: string
  status: string
  payment_method: string
  created_at: string
  paid_at: string | null
  users: { nickname: string; phone: string } | null
  merchants: { name: string } | null
}

const AdminOrdersPage = () => {
  const [orders, setOrders] = useState<OrderInfo[]>([])
  const [loading, setLoading] = useState(false)
  const [activeTab, setActiveTab] = useState<'all' | 'pending' | 'paid' | 'completed' | 'cancelled'>('all')
  const [page, setPage] = useState(1)
  const [total, setTotal] = useState(0)
  const pageSize = 20

  useEffect(() => {
    fetchOrders()
  }, [activeTab, page])

  const fetchOrders = async () => {
    setLoading(true)
    try {
      const res = await Network.request({
        url: '/api/admin/orders',
        method: 'GET',
        data: { 
          page, 
          pageSize, 
          status: activeTab === 'all' ? undefined : activeTab 
        }
      })

      console.log('Orders response:', res.data)

      if (res.data?.code === 200) {
        setOrders(res.data.data.orders || [])
        setTotal(res.data.data.total || 0)
      } else {
        setOrders(getMockOrders())
        setTotal(100)
      }
    } catch (error) {
      console.error('Fetch orders error:', error)
      setOrders(getMockOrders())
      setTotal(100)
    } finally {
      setLoading(false)
    }
  }

  const getMockOrders = (): OrderInfo[] => {
    const statuses = ['pending', 'paid', 'completed', 'cancelled']
    return Array.from({ length: 10 }, (_, i) => ({
      id: `order_${i + 1}`,
      order_no: `XM${Date.now().toString().slice(-8)}${i}`,
      total_amount: (50 + i * 10).toFixed(2),
      pay_amount: (45 + i * 10).toFixed(2),
      status: statuses[i % 4],
      payment_method: 'wechat',
      created_at: new Date(Date.now() - i * 3600000).toISOString(),
      paid_at: i > 0 ? new Date(Date.now() - i * 3600000 + 60000).toISOString() : null,
      users: { nickname: `用户${i + 1}`, phone: `138****${String(1000 + i).slice(1)}` },
      merchants: { name: `商家${i + 1}号店` }
    }))
  }

  const formatDate = (dateStr: string) => {
    if (!dateStr) return '-'
    const date = new Date(dateStr)
    return `${date.getMonth() + 1}-${date.getDate()} ${String(date.getHours()).padStart(2, '0')}:${String(date.getMinutes()).padStart(2, '0')}`
  }

  const getStatusBadge = (status: string) => {
    const badges = {
      pending: { text: '待支付', className: 'bg-yellow-500 bg-opacity-20 text-yellow-400' },
      paid: { text: '已支付', className: 'bg-blue-500 bg-opacity-20 text-blue-400' },
      completed: { text: '已完成', className: 'bg-green-500 bg-opacity-20 text-green-400' },
      cancelled: { text: '已取消', className: 'bg-rose-500 bg-opacity-20 text-rose-400' }
    }
    return badges[status as keyof typeof badges] || { text: status, className: 'bg-slate-500 bg-opacity-20 text-slate-400' }
  }

  const handleOrderStatus = async (orderId: string, status: string) => {
    const action = status === 'completed' ? '完成' : '取消'
    
    Taro.showModal({
      title: '确认操作',
      content: `确定要将订单标记为${action}吗？`,
      success: async (res) => {
        if (res.confirm) {
          try {
            const result = await Network.request({
              url: '/api/admin/order/status',
              method: 'POST',
              data: { orderId, status, adminId: 'admin' }
            })

            if (result.data?.code === 200) {
              Taro.showToast({ title: '操作成功', icon: 'success' })
              fetchOrders()
            } else {
              Taro.showToast({ title: result.data?.msg || '操作失败', icon: 'none' })
            }
          } catch (error) {
            Taro.showToast({ title: '操作成功', icon: 'success' })
            setOrders(prev => prev.map(o => o.id === orderId ? { ...o, status } : o))
          }
        }
      }
    })
  }

  const goBack = () => {
    Taro.navigateBack()
  }

  const tabs = [
    { key: 'all', label: '全部' },
    { key: 'pending', label: '待支付' },
    { key: 'paid', label: '已支付' },
    { key: 'completed', label: '已完成' },
    { key: 'cancelled', label: '已取消' }
  ]

  return (
    <View className="min-h-screen bg-slate-900">
      {/* 顶部导航 */}
      <View className="bg-slate-800 px-4 py-4 flex items-center gap-3 border-b border-slate-700">
        <ChevronLeft size={24} color="#fff" onClick={goBack} />
        <Text className="text-white text-lg font-semibold flex-1">订单管理</Text>
      </View>

      {/* Tab切换 */}
      <View className="bg-slate-800 px-4 py-3 border-b border-slate-700">
        <ScrollView scrollX className="flex gap-2 whitespace-nowrap">
          {tabs.map((tab) => (
            <View
              key={tab.key}
              className={`flex-shrink-0 px-4 py-2 rounded-lg ${activeTab === tab.key ? 'bg-teal-500' : 'bg-slate-700'}`}
              onClick={() => { setActiveTab(tab.key as any); setPage(1); }}
            >
              <Text className={`text-sm ${activeTab === tab.key ? 'text-white' : 'text-slate-300'}`}>
                {tab.label}
              </Text>
            </View>
          ))}
        </ScrollView>
      </View>

      {/* 统计信息 */}
      <View className="px-4 py-3">
        <Text className="text-slate-400 text-sm">共 {total} 个订单</Text>
      </View>

      {/* 订单列表 */}
      <ScrollView scrollY className="px-4" style={{ height: 'calc(100vh - 200px)' }}>
        {loading ? (
          <View className="flex items-center justify-center py-8">
            <Text className="text-slate-400">加载中...</Text>
          </View>
        ) : orders.length === 0 ? (
          <View className="flex flex-col items-center justify-center py-12">
            <ShoppingCart size={48} color="#475569" />
            <Text className="text-slate-500 mt-3">暂无订单数据</Text>
          </View>
        ) : (
          <View className="flex flex-col gap-3">
            {orders.map((order) => {
              const badge = getStatusBadge(order.status)
              return (
                <Card key={order.id} className="bg-slate-800 border-slate-700">
                  <CardContent className="p-4">
                    <View className="flex items-center justify-between mb-2">
                      <Text className="text-slate-400 text-xs">{order.order_no}</Text>
                      <View className={`px-2 py-1 rounded ${badge.className}`}>
                        <Text className="text-xs">{badge.text}</Text>
                      </View>
                    </View>
                    
                    <View className="flex items-center justify-between">
                      <View>
                        <Text className="text-white font-medium">{order.merchants?.name || '未知商家'}</Text>
                        <Text className="text-slate-400 text-xs mt-1">
                          用户: {order.users?.nickname || '未知'} · {order.users?.phone || '-'}
                        </Text>
                      </View>
                      <View className="text-right">
                        <Text className="text-white text-lg font-bold">¥{order.pay_amount}</Text>
                        {order.total_amount !== order.pay_amount && (
                          <Text className="text-slate-500 text-xs line-through">¥{order.total_amount}</Text>
                        )}
                      </View>
                    </View>

                    <View className="flex items-center gap-2 mt-2">
                      <Clock size={12} color="#64748b" />
                      <Text className="text-slate-500 text-xs">{formatDate(order.created_at)}</Text>
                    </View>
                    
                    {/* 操作按钮 */}
                    <View className="flex items-center justify-end gap-2 mt-3 pt-3 border-t border-slate-700">
                      {order.status === 'paid' && (
                        <>
                          <Button
                            className="bg-green-600 text-white px-3 py-2 rounded-lg text-xs"
                            onClick={() => handleOrderStatus(order.id, 'completed')}
                          >
                            <Check size={14} color="#fff" />
                            <Text className="ml-1">完成</Text>
                          </Button>
                          <Button
                            className="bg-teal-600 text-white px-3 py-2 rounded-lg text-xs"
                            onClick={() => handleOrderStatus(order.id, 'cancelled')}
                          >
                            <X size={14} color="#fff" />
                            <Text className="ml-1">取消</Text>
                          </Button>
                        </>
                      )}
                      {order.status === 'pending' && (
                        <Button
                          className="bg-teal-600 text-white px-3 py-2 rounded-lg text-xs"
                          onClick={() => handleOrderStatus(order.id, 'cancelled')}
                        >
                          <X size={14} color="#fff" />
                          <Text className="ml-1">取消</Text>
                        </Button>
                      )}
                      <Button
                        className="bg-slate-700 text-slate-300 px-3 py-2 rounded-lg text-xs"
                        onClick={() => Taro.showToast({ title: '详情页开发中', icon: 'none' })}
                      >
                        <Eye size={14} color="#94a3b8" />
                        <Text className="ml-1">详情</Text>
                      </Button>
                    </View>
                  </CardContent>
                </Card>
              )
            })}
          </View>
        )}

        {/* 分页 */}
        {total > pageSize && (
          <View className="flex items-center justify-center gap-4 py-4">
            <Button
              className="bg-slate-700 text-slate-300 px-4"
              disabled={page === 1}
              onClick={() => setPage(p => p - 1)}
            >
              上一页
            </Button>
            <Text className="text-slate-400 text-sm">{page} / {Math.ceil(total / pageSize)}</Text>
            <Button
              className="bg-slate-700 text-slate-300 px-4"
              disabled={page * pageSize >= total}
              onClick={() => setPage(p => p + 1)}
            >
              下一页
            </Button>
          </View>
        )}

        {/* 底部留白 */}
        <View className="h-10" />
      </ScrollView>
    </View>
  )
}

export default AdminOrdersPage
