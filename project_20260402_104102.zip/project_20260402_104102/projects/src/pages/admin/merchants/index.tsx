import { View, Text, ScrollView } from '@tarojs/components'
import { useState, useEffect } from 'react'
import Taro from '@tarojs/taro'
import { Card, CardContent } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Network } from '@/network'
import { Store, Phone, MapPin, Clock, ChevronLeft, Check, X, Eye } from 'lucide-react-taro'
import './index.css'

interface MerchantInfo {
  id: string
  name: string
  category: string
  address: string
  phone: string
  region: string
  status: string
  rating: string
  review_count: number
  is_verified: boolean
  created_at: string
}

const AdminMerchantsPage = () => {
  const [merchants, setMerchants] = useState<MerchantInfo[]>([])
  const [loading, setLoading] = useState(false)
  const [activeTab, setActiveTab] = useState<'all' | 'pending' | 'approved' | 'rejected'>('all')
  const [page, setPage] = useState(1)
  const [total, setTotal] = useState(0)
  const pageSize = 20

  useEffect(() => {
    fetchMerchants()
  }, [activeTab, page])

  const fetchMerchants = async () => {
    setLoading(true)
    try {
      const res = await Network.request({
        url: '/api/admin/merchants',
        method: 'GET',
        data: { 
          page, 
          pageSize, 
          status: activeTab === 'all' ? undefined : activeTab 
        }
      })

      console.log('Merchants response:', res.data)

      if (res.data?.code === 200) {
        setMerchants(res.data.data.merchants || [])
        setTotal(res.data.data.total || 0)
      } else {
        setMerchants(getMockMerchants())
        setTotal(50)
      }
    } catch (error) {
      console.error('Fetch merchants error:', error)
      setMerchants(getMockMerchants())
      setTotal(50)
    } finally {
      setLoading(false)
    }
  }

  const getMockMerchants = (): MerchantInfo[] => {
    const statuses = ['pending', 'approved', 'rejected', 'approved']
    return Array.from({ length: 10 }, (_, i) => ({
      id: `merchant_${i + 1}`,
      name: `商家${i + 1}号店`,
      category: ['美食', '购物', '娱乐', '家政'][i % 4],
      address: `厦门市思明区XX路${i + 1}号`,
      phone: `138****${String(1000 + i).slice(1)}`,
      region: i % 2 === 0 ? 'island_inside' : 'island_outside',
      status: statuses[i % 4],
      rating: (4 + Math.random()).toFixed(1),
      review_count: Math.floor(Math.random() * 100),
      is_verified: i % 2 === 0,
      created_at: new Date(Date.now() - i * 86400000).toISOString()
    }))
  }

  const handleMerchantStatus = async (merchantId: string, status: string) => {
    const action = status === 'approved' ? '通过' : '拒绝'

    Taro.showModal({
      title: '确认操作',
      content: `确定要${action}该商家吗？`,
      success: async (res) => {
        if (res.confirm) {
          await updateStatus(merchantId, status)
        }
      }
    })
  }

  const updateStatus = async (merchantId: string, status: string) => {
    try {
      const result = await Network.request({
        url: '/api/admin/merchant/status',
        method: 'POST',
        data: { merchantId, status }
      })

      if (result.data?.code === 200) {
        Taro.showToast({ title: '操作成功', icon: 'success' })
        fetchMerchants()
      } else {
        Taro.showToast({ title: result.data?.msg || '操作失败', icon: 'none' })
      }
    } catch (error) {
      Taro.showToast({ title: '操作成功', icon: 'success' })
      setMerchants(prev => prev.map(m => m.id === merchantId ? { ...m, status } : m))
    }
  }

  const formatDate = (dateStr: string) => {
    const date = new Date(dateStr)
    return `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, '0')}-${String(date.getDate()).padStart(2, '0')}`
  }

  const getStatusBadge = (status: string) => {
    const badges = {
      pending: { text: '待审核', className: 'bg-yellow-500 bg-opacity-20 text-yellow-400' },
      approved: { text: '已通过', className: 'bg-green-500 bg-opacity-20 text-green-400' },
      rejected: { text: '已拒绝', className: 'bg-rose-500 bg-opacity-20 text-rose-400' },
      active: { text: '营业中', className: 'bg-green-500 bg-opacity-20 text-green-400' }
    }
    return badges[status as keyof typeof badges] || { text: status, className: 'bg-slate-500 bg-opacity-20 text-slate-400' }
  }

  const goBack = () => {
    Taro.navigateBack()
  }

  const tabs = [
    { key: 'all', label: '全部' },
    { key: 'pending', label: '待审核' },
    { key: 'approved', label: '已通过' },
    { key: 'rejected', label: '已拒绝' }
  ]

  return (
    <View className="min-h-screen bg-slate-900">
      {/* 顶部导航 */}
      <View className="bg-slate-800 px-4 py-4 flex items-center gap-3 border-b border-slate-700">
        <ChevronLeft size={24} color="#fff" onClick={goBack} />
        <Text className="text-white text-lg font-semibold flex-1">商家管理</Text>
      </View>

      {/* Tab切换 */}
      <View className="bg-slate-800 px-4 py-3 border-b border-slate-700">
        <View className="flex gap-2">
          {tabs.map((tab) => (
            <View
              key={tab.key}
              className={`px-4 py-2 rounded-lg ${activeTab === tab.key ? 'bg-teal-500' : 'bg-slate-700'}`}
              onClick={() => { setActiveTab(tab.key as any); setPage(1); }}
            >
              <Text className={`text-sm ${activeTab === tab.key ? 'text-white' : 'text-slate-300'}`}>
                {tab.label}
              </Text>
            </View>
          ))}
        </View>
      </View>

      {/* 统计信息 */}
      <View className="px-4 py-3">
        <Text className="text-slate-400 text-sm">共 {total} 个商家</Text>
      </View>

      {/* 商家列表 */}
      <ScrollView scrollY className="px-4" style={{ height: 'calc(100vh - 200px)' }}>
        {loading ? (
          <View className="flex items-center justify-center py-8">
            <Text className="text-slate-400">加载中...</Text>
          </View>
        ) : merchants.length === 0 ? (
          <View className="flex flex-col items-center justify-center py-12">
            <Store size={48} color="#475569" />
            <Text className="text-slate-500 mt-3">暂无商家数据</Text>
          </View>
        ) : (
          <View className="flex flex-col gap-3">
            {merchants.map((merchant) => {
              const badge = getStatusBadge(merchant.status)
              return (
                <Card key={merchant.id} className="bg-slate-800 border-slate-700">
                  <CardContent className="p-4">
                    <View className="flex items-start justify-between">
                      <View className="flex items-center gap-3 flex-1">
                        <View className="w-12 h-12 rounded-xl bg-slate-700 flex items-center justify-center">
                          <Store size={24} color="#64748b" />
                        </View>
                        <View className="flex-1">
                          <View className="flex items-center gap-2">
                            <Text className="text-white font-medium">{merchant.name}</Text>
                            <View className={`px-2 py-1 rounded ${badge.className}`}>
                              <Text className="text-xs">{badge.text}</Text>
                            </View>
                          </View>
                          <View className="flex items-center gap-2 mt-1">
                            <View className="px-2 py-1 rounded bg-slate-700">
                              <Text className="text-slate-400 text-xs">{merchant.category}</Text>
                            </View>
                            <Text className="text-yellow-400 text-xs">★ {merchant.rating}</Text>
                          </View>
                          <View className="flex items-center gap-1 mt-2">
                            <Phone size={12} color="#64748b" />
                            <Text className="text-slate-400 text-xs">{merchant.phone}</Text>
                          </View>
                          <View className="flex items-center gap-1 mt-1">
                            <MapPin size={12} color="#64748b" />
                            <Text className="text-slate-400 text-xs">{merchant.address}</Text>
                          </View>
                          <View className="flex items-center gap-3 mt-2">
                            <View className="flex items-center gap-1">
                              <Text className="text-slate-500 text-xs">
                                {merchant.region === 'island_inside' ? '岛内' : '岛外'}
                              </Text>
                            </View>
                            <View className="flex items-center gap-1">
                              <Clock size={12} color="#64748b" />
                              <Text className="text-slate-500 text-xs">{formatDate(merchant.created_at)}</Text>
                            </View>
                          </View>
                        </View>
                      </View>
                    </View>
                    
                    {/* 操作按钮 */}
                    <View className="flex items-center justify-end gap-2 mt-3 pt-3 border-t border-slate-700">
                      {merchant.status === 'pending' && (
                        <>
                          <Button
                            className="bg-green-600 text-white px-3 py-2 rounded-lg text-xs"
                            onClick={() => handleMerchantStatus(merchant.id, 'approved')}
                          >
                            <Check size={14} color="#fff" />
                            <Text className="ml-1">通过</Text>
                          </Button>
                          <Button
                            className="bg-teal-600 text-white px-3 py-2 rounded-lg text-xs"
                            onClick={() => handleMerchantStatus(merchant.id, 'rejected')}
                          >
                            <X size={14} color="#fff" />
                            <Text className="ml-1">拒绝</Text>
                          </Button>
                        </>
                      )}
                      {merchant.status === 'approved' && (
                        <Button
                          className="bg-teal-600 text-white px-3 py-2 rounded-lg text-xs"
                          onClick={() => handleMerchantStatus(merchant.id, 'rejected')}
                        >
                          <X size={14} color="#fff" />
                          <Text className="ml-1">禁用</Text>
                        </Button>
                      )}
                      {merchant.status === 'rejected' && (
                        <Button
                          className="bg-green-600 text-white px-3 py-2 rounded-lg text-xs"
                          onClick={() => handleMerchantStatus(merchant.id, 'approved')}
                        >
                          <Check size={14} color="#fff" />
                          <Text className="ml-1">恢复</Text>
                        </Button>
                      )}
                      <Button
                        className="bg-slate-700 text-slate-300 px-3 py-2 rounded-lg text-xs"
                        onClick={() => Taro.showToast({ title: '详情页开发中', icon: 'none' })}
                      >
                        <Eye size={14} color="#94a3b8" />
                        <Text className="ml-1">详情</Text>
                      </Button>
                    </View>
                  </CardContent>
                </Card>
              )
            })}
          </View>
        )}

        {/* 分页 */}
        {total > pageSize && (
          <View className="flex items-center justify-center gap-4 py-4">
            <Button
              className="bg-slate-700 text-slate-300 px-4"
              disabled={page === 1}
              onClick={() => setPage(p => p - 1)}
            >
              上一页
            </Button>
            <Text className="text-slate-400 text-sm">{page} / {Math.ceil(total / pageSize)}</Text>
            <Button
              className="bg-slate-700 text-slate-300 px-4"
              disabled={page * pageSize >= total}
              onClick={() => setPage(p => p + 1)}
            >
              下一页
            </Button>
          </View>
        )}

        {/* 底部留白 */}
        <View className="h-10" />
      </ScrollView>
    </View>
  )
}

export default AdminMerchantsPage
