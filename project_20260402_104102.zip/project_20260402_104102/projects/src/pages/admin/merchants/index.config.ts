export default typeof definePageConfig === 'function'
  ? definePageConfig({ navigationBarTitleText: '商家管理' })
  : { navigationBarTitleText: '商家管理' }
