import { View, Text } from '@tarojs/components'
import Taro from '@tarojs/taro'
import { useState, useEffect } from 'react'
import { Card, CardContent } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { useUserStore } from '@/stores/user'
import { Network } from '@/network'
import {
  ShieldCheck,
  Smartphone,
  Lock,
  ChevronRight,
  CircleAlert
} from 'lucide-react-taro'

interface SecurityInfo {
  hasPassword: boolean
  hasPhone: boolean
  phone?: string
}

export default function AccountSecurityPage() {
  const { userInfo } = useUserStore()
  const [securityInfo, setSecurityInfo] = useState<SecurityInfo>({
    hasPassword: false,
    hasPhone: false
  })
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    loadSecurityInfo()
  }, [])

  // 获取安全信息
  const loadSecurityInfo = async () => {
    try {
      const res = await Network.request({
        url: `/api/auth/security-info?userId=${userInfo?.id}`
      })

      if (res.data.code === 200) {
        setSecurityInfo(res.data.data)
      }
    } catch (error) {
      console.error('Load security info error:', error)
    } finally {
      setLoading(false)
    }
  }

  // 计算安全等级
  const getSecurityLevel = () => {
    let score = 0
    if (securityInfo.hasPhone) score += 50
    if (securityInfo.hasPassword) score += 50
    return score
  }

  const securityLevel = getSecurityLevel()

  // 导航到相关页面
  const navigateTo = (page: string) => {
    Taro.navigateTo({ url: `/pages/settings/${page}` })
  }

  return (
    <View className="min-h-screen bg-stone-50">
      {/* 安全评分卡片 */}
      <View className="mx-4 mt-4">
        <Card className="bg-gradient-to-br from-teal-500 to-teal-600 border-0">
          <CardContent className="p-6">
            <View className="flex items-center justify-between mb-4">
              <Text className="text-white text-sm">账号安全评分</Text>
              <Badge style={{ backgroundColor: 'rgba(255,255,255,0.2)' }} className="text-white border-0">
                {securityLevel >= 80 ? '安全' : securityLevel >= 50 ? '一般' : '危险'}
              </Badge>
            </View>

            <View className="flex items-end gap-2 mb-4">
              <Text className="text-white text-5xl font-bold">{securityLevel}</Text>
              <Text style={{ color: 'rgba(255,255,255,0.8)' }} className="text-lg mb-2">分</Text>
            </View>

            <View style={{ backgroundColor: 'rgba(255,255,255,0.2)' }} className="rounded-full h-2 overflow-hidden">
              <View
                className="h-full bg-white rounded-full"
                style={{ width: `${securityLevel}%` }}
              />
            </View>

            {securityLevel < 100 && (
              <View className="mt-4 flex items-start gap-2">
                <CircleAlert size={16} color="#fff" />
                <Text style={{ color: 'rgba(255,255,255,0.8)' }} className="text-xs flex-1">
                  建议完善安全设置，提高账号安全性
                </Text>
              </View>
            )}
          </CardContent>
        </Card>
      </View>

      {/* 安全设置列表 */}
      <View className="mx-4 mt-6">
        <Text className="text-sm text-slate-500 mb-2 block px-2">安全设置</Text>

        <Card className="rounded-2xl overflow-hidden">
          <CardContent className="p-0">
            {/* 手机号绑定 */}
            <View
              className="flex items-center px-4 py-4 border-b border-slate-100"
              onClick={() => navigateTo('bind-phone')}
            >
              <View className="w-10 h-10 rounded-xl flex items-center justify-center bg-teal-50">
                <Smartphone size={20} color="#14B8A6" />
              </View>
              <View className="flex-1 ml-3">
                <Text className="text-sm font-medium block">手机号</Text>
                <Text className="text-xs text-slate-400">
                  {securityInfo.hasPhone
                    ? `已绑定 ${securityInfo.phone?.replace(/(\d{3})\d{4}(\d{4})/, '$1****$2')}`
                    : '未绑定'}
                </Text>
              </View>
              <Badge className={securityInfo.hasPhone ? 'bg-green-50 text-green-600 border-0' : 'bg-amber-50 text-amber-600 border-0'}>
                {securityInfo.hasPhone ? '已设置' : '未设置'}
              </Badge>
              <ChevronRight size={20} color="#d1d5db" className="ml-2" />
            </View>

            {/* 登录密码 */}
            <View
              className="flex items-center px-4 py-4"
              onClick={() => navigateTo('change-password')}
            >
              <View className="w-10 h-10 rounded-xl flex items-center justify-center bg-teal-50">
                <Lock size={20} color="#14B8A6" />
              </View>
              <View className="flex-1 ml-3">
                <Text className="text-sm font-medium block">登录密码</Text>
                <Text className="text-xs text-slate-400">
                  {securityInfo.hasPassword ? '已设置，定期修改可提高安全性' : '未设置'}
                </Text>
              </View>
              <Badge className={securityInfo.hasPassword ? 'bg-green-50 text-green-600 border-0' : 'bg-amber-50 text-amber-600 border-0'}>
                {securityInfo.hasPassword ? '已设置' : '未设置'}
              </Badge>
              <ChevronRight size={20} color="#d1d5db" className="ml-2" />
            </View>
          </CardContent>
        </Card>
      </View>

      {/* 安全提示 */}
      <View className="mx-4 mt-6">
        <Text className="text-sm text-slate-500 mb-2 block px-2">安全提示</Text>

        <Card className="rounded-2xl">
          <CardContent className="p-4">
            <View className="flex items-start gap-3">
              <ShieldCheck size={20} color="#14B8A6" />
              <View className="flex-1">
                <Text className="text-sm font-medium block mb-2">如何保护账号安全？</Text>
                <Text className="text-xs text-slate-500 block">• 绑定手机号，可用于找回密码</Text>
                <Text className="text-xs text-slate-500 block">• 设置复杂密码，定期更换</Text>
                <Text className="text-xs text-slate-500 block">• 不要将账号密码告知他人</Text>
                <Text className="text-xs text-slate-500 block">• 发现账号异常及时修改密码</Text>
              </View>
            </View>
          </CardContent>
        </Card>
      </View>

      {/* 加载状态 */}
      {loading && (
        <View style={{ backgroundColor: 'rgba(255,255,255,0.8)' }} className="fixed inset-0 flex items-center justify-center">
          <Text className="text-slate-400">加载中...</Text>
        </View>
      )}
    </View>
  )
}
