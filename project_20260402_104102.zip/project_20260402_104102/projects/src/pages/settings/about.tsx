import { View, Text, ScrollView } from '@tarojs/components'
import Taro from '@tarojs/taro'
import { Card, CardContent } from '@/components/ui/card'

import './about.css'

const AboutPage = () => {
  const handleCopy = (text: string) => {
    Taro.setClipboardData({
      data: text,
      success: () => {
        Taro.showToast({ title: '已复制', icon: 'success' })
      }
    })
  }

  return (
    <View className="min-h-screen bg-zinc-50">
      <ScrollView scrollY className="h-screen">
        {/* Logo 和版本 */}
        <View className="flex flex-col items-center pt-10 pb-6">
          <View className="w-20 h-20 rounded-2xl bg-teal-500 flex items-center justify-center mb-3">
            <Text className="text-white text-2xl font-bold">厦</Text>
          </View>
          <Text className="text-lg font-bold text-zinc-800 block">厦门本地生活</Text>
          <Text className="text-xs text-zinc-400 mt-1">版本 1.0.0</Text>
        </View>

        {/* 简介 */}
        <View className="px-4">
          <Card>
            <CardContent className="p-4">
              <Text className="text-sm text-zinc-600 leading-6">
                厦门本地生活是一款专注于厦门本地的AI智能导购平台。我们通过AI技术为用户提供个性化推荐，帮助用户发现厦门最地道的美食、最优惠的活动。
              </Text>
              <Text className="text-sm text-zinc-600 leading-6 mt-3">
                支持岛内/岛外分区运营，精准匹配本地商家与用户，打造厦门最优质的本地生活服务平台。
              </Text>
            </CardContent>
          </Card>
        </View>

        {/* 特色功能 */}
        <View className="px-4 mt-4">
          <Text className="text-xs text-zinc-400 px-1 py-2 block">特色功能</Text>
          <Card>
            <CardContent className="p-4">
              <View className="grid grid-cols-2 gap-4">
                <View className="bg-teal-50 rounded-lg p-3">
                  <Text className="text-teal-500 font-semibold text-sm block">AI 智能导购</Text>
                  <Text className="text-zinc-500 text-xs mt-1">个性化推荐，精准匹配</Text>
                </View>
                <View className="bg-blue-50 rounded-lg p-3">
                  <Text className="text-blue-500 font-semibold text-sm block">岛内外分区</Text>
                  <Text className="text-zinc-500 text-xs mt-1">精准本地服务</Text>
                </View>
                <View className="bg-green-50 rounded-lg p-3">
                  <Text className="text-green-500 font-semibold text-sm block">裂变红包</Text>
                  <Text className="text-zinc-500 text-xs mt-1">邀请好友得奖励</Text>
                </View>
                <View className="bg-yellow-50 rounded-lg p-3">
                  <Text className="text-yellow-500 font-semibold text-sm block">到店核销</Text>
                  <Text className="text-zinc-500 text-xs mt-1">零配送，省心省力</Text>
                </View>
              </View>
            </CardContent>
          </Card>
        </View>

        {/* 联系方式 */}
        <View className="px-4 mt-4">
          <Text className="text-xs text-zinc-400 px-1 py-2 block">联系我们</Text>
          <Card>
            <CardContent className="p-0">
              <View
                className="flex items-center justify-between px-4 py-3 border-b border-zinc-100"
                onClick={() => handleCopy('400-888-8888')}
              >
                <View className="flex items-center gap-3">
                  📞
                  <Text className="text-sm text-zinc-700">客服电话</Text>
                </View>
                <Text className="text-xs text-zinc-400">400-888-8888</Text>
              </View>
              <View
                className="flex items-center justify-between px-4 py-3 border-b border-zinc-100"
                onClick={() => handleCopy('service@xiamen-life.com')}
              >
                <View className="flex items-center gap-3">
                  📧
                  <Text className="text-sm text-zinc-700">客服邮箱</Text>
                </View>
                <Text className="text-xs text-zinc-400">service@xiamen-life.com</Text>
              </View>
              <View
                className="flex items-center justify-between px-4 py-3"
                onClick={() => handleCopy('www.xiamen-life.com')}
              >
                <View className="flex items-center gap-3">
                  🌐
                  <Text className="text-sm text-zinc-700">官方网站</Text>
                </View>
                <Text className="text-xs text-zinc-400">www.xiamen-life.com</Text>
              </View>
            </CardContent>
          </Card>
        </View>

        {/* 版权信息 */}
        <View className="text-center py-8">
          <Text className="text-xs text-zinc-300 block">Copyright © 2024 厦门本地生活</Text>
          <Text className="text-xs text-zinc-300 block mt-1">All Rights Reserved</Text>
        </View>

        {/* 底部留白 */}
        <View className="h-10" />
      </ScrollView>
    </View>
  )
}

export default AboutPage
