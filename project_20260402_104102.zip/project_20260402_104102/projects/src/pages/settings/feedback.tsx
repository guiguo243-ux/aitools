import { View, Text, ScrollView, Radio, RadioGroup } from '@tarojs/components'
import { useState } from 'react'
import Taro from '@tarojs/taro'
import { Card, CardContent } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Textarea } from '@/components/ui/textarea'
import './feedback.css'

const feedbackTypes = [
  { id: 'bug', name: '功能异常' },
  { id: 'suggestion', name: '建议反馈' },
  { id: 'complaint', name: '投诉举报' },
  { id: 'other', name: '其他' }
]

const FeedbackPage = () => {
  const [feedbackType, setFeedbackType] = useState('suggestion')
  const [content, setContent] = useState('')
  const [contact, setContact] = useState('')
  const [submitting, setSubmitting] = useState(false)

  const handleSubmit = async () => {
    if (!content.trim()) {
      Taro.showToast({ title: '请输入反馈内容', icon: 'none' })
      return
    }

    if (content.length < 10) {
      Taro.showToast({ title: '反馈内容至少10个字', icon: 'none' })
      return
    }

    setSubmitting(true)
    try {
      // 模拟提交
      await new Promise(resolve => setTimeout(resolve, 1000))
      
      Taro.showToast({ title: '提交成功', icon: 'success' })
      setTimeout(() => {
        Taro.navigateBack()
      }, 1500)
    } catch (error) {
      Taro.showToast({ title: '提交失败', icon: 'none' })
    } finally {
      setSubmitting(false)
    }
  }

  return (
    <View className="min-h-screen bg-zinc-50">
      <ScrollView scrollY className="h-screen">
        {/* 反馈类型 */}
        <View className="mt-3 px-4">
          <Text className="text-xs text-zinc-400 py-2 block">反馈类型</Text>
          <Card>
            <CardContent className="p-0">
              <RadioGroup
                className="flex flex-wrap gap-2 p-4"
                onChange={(e) => setFeedbackType(e.detail.value)}
              >
                {feedbackTypes.map((type) => (
                  <View
                    key={type.id}
                    className={`px-4 py-2 rounded-full border ${
                      feedbackType === type.id
                        ? 'border-teal-500 bg-teal-50'
                        : 'border-zinc-200 bg-white'
                    }`}
                    onClick={() => setFeedbackType(type.id)}
                  >
                    <Radio
                      value={type.id}
                      checked={feedbackType === type.id}
                      color="#FF6B35"
                      className="hidden"
                    />
                    <Text
                      className={`text-sm ${
                        feedbackType === type.id ? 'text-teal-500' : 'text-zinc-600'
                      }`}
                    >
                      {type.name}
                    </Text>
                  </View>
                ))}
              </RadioGroup>
            </CardContent>
          </Card>
        </View>

        {/* 反馈内容 */}
        <View className="mt-4 px-4">
          <Text className="text-xs text-zinc-400 py-2 block">反馈内容</Text>
          <Card>
            <CardContent className="p-4">
              <Textarea
                className="w-full min-h-[150px] text-sm"
                placeholder="请详细描述您遇到的问题或建议，以便我们更好地为您服务..."
                maxlength={500}
                value={content}
                onInput={(e) => setContent(e.detail.value)}
              />
              <View className="flex justify-end mt-2">
                <Text className="text-xs text-zinc-400">{content.length}/500</Text>
              </View>
            </CardContent>
          </Card>
        </View>

        {/* 联系方式 */}
        <View className="mt-4 px-4">
          <Text className="text-xs text-zinc-400 py-2 block">联系方式（选填）</Text>
          <Card>
            <CardContent className="p-4">
              <Textarea
                className="w-full min-h-[60px] text-sm"
                placeholder="请输入您的手机号或微信号，方便我们联系您"
                maxlength={50}
                value={contact}
                onInput={(e) => setContact(e.detail.value)}
              />
            </CardContent>
          </Card>
        </View>

        {/* 提示 */}
        <View className="mt-4 px-4">
          <Text className="text-xs text-zinc-400 block">
            温馨提示：您的反馈将在1-3个工作日内处理，感谢您的支持与理解。
          </Text>
        </View>

        {/* 提交按钮 */}
        <View className="px-4 py-6">
          <Button
            className="w-full bg-teal-500 text-white"
            disabled={submitting || !content.trim()}
            onClick={handleSubmit}
          >
            {submitting ? '提交中...' : '提交反馈'}
          </Button>
        </View>

        {/* 底部留白 */}
        <View className="h-10" />
      </ScrollView>
    </View>
  )
}

export default FeedbackPage
