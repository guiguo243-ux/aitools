import { View, Text } from '@tarojs/components'
import Taro from '@tarojs/taro'
import { useState, useEffect } from 'react'
import { Card, CardContent } from '@/components/ui/card'
import { Check } from 'lucide-react-taro'

const LANGUAGES = [
  { code: 'zh-CN', name: '简体中文', local: '中文（简体）' },
  { code: 'zh-TW', name: '繁體中文', local: '中文（繁體）' },
  { code: 'en', name: 'English', local: 'English' },
  { code: 'ja', name: '日本語', local: '日本語' },
  { code: 'ko', name: '한국어', local: '한국어' }
]

export default function LanguageSettingsPage() {
  const [currentLang, setCurrentLang] = useState('zh-CN')

  useEffect(() => {
    // 从存储中获取当前语言设置
    const savedLang = Taro.getStorageSync('language') || 'zh-CN'
    setCurrentLang(savedLang)
  }, [])

  const selectLanguage = (code: string) => {
    if (code === currentLang) return

    Taro.showModal({
      title: '切换语言',
      content: '切换语言后需要重启应用才能生效，是否切换？',
      success: (res) => {
        if (res.confirm) {
          Taro.setStorageSync('language', code)
          setCurrentLang(code)
          Taro.showToast({ title: '设置成功', icon: 'success' })
        }
      }
    })
  }

  return (
    <View className="min-h-screen bg-stone-50">
      {/* 提示 */}
      <View className="mx-4 mt-4 px-2">
        <Text className="text-xs text-slate-400">
          选择您偏好的语言，切换后需要重启应用才能生效
        </Text>
      </View>

      {/* 语言列表 */}
      <View className="mx-4 mt-4">
        <Card className="rounded-2xl overflow-hidden">
          <CardContent className="p-0">
            {LANGUAGES.map((lang, index) => (
              <View
                key={lang.code}
                className={`flex items-center justify-between px-4 py-4 ${
                  index < LANGUAGES.length - 1 ? 'border-b border-slate-100' : ''
                }`}
                onClick={() => selectLanguage(lang.code)}
              >
                <View>
                  <Text className="text-sm font-medium block">{lang.name}</Text>
                  <Text className="text-xs text-slate-400">{lang.local}</Text>
                </View>
                {currentLang === lang.code && (
                  <Check size={20} color="#14B8A6" />
                )}
              </View>
            ))}
          </CardContent>
        </Card>
      </View>

      {/* 说明 */}
      <View className="mx-4 mt-6 px-2">
        <Text className="text-xs text-slate-400 block">
          当前支持的语言版本有限，部分内容可能仍显示为中文。
        </Text>
      </View>
    </View>
  )
}
