import { View, Text, ScrollView } from '@tarojs/components'
import { useState, ReactNode } from 'react'
import Taro from '@tarojs/taro'
import { Card, CardContent } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Switch } from '@/components/ui/switch'
import { useUserStore } from '@/stores/user'
import { Network } from '@/network'
import { User, Smartphone, Lock, Shield, Bell, MessageSquare, Globe, FileText, CircleQuestionMark, Info, ChevronRight, Trash2 } from 'lucide-react-taro'
import './index.css'

// 设置项组件
interface SettingItemProps {
  icon: ReactNode
  title: string
  value?: string
  showArrow?: boolean
  showSwitch?: boolean
  switchValue?: boolean
  onSwitchChange?: (value: boolean) => void
  onClick?: () => void
  isLast?: boolean
}

const SettingItem = ({
  icon,
  title,
  value,
  showArrow = true,
  showSwitch = false,
  switchValue = false,
  onSwitchChange,
  onClick,
  isLast = false
}: SettingItemProps) => (
  <View
    className={`flex items-center justify-between px-4 py-3 ${!isLast ? 'border-b border-slate-100' : ''}`}
    onClick={showSwitch ? undefined : onClick}
  >
    <View className="flex items-center gap-3">
      {icon}
      <Text className="text-sm text-slate-700">{title}</Text>
    </View>
    <View className="flex items-center gap-2">
      {value && <Text className="text-xs text-slate-400">{value}</Text>}
      {showSwitch && (
        <Switch
          checked={switchValue}
          onCheckedChange={(checked) => onSwitchChange?.(checked)}
        />
      )}
      {showArrow && !showSwitch && <ChevronRight size={18} color="#cbd5e1" />}
    </View>
  </View>
)

const SettingsPage = () => {
  const { logout, isLoggedIn } = useUserStore()
  const [notificationSettings, setNotificationSettings] = useState({
    orderNotice: true,
    promotionNotice: true,
    systemNotice: false
  })

  const handleLogout = () => {
    if (!isLoggedIn) {
      Taro.showToast({ title: '您还未登录', icon: 'none' })
      return
    }

    Taro.showModal({
      title: '提示',
      content: '确定要退出登录吗？',
      success: async (res) => {
        if (res.confirm) {
          try {
            // 调用后端退出接口
            const userId = useUserStore.getState().userInfo?.id
            if (userId) {
              await Network.request({
                url: '/api/auth/logout',
                method: 'POST',
                data: { userId }
              })
            }

            // 调用 store 的 logout 方法清除本地状态
            logout()
            
            // 提示退出成功
            Taro.showToast({ 
              title: '已退出登录', 
              icon: 'success',
              duration: 1500
            })
            
            // 延迟跳转到首页
            setTimeout(() => {
              Taro.reLaunch({ url: '/pages/index/index' })
            }, 1500)
          } catch (error) {
            console.error('Logout error:', error)
            // 即使接口失败，也清除本地状态
            logout()
            Taro.reLaunch({ url: '/pages/index/index' })
          }
        }
      }
    })
  }

  const goToPage = (page: string) => {
    Taro.navigateTo({ url: page })
  }

  const clearCache = () => {
    Taro.showModal({
      title: '清除缓存',
      content: '确定要清除本地缓存吗？',
      success: (res) => {
        if (res.confirm) {
          Taro.clearStorage({
            success: () => {
              Taro.showToast({ title: '清除成功', icon: 'success' })
            }
          })
        }
      }
    })
  }

  return (
    <View className="min-h-screen bg-stone-50">
      <ScrollView scrollY className="h-screen">
        {/* 账号设置 */}
        <View className="mt-3">
          <Text className="text-xs text-slate-400 px-4 py-2 block">账号设置</Text>
          <Card className="rounded-2xl overflow-hidden">
            <CardContent className="p-0">
              <SettingItem
                icon={<User size={18} color="#14B8A6" />}
                title="个人信息"
                value="已完善"
                onClick={() => goToPage('/pages/edit-profile/index')}
              />
              <SettingItem
                icon={<Smartphone size={18} color="#14B8A6" />}
                title="绑定手机"
                value="138****8888"
                onClick={() => goToPage('/pages/settings/bind-phone')}
              />
              <SettingItem
                icon={<Lock size={18} color="#14B8A6" />}
                title="修改密码"
                onClick={() => goToPage('/pages/settings/change-password')}
              />
              <SettingItem
                icon={<Shield size={18} color="#14B8A6" />}
                title="账号安全"
                onClick={() => goToPage('/pages/settings/account-security')}
                isLast
              />
            </CardContent>
          </Card>
        </View>

        {/* 消息通知设置 */}
        <View className="mt-4">
          <Text className="text-xs text-slate-400 px-4 py-2 block">消息通知</Text>
          <Card className="rounded-2xl overflow-hidden">
            <CardContent className="p-0">
              <SettingItem
                icon={<Bell size={18} color="#14B8A6" />}
                title="订单通知"
                showSwitch
                switchValue={notificationSettings.orderNotice}
                onSwitchChange={(value) => 
                  setNotificationSettings({ ...notificationSettings, orderNotice: value })
                }
              />
              <SettingItem
                icon={<MessageSquare size={18} color="#14B8A6" />}
                title="优惠活动通知"
                showSwitch
                switchValue={notificationSettings.promotionNotice}
                onSwitchChange={(value) => 
                  setNotificationSettings({ ...notificationSettings, promotionNotice: value })
                }
              />
              <SettingItem
                icon={<Bell size={18} color="#14B8A6" />}
                title="系统消息通知"
                showSwitch
                switchValue={notificationSettings.systemNotice}
                onSwitchChange={(value) => 
                  setNotificationSettings({ ...notificationSettings, systemNotice: value })
                }
                isLast
              />
            </CardContent>
          </Card>
        </View>

        {/* 其他设置 */}
        <View className="mt-4">
          <Text className="text-xs text-slate-400 px-4 py-2 block">其他设置</Text>
          <Card className="rounded-2xl overflow-hidden">
            <CardContent className="p-0">
              <SettingItem
                icon={<Globe size={18} color="#14B8A6" />}
                title="语言设置"
                value="简体中文"
                onClick={() => goToPage('/pages/settings/language')}
              />
              <SettingItem
                icon={<FileText size={18} color="#14B8A6" />}
                title="用户协议"
                onClick={() => goToPage('/pages/agreement/index?type=user')}
              />
              <SettingItem
                icon={<FileText size={18} color="#14B8A6" />}
                title="隐私政策"
                onClick={() => goToPage('/pages/agreement/index?type=privacy')}
              />
              <SettingItem
                icon={<CircleQuestionMark size={18} color="#14B8A6" />}
                title="帮助与反馈"
                onClick={() => goToPage('/pages/settings/feedback')}
              />
              <SettingItem
                icon={<Info size={18} color="#14B8A6" />}
                title="关于我们"
                onClick={() => goToPage('/pages/settings/about')}
                isLast
              />
            </CardContent>
          </Card>
        </View>

        {/* 清除缓存 */}
        <View className="mt-4">
          <Card className="rounded-2xl overflow-hidden">
            <CardContent className="p-0">
              <View
                className="flex items-center justify-between px-4 py-3"
                onClick={clearCache}
              >
                <View className="flex items-center gap-3">
                  <Trash2 size={18} color="#14B8A6" />
                  <Text className="text-sm text-slate-700">清除缓存</Text>
                </View>
                <Text className="text-xs text-slate-400">12.5 MB</Text>
              </View>
            </CardContent>
          </Card>
        </View>

        {/* 退出登录按钮 */}
        <View className="px-4 py-6">
          <Button
            className="w-full bg-white border border-slate-200 text-teal-500 rounded-full"
            onClick={handleLogout}
          >
            退出登录
          </Button>
        </View>

        {/* 版本信息 */}
        <View className="text-center pb-8">
          <Text className="text-xs text-slate-300">版本号 v1.0.0</Text>
        </View>

        {/* 底部留白 */}
        <View className="h-10" />
      </ScrollView>
    </View>
  )
}

export default SettingsPage
