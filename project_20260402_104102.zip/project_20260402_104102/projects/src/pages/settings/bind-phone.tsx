import { View, Text } from '@tarojs/components'
import Taro from '@tarojs/taro'
import { useState } from 'react'
import { Card, CardContent } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { useUserStore } from '@/stores/user'
import { Network } from '@/network'
import { Smartphone, ShieldCheck } from 'lucide-react-taro'

export default function BindPhonePage() {
  const { userInfo } = useUserStore()
  const [phone, setPhone] = useState('')
  const [code, setCode] = useState('')
  const [loading, setLoading] = useState(false)
  const [countdown, setCountdown] = useState(0)

  // 发送验证码
  const sendCode = async () => {
    if (!phone || !/^1[3-9]\d{9}$/.test(phone)) {
      Taro.showToast({ title: '请输入正确的手机号', icon: 'none' })
      return
    }

    if (countdown > 0) return

    try {
      const res = await Network.request({
        url: '/api/auth/send-code',
        method: 'POST',
        data: { phone }
      })

      if (res.data.code === 200) {
        Taro.showToast({ title: '验证码已发送', icon: 'success' })
        // 开始倒计时
        setCountdown(60)
        const timer = setInterval(() => {
          setCountdown(prev => {
            if (prev <= 1) {
              clearInterval(timer)
              return 0
            }
            return prev - 1
          })
        }, 1000)
      } else {
        Taro.showToast({ title: res.data.msg || '发送失败', icon: 'none' })
      }
    } catch (error) {
      Taro.showToast({ title: '发送失败', icon: 'none' })
    }
  }

  // 绑定手机号
  const handleBind = async () => {
    if (!phone || !/^1[3-9]\d{9}$/.test(phone)) {
      Taro.showToast({ title: '请输入正确的手机号', icon: 'none' })
      return
    }

    if (!code || code.length !== 6) {
      Taro.showToast({ title: '请输入6位验证码', icon: 'none' })
      return
    }

    setLoading(true)
    try {
      const res = await Network.request({
        url: '/api/auth/bind-phone',
        method: 'POST',
        data: {
          userId: userInfo?.id,
          phone,
          code
        }
      })

      if (res.data.code === 200) {
        Taro.showToast({ title: '绑定成功', icon: 'success' })
        setTimeout(() => {
          Taro.navigateBack()
        }, 1500)
      } else {
        Taro.showToast({ title: res.data.msg || '绑定失败', icon: 'none' })
      }
    } catch (error) {
      Taro.showToast({ title: '绑定失败', icon: 'none' })
    } finally {
      setLoading(false)
    }
  }

  return (
    <View className="min-h-screen bg-stone-50">
      {/* 说明卡片 */}
      <View className="mx-4 mt-4">
        <Card className="bg-gradient-to-r from-teal-500 to-teal-600 border-0">
          <CardContent className="p-4 flex items-center gap-3">
            <View className="w-12 h-12 rounded-full flex items-center justify-center" style={{ backgroundColor: 'rgba(255,255,255,0.2)' }}>
              <Smartphone size={24} color="#fff" />
            </View>
            <View className="flex-1">
              <Text className="text-white font-semibold block">绑定手机号</Text>
              <Text className="text-white text-xs opacity-80">绑定后可用于账号安全验证和密码找回</Text>
            </View>
          </CardContent>
        </Card>
      </View>

      {/* 表单 */}
      <View className="mx-4 mt-4">
        <Card className="rounded-2xl overflow-hidden">
          <CardContent className="p-0">
            {/* 手机号输入 */}
            <View className="flex items-center px-4 py-4 border-b border-slate-100">
              <Text className="text-sm text-slate-500 w-20">手机号</Text>
              <Input
                className="flex-1"
                type="number"
                maxlength={11}
                placeholder="请输入手机号"
                value={phone}
                onInput={(e) => setPhone(e.detail.value)}
              />
            </View>

            {/* 验证码输入 */}
            <View className="flex items-center px-4 py-4">
              <Text className="text-sm text-slate-500 w-20">验证码</Text>
              <Input
                className="flex-1"
                type="number"
                maxlength={6}
                placeholder="请输入验证码"
                value={code}
                onInput={(e) => setCode(e.detail.value)}
              />
              <View
                className={`px-3 py-2 rounded-lg ${countdown > 0 ? 'bg-slate-100' : 'bg-teal-50'}`}
                onClick={sendCode}
              >
                <Text className={`text-sm ${countdown > 0 ? 'text-slate-400' : 'text-teal-600'}`}>
                  {countdown > 0 ? `${countdown}s` : '获取验证码'}
                </Text>
              </View>
            </View>
          </CardContent>
        </Card>
      </View>

      {/* 提示 */}
      <View className="mx-4 mt-4 px-2">
        <View className="flex items-start gap-2">
          <ShieldCheck size={16} color="#14B8A6" />
          <Text className="text-xs text-slate-400 flex-1">
            绑定手机号后，您可以使用手机号登录，并通过手机验证码重置密码
          </Text>
        </View>
      </View>

      {/* 提交按钮 */}
      <View className="mx-4 mt-8">
        <Button
          className="w-full bg-teal-500 text-white rounded-full py-3"
          onClick={handleBind}
          disabled={loading}
        >
          {loading ? '绑定中...' : '确认绑定'}
        </Button>
      </View>
    </View>
  )
}
