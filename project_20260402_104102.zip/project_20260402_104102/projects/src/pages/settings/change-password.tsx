import { View, Text } from '@tarojs/components'
import Taro from '@tarojs/taro'
import { useState, useEffect } from 'react'
import { Card, CardContent } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { useUserStore } from '@/stores/user'
import { Network } from '@/network'
import { Lock, ShieldCheck, Eye, EyeOff } from 'lucide-react-taro'

export default function ChangePasswordPage() {
  const { userInfo } = useUserStore()
  const [hasPassword, setHasPassword] = useState(false)
  const [loading, setLoading] = useState(false)

  // 表单数据
  const [oldPassword, setOldPassword] = useState('')
  const [newPassword, setNewPassword] = useState('')
  const [confirmPassword, setConfirmPassword] = useState('')
  const [code, setCode] = useState('')
  const [countdown, setCountdown] = useState(0)

  // 密码显示状态
  const [showOldPassword, setShowOldPassword] = useState(false)
  const [showNewPassword, setShowNewPassword] = useState(false)
  const [showConfirmPassword, setShowConfirmPassword] = useState(false)

  useEffect(() => {
    loadSecurityInfo()
  }, [])

  // 获取安全信息
  const loadSecurityInfo = async () => {
    try {
      const res = await Network.request({
        url: `/api/auth/security-info?userId=${userInfo?.id}`
      })

      if (res.data.code === 200) {
        setHasPassword(res.data.data.hasPassword)
      }
    } catch (error) {
      console.error('Load security info error:', error)
    }
  }

  // 发送验证码
  const sendCode = async () => {
    if (countdown > 0) return

    if (!userInfo?.phone) {
      Taro.showToast({ title: '请先绑定手机号', icon: 'none' })
      return
    }

    try {
      const res = await Network.request({
        url: '/api/auth/send-code',
        method: 'POST',
        data: { phone: userInfo.phone }
      })

      if (res.data.code === 200) {
        Taro.showToast({ title: '验证码已发送', icon: 'success' })
        setCountdown(60)
        const timer = setInterval(() => {
          setCountdown(prev => {
            if (prev <= 1) {
              clearInterval(timer)
              return 0
            }
            return prev - 1
          })
        }, 1000)
      } else {
        Taro.showToast({ title: res.data.msg || '发送失败', icon: 'none' })
      }
    } catch (error) {
      Taro.showToast({ title: '发送失败', icon: 'none' })
    }
  }

  // 提交
  const handleSubmit = async () => {
    // 验证
    if (hasPassword && !oldPassword) {
      Taro.showToast({ title: '请输入原密码', icon: 'none' })
      return
    }

    if (!newPassword || newPassword.length < 6) {
      Taro.showToast({ title: '密码长度需要6-20位', icon: 'none' })
      return
    }

    if (newPassword !== confirmPassword) {
      Taro.showToast({ title: '两次密码不一致', icon: 'none' })
      return
    }

    if (!hasPassword && !code) {
      Taro.showToast({ title: '请输入验证码', icon: 'none' })
      return
    }

    setLoading(true)
    try {
      const url = hasPassword ? '/api/auth/change-password' : '/api/auth/set-password'
      const data = hasPassword
        ? { userId: userInfo?.id, oldPassword, newPassword }
        : { userId: userInfo?.id, password: newPassword, code }

      const res = await Network.request({
        url,
        method: 'POST',
        data
      })

      if (res.data.code === 200) {
        Taro.showToast({ title: '设置成功', icon: 'success' })
        setTimeout(() => {
          Taro.navigateBack()
        }, 1500)
      } else {
        Taro.showToast({ title: res.data.msg || '设置失败', icon: 'none' })
      }
    } catch (error) {
      Taro.showToast({ title: '设置失败', icon: 'none' })
    } finally {
      setLoading(false)
    }
  }

  return (
    <View className="min-h-screen bg-stone-50">
      {/* 说明卡片 */}
      <View className="mx-4 mt-4">
        <Card className="bg-gradient-to-r from-teal-500 to-teal-600 border-0">
          <CardContent className="p-4 flex items-center gap-3">
            <View className="w-12 h-12 rounded-full flex items-center justify-center" style={{ backgroundColor: 'rgba(255,255,255,0.2)' }}>
              <Lock size={24} color="#fff" />
            </View>
            <View className="flex-1">
              <Text className="text-white font-semibold block">
                {hasPassword ? '修改登录密码' : '设置登录密码'}
              </Text>
              <Text className="text-white text-xs opacity-80">
                {hasPassword ? '定期修改密码可以提高账号安全性' : '设置密码后可以使用密码登录'}
              </Text>
            </View>
          </CardContent>
        </Card>
      </View>

      {/* 表单 */}
      <View className="mx-4 mt-4">
        <Card className="rounded-2xl overflow-hidden">
          <CardContent className="p-0">
            {/* 原密码（已设置密码时显示） */}
            {hasPassword && (
              <View className="flex items-center px-4 py-4 border-b border-slate-100">
                <Text className="text-sm text-slate-500 w-24">原密码</Text>
                <View className="flex-1 flex items-center">
                  <Input
                    className="flex-1"
                    password={!showOldPassword}
                    placeholder="请输入原密码"
                    value={oldPassword}
                    onInput={(e) => setOldPassword(e.detail.value)}
                  />
                  <View onClick={() => setShowOldPassword(!showOldPassword)}>
                    {showOldPassword ? (
                      <EyeOff size={20} color="#9ca3af" />
                    ) : (
                      <Eye size={20} color="#9ca3af" />
                    )}
                  </View>
                </View>
              </View>
            )}

            {/* 验证码（首次设置时显示） */}
            {!hasPassword && (
              <View className="flex items-center px-4 py-4 border-b border-slate-100">
                <Text className="text-sm text-slate-500 w-24">验证码</Text>
                <Input
                  className="flex-1"
                  type="number"
                  maxlength={6}
                  placeholder="请输入验证码"
                  value={code}
                  onInput={(e) => setCode(e.detail.value)}
                />
                <View
                  className={`px-3 py-2 rounded-lg ${countdown > 0 ? 'bg-slate-100' : 'bg-teal-50'}`}
                  onClick={sendCode}
                >
                  <Text className={`text-sm ${countdown > 0 ? 'text-slate-400' : 'text-teal-600'}`}>
                    {countdown > 0 ? `${countdown}s` : '获取验证码'}
                  </Text>
                </View>
              </View>
            )}

            {/* 新密码 */}
            <View className="flex items-center px-4 py-4 border-b border-slate-100">
              <Text className="text-sm text-slate-500 w-24">新密码</Text>
              <View className="flex-1 flex items-center">
                <Input
                  className="flex-1"
                  password={!showNewPassword}
                  placeholder="请输入新密码（6-20位）"
                  value={newPassword}
                  onInput={(e) => setNewPassword(e.detail.value)}
                />
                <View onClick={() => setShowNewPassword(!showNewPassword)}>
                  {showNewPassword ? (
                    <EyeOff size={20} color="#9ca3af" />
                  ) : (
                    <Eye size={20} color="#9ca3af" />
                  )}
                </View>
              </View>
            </View>

            {/* 确认密码 */}
            <View className="flex items-center px-4 py-4">
              <Text className="text-sm text-slate-500 w-24">确认密码</Text>
              <View className="flex-1 flex items-center">
                <Input
                  className="flex-1"
                  password={!showConfirmPassword}
                  placeholder="请再次输入新密码"
                  value={confirmPassword}
                  onInput={(e) => setConfirmPassword(e.detail.value)}
                />
                <View onClick={() => setShowConfirmPassword(!showConfirmPassword)}>
                  {showConfirmPassword ? (
                    <EyeOff size={20} color="#9ca3af" />
                  ) : (
                    <Eye size={20} color="#9ca3af" />
                  )}
                </View>
              </View>
            </View>
          </CardContent>
        </Card>
      </View>

      {/* 提示 */}
      <View className="mx-4 mt-4 px-2">
        <View className="flex items-start gap-2">
          <ShieldCheck size={16} color="#14B8A6" />
          <View className="flex-1">
            <Text className="text-xs text-slate-400 block">密码要求：</Text>
            <Text className="text-xs text-slate-400 block">• 长度6-20位</Text>
            <Text className="text-xs text-slate-400 block">• 建议使用字母、数字和符号的组合</Text>
          </View>
        </View>
      </View>

      {/* 提交按钮 */}
      <View className="mx-4 mt-8">
        <Button
          className="w-full bg-teal-500 text-white rounded-full py-3"
          onClick={handleSubmit}
          disabled={loading}
        >
          {loading ? '提交中...' : '确认'}
        </Button>
      </View>
    </View>
  )
}
