import { create } from 'zustand'
import Taro from '@tarojs/taro'

// 用户信息类型
export interface UserInfo {
  id: string
  openid?: string
  nickname: string
  avatar?: string
  phone?: string
  region: string
  referrer_id?: string
  points: number
  balance: number
  created_at: string
}

// 登录状态
interface AuthState {
  isLoggedIn: boolean
  token: string | null
  userInfo: UserInfo | null
  
  // Actions
  setToken: (token: string) => void
  setUserInfo: (info: UserInfo) => void
  login: (token: string, user: UserInfo) => void
  logout: () => void
  updateUserInfo: (info: Partial<UserInfo>) => void
  
  // Persistence
  loadFromStorage: () => void
  saveToStorage: () => void
}

export const useUserStore = create<AuthState>((set, get) => ({
  isLoggedIn: false,
  token: null,
  userInfo: null,

  setToken: (token) => {
    set({ token, isLoggedIn: !!token })
    get().saveToStorage()
  },

  setUserInfo: (info) => {
    set({ userInfo: info, isLoggedIn: true })
    get().saveToStorage()
  },

  login: (token, user) => {
    set({
      token,
      userInfo: user,
      isLoggedIn: true
    })
    get().saveToStorage()
  },

  logout: () => {
    set({
      isLoggedIn: false,
      token: null,
      userInfo: null
    })
    // 清除本地存储
    Taro.removeStorageSync('token')
    Taro.removeStorageSync('userInfo')
  },

  updateUserInfo: (info) => {
    const currentInfo = get().userInfo
    if (currentInfo) {
      const newInfo = { ...currentInfo, ...info }
      set({ userInfo: newInfo })
      get().saveToStorage()
    }
  },

  loadFromStorage: () => {
    try {
      const token = Taro.getStorageSync('token')
      const userInfoStr = Taro.getStorageSync('userInfo')
      
      if (token && userInfoStr) {
        const userInfo = JSON.parse(userInfoStr)
        set({
          token,
          userInfo,
          isLoggedIn: true
        })
      }
    } catch (error) {
      console.error('Load auth from storage error:', error)
    }
  },

  saveToStorage: () => {
    const { token, userInfo } = get()
    
    try {
      if (token) {
        Taro.setStorageSync('token', token)
      }
      if (userInfo) {
        Taro.setStorageSync('userInfo', JSON.stringify(userInfo))
      }
    } catch (error) {
      console.error('Save auth to storage error:', error)
    }
  }
}))

// 初始化时加载存储的登录状态
export const initAuth = () => {
  useUserStore.getState().loadFromStorage()
}
