/**
 * 厦门本地知识库（纯到店核销版）
 * 用于AI导购的本地化数据和话术
 */

// 区域与商圈绑定
export interface DistrictArea {
  district: string        // 行政区
  regionType: 'island_inside' | 'island_outside'  // 岛内/岛外
  businessAreas: string[] // 商圈列表
  landmarks: string[]     // 地标
  storeDensity: string    // 到店商家密度描述
}

export const XIAMEN_DISTRICTS: DistrictArea[] = [
  {
    district: '思明区',
    regionType: 'island_inside',
    businessAreas: ['中山路商圈', '沙坡尾', '曾厝垵', '软件园二期', '莲坂商圈', '瑞景商圈'],
    landmarks: ['鼓浪屿', '南普陀寺', '厦门大学', '环岛路', '白城沙滩', '胡里山炮台'],
    storeDensity: '到店商家密集，老字号集中'
  },
  {
    district: '湖里区',
    regionType: 'island_inside',
    businessAreas: ['五缘湾', 'SM城市广场', '湖里老街', '高崎机场商圈', '江头商圈'],
    landmarks: ['五缘湾湿地公园', '厦门机场', '湖里公园', '仙岳山'],
    storeDensity: '写字楼集中，企业团餐首选'
  },
  {
    district: '集美区',
    regionType: 'island_outside',
    businessAreas: ['集美学村', '杏林湾', '软件园三期', '万达广场'],
    landmarks: ['集美学村', '龙舟池', '园博苑', '灵玲马戏城'],
    storeDensity: '学村周边美食聚集'
  },
  {
    district: '海沧区',
    regionType: 'island_outside',
    businessAreas: ['海沧湾', '阿罗海城市广场', '新阳工业区'],
    landmarks: ['海沧大桥', '天竺山', '日月谷温泉'],
    storeDensity: '社区配套完善，家庭消费首选'
  },
  {
    district: '同安区',
    regionType: 'island_outside',
    businessAreas: ['同安老城区', '工业集中区', 'BRT沿线'],
    landmarks: ['同安古城', '梵天寺', '影视城', '北辰山'],
    storeDensity: '本地老字号众多，性价比高'
  },
  {
    district: '翔安区',
    regionType: 'island_outside',
    businessAreas: ['翔安新城', '新店商圈', '大学城'],
    landmarks: ['翔安隧道', '香山', '大嶝岛'],
    storeDensity: '新兴商圈，到店优惠多'
  }
]

// 品类专属标签（纯到店版）
export interface CategoryTag {
  id: string
  name: string
  icon: string
  description: string
  suitableFor: string[]  // 适合的场景
  peakTimes: string[]    // 到店高峰时段
}

export const CATEGORY_TAGS: CategoryTag[] = [
  {
    id: 'minnan_food',
    name: '闽南美食',
    icon: '🍜',
    description: '地道闽南味，到店堂食更香',
    suitableFor: ['家庭聚餐', '朋友聚会', '游客打卡'],
    peakTimes: ['11:00-13:00', '17:00-20:00']
  },
  {
    id: 'seafood_stall',
    name: '海鲜排档',
    icon: '🦀',
    description: '新鲜海产，到店现点现做',
    suitableFor: ['家庭聚餐', '朋友聚会', '商务宴请'],
    peakTimes: ['17:00-21:00']
  },
  {
    id: 'local_fresh',
    name: '本地生鲜',
    icon: '🥬',
    description: '岛内外直供，到店自提更新鲜',
    suitableFor: ['日常采购', '家庭做饭'],
    peakTimes: ['07:00-09:00', '16:00-18:00']
  },
  {
    id: 'night_food',
    name: '深夜食堂',
    icon: '🌙',
    description: '夜猫子福音，到店氛围好',
    suitableFor: ['夜宵', '加班', '追剧'],
    peakTimes: ['22:00-02:00']
  },
  {
    id: 'life_service',
    name: '生活服务',
    icon: '💆',
    description: '到店体验，服务更专业',
    suitableFor: ['美容美发', '按摩SPA', '健身'],
    peakTimes: ['10:00-22:00']
  },
  {
    id: 'group_meal',
    name: '企业团餐',
    icon: '🍱',
    description: '写字楼专属，到店聚餐更实惠',
    suitableFor: ['企业午餐', '会议餐', '团建'],
    peakTimes: ['11:30-13:00', '18:00-19:30']
  }
]

// AI到店逼单话术模板（纯到店核销版）
export interface InstoreUrgencyTemplate {
  scenario: string           // 场景
  templates: string[]        // 话术模板
  variables: string[]        // 可替换变量
}

export const INSTORE_URGENCY_TEMPLATES: InstoreUrgencyTemplate[] = [
  {
    scenario: '区域匹配到店',
    templates: [
      '您在{district}，这家{name}{category}是本区域到店好评TOP{rank}，到店核销立减{discount}元，券有效期{valid_hours}小时～',
      '{district}本地宝藏店！{name}到店专属价已上线，本区域用户专享，到店直接核销，跨区无法使用～'
    ],
    variables: ['district', 'name', 'category', 'rank', 'discount', 'valid_hours']
  },
  {
    scenario: '到店库存稀缺',
    templates: [
      '今日{product_name}到店名额仅剩{stock}个，到店核销立享{discount}折优惠，手慢无～',
      '限时到店福利！{product_name}仅剩{stock}个到店名额，过期作废，建议提前锁定～'
    ],
    variables: ['stock', 'product_name', 'discount']
  },
  {
    scenario: '到店时效紧迫',
    templates: [
      '距店铺打烊还有{hours_left}小时，现在锁单到店立减{discount_amount}元，错过等明天～',
      '今日最后{hours_left}小时！{name}到店专属套餐，到店核销直接用，简单方便～'
    ],
    variables: ['hours_left', 'discount_amount', 'name']
  },
  {
    scenario: '本地到店热度',
    templates: [
      '{business_area}到店人气TOP{rank}！{name}本地人都在排队，线上下单到店免排队，核销秒完成～',
      '厦门本地老字号！{name}传承{years}年，{district}区域到店专享价，比到店直接付更便宜～'
    ],
    variables: ['business_area', 'rank', 'name', 'years', 'district']
  },
  {
    scenario: '新店到店福利',
    templates: [
      '新店开业到店福利！{name}入驻{days}天，到店核销{discount}折起，首单再减{first_discount}元～',
      '首单到店立减{first_discount}元！{name}刚入驻，到店尝鲜价，本区域用户专享～'
    ],
    variables: ['name', 'days', 'discount', 'first_discount']
  },
  {
    scenario: '到店比价优势',
    templates: [
      '比到店直接付便宜{compare_amount}元！{name}同等品质更实惠，线上锁价到店核销～',
      '大众点评{rating}分，我们这里到店下单再省{discount_amount}元，到店直接用～'
    ],
    variables: ['compare_amount', 'name', 'rating', 'discount_amount']
  },
  {
    scenario: '到店裂变引导',
    templates: [
      '分享好友一起到店，两人都得专属到店券，{district}区域可用，到店核销立享～',
      '组队到店更优惠！找{need_count}位{district}好友拼单到店，核销再减{group_discount}元～'
    ],
    variables: ['district', 'need_count', 'group_discount']
  }
]

// 商家本地标签（纯到店版）
export interface MerchantLocalTag {
  id: string
  name: string
  icon: string
  color: string
  description: string
}

export const MERCHANT_LOCAL_TAGS: MerchantLocalTag[] = [
  { id: 'old_brand', name: '本地老字号', icon: '🏆', color: '#FF6B35', description: '本地经营5年以上' },
  { id: 'top_rated', name: '到店好评如潮', icon: '⭐', color: '#EAB308', description: '到店好评率95%以上' },
  { id: 'instore_hot', name: '到店人气王', icon: '🔥', color: '#EF4444', description: '到店客流持续火爆' },
  { id: 'local_favorite', name: '本地人最爱', icon: '❤️', color: '#EC4899', description: '本地用户复购率高' },
  { id: 'new_store', name: '新店到店福利', icon: '🎁', color: '#10B981', description: '入驻30天内到店特惠' },
  { id: 'night_owl', name: '深夜营业', icon: '🌙', color: '#8B5CF6', description: '营业至凌晨，到店宵夜好去处' },
  { id: 'group_friendly', name: '聚餐首选', icon: '👥', color: '#06B6D4', description: '适合多人到店聚餐' },
  { id: 'family_friendly', name: '家庭友好', icon: '👨‍👩‍👧‍👦', color: '#F59E0B', description: '适合家庭到店消费' }
]

// 到店裂变话术模板
export interface InstoreShareTemplate {
  type: 'island_inside' | 'island_outside'
  title: string
  content: string
  callToAction: string
}

export const INSTORE_SHARE_TEMPLATES: InstoreShareTemplate[] = [
  {
    type: 'island_inside',
    title: '厦门岛内到店福利',
    content: '厦门思明/湖里本地福利！AI精选宝藏店，扫码领岛内到店专属券，到店核销立减，分享好友双方都得红包～',
    callToAction: '扫码领到店专属券'
  },
  {
    type: 'island_outside',
    title: '厦门岛外到店福利',
    content: '集美/海沧街坊看过来！AI推荐本地好店，岛外到店专享价，扫码领券，到店即用，分享裂变多省一笔～',
    callToAction: '扫码领到店专属券'
  }
]

// 获取区域类型
export function getRegionType(district: string): 'island_inside' | 'island_outside' {
  const found = XIAMEN_DISTRICTS.find(d => d.district === district)
  return found?.regionType || 'island_inside'
}

// 获取商圈列表
export function getBusinessAreas(district: string): string[] {
  const found = XIAMEN_DISTRICTS.find(d => d.district === district)
  return found?.businessAreas || []
}

// 获取最近商圈
export function getNearestBusinessArea(district: string): string {
  const areas = getBusinessAreas(district)
  return areas[0] || '市中心'
}

// 生成到店逼单话术
export function generateInstoreUrgencyMessage(
  scenario: string,
  params: Record<string, string | number>
): string {
  const template = INSTORE_URGENCY_TEMPLATES.find(t => t.scenario === scenario)
  if (!template) return ''
  
  let message = template.templates[Math.floor(Math.random() * template.templates.length)]
  
  // 替换变量
  Object.entries(params).forEach(([key, value]) => {
    message = message.replace(`{${key}}`, String(value))
  })
  
  return message
}

// 生成到店裂变分享话术
export function generateInstoreShareMessage(regionType: 'island_inside' | 'island_outside'): InstoreShareTemplate {
  return INSTORE_SHARE_TEMPLATES.find(t => t.type === regionType) || INSTORE_SHARE_TEMPLATES[0]
}

// 获取区域显示名称
export function getRegionDisplayName(regionType: 'island_inside' | 'island_outside'): string {
  return regionType === 'island_inside' ? '岛内' : '岛外'
}

// 判断是否跨区（用于到店核销限制）
export function isCrossRegionForInstore(
  userDistrict: string,
  merchantDistrict: string
): boolean {
  const userRegion = getRegionType(userDistrict)
  const merchantRegion = getRegionType(merchantDistrict)
  return userRegion !== merchantRegion
}

// 生成核销限制提示
export function generateInstoreRestrictionMessage(
  userDistrict: string,
  merchantDistrict: string
): string {
  const userRegion = getRegionType(userDistrict)
  const merchantRegion = getRegionType(merchantDistrict)
  
  if (userRegion !== merchantRegion) {
    const userRegionName = getRegionDisplayName(userRegion)
    const merchantRegionName = getRegionDisplayName(merchantRegion)
    return `⚠️ 此券仅限${merchantRegionName}到店核销\n\n您当前在${userRegionName}（${userDistrict}），商家位于${merchantRegionName}（${merchantDistrict}）\n\n跨区域到店券无法核销，建议选择您所在区域的到店商家～`
  }
  
  return ''
}

// 获取区域显示信息
export function getDistrictInfo(district: string): DistrictArea | undefined {
  return XIAMEN_DISTRICTS.find(d => d.district === district)
}
