// 模拟数据 - 厦门AI本地生活平台

export interface Category {
  id: number
  name: string
  icon: string
  description: string
}

export interface Merchant {
  id: string
  name: string
  category: string
  description: string
  address: string
  district: string
  phone: string
  businessHours: string
  imageUrl: string | null
  tags: string[]
  rating: string
  reviewCount: number
  region: 'island_inside' | 'island_outside'
  isVerified: boolean
  aiWeight: number
  distance?: string
}

// 分类数据
export const categories: Category[] = [
  { id: 1, name: '美食', icon: '🍽️', description: '餐饮美食、特色小吃' },
  { id: 2, name: '购物', icon: '🛒', description: '商场超市、特色商品' },
  { id: 3, name: '娱乐', icon: '🎮', description: '休闲娱乐、游玩景点' },
  { id: 4, name: '生活服务', icon: '🏠', description: '家政服务、维修保养' },
  { id: 5, name: '丽人', icon: '💄', description: '美容美发、美甲美睫' },
  { id: 6, name: '运动健身', icon: '🏃', description: '健身房、运动场馆' },
  { id: 7, name: '酒店住宿', icon: '🏨', description: '酒店民宿、短租公寓' },
  { id: 8, name: '教育培训', icon: '📚', description: '培训课程、兴趣爱好' },
]

// 岛内商家数据
export const islandInsideMerchants: Merchant[] = [
  {
    id: 'm001',
    name: '临家闽南菜（环岛路店）',
    category: '美食',
    description: '地道闽南菜，老字号餐厅，招牌姜母鸭、海蛎煎',
    address: '思明区环岛南路3068号',
    district: '思明区',
    phone: '0592-2567890',
    businessHours: '11:00-21:00',
    imageUrl: null,
    tags: ['闽南菜', '老字号', '家庭聚餐'],
    rating: '4.8',
    reviewCount: 1256,
    region: 'island_inside',
    isVerified: true,
    aiWeight: 100,
    distance: '1.2km',
  },
  {
    id: 'm002',
    name: '沙坡尾海鲜大排档',
    category: '美食',
    description: '新鲜海鲜，网红打卡地，性价比高',
    address: '思明区沙坡尾艺术西区',
    district: '思明区',
    phone: '0592-2098765',
    businessHours: '17:00-02:00',
    imageUrl: null,
    tags: ['海鲜', '大排档', '网红店'],
    rating: '4.6',
    reviewCount: 892,
    region: 'island_inside',
    isVerified: true,
    aiWeight: 90,
    distance: '2.3km',
  },
  {
    id: 'm003',
    name: '中山路老街小吃',
    category: '美食',
    description: '汇聚厦门特色小吃，沙茶面、土笋冻、花生汤',
    address: '思明区中山路步行街',
    district: '思明区',
    phone: '0592-2034567',
    businessHours: '08:00-22:00',
    imageUrl: null,
    tags: ['小吃', '特色美食', '步行街'],
    rating: '4.5',
    reviewCount: 2341,
    region: 'island_inside',
    isVerified: true,
    aiWeight: 85,
    distance: '1.8km',
  },
  {
    id: 'm004',
    name: '万象城购物中心',
    category: '购物',
    description: '高端购物中心，国际品牌齐全',
    address: '思明区湖滨东路99号',
    district: '思明区',
    phone: '0592-5558888',
    businessHours: '10:00-22:00',
    imageUrl: null,
    tags: ['购物', '商场', '高端'],
    rating: '4.7',
    reviewCount: 3567,
    region: 'island_inside',
    isVerified: true,
    aiWeight: 95,
    distance: '0.8km',
  },
  {
    id: 'm005',
    name: '湖里万达广场',
    category: '购物',
    description: '大型商业综合体，购物娱乐一体',
    address: '湖里区仙岳路4666号',
    district: '湖里区',
    phone: '0592-5666666',
    businessHours: '10:00-22:00',
    imageUrl: null,
    tags: ['购物', '商场', '亲子'],
    rating: '4.6',
    reviewCount: 2134,
    region: 'island_inside',
    isVerified: true,
    aiWeight: 85,
    distance: '3.5km',
  },
  {
    id: 'm006',
    name: '曾厝垵文创村',
    category: '娱乐',
    description: '文艺小店聚集地，适合拍照打卡',
    address: '思明区曾厝垵',
    district: '思明区',
    phone: '',
    businessHours: '全天开放',
    imageUrl: null,
    tags: ['文艺', '打卡', '文创'],
    rating: '4.4',
    reviewCount: 5678,
    region: 'island_inside',
    isVerified: true,
    aiWeight: 80,
    distance: '4.2km',
  },
]

// 岛外商家数据
export const islandOutsideMerchants: Merchant[] = [
  {
    id: 'm101',
    name: '集美学村美食街',
    category: '美食',
    description: '集美特色美食，学生党最爱',
    address: '集美区集美大道',
    district: '集美区',
    phone: '',
    businessHours: '10:00-22:00',
    imageUrl: null,
    tags: ['美食', '学生党', '性价比'],
    rating: '4.3',
    reviewCount: 567,
    region: 'island_outside',
    isVerified: true,
    aiWeight: 70,
    distance: '8.5km',
  },
  {
    id: 'm102',
    name: '海沧海鲜城',
    category: '美食',
    description: '新鲜海鲜，价格实惠',
    address: '海沧区海沧大道',
    district: '海沧区',
    phone: '0592-6567890',
    businessHours: '11:00-22:00',
    imageUrl: null,
    tags: ['海鲜', '实惠', '海沧'],
    rating: '4.5',
    reviewCount: 423,
    region: 'island_outside',
    isVerified: true,
    aiWeight: 75,
    distance: '12.3km',
  },
  {
    id: 'm103',
    name: '同安古城小吃',
    category: '美食',
    description: '同安传统美食，历史悠久',
    address: '同安区大同街道',
    district: '同安区',
    phone: '',
    businessHours: '06:00-20:00',
    imageUrl: null,
    tags: ['传统', '小吃', '老字号'],
    rating: '4.4',
    reviewCount: 789,
    region: 'island_outside',
    isVerified: true,
    aiWeight: 65,
    distance: '25.6km',
  },
  {
    id: 'm104',
    name: '集美万达广场',
    category: '购物',
    description: '岛外最大购物中心',
    address: '集美区银江路137号',
    district: '集美区',
    phone: '0592-6666666',
    businessHours: '10:00-22:00',
    imageUrl: null,
    tags: ['购物', '商场', '岛外'],
    rating: '4.5',
    reviewCount: 1456,
    region: 'island_outside',
    isVerified: true,
    aiWeight: 80,
    distance: '9.2km',
  },
  {
    id: 'm105',
    name: '翔安湿地公园',
    category: '娱乐',
    description: '自然生态公园，适合亲子游',
    address: '翔安区翔安东路',
    district: '翔安区',
    phone: '',
    businessHours: '06:00-18:00',
    imageUrl: null,
    tags: ['公园', '亲子', '自然'],
    rating: '4.3',
    reviewCount: 234,
    region: 'island_outside',
    isVerified: true,
    aiWeight: 60,
    distance: '18.7km',
  },
]

// 根据区域获取商家列表
export const getMerchantsByRegion = (region: 'island_inside' | 'island_outside'): Merchant[] => {
  return region === 'island_inside' ? islandInsideMerchants : islandOutsideMerchants
}

// 根据ID获取商家详情
export const getMerchantById = (id: string): Merchant | undefined => {
  return [...islandInsideMerchants, ...islandOutsideMerchants].find(m => m.id === id)
}

// 根据分类筛选商家
export const getMerchantsByCategory = (category: string, region: 'island_inside' | 'island_outside'): Merchant[] => {
  const merchants = getMerchantsByRegion(region)
  if (!category || category === '全部') return merchants
  return merchants.filter(m => m.category === category)
}

// 搜索商家
export const searchMerchants = (keyword: string, region: 'island_inside' | 'island_outside'): Merchant[] => {
  const merchants = getMerchantsByRegion(region)
  if (!keyword) return merchants
  const lowerKeyword = keyword.toLowerCase()
  return merchants.filter(m => 
    m.name.toLowerCase().includes(lowerKeyword) ||
    m.description.toLowerCase().includes(lowerKeyword) ||
    m.tags.some(t => t.toLowerCase().includes(lowerKeyword))
  )
}
