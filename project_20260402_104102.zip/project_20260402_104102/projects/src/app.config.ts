export default defineAppConfig({
  pages: [
    'pages/index/index',
    'pages/category/index',
    'pages/message/index',
    'pages/profile/index',
    'pages/login/index',
    'pages/ai-chat/index',
    'pages/merchant/detail',
    'pages/red-packet/index',
    'pages/referral/index',
    'pages/ranking/index',
    'pages/order/index',
    'pages/order/detail',
    'pages/order-confirm/index',
    'pages/wallet/index',
    'pages/address/index',
    'pages/address/edit',
    'pages/settings/index',
    'pages/settings/about',
    'pages/settings/feedback',
    'pages/settings/bind-phone',
    'pages/settings/change-password',
    'pages/settings/account-security',
    'pages/settings/language',
    'pages/review/index',
    'pages/review/create',
    'pages/search/index',
    'pages/favorite/index',
    'pages/coupon-center/index',
    'pages/edit-profile/index',
    'pages/refund/index',
    'pages/points-shop/index',
    'pages/points-records/index',
    'pages/member/index',
    'pages/group-buy/index',
    'pages/flash-sale/index',
    'pages/agreement/index',
    'pages/merchant/portal',
    'pages/merchant/apply',
    'pages/merchant/dashboard',
    'pages/merchant/products',
    'pages/merchant/product-edit',
    'pages/merchant/verification',
    'pages/merchant/settings',
    'pages/merchant/payment-settings',
    'pages/merchant/delivery-settings',
    'pages/merchant/notification-settings',
    'pages/admin/login/index',
    'pages/admin/dashboard/index',
    'pages/admin/users/index',
    'pages/admin/merchants/index',
    'pages/admin/orders/index',
    'pages/admin/coupons/index',
    'pages/admin/coupon-create',
    'pages/admin/system-config/index'
  ],
  window: {
    backgroundTextStyle: 'light',
    navigationBarBackgroundColor: '#ffffff',
    navigationBarTitleText: '厦门本地生活',
    navigationBarTextStyle: 'black'
  },
  tabBar: {
    color: '#94a3b8',
    selectedColor: '#14B8A6',
    backgroundColor: '#ffffff',
    borderStyle: 'black',
    list: [
      {
        pagePath: 'pages/index/index',
        text: '首页',
        iconPath: './assets/tabbar/house.png',
        selectedIconPath: './assets/tabbar/house-active.png'
      },
      {
        pagePath: 'pages/category/index',
        text: '分类',
        iconPath: './assets/tabbar/layout-grid.png',
        selectedIconPath: './assets/tabbar/layout-grid-active.png'
      },
      {
        pagePath: 'pages/message/index',
        text: '消息',
        iconPath: './assets/tabbar/message-circle.png',
        selectedIconPath: './assets/tabbar/message-circle-active.png'
      },
      {
        pagePath: 'pages/profile/index',
        text: '我的',
        iconPath: './assets/tabbar/user.png',
        selectedIconPath: './assets/tabbar/user-active.png'
      }
    ]
  }
})
