/**
 * AI导购服务（纯到店核销版）
 * 集成厦门本地知识库，提供个性化推荐和到店逼单话术
 */

import {
  XIAMEN_DISTRICTS,
  CATEGORY_TAGS,
  MERCHANT_LOCAL_TAGS,
  getRegionType,
  getBusinessAreas,
  generateInstoreUrgencyMessage,
  isCrossRegionForInstore,
  generateInstoreRestrictionMessage,
  type DistrictArea,
  type CategoryTag
} from '@/data/xiamen-local'

// AI到店推荐请求参数
export interface AIInstoreRecommendRequest {
  userId: string
  district: string
  businessArea?: string
  category?: string
  timeSlot?: 'breakfast' | 'lunch' | 'dinner' | 'night'
  scene?: 'solo' | 'family' | 'business' | 'date'
}

// AI到店推荐结果
export interface AIInstoreRecommendResult {
  merchants: InstoreMerchantRecommend[]
  urgencyMessages: string[]
  localTips: string[]
  crossRegionWarning?: {
    isCrossRegion: boolean
    userRegion: 'island_inside' | 'island_outside'
    merchantRegion: 'island_inside' | 'island_outside'
    restrictionMessage: string
  }
}

// 到店商家推荐
export interface InstoreMerchantRecommend {
  id: string
  name: string
  category: string
  district: string
  businessArea: string
  rating: number
  monthlyVisits: number      // 月到店客流
  distance: number           // 距离（公里）
  avgWaitTime: number        // 平均等位时间
  localTags: string[]
  instoreDiscount: number    // 到店专属优惠
  urgencyReason: string
  priority: number
}

/**
 * AI导购服务类（纯到店版）
 */
export class AIGuideService {
  /**
   * 获取AI到店推荐
   */
  async getInstoreRecommendations(params: AIInstoreRecommendRequest): Promise<AIInstoreRecommendResult> {
    const { district, businessArea, category, timeSlot, scene } = params
    const regionType = getRegionType(district)
    const nearbyBusinessAreas = businessArea ? [businessArea] : getBusinessAreas(district)

    // 1. 获取到店商家列表（模拟数据）
    const merchants = await this.fetchInstoreMerchants({
      district,
      businessAreas: nearbyBusinessAreas,
      category,
      regionType
    })

    // 2. 优先排序本地商家（同区域不展示跨区商家）
    const sortedMerchants = this.sortByLocality(merchants, district)

    // 3. 生成到店逼单话术
    const urgencyMessages = this.generateInstoreUrgencyMessages(sortedMerchants.slice(0, 3), district)

    // 4. 生成本地化到店提示
    const localTips = this.generateInstoreLocalTips(district, timeSlot, scene)

    // 5. 检测跨区域警告（用于提醒用户）
    const crossRegionWarning = this.checkCrossRegionForInstore(sortedMerchants[0], district)

    return {
      merchants: sortedMerchants.slice(0, 10),
      urgencyMessages,
      localTips,
      crossRegionWarning
    }
  }

  /**
   * 获取到店商家列表
   */
  private async fetchInstoreMerchants(params: {
    district: string
    businessAreas: string[]
    category?: string
    regionType: 'island_inside' | 'island_outside'
  }): Promise<InstoreMerchantRecommend[]> {
    // 返回模拟数据（实际应调用后端接口）
    return this.getMockInstoreMerchants(params.district)
  }

  /**
   * 按本地优先级排序（仅展示同区域到店商家）
   */
  private sortByLocality(
    merchants: InstoreMerchantRecommend[],
    userDistrict: string
  ): InstoreMerchantRecommend[] {
    const userRegion = getRegionType(userDistrict)
    
    // 只展示同区域的到店商家，跨区商家不展示
    return merchants
      .filter(m => getRegionType(m.district) === userRegion)
      .sort((a, b) => {
        // 1. 同区优先
        const aSameDistrict = a.district === userDistrict ? 1 : 0
        const bSameDistrict = b.district === userDistrict ? 1 : 0
        if (aSameDistrict !== bSameDistrict) {
          return bSameDistrict - aSameDistrict
        }

        // 2. 评分和到店客流排序
        return (b.rating * 10 + b.monthlyVisits / 100) - (a.rating * 10 + a.monthlyVisits / 100)
      })
  }

  /**
   * 生成到店逼单话术
   */
  private generateInstoreUrgencyMessages(
    merchants: InstoreMerchantRecommend[],
    userDistrict: string
  ): string[] {
    const messages: string[] = []

    merchants.forEach((merchant, index) => {
      const scenario = index === 0 ? '区域匹配到店' : 
                       merchant.localTags.includes('new_store') ? '新店到店福利' : 
                       '本地到店热度'
      
      const message = generateInstoreUrgencyMessage(scenario, {
        district: userDistrict,
        name: merchant.name,
        category: merchant.category,
        rank: index + 1,
        discount: merchant.instoreDiscount,
        valid_hours: 24,
        stock: Math.floor(Math.random() * 10) + 3,
        business_area: merchant.businessArea
      })

      if (message) {
        messages.push(message)
      }
    })

    return messages
  }

  /**
   * 生成本地化到店提示
   */
  private generateInstoreLocalTips(
    district: string,
    timeSlot?: string,
    scene?: string
  ): string[] {
    const tips: string[] = []
    const regionType = getRegionType(district)
    const districtInfo = XIAMEN_DISTRICTS.find(d => d.district === district)

    // 区域提示
    tips.push(`📍 您在${district}，附近热门到店商圈：${districtInfo?.businessAreas.slice(0, 3).join('、') || '市中心'}`)

    // 时段提示
    if (timeSlot) {
      const timeTips: Record<string, string> = {
        breakfast: '🌅 到店早餐推荐：闽南特色沙茶面、花生汤、面线糊',
        lunch: '☀️ 到店午餐高峰，建议提前锁位，到店免排队',
        dinner: '🌙 到店晚餐时段，提前下单锁定优惠，到店核销即享',
        night: '🌙 深夜到店宵夜，烧烤、海鲜排档营业中'
      }
      if (timeTips[timeSlot]) {
        tips.push(timeTips[timeSlot])
      }
    }

    // 场景提示
    if (scene) {
      const sceneTips: Record<string, string> = {
        solo: '👤 一人到店精选，小份量刚刚好',
        family: '👨‍👩‍👧‍👦 家庭到店聚餐，大桌预订+专属优惠',
        business: '💼 商务到店宴请，包间预订+高品质服务',
        date: '💕 约会到店首选，浪漫氛围感餐厅'
      }
      if (sceneTips[scene]) {
        tips.push(sceneTips[scene])
      }
    }

    // 岛内外提示
    if (regionType === 'island_inside') {
      tips.push('🏝️ 岛内用户专享：更多老字号到店优惠，堂食体验更佳')
    } else {
      tips.push('🌊 岛外用户专享：本地生鲜到店自提，企业团餐到店更实惠')
    }

    return tips
  }

  /**
   * 检测跨区域到店限制
   */
  private checkCrossRegionForInstore(
    merchant: InstoreMerchantRecommend,
    userDistrict: string
  ): AIInstoreRecommendResult['crossRegionWarning'] | undefined {
    if (!merchant) return undefined

    const isCross = isCrossRegionForInstore(userDistrict, merchant.district)
    if (!isCross) return undefined

    return {
      isCrossRegion: true,
      userRegion: getRegionType(userDistrict),
      merchantRegion: getRegionType(merchant.district),
      restrictionMessage: generateInstoreRestrictionMessage(userDistrict, merchant.district)
    }
  }

  /**
   * 获取品类标签
   */
  getCategoryTags(): CategoryTag[] {
    return CATEGORY_TAGS
  }

  /**
   * 获取商家本地标签
   */
  getMerchantLocalTags(): typeof MERCHANT_LOCAL_TAGS {
    return MERCHANT_LOCAL_TAGS
  }

  /**
   * 获取厦门区域信息
   */
  getDistrictInfo(district: string): DistrictArea | undefined {
    return XIAMEN_DISTRICTS.find(d => d.district === district)
  }

  /**
   * 模拟到店商家数据
   */
  private getMockInstoreMerchants(district: string): InstoreMerchantRecommend[] {
    const userRegion = getRegionType(district)
    
    const allMerchants: InstoreMerchantRecommend[] = [
      {
        id: '1',
        name: '老厦门沙茶面',
        category: '闽南美食',
        district: '思明区',
        businessArea: '中山路商圈',
        rating: 4.8,
        monthlyVisits: 3580,
        distance: 0.8,
        avgWaitTime: 10,
        localTags: ['本地老字号', '本地人最爱'],
        instoreDiscount: 15,
        urgencyReason: '到店好评TOP1',
        priority: 100
      },
      {
        id: '2',
        name: '沙坡尾海鲜排档',
        category: '海鲜排档',
        district: '思明区',
        businessArea: '沙坡尾',
        rating: 4.7,
        monthlyVisits: 2820,
        distance: 1.2,
        avgWaitTime: 15,
        localTags: ['到店好评如潮', '本地人最爱'],
        instoreDiscount: 12,
        urgencyReason: '到店人气火爆',
        priority: 95
      },
      {
        id: '3',
        name: '五缘湾私房菜',
        category: '闽南美食',
        district: '湖里区',
        businessArea: '五缘湾',
        rating: 4.6,
        monthlyVisits: 2100,
        distance: 2.5,
        avgWaitTime: 5,
        localTags: ['聚餐首选', '家庭友好'],
        instoreDiscount: 18,
        urgencyReason: '到店聚餐首选',
        priority: 90
      },
      {
        id: '4',
        name: '集美大排档',
        category: '闽南美食',
        district: '集美区',
        businessArea: '集美学村',
        rating: 4.5,
        monthlyVisits: 1580,
        distance: 3.2,
        avgWaitTime: 8,
        localTags: ['新店到店福利'],
        instoreDiscount: 20,
        urgencyReason: '新店到店特惠',
        priority: 88
      },
      {
        id: '5',
        name: '海沧渔家乐',
        category: '海鲜排档',
        district: '海沧区',
        businessArea: '海沧湾',
        rating: 4.4,
        monthlyVisits: 1200,
        distance: 4.1,
        avgWaitTime: 5,
        localTags: ['到店人气王', '家庭友好'],
        instoreDiscount: 15,
        urgencyReason: '岛外到店首选',
        priority: 85
      }
    ]

    // 只返回同区域的商家
    return allMerchants.filter(m => getRegionType(m.district) === userRegion)
  }
}

// 导出单例
export const aiGuideService = new AIGuideService()

/**
 * 快捷方法：获取AI到店推荐
 */
export async function getAIInstoreRecommendations(params: AIInstoreRecommendRequest): Promise<AIInstoreRecommendResult> {
  return aiGuideService.getInstoreRecommendations(params)
}

/**
 * 快捷方法：生成到店逼单话术
 */
export function generateInstoreUrgency(
  merchant: {
    name: string
    category: string
    district: string
    rating: number
    instoreDiscount: number
  },
  userDistrict: string
): string {
  const businessArea = getBusinessAreas(merchant.district)[0] || ''

  return generateInstoreUrgencyMessage('区域匹配到店', {
    district: userDistrict,
    name: merchant.name,
    category: merchant.category,
    discount: merchant.instoreDiscount,
    business_area: businessArea,
    rating: merchant.rating
  })
}
