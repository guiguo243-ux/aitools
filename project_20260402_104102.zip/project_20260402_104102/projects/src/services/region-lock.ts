/**
 * 区域锁服务（纯到店核销版）
 * 用于红包/优惠券的区域验证、跨区核销限制
 */

import {
  getRegionType,
  getRegionDisplayName,
  generateInstoreRestrictionMessage
} from '@/data/xiamen-local'

// 用户区域绑定信息
export interface UserRegionBinding {
  userId: string
  phone: string              // 手机号（实名）
  primaryDistrict: string    // 常驻区域
  secondaryDistricts: string[]  // 常用地址区域
  bindTime: Date             // 绑定时间
  lastVerifyTime: Date       // 最后验证时间
  verifyCount: number        // 验证次数
}

// 到店券区域限制
export interface InstoreCouponRestriction {
  couponId: string
  couponType: 'instore_discount' | 'instore_cash' | 'instore_free'
  regionType: 'island_inside' | 'island_outside' | 'all'
  allowedDistricts: string[]  // 可用区域列表（空表示不限具体区）
  excludeDistricts: string[]  // 排除区域列表
  merchantId?: string         // 指定商家（可选）
}

// 跨区核销限制
export interface CrossRegionRestriction {
  isCrossRegion: boolean
  userRegion: 'island_inside' | 'island_outside'
  merchantRegion: 'island_inside' | 'island_outside'
  canVerify: boolean          // 是否可核销
  restrictionMessage: string  // 限制提示
}

// 到店核销验证结果
export interface InstoreVerifyResult {
  isValid: boolean
  reason?: string
  suggestedMerchants?: string[]  // 建议的同区域商家
}

/**
 * 区域锁服务类（纯到店核销版）
 */
export class RegionLockService {
  /**
   * 验证到店券是否可用
   */
  verifyInstoreCouponRegion(
    coupon: InstoreCouponRestriction,
    userDistrict: string,
    merchantDistrict: string
  ): InstoreVerifyResult {
    // 1. 全区域可用
    if (coupon.regionType === 'all') {
      return { isValid: true }
    }

    // 2. 验证用户区域
    const userRegion = getRegionType(userDistrict)
    if (coupon.regionType !== userRegion) {
      return {
        isValid: false,
        reason: `此到店券仅限${getRegionDisplayName(coupon.regionType)}用户使用`,
        suggestedMerchants: this.getSuggestedInstoreMerchants(coupon.regionType)
      }
    }

    // 3. 验证指定区域
    if (coupon.allowedDistricts.length > 0) {
      if (!coupon.allowedDistricts.includes(userDistrict)) {
        return {
          isValid: false,
          reason: `此到店券仅限${coupon.allowedDistricts.join('、')}到店使用`
        }
      }
    }

    // 4. 验证排除区域
    if (coupon.excludeDistricts.length > 0) {
      if (coupon.excludeDistricts.includes(userDistrict)) {
        return {
          isValid: false,
          reason: `此到店券在${coupon.excludeDistricts.join('、')}不可用`
        }
      }
    }

    // 5. 验证商家区域匹配（关键：跨区到店券不可核销）
    const merchantRegion = getRegionType(merchantDistrict)
    if (coupon.regionType !== merchantRegion) {
      return {
        isValid: false,
        reason: `此到店券仅限${getRegionDisplayName(coupon.regionType)}商家到店核销，跨区无法使用`
      }
    }

    return { isValid: true }
  }

  /**
   * 检测跨区核销限制
   */
  checkCrossRegionVerification(
    userDistrict: string,
    userRealtimeDistrict: string,  // 用户实时定位区域
    merchantDistrict: string
  ): CrossRegionRestriction {
    const userRegion = getRegionType(userDistrict)
    const userRealtimeRegion = getRegionType(userRealtimeDistrict)
    const merchantRegion = getRegionType(merchantDistrict)

    // 三重核验：注册区域 + 实时定位 + 商家区域
    const isUserRegionMatch = userRegion === merchantRegion
    const isRealtimeMatch = userRealtimeRegion === merchantRegion
    const isCrossRegion = !isUserRegionMatch || !isRealtimeMatch

    if (!isCrossRegion) {
      return {
        isCrossRegion: false,
        userRegion,
        merchantRegion,
        canVerify: true,
        restrictionMessage: ''
      }
    }

    // 跨区不可核销
    return {
      isCrossRegion: true,
      userRegion,
      merchantRegion,
      canVerify: false,
      restrictionMessage: generateInstoreRestrictionMessage(userDistrict, merchantDistrict)
    }
  }

  /**
   * 执行到店核销验证（三重核验）
   */
  executeInstoreVerification(
    _userId: string,
    userDistrict: string,
    userRealtimeDistrict: string,
    merchantDistrict: string,
    _couponId: string
  ): InstoreVerifyResult {
    // 1. 检测跨区限制
    const crossRegionCheck = this.checkCrossRegionVerification(
      userDistrict,
      userRealtimeDistrict,
      merchantDistrict
    )

    if (!crossRegionCheck.canVerify) {
      return {
        isValid: false,
        reason: crossRegionCheck.restrictionMessage,
        suggestedMerchants: this.getSuggestedInstoreMerchants(crossRegionCheck.userRegion)
      }
    }

    // 2. 验证到店券（实际应从数据库获取券信息）
    // TODO: 从数据库获取券信息并验证

    return { isValid: true }
  }

  /**
   * 获取推荐的同区域到店商家
   */
  private getSuggestedInstoreMerchants(regionType: 'island_inside' | 'island_outside'): string[] {
    if (regionType === 'island_inside') {
      return ['思明区老厦门沙茶面', '湖里区五缘湾私房菜']
    } else {
      return ['集美区集美大排档', '海沧区海沧渔家乐']
    }
  }

  /**
   * 绑定用户区域（实名+常驻区域）
   */
  async bindUserRegion(
    userId: string,
    phone: string,
    district: string
  ): Promise<UserRegionBinding> {
    // 实际应调用后端接口
    const binding: UserRegionBinding = {
      userId,
      phone,
      primaryDistrict: district,
      secondaryDistricts: [],
      bindTime: new Date(),
      lastVerifyTime: new Date(),
      verifyCount: 1
    }

    console.log('[RegionLock] 用户区域绑定（到店核销版）:', binding)

    return binding
  }

  /**
   * 验证用户区域绑定
   */
  async verifyUserRegion(
    _userId: string,
    _currentDistrict: string
  ): Promise<InstoreVerifyResult> {
    // 实际应从数据库获取绑定信息并验证
    return { isValid: true }
  }

  /**
   * 获取用户可用到店券列表（按区域过滤）
   */
  async getAvailableInstoreCoupons(
    _userId: string,
    _merchantDistrict: string
  ): Promise<InstoreCouponRestriction[]> {
    // 实际应从数据库获取
    return []
  }
}

// 导出单例
export const regionLockService = new RegionLockService()

/**
 * 快捷方法：验证到店券区域
 */
export function verifyInstoreCouponRegion(
  coupon: InstoreCouponRestriction,
  userDistrict: string,
  merchantDistrict: string
): InstoreVerifyResult {
  return regionLockService.verifyInstoreCouponRegion(coupon, userDistrict, merchantDistrict)
}

/**
 * 快捷方法：检测跨区核销限制
 */
export function checkCrossRegionVerification(
  userDistrict: string,
  userRealtimeDistrict: string,
  merchantDistrict: string
): CrossRegionRestriction {
  return regionLockService.checkCrossRegionVerification(userDistrict, userRealtimeDistrict, merchantDistrict)
}
