import { relations } from "drizzle-orm/relations";
import { users, userResources, resources, userAccounts, merchants, coupons, orders, products, referralRewards, aiConversations, trendingContent, contentUsageRecords, productRedemptions, categories, businessCards, pointRecords, checkInRecords, vipMemberships, customerMessages, taskRecords, userCoupons, balanceRecords, regionRankings, shareRecords, userBalances, userRedPackets } from "./schema";

export const userResourcesRelations = relations(userResources, ({one}) => ({
	user: one(users, {
		fields: [userResources.userId],
		references: [users.id]
	}),
	resource: one(resources, {
		fields: [userResources.resourceId],
		references: [resources.id]
	}),
}));

export const usersRelations = relations(users, ({many}) => ({
	userResources: many(userResources),
	userAccounts: many(userAccounts),
	orders: many(orders),
	referralRewards_userId: many(referralRewards, {
		relationName: "referralRewards_userId_users_id"
	}),
	referralRewards_relatedUserId: many(referralRewards, {
		relationName: "referralRewards_relatedUserId_users_id"
	}),
	aiConversations: many(aiConversations),
	productRedemptions: many(productRedemptions),
	merchants: many(merchants),
	businessCards: many(businessCards),
	pointRecords: many(pointRecords),
	checkInRecords: many(checkInRecords),
	vipMemberships: many(vipMemberships),
	customerMessages: many(customerMessages),
	taskRecords: many(taskRecords),
	userCoupons: many(userCoupons),
	balanceRecords: many(balanceRecords),
	regionRankings: many(regionRankings),
	shareRecords: many(shareRecords),
	userBalances: many(userBalances),
	userRedPackets: many(userRedPackets),
}));

export const resourcesRelations = relations(resources, ({many}) => ({
	userResources: many(userResources),
}));

export const userAccountsRelations = relations(userAccounts, ({one}) => ({
	user: one(users, {
		fields: [userAccounts.userId],
		references: [users.id]
	}),
}));

export const couponsRelations = relations(coupons, ({one, many}) => ({
	merchant: one(merchants, {
		fields: [coupons.merchantId],
		references: [merchants.id]
	}),
	orders: many(orders),
	userCoupons: many(userCoupons),
}));

export const merchantsRelations = relations(merchants, ({one, many}) => ({
	coupons: many(coupons),
	orders: many(orders),
	products: many(products),
	user: one(users, {
		fields: [merchants.userId],
		references: [users.id]
	}),
	category: one(categories, {
		fields: [merchants.categoryId],
		references: [categories.id]
	}),
}));

export const ordersRelations = relations(orders, ({one}) => ({
	user: one(users, {
		fields: [orders.userId],
		references: [users.id]
	}),
	merchant: one(merchants, {
		fields: [orders.merchantId],
		references: [merchants.id]
	}),
	product: one(products, {
		fields: [orders.productId],
		references: [products.id]
	}),
	coupon: one(coupons, {
		fields: [orders.couponId],
		references: [coupons.id]
	}),
}));

export const productsRelations = relations(products, ({one, many}) => ({
	orders: many(orders),
	merchant: one(merchants, {
		fields: [products.merchantId],
		references: [merchants.id]
	}),
}));

export const referralRewardsRelations = relations(referralRewards, ({one}) => ({
	user_userId: one(users, {
		fields: [referralRewards.userId],
		references: [users.id],
		relationName: "referralRewards_userId_users_id"
	}),
	user_relatedUserId: one(users, {
		fields: [referralRewards.relatedUserId],
		references: [users.id],
		relationName: "referralRewards_relatedUserId_users_id"
	}),
}));

export const aiConversationsRelations = relations(aiConversations, ({one}) => ({
	user: one(users, {
		fields: [aiConversations.userId],
		references: [users.id]
	}),
}));

export const contentUsageRecordsRelations = relations(contentUsageRecords, ({one}) => ({
	trendingContent: one(trendingContent, {
		fields: [contentUsageRecords.contentId],
		references: [trendingContent.id]
	}),
}));

export const trendingContentRelations = relations(trendingContent, ({many}) => ({
	contentUsageRecords: many(contentUsageRecords),
}));

export const productRedemptionsRelations = relations(productRedemptions, ({one}) => ({
	user: one(users, {
		fields: [productRedemptions.userId],
		references: [users.id]
	}),
}));

export const categoriesRelations = relations(categories, ({many}) => ({
	merchants: many(merchants),
}));

export const businessCardsRelations = relations(businessCards, ({one}) => ({
	user: one(users, {
		fields: [businessCards.userId],
		references: [users.id]
	}),
}));

export const pointRecordsRelations = relations(pointRecords, ({one}) => ({
	user: one(users, {
		fields: [pointRecords.userId],
		references: [users.id]
	}),
}));

export const checkInRecordsRelations = relations(checkInRecords, ({one}) => ({
	user: one(users, {
		fields: [checkInRecords.userId],
		references: [users.id]
	}),
}));

export const vipMembershipsRelations = relations(vipMemberships, ({one}) => ({
	user: one(users, {
		fields: [vipMemberships.userId],
		references: [users.id]
	}),
}));

export const customerMessagesRelations = relations(customerMessages, ({one}) => ({
	user: one(users, {
		fields: [customerMessages.userId],
		references: [users.id]
	}),
}));

export const taskRecordsRelations = relations(taskRecords, ({one}) => ({
	user: one(users, {
		fields: [taskRecords.userId],
		references: [users.id]
	}),
}));

export const userCouponsRelations = relations(userCoupons, ({one}) => ({
	user: one(users, {
		fields: [userCoupons.userId],
		references: [users.id]
	}),
	coupon: one(coupons, {
		fields: [userCoupons.couponId],
		references: [coupons.id]
	}),
}));

export const balanceRecordsRelations = relations(balanceRecords, ({one}) => ({
	user: one(users, {
		fields: [balanceRecords.userId],
		references: [users.id]
	}),
}));

export const regionRankingsRelations = relations(regionRankings, ({one}) => ({
	user: one(users, {
		fields: [regionRankings.userId],
		references: [users.id]
	}),
}));

export const shareRecordsRelations = relations(shareRecords, ({one}) => ({
	user: one(users, {
		fields: [shareRecords.userId],
		references: [users.id]
	}),
}));

export const userBalancesRelations = relations(userBalances, ({one}) => ({
	user: one(users, {
		fields: [userBalances.userId],
		references: [users.id]
	}),
}));

export const userRedPacketsRelations = relations(userRedPackets, ({one}) => ({
	user: one(users, {
		fields: [userRedPackets.userId],
		references: [users.id]
	}),
}));