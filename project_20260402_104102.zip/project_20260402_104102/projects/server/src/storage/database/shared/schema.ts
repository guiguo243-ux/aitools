import { pgTable, serial, timestamp, index, pgPolicy, varchar, text, boolean, integer, foreignKey, uuid, numeric, unique } from "drizzle-orm/pg-core"
import { sql } from "drizzle-orm"



export const healthCheck = pgTable("health_check", {
	id: serial().notNull(),
	updatedAt: timestamp("updated_at", { withTimezone: true, mode: 'string' }).defaultNow(),
});

export const resources = pgTable("resources", {
	id: serial().primaryKey().notNull(),
	title: varchar({ length: 100 }).notNull(),
	description: varchar({ length: 500 }),
	type: varchar({ length: 20 }).notNull(),
	icon: varchar({ length: 10 }),
	content: text(),
	isLocked: boolean("is_locked").default(true).notNull(),
	requiredPoints: integer("required_points").default(0),
	sortOrder: integer("sort_order").default(0).notNull(),
	createdAt: timestamp("created_at", { withTimezone: true, mode: 'string' }).defaultNow().notNull(),
	updatedAt: timestamp("updated_at", { withTimezone: true, mode: 'string' }),
}, (table) => [
	index("resources_is_locked_idx").using("btree", table.isLocked.asc().nullsLast().op("bool_ops")),
	index("resources_sort_order_idx").using("btree", table.sortOrder.asc().nullsLast().op("int4_ops")),
	index("resources_type_idx").using("btree", table.type.asc().nullsLast().op("text_ops")),
	pgPolicy("resources_允许公开读取", { as: "permissive", for: "select", to: ["public"], using: sql`true` }),
	pgPolicy("resources_允许公开写入", { as: "permissive", for: "insert", to: ["public"] }),
	pgPolicy("resources_允许公开更新", { as: "permissive", for: "update", to: ["public"] }),
	pgPolicy("resources_允许公开删除", { as: "permissive", for: "delete", to: ["public"] }),
]);

export const userResources = pgTable("user_resources", {
	id: uuid().defaultRandom().primaryKey().notNull(),
	userId: uuid("user_id").notNull(),
	resourceId: integer("resource_id").notNull(),
	unlockedAt: timestamp("unlocked_at", { withTimezone: true, mode: 'string' }).defaultNow().notNull(),
}, (table) => [
	index("user_resources_resource_id_idx").using("btree", table.resourceId.asc().nullsLast().op("int4_ops")),
	index("user_resources_user_id_idx").using("btree", table.userId.asc().nullsLast().op("uuid_ops")),
	foreignKey({
			columns: [table.userId],
			foreignColumns: [users.id],
			name: "user_resources_user_id_users_id_fk"
		}).onDelete("cascade"),
	foreignKey({
			columns: [table.resourceId],
			foreignColumns: [resources.id],
			name: "user_resources_resource_id_resources_id_fk"
		}).onDelete("cascade"),
	pgPolicy("user_resources_允许公开读取", { as: "permissive", for: "select", to: ["public"], using: sql`true` }),
	pgPolicy("user_resources_允许公开写入", { as: "permissive", for: "insert", to: ["public"] }),
	pgPolicy("user_resources_允许公开更新", { as: "permissive", for: "update", to: ["public"] }),
	pgPolicy("user_resources_允许公开删除", { as: "permissive", for: "delete", to: ["public"] }),
]);

export const userAccounts = pgTable("user_accounts", {
	id: uuid().defaultRandom().primaryKey().notNull(),
	userId: uuid("user_id").notNull(),
	platform: varchar({ length: 20 }).notNull(),
	accountId: varchar("account_id", { length: 100 }).notNull(),
	nickname: varchar({ length: 100 }),
	followersCount: integer("followers_count").default(0),
	status: varchar({ length: 20 }).default('active').notNull(),
	createdAt: timestamp("created_at", { withTimezone: true, mode: 'string' }).defaultNow().notNull(),
	updatedAt: timestamp("updated_at", { withTimezone: true, mode: 'string' }),
}, (table) => [
	index("user_accounts_platform_idx").using("btree", table.platform.asc().nullsLast().op("text_ops")),
	index("user_accounts_user_id_idx").using("btree", table.userId.asc().nullsLast().op("uuid_ops")),
	foreignKey({
			columns: [table.userId],
			foreignColumns: [users.id],
			name: "user_accounts_user_id_users_id_fk"
		}).onDelete("cascade"),
	pgPolicy("user_accounts_允许公开读取", { as: "permissive", for: "select", to: ["public"], using: sql`true` }),
	pgPolicy("user_accounts_允许公开写入", { as: "permissive", for: "insert", to: ["public"] }),
	pgPolicy("user_accounts_允许公开更新", { as: "permissive", for: "update", to: ["public"] }),
	pgPolicy("user_accounts_允许公开删除", { as: "permissive", for: "delete", to: ["public"] }),
]);

export const inviteRecords = pgTable("invite_records", {
	id: serial().primaryKey().notNull(),
	inviterId: varchar("inviter_id", { length: 255 }).notNull(),
	inviteeId: varchar("invitee_id", { length: 255 }).notNull(),
	inviteePhone: varchar("invitee_phone", { length: 20 }),
	rewardPoints: integer("reward_points").default(30),
	status: varchar({ length: 20 }).default('completed'),
	createdAt: timestamp("created_at", { mode: 'string' }).default(sql`CURRENT_TIMESTAMP`),
	updatedAt: timestamp("updated_at", { mode: 'string' }),
}, (table) => [
	index("idx_invite_records_invitee_id").using("btree", table.inviteeId.asc().nullsLast().op("text_ops")),
	index("idx_invite_records_inviter_id").using("btree", table.inviterId.asc().nullsLast().op("text_ops")),
	index("idx_invite_records_status").using("btree", table.status.asc().nullsLast().op("text_ops")),
	pgPolicy("Allow all access to invite_records", { as: "permissive", for: "all", to: ["public"], using: sql`true`, withCheck: sql`true`  }),
]);

export const coupons = pgTable("coupons", {
	id: uuid().defaultRandom().primaryKey().notNull(),
	merchantId: uuid("merchant_id"),
	name: varchar({ length: 100 }).notNull(),
	type: varchar({ length: 20 }).notNull(),
	amount: numeric({ precision: 10, scale:  2 }).notNull(),
	minAmount: numeric("min_amount", { precision: 10, scale:  2 }),
	region: varchar({ length: 20 }),
	validDays: integer("valid_days").default(30),
	totalCount: integer("total_count").default(sql`'-1'`),
	usedCount: integer("used_count").default(0).notNull(),
	isActive: boolean("is_active").default(true).notNull(),
	startAt: timestamp("start_at", { withTimezone: true, mode: 'string' }),
	endAt: timestamp("end_at", { withTimezone: true, mode: 'string' }),
	createdAt: timestamp("created_at", { withTimezone: true, mode: 'string' }).defaultNow().notNull(),
}, (table) => [
	index("coupons_is_active_idx").using("btree", table.isActive.asc().nullsLast().op("bool_ops")),
	index("coupons_merchant_id_idx").using("btree", table.merchantId.asc().nullsLast().op("uuid_ops")),
	index("coupons_region_idx").using("btree", table.region.asc().nullsLast().op("text_ops")),
	index("coupons_type_idx").using("btree", table.type.asc().nullsLast().op("text_ops")),
	foreignKey({
			columns: [table.merchantId],
			foreignColumns: [merchants.id],
			name: "coupons_merchant_id_fkey"
		}).onDelete("cascade"),
	pgPolicy("coupons_允许公开删除", { as: "permissive", for: "delete", to: ["public"] }),
	pgPolicy("coupons_允许公开更新", { as: "permissive", for: "update", to: ["public"] }),
	pgPolicy("coupons_允许公开写入", { as: "permissive", for: "insert", to: ["public"] }),
	pgPolicy("coupons_允许公开读取", { as: "permissive", for: "select", to: ["public"] }),
]);

export const orders = pgTable("orders", {
	id: uuid().defaultRandom().primaryKey().notNull(),
	orderNo: varchar("order_no", { length: 50 }).notNull(),
	userId: uuid("user_id").notNull(),
	merchantId: uuid("merchant_id").notNull(),
	productId: uuid("product_id"),
	totalAmount: numeric("total_amount", { precision: 10, scale:  2 }).notNull(),
	payAmount: numeric("pay_amount", { precision: 10, scale:  2 }).notNull(),
	couponId: uuid("coupon_id"),
	couponAmount: numeric("coupon_amount", { precision: 10, scale:  2 }),
	commissionAmount: numeric("commission_amount", { precision: 10, scale:  2 }),
	referrerCommission: numeric("referrer_commission", { precision: 10, scale:  2 }),
	status: varchar({ length: 20 }).default('pending').notNull(),
	paymentMethod: varchar("payment_method", { length: 20 }),
	paidAt: timestamp("paid_at", { withTimezone: true, mode: 'string' }),
	completedAt: timestamp("completed_at", { withTimezone: true, mode: 'string' }),
	cancelledAt: timestamp("cancelled_at", { withTimezone: true, mode: 'string' }),
	createdAt: timestamp("created_at", { withTimezone: true, mode: 'string' }).defaultNow().notNull(),
	updatedAt: timestamp("updated_at", { withTimezone: true, mode: 'string' }),
}, (table) => [
	index("orders_created_at_idx").using("btree", table.createdAt.asc().nullsLast().op("timestamptz_ops")),
	index("orders_merchant_id_idx").using("btree", table.merchantId.asc().nullsLast().op("uuid_ops")),
	index("orders_order_no_idx").using("btree", table.orderNo.asc().nullsLast().op("text_ops")),
	index("orders_status_idx").using("btree", table.status.asc().nullsLast().op("text_ops")),
	index("orders_user_id_idx").using("btree", table.userId.asc().nullsLast().op("uuid_ops")),
	foreignKey({
			columns: [table.userId],
			foreignColumns: [users.id],
			name: "orders_user_id_fkey"
		}).onDelete("cascade"),
	foreignKey({
			columns: [table.merchantId],
			foreignColumns: [merchants.id],
			name: "orders_merchant_id_fkey"
		}).onDelete("cascade"),
	foreignKey({
			columns: [table.productId],
			foreignColumns: [products.id],
			name: "orders_product_id_fkey"
		}).onDelete("set null"),
	foreignKey({
			columns: [table.couponId],
			foreignColumns: [coupons.id],
			name: "orders_coupon_id_fkey"
		}).onDelete("set null"),
	pgPolicy("orders_允许公开删除", { as: "permissive", for: "delete", to: ["public"] }),
	pgPolicy("orders_允许公开更新", { as: "permissive", for: "update", to: ["public"] }),
	pgPolicy("orders_允许公开写入", { as: "permissive", for: "insert", to: ["public"] }),
	pgPolicy("orders_允许公开读取", { as: "permissive", for: "select", to: ["public"] }),
]);

export const products = pgTable("products", {
	id: uuid().defaultRandom().primaryKey().notNull(),
	merchantId: uuid("merchant_id").notNull(),
	name: varchar({ length: 100 }).notNull(),
	description: text(),
	imageUrl: varchar("image_url", { length: 500 }),
	price: numeric({ precision: 10, scale:  2 }).notNull(),
	originalPrice: numeric("original_price", { precision: 10, scale:  2 }),
	salesCount: integer("sales_count").default(0).notNull(),
	stock: integer().default(sql`'-1'`),
	isActive: boolean("is_active").default(true).notNull(),
	isRecommended: boolean("is_recommended").default(false),
	sortOrder: integer("sort_order").default(0).notNull(),
	createdAt: timestamp("created_at", { withTimezone: true, mode: 'string' }).defaultNow().notNull(),
	updatedAt: timestamp("updated_at", { withTimezone: true, mode: 'string' }),
}, (table) => [
	index("products_is_active_idx").using("btree", table.isActive.asc().nullsLast().op("bool_ops")),
	index("products_is_recommended_idx").using("btree", table.isRecommended.asc().nullsLast().op("bool_ops")),
	index("products_merchant_id_idx").using("btree", table.merchantId.asc().nullsLast().op("uuid_ops")),
	index("products_sales_count_idx").using("btree", table.salesCount.asc().nullsLast().op("int4_ops")),
	foreignKey({
			columns: [table.merchantId],
			foreignColumns: [merchants.id],
			name: "products_merchant_id_fkey"
		}).onDelete("cascade"),
	pgPolicy("products_允许公开删除", { as: "permissive", for: "delete", to: ["public"] }),
	pgPolicy("products_允许公开更新", { as: "permissive", for: "update", to: ["public"] }),
	pgPolicy("products_允许公开写入", { as: "permissive", for: "insert", to: ["public"] }),
	pgPolicy("products_允许公开读取", { as: "permissive", for: "select", to: ["public"] }),
]);

export const referralRewards = pgTable("referral_rewards", {
	id: uuid().defaultRandom().primaryKey().notNull(),
	userId: uuid("user_id").notNull(),
	relatedUserId: uuid("related_user_id"),
	type: varchar({ length: 20 }).notNull(),
	amount: numeric({ precision: 10, scale:  2 }).notNull(),
	status: varchar({ length: 20 }).default('pending').notNull(),
	settledAt: timestamp("settled_at", { withTimezone: true, mode: 'string' }),
	createdAt: timestamp("created_at", { withTimezone: true, mode: 'string' }).defaultNow().notNull(),
}, (table) => [
	index("referral_rewards_related_user_id_idx").using("btree", table.relatedUserId.asc().nullsLast().op("uuid_ops")),
	index("referral_rewards_status_idx").using("btree", table.status.asc().nullsLast().op("text_ops")),
	index("referral_rewards_user_id_idx").using("btree", table.userId.asc().nullsLast().op("uuid_ops")),
	foreignKey({
			columns: [table.userId],
			foreignColumns: [users.id],
			name: "referral_rewards_user_id_fkey"
		}).onDelete("cascade"),
	foreignKey({
			columns: [table.relatedUserId],
			foreignColumns: [users.id],
			name: "referral_rewards_related_user_id_fkey"
		}).onDelete("set null"),
	pgPolicy("referral_rewards_允许公开删除", { as: "permissive", for: "delete", to: ["public"] }),
	pgPolicy("referral_rewards_允许公开更新", { as: "permissive", for: "update", to: ["public"] }),
	pgPolicy("referral_rewards_允许公开写入", { as: "permissive", for: "insert", to: ["public"] }),
	pgPolicy("referral_rewards_允许公开读取", { as: "permissive", for: "select", to: ["public"] }),
]);

export const categories = pgTable("categories", {
	id: serial().primaryKey().notNull(),
	name: varchar({ length: 50 }).notNull(),
	icon: varchar({ length: 100 }),
	description: varchar({ length: 200 }),
	sortOrder: integer("sort_order").default(0).notNull(),
	isActive: boolean("is_active").default(true).notNull(),
	createdAt: timestamp("created_at", { withTimezone: true, mode: 'string' }).defaultNow().notNull(),
}, (table) => [
	index("categories_is_active_idx").using("btree", table.isActive.asc().nullsLast().op("bool_ops")),
	index("categories_sort_order_idx").using("btree", table.sortOrder.asc().nullsLast().op("int4_ops")),
	pgPolicy("categories_允许公开删除", { as: "permissive", for: "delete", to: ["public"] }),
	pgPolicy("categories_允许公开更新", { as: "permissive", for: "update", to: ["public"] }),
	pgPolicy("categories_允许公开写入", { as: "permissive", for: "insert", to: ["public"] }),
	pgPolicy("categories_允许公开读取", { as: "permissive", for: "select", to: ["public"] }),
]);

export const aiConversations = pgTable("ai_conversations", {
	id: uuid().defaultRandom().primaryKey().notNull(),
	userId: uuid("user_id").notNull(),
	sessionId: varchar("session_id", { length: 100 }).notNull(),
	role: varchar({ length: 20 }).notNull(),
	content: text().notNull(),
	region: varchar({ length: 20 }),
	createdAt: timestamp("created_at", { withTimezone: true, mode: 'string' }).defaultNow().notNull(),
}, (table) => [
	index("ai_conversations_created_at_idx").using("btree", table.createdAt.asc().nullsLast().op("timestamptz_ops")),
	index("ai_conversations_session_id_idx").using("btree", table.sessionId.asc().nullsLast().op("text_ops")),
	index("ai_conversations_user_id_idx").using("btree", table.userId.asc().nullsLast().op("uuid_ops")),
	foreignKey({
			columns: [table.userId],
			foreignColumns: [users.id],
			name: "ai_conversations_user_id_fkey"
		}).onDelete("cascade"),
	pgPolicy("ai_conversations_允许公开删除", { as: "permissive", for: "delete", to: ["public"] }),
	pgPolicy("ai_conversations_允许公开更新", { as: "permissive", for: "update", to: ["public"] }),
	pgPolicy("ai_conversations_允许公开写入", { as: "permissive", for: "insert", to: ["public"] }),
	pgPolicy("ai_conversations_允许公开读取", { as: "permissive", for: "select", to: ["public"] }),
]);

export const contentUsageRecords = pgTable("content_usage_records", {
	id: uuid().defaultRandom().primaryKey().notNull(),
	userId: uuid("user_id").notNull(),
	contentId: integer("content_id").notNull(),
	actionType: varchar("action_type", { length: 20 }).notNull(),
	createdAt: timestamp("created_at", { withTimezone: true, mode: 'string' }).defaultNow().notNull(),
}, (table) => [
	index("content_usage_records_content_id_idx").using("btree", table.contentId.asc().nullsLast().op("int4_ops")),
	index("content_usage_records_user_id_idx").using("btree", table.userId.asc().nullsLast().op("uuid_ops")),
	foreignKey({
			columns: [table.contentId],
			foreignColumns: [trendingContent.id],
			name: "content_usage_records_content_id_fkey"
		}).onDelete("cascade"),
]);

export const productRedemptions = pgTable("product_redemptions", {
	id: uuid().defaultRandom().primaryKey().notNull(),
	userId: uuid("user_id").notNull(),
	productId: integer("product_id").notNull(),
	pointsSpent: integer("points_spent").notNull(),
	status: varchar({ length: 20 }).default('pending').notNull(),
	createdAt: timestamp("created_at", { withTimezone: true, mode: 'string' }).defaultNow().notNull(),
}, (table) => [
	index("product_redemptions_status_idx").using("btree", table.status.asc().nullsLast().op("text_ops")),
	index("product_redemptions_user_id_idx").using("btree", table.userId.asc().nullsLast().op("uuid_ops")),
	foreignKey({
			columns: [table.userId],
			foreignColumns: [users.id],
			name: "product_redemptions_user_id_fkey"
		}).onDelete("cascade"),
]);

export const shopProducts = pgTable("shop_products", {
	id: serial().primaryKey().notNull(),
	name: varchar({ length: 100 }).notNull(),
	description: varchar({ length: 500 }),
	imageUrl: varchar("image_url", { length: 500 }),
	price: integer().notNull(),
	stock: integer().default(sql`'-1'`),
	category: varchar({ length: 20 }),
	isActive: boolean("is_active").default(true).notNull(),
	sortOrder: integer("sort_order").default(0).notNull(),
	createdAt: timestamp("created_at", { withTimezone: true, mode: 'string' }).defaultNow().notNull(),
}, (table) => [
	index("shop_products_category_idx").using("btree", table.category.asc().nullsLast().op("text_ops")),
	index("shop_products_is_active_idx").using("btree", table.isActive.asc().nullsLast().op("bool_ops")),
	index("shop_products_sort_order_idx").using("btree", table.sortOrder.asc().nullsLast().op("int4_ops")),
]);

export const taskTemplates = pgTable("task_templates", {
	id: serial().primaryKey().notNull(),
	title: varchar({ length: 100 }).notNull(),
	description: varchar({ length: 200 }),
	taskType: varchar("task_type", { length: 20 }).notNull(),
	rewardPoints: integer("reward_points").notNull(),
	requiredProgress: integer("required_progress").default(1),
	isActive: boolean("is_active").default(true).notNull(),
	sortOrder: integer("sort_order").default(0).notNull(),
	createdAt: timestamp("created_at", { withTimezone: true, mode: 'string' }).defaultNow().notNull(),
}, (table) => [
	index("task_templates_is_active_idx").using("btree", table.isActive.asc().nullsLast().op("bool_ops")),
	index("task_templates_task_type_idx").using("btree", table.taskType.asc().nullsLast().op("text_ops")),
]);

export const merchants = pgTable("merchants", {
	id: uuid().defaultRandom().primaryKey().notNull(),
	userId: uuid("user_id"),
	name: varchar({ length: 100 }).notNull(),
	category: varchar({ length: 50 }).notNull(),
	description: text(),
	address: varchar({ length: 200 }),
	latitude: varchar({ length: 20 }),
	longitude: varchar({ length: 20 }),
	phone: varchar({ length: 20 }),
	businessHours: varchar("business_hours", { length: 100 }),
	imageUrl: varchar("image_url", { length: 500 }),
	tags: text(),
	rating: varchar({ length: 10 }).default('5.0'),
	reviewCount: integer("review_count").default(0).notNull(),
	viewCount: integer("view_count").default(0).notNull(),
	isVerified: boolean("is_verified").default(false).notNull(),
	status: varchar({ length: 20 }).default('active').notNull(),
	createdAt: timestamp("created_at", { withTimezone: true, mode: 'string' }).defaultNow().notNull(),
	updatedAt: timestamp("updated_at", { withTimezone: true, mode: 'string' }),
	categoryId: integer("category_id"),
	district: varchar({ length: 50 }),
	coverImage: varchar("cover_image", { length: 500 }),
	region: varchar({ length: 20 }).default('island_inside'),
	promoCode: varchar("promo_code", { length: 50 }),
	aiWeight: integer("ai_weight").default(0),
	commissionRate: numeric("commission_rate", { precision: 5, scale:  2 }).default('0.10'),
}, (table) => [
	index("merchants_ai_weight_idx").using("btree", table.aiWeight.asc().nullsLast().op("int4_ops")),
	index("merchants_category_id_idx").using("btree", table.categoryId.asc().nullsLast().op("int4_ops")),
	index("merchants_category_idx").using("btree", table.category.asc().nullsLast().op("text_ops")),
	index("merchants_is_verified_idx").using("btree", table.isVerified.asc().nullsLast().op("bool_ops")),
	index("merchants_latitude_longitude_idx").using("btree", table.latitude.asc().nullsLast().op("text_ops"), table.longitude.asc().nullsLast().op("text_ops")),
	index("merchants_promo_code_idx").using("btree", table.promoCode.asc().nullsLast().op("text_ops")),
	index("merchants_rating_idx").using("btree", table.rating.asc().nullsLast().op("text_ops")),
	index("merchants_region_idx").using("btree", table.region.asc().nullsLast().op("text_ops")),
	index("merchants_status_idx").using("btree", table.status.asc().nullsLast().op("text_ops")),
	foreignKey({
			columns: [table.userId],
			foreignColumns: [users.id],
			name: "merchants_user_id_fkey"
		}).onDelete("set null"),
	foreignKey({
			columns: [table.categoryId],
			foreignColumns: [categories.id],
			name: "merchants_category_id_fkey"
		}).onDelete("set null"),
	pgPolicy("merchants_允许公开删除", { as: "permissive", for: "delete", to: ["public"] }),
	pgPolicy("merchants_允许公开更新", { as: "permissive", for: "update", to: ["public"] }),
	pgPolicy("merchants_允许公开写入", { as: "permissive", for: "insert", to: ["public"] }),
	pgPolicy("merchants_允许公开读取", { as: "permissive", for: "select", to: ["public"] }),
]);

export const businessCards = pgTable("business_cards", {
	id: uuid().defaultRandom().primaryKey().notNull(),
	userId: uuid("user_id"),
	company: varchar({ length: 100 }),
	position: varchar({ length: 50 }),
	introduction: text(),
	aiIntroduction: text("ai_introduction"),
	tags: text(),
	wechat: varchar({ length: 50 }),
	phone: varchar({ length: 20 }),
	email: varchar({ length: 100 }),
	address: varchar({ length: 200 }),
	latitude: varchar({ length: 20 }),
	longitude: varchar({ length: 20 }),
	qrcodeUrl: varchar("qrcode_url", { length: 500 }),
	viewCount: integer("view_count").default(0).notNull(),
	likeCount: integer("like_count").default(0).notNull(),
	isPublic: boolean("is_public").default(true).notNull(),
	createdAt: timestamp("created_at", { withTimezone: true, mode: 'string' }).defaultNow().notNull(),
	updatedAt: timestamp("updated_at", { withTimezone: true, mode: 'string' }),
}, (table) => [
	index("business_cards_city_idx").using("btree", table.address.asc().nullsLast().op("text_ops")),
	index("business_cards_user_id_idx").using("btree", table.userId.asc().nullsLast().op("uuid_ops")),
	foreignKey({
			columns: [table.userId],
			foreignColumns: [users.id],
			name: "business_cards_user_id_fkey"
		}).onDelete("cascade"),
]);

export const statistics = pgTable("statistics", {
	id: serial().primaryKey().notNull(),
	date: varchar({ length: 10 }).notNull(),
	newUsers: integer("new_users").default(0).notNull(),
	activeUsers: integer("active_users").default(0).notNull(),
	tasksCompleted: integer("tasks_completed").default(0).notNull(),
	pointsAwarded: integer("points_awarded").default(0).notNull(),
	matchesCreated: integer("matches_created").default(0).notNull(),
	wechatAdds: integer("wechat_adds").default(0).notNull(),
	createdAt: timestamp("created_at", { withTimezone: true, mode: 'string' }).defaultNow().notNull(),
}, (table) => [
	index("statistics_date_idx").using("btree", table.date.asc().nullsLast().op("text_ops")),
	pgPolicy("statistics_允许公开读取", { as: "permissive", for: "select", to: ["public"], using: sql`true` }),
	pgPolicy("statistics_允许公开写入", { as: "permissive", for: "insert", to: ["public"] }),
	pgPolicy("statistics_允许公开更新", { as: "permissive", for: "update", to: ["public"] }),
	pgPolicy("statistics_允许公开删除", { as: "permissive", for: "delete", to: ["public"] }),
]);

export const wechatConfigs = pgTable("wechat_configs", {
	id: serial().primaryKey().notNull(),
	wechatId: varchar("wechat_id", { length: 50 }).notNull(),
	qrcodeUrl: varchar("qrcode_url", { length: 500 }),
	description: varchar({ length: 200 }),
	isActive: boolean("is_active").default(true).notNull(),
	sortOrder: integer("sort_order").default(0).notNull(),
	createdAt: timestamp("created_at", { withTimezone: true, mode: 'string' }).defaultNow().notNull(),
	updatedAt: timestamp("updated_at", { withTimezone: true, mode: 'string' }),
}, (table) => [
	index("wechat_configs_is_active_idx").using("btree", table.isActive.asc().nullsLast().op("bool_ops")),
	index("wechat_configs_sort_order_idx").using("btree", table.sortOrder.asc().nullsLast().op("int4_ops")),
	pgPolicy("wechat_configs_允许公开读取", { as: "permissive", for: "select", to: ["public"], using: sql`true` }),
	pgPolicy("wechat_configs_允许公开写入", { as: "permissive", for: "insert", to: ["public"] }),
	pgPolicy("wechat_configs_允许公开更新", { as: "permissive", for: "update", to: ["public"] }),
	pgPolicy("wechat_configs_允许公开删除", { as: "permissive", for: "delete", to: ["public"] }),
]);

export const matchRecords = pgTable("match_records", {
	id: uuid().defaultRandom().primaryKey().notNull(),
	userId: uuid("user_id").notNull(),
	matchedUserId: uuid("matched_user_id"),
	matchedAccountId: varchar("matched_account_id", { length: 100 }),
	matchedPlatform: varchar("matched_platform", { length: 20 }),
	matchType: varchar("match_type", { length: 20 }).default('ai'),
	matchScore: integer("match_score").default(0),
	matchReason: text("match_reason"),
	status: varchar({ length: 20 }).default('pending'),
	createdAt: timestamp("created_at", { withTimezone: true, mode: 'string' }).default(sql`CURRENT_TIMESTAMP`),
}, (table) => [
	index("idx_match_records_created_at").using("btree", table.createdAt.asc().nullsLast().op("timestamptz_ops")),
	index("idx_match_records_matched_user_id").using("btree", table.matchedUserId.asc().nullsLast().op("uuid_ops")),
	index("idx_match_records_status").using("btree", table.status.asc().nullsLast().op("text_ops")),
	index("idx_match_records_user_id").using("btree", table.userId.asc().nullsLast().op("uuid_ops")),
	pgPolicy("Allow all access to match_records", { as: "permissive", for: "all", to: ["public"], using: sql`true`, withCheck: sql`true`  }),
]);

export const pointRecords = pgTable("point_records", {
	id: uuid().defaultRandom().primaryKey().notNull(),
	userId: uuid("user_id").notNull(),
	amount: integer().notNull(),
	type: varchar({ length: 20 }).notNull(),
	description: varchar({ length: 200 }),
	relatedId: uuid("related_id"),
	createdAt: timestamp("created_at", { withTimezone: true, mode: 'string' }).defaultNow().notNull(),
}, (table) => [
	index("point_records_created_at_idx").using("btree", table.createdAt.asc().nullsLast().op("timestamptz_ops")),
	index("point_records_related_id_idx").using("btree", table.relatedId.asc().nullsLast().op("uuid_ops")),
	index("point_records_type_idx").using("btree", table.type.asc().nullsLast().op("text_ops")),
	index("point_records_user_id_idx").using("btree", table.userId.asc().nullsLast().op("uuid_ops")),
	foreignKey({
			columns: [table.userId],
			foreignColumns: [users.id],
			name: "point_records_user_id_users_id_fk"
		}).onDelete("cascade"),
	pgPolicy("point_records_允许公开读取", { as: "permissive", for: "select", to: ["public"], using: sql`true` }),
	pgPolicy("point_records_允许公开写入", { as: "permissive", for: "insert", to: ["public"] }),
	pgPolicy("point_records_允许公开更新", { as: "permissive", for: "update", to: ["public"] }),
	pgPolicy("point_records_允许公开删除", { as: "permissive", for: "delete", to: ["public"] }),
]);

export const checkInRecords = pgTable("check_in_records", {
	id: uuid().defaultRandom().primaryKey().notNull(),
	userId: uuid("user_id").notNull(),
	checkInDate: varchar("check_in_date", { length: 10 }).notNull(),
	continuousDays: integer("continuous_days").default(1).notNull(),
	rewardPoints: integer("reward_points").notNull(),
	createdAt: timestamp("created_at", { withTimezone: true, mode: 'string' }).defaultNow().notNull(),
}, (table) => [
	index("check_in_records_date_idx").using("btree", table.checkInDate.asc().nullsLast().op("text_ops")),
	index("check_in_records_user_date_idx").using("btree", table.userId.asc().nullsLast().op("text_ops"), table.checkInDate.asc().nullsLast().op("uuid_ops")),
	index("check_in_records_user_id_idx").using("btree", table.userId.asc().nullsLast().op("uuid_ops")),
	foreignKey({
			columns: [table.userId],
			foreignColumns: [users.id],
			name: "check_in_records_user_id_fkey"
		}).onDelete("cascade"),
]);

export const vipMemberships = pgTable("vip_memberships", {
	id: uuid().defaultRandom().primaryKey().notNull(),
	userId: uuid("user_id").notNull(),
	vipType: varchar("vip_type", { length: 20 }).notNull(),
	startDate: timestamp("start_date", { withTimezone: true, mode: 'string' }).notNull(),
	endDate: timestamp("end_date", { withTimezone: true, mode: 'string' }).notNull(),
	status: varchar({ length: 20 }).default('active').notNull(),
	paymentAmount: integer("payment_amount").notNull(),
	paymentMethod: varchar("payment_method", { length: 20 }),
	createdAt: timestamp("created_at", { withTimezone: true, mode: 'string' }).defaultNow().notNull(),
}, (table) => [
	index("vip_memberships_status_idx").using("btree", table.status.asc().nullsLast().op("text_ops")),
	index("vip_memberships_user_id_idx").using("btree", table.userId.asc().nullsLast().op("uuid_ops")),
	foreignKey({
			columns: [table.userId],
			foreignColumns: [users.id],
			name: "vip_memberships_user_id_fkey"
		}).onDelete("cascade"),
]);

export const customerMessages = pgTable("customer_messages", {
	id: uuid().defaultRandom().primaryKey().notNull(),
	userId: uuid("user_id").notNull(),
	messageType: varchar("message_type", { length: 20 }).notNull(),
	content: text().notNull(),
	senderType: varchar("sender_type", { length: 20 }).notNull(),
	isRead: boolean("is_read").default(false).notNull(),
	createdAt: timestamp("created_at", { withTimezone: true, mode: 'string' }).defaultNow().notNull(),
}, (table) => [
	index("customer_messages_created_at_idx").using("btree", table.createdAt.asc().nullsLast().op("timestamptz_ops")),
	index("customer_messages_sender_type_idx").using("btree", table.senderType.asc().nullsLast().op("text_ops")),
	index("customer_messages_user_id_idx").using("btree", table.userId.asc().nullsLast().op("uuid_ops")),
	foreignKey({
			columns: [table.userId],
			foreignColumns: [users.id],
			name: "customer_messages_user_id_fkey"
		}).onDelete("cascade"),
]);

export const customerServiceConfig = pgTable("customer_service_config", {
	id: serial().primaryKey().notNull(),
	serviceType: varchar("service_type", { length: 20 }).notNull(),
	contactInfo: varchar("contact_info", { length: 200 }).notNull(),
	qrcodeUrl: varchar("qrcode_url", { length: 500 }),
	description: varchar({ length: 200 }),
	isActive: boolean("is_active").default(true).notNull(),
	sortOrder: integer("sort_order").default(0).notNull(),
	createdAt: timestamp("created_at", { withTimezone: true, mode: 'string' }).defaultNow().notNull(),
}, (table) => [
	index("customer_service_config_is_active_idx").using("btree", table.isActive.asc().nullsLast().op("bool_ops")),
	index("customer_service_config_service_type_idx").using("btree", table.serviceType.asc().nullsLast().op("text_ops")),
]);

export const trendingContent = pgTable("trending_content", {
	id: serial().primaryKey().notNull(),
	title: varchar({ length: 200 }).notNull(),
	content: text().notNull(),
	category: varchar({ length: 50 }).notNull(),
	platform: varchar({ length: 20 }).notNull(),
	contentType: varchar("content_type", { length: 20 }).notNull(),
	tags: text(),
	hotScore: integer("hot_score").default(0).notNull(),
	viewCount: integer("view_count").default(0).notNull(),
	useCount: integer("use_count").default(0).notNull(),
	isActive: boolean("is_active").default(true).notNull(),
	publishedAt: timestamp("published_at", { withTimezone: true, mode: 'string' }),
	createdAt: timestamp("created_at", { withTimezone: true, mode: 'string' }).defaultNow().notNull(),
}, (table) => [
	index("trending_content_category_idx").using("btree", table.category.asc().nullsLast().op("text_ops")),
	index("trending_content_hot_score_idx").using("btree", table.hotScore.asc().nullsLast().op("int4_ops")),
	index("trending_content_is_active_idx").using("btree", table.isActive.asc().nullsLast().op("bool_ops")),
	index("trending_content_platform_idx").using("btree", table.platform.asc().nullsLast().op("text_ops")),
]);

export const taskRecords = pgTable("task_records", {
	id: uuid().defaultRandom().primaryKey().notNull(),
	userId: uuid("user_id").notNull(),
	taskType: varchar("task_type", { length: 20 }).notNull(),
	taskTitle: varchar("task_title", { length: 100 }).notNull(),
	rewardPoints: integer("reward_points").notNull(),
	status: varchar({ length: 20 }).default('pending').notNull(),
	progress: integer().default(0),
	total: integer().default(1),
	completedAt: timestamp("completed_at", { withTimezone: true, mode: 'string' }),
	createdAt: timestamp("created_at", { withTimezone: true, mode: 'string' }).defaultNow().notNull(),
}, (table) => [
	index("task_records_created_at_idx").using("btree", table.createdAt.asc().nullsLast().op("timestamptz_ops")),
	index("task_records_status_idx").using("btree", table.status.asc().nullsLast().op("text_ops")),
	index("task_records_task_type_idx").using("btree", table.taskType.asc().nullsLast().op("text_ops")),
	index("task_records_user_id_idx").using("btree", table.userId.asc().nullsLast().op("uuid_ops")),
	foreignKey({
			columns: [table.userId],
			foreignColumns: [users.id],
			name: "task_records_user_id_users_id_fk"
		}).onDelete("cascade"),
	pgPolicy("task_records_允许公开读取", { as: "permissive", for: "select", to: ["public"], using: sql`true` }),
	pgPolicy("task_records_允许公开写入", { as: "permissive", for: "insert", to: ["public"] }),
	pgPolicy("task_records_允许公开更新", { as: "permissive", for: "update", to: ["public"] }),
	pgPolicy("task_records_允许公开删除", { as: "permissive", for: "delete", to: ["public"] }),
]);

export const users = pgTable("users", {
	id: uuid().defaultRandom().primaryKey().notNull(),
	openid: varchar({ length: 128 }),
	nickname: varchar({ length: 100 }),
	avatar: varchar({ length: 500 }),
	phone: varchar({ length: 20 }),
	city: varchar({ length: 50 }),
	industry: varchar({ length: 50 }),
	points: integer().default(0).notNull(),
	level: integer().default(1).notNull(),
	inviteCode: varchar("invite_code", { length: 20 }),
	invitedBy: uuid("invited_by"),
	lastSignInAt: timestamp("last_sign_in_at", { withTimezone: true, mode: 'string' }),
	createdAt: timestamp("created_at", { withTimezone: true, mode: 'string' }).defaultNow().notNull(),
	updatedAt: timestamp("updated_at", { withTimezone: true, mode: 'string' }),
	bio: text(),
	wechat: varchar({ length: 50 }),
	email: varchar({ length: 100 }),
	region: varchar({ length: 20 }).default('island_inside'),
	district: varchar({ length: 50 }),
	referralCode: varchar("referral_code", { length: 20 }),
	referrerId: uuid("referrer_id"),
	isNewUser: boolean("is_new_user").default(true),
}, (table) => [
	index("users_city_idx").using("btree", table.city.asc().nullsLast().op("text_ops")),
	index("users_invite_code_idx").using("btree", table.inviteCode.asc().nullsLast().op("text_ops")),
	index("users_invited_by_idx").using("btree", table.invitedBy.asc().nullsLast().op("uuid_ops")),
	index("users_level_idx").using("btree", table.level.asc().nullsLast().op("int4_ops")),
	index("users_openid_idx").using("btree", table.openid.asc().nullsLast().op("text_ops")),
	index("users_points_idx").using("btree", table.points.asc().nullsLast().op("int4_ops")),
	index("users_referral_code_idx").using("btree", table.referralCode.asc().nullsLast().op("text_ops")),
	index("users_referrer_id_idx").using("btree", table.referrerId.asc().nullsLast().op("uuid_ops")),
	index("users_region_idx").using("btree", table.region.asc().nullsLast().op("text_ops")),
	unique("users_openid_unique").on(table.openid),
	unique("users_invite_code_unique").on(table.inviteCode),
	unique("users_referral_code_unique").on(table.referralCode),
	pgPolicy("users_允许公开读取", { as: "permissive", for: "select", to: ["public"], using: sql`true` }),
	pgPolicy("users_允许公开写入", { as: "permissive", for: "insert", to: ["public"] }),
	pgPolicy("users_允许公开更新", { as: "permissive", for: "update", to: ["public"] }),
	pgPolicy("users_允许公开删除", { as: "permissive", for: "delete", to: ["public"] }),
]);

export const userCoupons = pgTable("user_coupons", {
	id: uuid().defaultRandom().primaryKey().notNull(),
	userId: uuid("user_id").notNull(),
	couponId: uuid("coupon_id").notNull(),
	source: varchar({ length: 20 }).notNull(),
	status: varchar({ length: 20 }).default('unused').notNull(),
	usedAt: timestamp("used_at", { withTimezone: true, mode: 'string' }),
	orderId: uuid("order_id"),
	expireAt: timestamp("expire_at", { withTimezone: true, mode: 'string' }).notNull(),
	createdAt: timestamp("created_at", { withTimezone: true, mode: 'string' }).defaultNow().notNull(),
}, (table) => [
	index("user_coupons_coupon_id_idx").using("btree", table.couponId.asc().nullsLast().op("uuid_ops")),
	index("user_coupons_expire_at_idx").using("btree", table.expireAt.asc().nullsLast().op("timestamptz_ops")),
	index("user_coupons_status_idx").using("btree", table.status.asc().nullsLast().op("text_ops")),
	index("user_coupons_user_id_idx").using("btree", table.userId.asc().nullsLast().op("uuid_ops")),
	foreignKey({
			columns: [table.userId],
			foreignColumns: [users.id],
			name: "user_coupons_user_id_fkey"
		}).onDelete("cascade"),
	foreignKey({
			columns: [table.couponId],
			foreignColumns: [coupons.id],
			name: "user_coupons_coupon_id_fkey"
		}).onDelete("cascade"),
	pgPolicy("user_coupons_允许公开删除", { as: "permissive", for: "delete", to: ["public"] }),
	pgPolicy("user_coupons_允许公开更新", { as: "permissive", for: "update", to: ["public"] }),
	pgPolicy("user_coupons_允许公开写入", { as: "permissive", for: "insert", to: ["public"] }),
	pgPolicy("user_coupons_允许公开读取", { as: "permissive", for: "select", to: ["public"] }),
]);

export const redPacketConfigs = pgTable("red_packet_configs", {
	id: uuid().defaultRandom().primaryKey().notNull(),
	name: varchar({ length: 100 }).notNull(),
	scene: varchar({ length: 50 }).notNull(),
	type: varchar({ length: 20 }).notNull(),
	amount: numeric({ precision: 10, scale:  2 }).notNull(),
	minSpend: numeric("min_spend", { precision: 10, scale:  2 }).default('0'),
	region: varchar({ length: 20 }),
	category: varchar({ length: 50 }),
	validDays: integer("valid_days").default(7),
	validMinutes: integer("valid_minutes"),
	priority: integer().default(0),
	isActive: boolean("is_active").default(true).notNull(),
	description: text(),
	createdAt: timestamp("created_at", { withTimezone: true, mode: 'string' }).defaultNow().notNull(),
	updatedAt: timestamp("updated_at", { withTimezone: true, mode: 'string' }),
}, (table) => [
	index("red_packet_configs_is_active_idx").using("btree", table.isActive.asc().nullsLast().op("bool_ops")),
	index("red_packet_configs_region_idx").using("btree", table.region.asc().nullsLast().op("text_ops")),
	index("red_packet_configs_scene_idx").using("btree", table.scene.asc().nullsLast().op("text_ops")),
	pgPolicy("red_packet_configs_允许公开删除", { as: "permissive", for: "delete", to: ["public"] }),
	pgPolicy("red_packet_configs_允许公开更新", { as: "permissive", for: "update", to: ["public"] }),
	pgPolicy("red_packet_configs_允许公开写入", { as: "permissive", for: "insert", to: ["public"] }),
	pgPolicy("red_packet_configs_允许公开读取", { as: "permissive", for: "select", to: ["public"] }),
]);

export const balanceRecords = pgTable("balance_records", {
	id: uuid().defaultRandom().primaryKey().notNull(),
	userId: uuid("user_id").notNull(),
	amount: numeric({ precision: 10, scale:  2 }).notNull(),
	type: varchar({ length: 20 }).notNull(),
	description: varchar({ length: 200 }),
	relatedId: uuid("related_id"),
	status: varchar({ length: 20 }).default('completed').notNull(),
	createdAt: timestamp("created_at", { withTimezone: true, mode: 'string' }).defaultNow().notNull(),
}, (table) => [
	index("balance_records_created_at_idx").using("btree", table.createdAt.asc().nullsLast().op("timestamptz_ops")),
	index("balance_records_type_idx").using("btree", table.type.asc().nullsLast().op("text_ops")),
	index("balance_records_user_id_idx").using("btree", table.userId.asc().nullsLast().op("uuid_ops")),
	foreignKey({
			columns: [table.userId],
			foreignColumns: [users.id],
			name: "balance_records_user_id_fkey"
		}).onDelete("cascade"),
	pgPolicy("balance_records_允许公开删除", { as: "permissive", for: "delete", to: ["public"] }),
	pgPolicy("balance_records_允许公开更新", { as: "permissive", for: "update", to: ["public"] }),
	pgPolicy("balance_records_允许公开写入", { as: "permissive", for: "insert", to: ["public"] }),
	pgPolicy("balance_records_允许公开读取", { as: "permissive", for: "select", to: ["public"] }),
]);

export const referralRewardRules = pgTable("referral_reward_rules", {
	id: uuid().defaultRandom().primaryKey().notNull(),
	name: varchar({ length: 100 }).notNull(),
	action: varchar({ length: 50 }).notNull(),
	referrerReward: text().notNull(),
	refereeReward: text().notNull(),
	region: varchar({ length: 20 }),
	isActive: boolean("is_active").default(true).notNull(),
	createdAt: timestamp("created_at", { withTimezone: true, mode: 'string' }).defaultNow().notNull(),
}, (table) => [
	index("referral_reward_rules_action_idx").using("btree", table.action.asc().nullsLast().op("text_ops")),
	index("referral_reward_rules_is_active_idx").using("btree", table.isActive.asc().nullsLast().op("bool_ops")),
	pgPolicy("referral_reward_rules_允许公开删除", { as: "permissive", for: "delete", to: ["public"] }),
	pgPolicy("referral_reward_rules_允许公开更新", { as: "permissive", for: "update", to: ["public"] }),
	pgPolicy("referral_reward_rules_允许公开写入", { as: "permissive", for: "insert", to: ["public"] }),
	pgPolicy("referral_reward_rules_允许公开读取", { as: "permissive", for: "select", to: ["public"] }),
]);

export const regionRankings = pgTable("region_rankings", {
	id: uuid().defaultRandom().primaryKey().notNull(),
	userId: uuid("user_id").notNull(),
	region: varchar({ length: 20 }).notNull(),
	rankType: varchar("rank_type", { length: 20 }).notNull(),
	period: varchar({ length: 20 }).notNull(),
	score: integer().default(0),
	rank: integer(),
	periodStart: timestamp("period_start", { withTimezone: true, mode: 'string' }),
	periodEnd: timestamp("period_end", { withTimezone: true, mode: 'string' }),
	createdAt: timestamp("created_at", { withTimezone: true, mode: 'string' }).defaultNow().notNull(),
}, (table) => [
	index("region_rankings_period_idx").using("btree", table.period.asc().nullsLast().op("text_ops")),
	index("region_rankings_rank_type_idx").using("btree", table.rankType.asc().nullsLast().op("text_ops")),
	index("region_rankings_region_idx").using("btree", table.region.asc().nullsLast().op("text_ops")),
	index("region_rankings_user_id_idx").using("btree", table.userId.asc().nullsLast().op("uuid_ops")),
	foreignKey({
			columns: [table.userId],
			foreignColumns: [users.id],
			name: "region_rankings_user_id_fkey"
		}).onDelete("cascade"),
	pgPolicy("region_rankings_允许公开删除", { as: "permissive", for: "delete", to: ["public"] }),
	pgPolicy("region_rankings_允许公开更新", { as: "permissive", for: "update", to: ["public"] }),
	pgPolicy("region_rankings_允许公开写入", { as: "permissive", for: "insert", to: ["public"] }),
	pgPolicy("region_rankings_允许公开读取", { as: "permissive", for: "select", to: ["public"] }),
]);

// 到店核销码表
export const verifications = pgTable("verifications", {
	id: uuid().defaultRandom().primaryKey().notNull(),
	orderId: uuid("order_id").notNull(),
	userId: uuid("user_id").notNull(),
	merchantId: uuid("merchant_id").notNull(),
	verifyCode: varchar("verify_code", { length: 20 }).notNull(),
	qrContent: text("qr_content"),
	userDistrict: varchar("user_district", { length: 50 }),
	merchantDistrict: varchar("merchant_district", { length: 50 }),
	amount: numeric({ precision: 10, scale: 2 }).notNull(),
	discount: numeric({ precision: 10, scale: 2 }),
	finalAmount: numeric("final_amount", { precision: 10, scale: 2 }),
	status: varchar({ length: 20 }).default('pending').notNull(),
	verifiedAt: timestamp("verified_at", { withTimezone: true, mode: 'string' }),
	verifiedBy: uuid("verified_by"),
	expiresAt: timestamp("expires_at", { withTimezone: true, mode: 'string' }).notNull(),
	createdAt: timestamp("created_at", { withTimezone: true, mode: 'string' }).defaultNow().notNull(),
}, (table) => [
	index("verifications_expires_at_idx").using("btree", table.expiresAt.asc().nullsLast().op("timestamptz_ops")),
	index("verifications_merchant_id_idx").using("btree", table.merchantId.asc().nullsLast().op("uuid_ops")),
	index("verifications_order_id_idx").using("btree", table.orderId.asc().nullsLast().op("uuid_ops")),
	index("verifications_status_idx").using("btree", table.status.asc().nullsLast().op("text_ops")),
	index("verifications_user_id_idx").using("btree", table.userId.asc().nullsLast().op("uuid_ops")),
	index("verifications_verify_code_idx").using("btree", table.verifyCode.asc().nullsLast().op("text_ops")),
	foreignKey({
			columns: [table.orderId],
			foreignColumns: [orders.id],
			name: "verifications_order_id_fkey"
		}).onDelete("cascade"),
	foreignKey({
			columns: [table.userId],
			foreignColumns: [users.id],
			name: "verifications_user_id_fkey"
		}).onDelete("cascade"),
	foreignKey({
			columns: [table.merchantId],
			foreignColumns: [merchants.id],
			name: "verifications_merchant_id_fkey"
		}).onDelete("cascade"),
	pgPolicy("verifications_允许公开删除", { as: "permissive", for: "delete", to: ["public"] }),
	pgPolicy("verifications_允许公开更新", { as: "permissive", for: "update", to: ["public"] }),
	pgPolicy("verifications_允许公开写入", { as: "permissive", for: "insert", to: ["public"] }),
	pgPolicy("verifications_允许公开读取", { as: "permissive", for: "select", to: ["public"] }),
]);

// 商家入驻申请表
export const merchantApplications = pgTable("merchant_applications", {
	id: uuid().defaultRandom().primaryKey().notNull(),
	userId: uuid("user_id"),
	name: varchar({ length: 100 }).notNull(),
	category: varchar({ length: 50 }).notNull(),
	region: varchar({ length: 20 }).notNull(),
	district: varchar({ length: 50 }).notNull(),
	address: varchar({ length: 200 }).notNull(),
	contactName: varchar("contact_name", { length: 50 }).notNull(),
	contactPhone: varchar("contact_phone", { length: 20 }).notNull(),
	businessLicense: varchar("business_license", { length: 500 }),
	storeImage: varchar("store_image", { length: 500 }),
	description: text(),
	status: varchar({ length: 20 }).default('pending').notNull(),
	reviewNote: text("review_note"),
	reviewedAt: timestamp("reviewed_at", { withTimezone: true, mode: 'string' }),
	reviewedBy: uuid("reviewed_by"),
	merchantId: uuid("merchant_id"),
	createdAt: timestamp("created_at", { withTimezone: true, mode: 'string' }).defaultNow().notNull(),
	updatedAt: timestamp("updated_at", { withTimezone: true, mode: 'string' }),
}, (table) => [
	index("merchant_applications_category_idx").using("btree", table.category.asc().nullsLast().op("text_ops")),
	index("merchant_applications_district_idx").using("btree", table.district.asc().nullsLast().op("text_ops")),
	index("merchant_applications_region_idx").using("btree", table.region.asc().nullsLast().op("text_ops")),
	index("merchant_applications_status_idx").using("btree", table.status.asc().nullsLast().op("text_ops")),
	index("merchant_applications_user_id_idx").using("btree", table.userId.asc().nullsLast().op("uuid_ops")),
	foreignKey({
			columns: [table.userId],
			foreignColumns: [users.id],
			name: "merchant_applications_user_id_fkey"
		}).onDelete("set null"),
	foreignKey({
			columns: [table.merchantId],
			foreignColumns: [merchants.id],
			name: "merchant_applications_merchant_id_fkey"
		}).onDelete("set null"),
	pgPolicy("merchant_applications_允许公开删除", { as: "permissive", for: "delete", to: ["public"] }),
	pgPolicy("merchant_applications_允许公开更新", { as: "permissive", for: "update", to: ["public"] }),
	pgPolicy("merchant_applications_允许公开写入", { as: "permissive", for: "insert", to: ["public"] }),
	pgPolicy("merchant_applications_允许公开读取", { as: "permissive", for: "select", to: ["public"] }),
]);

// 商家每日统计表
export const merchantDailyStats = pgTable("merchant_daily_stats", {
	id: uuid().defaultRandom().primaryKey().notNull(),
	merchantId: uuid("merchant_id").notNull(),
	date: varchar({ length: 10 }).notNull(),
	orderCount: integer("order_count").default(0).notNull(),
	totalAmount: numeric("total_amount", { precision: 10, scale: 2 }).default('0').notNull(),
	verifyCount: integer("verify_count").default(0).notNull(),
	newCustomerCount: integer("new_customer_count").default(0).notNull(),
	commissionAmount: numeric("commission_amount", { precision: 10, scale: 2 }).default('0').notNull(),
	createdAt: timestamp("created_at", { withTimezone: true, mode: 'string' }).defaultNow().notNull(),
}, (table) => [
	index("merchant_daily_stats_date_idx").using("btree", table.date.asc().nullsLast().op("text_ops")),
	index("merchant_daily_stats_merchant_id_idx").using("btree", table.merchantId.asc().nullsLast().op("uuid_ops")),
	foreignKey({
			columns: [table.merchantId],
			foreignColumns: [merchants.id],
			name: "merchant_daily_stats_merchant_id_fkey"
		}).onDelete("cascade"),
	pgPolicy("merchant_daily_stats_允许公开删除", { as: "permissive", for: "delete", to: ["public"] }),
	pgPolicy("merchant_daily_stats_允许公开更新", { as: "permissive", for: "update", to: ["public"] }),
	pgPolicy("merchant_daily_stats_允许公开写入", { as: "permissive", for: "insert", to: ["public"] }),
	pgPolicy("merchant_daily_stats_允许公开读取", { as: "permissive", for: "select", to: ["public"] }),
]);

export const shareRecords = pgTable("share_records", {
	id: uuid().defaultRandom().primaryKey().notNull(),
	userId: uuid("user_id").notNull(),
	shareType: varchar("share_type", { length: 20 }).notNull(),
	relatedId: varchar("related_id", { length: 100 }),
	region: varchar({ length: 20 }),
	viewCount: integer("view_count").default(0),
	clickCount: integer("click_count").default(0),
	convertCount: integer("convert_count").default(0),
	createdAt: timestamp("created_at", { withTimezone: true, mode: 'string' }).defaultNow().notNull(),
}, (table) => [
	index("share_records_created_at_idx").using("btree", table.createdAt.asc().nullsLast().op("timestamptz_ops")),
	index("share_records_share_type_idx").using("btree", table.shareType.asc().nullsLast().op("text_ops")),
	index("share_records_user_id_idx").using("btree", table.userId.asc().nullsLast().op("uuid_ops")),
	foreignKey({
			columns: [table.userId],
			foreignColumns: [users.id],
			name: "share_records_user_id_fkey"
		}).onDelete("cascade"),
	pgPolicy("share_records_允许公开删除", { as: "permissive", for: "delete", to: ["public"] }),
	pgPolicy("share_records_允许公开更新", { as: "permissive", for: "update", to: ["public"] }),
	pgPolicy("share_records_允许公开写入", { as: "permissive", for: "insert", to: ["public"] }),
	pgPolicy("share_records_允许公开读取", { as: "permissive", for: "select", to: ["public"] }),
]);

export const userBalances = pgTable("user_balances", {
	id: uuid().defaultRandom().primaryKey().notNull(),
	userId: uuid("user_id").notNull(),
	balance: numeric({ precision: 10, scale:  2 }).default('0').notNull(),
	frozenBalance: numeric("frozen_balance", { precision: 10, scale:  2 }).default('0'),
	totalEarned: numeric("total_earned", { precision: 10, scale:  2 }).default('0'),
	totalWithdrawn: numeric("total_withdrawn", { precision: 10, scale:  2 }).default('0'),
	createdAt: timestamp("created_at", { withTimezone: true, mode: 'string' }).defaultNow().notNull(),
	updatedAt: timestamp("updated_at", { withTimezone: true, mode: 'string' }),
}, (table) => [
	index("user_balances_user_id_idx").using("btree", table.userId.asc().nullsLast().op("uuid_ops")),
	foreignKey({
			columns: [table.userId],
			foreignColumns: [users.id],
			name: "user_balances_user_id_fkey"
		}).onDelete("cascade"),
	pgPolicy("user_balances_允许公开删除", { as: "permissive", for: "delete", to: ["public"] }),
	pgPolicy("user_balances_允许公开更新", { as: "permissive", for: "update", to: ["public"] }),
	pgPolicy("user_balances_允许公开写入", { as: "permissive", for: "insert", to: ["public"] }),
	pgPolicy("user_balances_允许公开读取", { as: "permissive", for: "select", to: ["public"] }),
]);

export const userRedPackets = pgTable("user_red_packets", {
	id: uuid().defaultRandom().primaryKey().notNull(),
	userId: uuid("user_id").notNull(),
	configId: uuid("config_id"),
	type: varchar({ length: 20 }).notNull(),
	amount: numeric({ precision: 10, scale:  2 }).notNull(),
	minSpend: numeric("min_spend", { precision: 10, scale:  2 }).default('0'),
	source: varchar({ length: 50 }).notNull(),
	relatedUserId: uuid("related_user_id"),
	region: varchar({ length: 20 }).notNull(),
	status: varchar({ length: 20 }).default('unused').notNull(),
	usedAt: timestamp("used_at", { withTimezone: true, mode: 'string' }),
	orderId: uuid("order_id"),
	expireAt: timestamp("expire_at", { withTimezone: true, mode: 'string' }).notNull(),
	createdAt: timestamp("created_at", { withTimezone: true, mode: 'string' }).defaultNow().notNull(),
}, (table) => [
	index("user_red_packets_expire_at_idx").using("btree", table.expireAt.asc().nullsLast().op("timestamptz_ops")),
	index("user_red_packets_region_idx").using("btree", table.region.asc().nullsLast().op("text_ops")),
	index("user_red_packets_source_idx").using("btree", table.source.asc().nullsLast().op("text_ops")),
	index("user_red_packets_status_idx").using("btree", table.status.asc().nullsLast().op("text_ops")),
	index("user_red_packets_user_id_idx").using("btree", table.userId.asc().nullsLast().op("uuid_ops")),
	foreignKey({
			columns: [table.userId],
			foreignColumns: [users.id],
			name: "user_red_packets_user_id_fkey"
		}).onDelete("cascade"),
	pgPolicy("user_red_packets_允许公开删除", { as: "permissive", for: "delete", to: ["public"] }),
	pgPolicy("user_red_packets_允许公开更新", { as: "permissive", for: "update", to: ["public"] }),
	pgPolicy("user_red_packets_允许公开写入", { as: "permissive", for: "insert", to: ["public"] }),
	pgPolicy("user_red_packets_允许公开读取", { as: "permissive", for: "select", to: ["public"] }),
]);

// 管理员表
export const admins = pgTable("admins", {
	id: uuid().defaultRandom().primaryKey().notNull(),
	username: varchar({ length: 50 }).notNull(),
	password: varchar({ length: 255 }).notNull(),
	nickname: varchar({ length: 100 }),
	role: varchar({ length: 20 }).default('admin').notNull(), // super_admin, admin, operator
	status: varchar({ length: 20 }).default('active').notNull(),
	lastLoginAt: timestamp("last_login_at", { withTimezone: true, mode: 'string' }),
	createdAt: timestamp("created_at", { withTimezone: true, mode: 'string' }).defaultNow().notNull(),
	updatedAt: timestamp("updated_at", { withTimezone: true, mode: 'string' }),
}, (table) => [
	index("admins_username_idx").using("btree", table.username.asc().nullsLast().op("text_ops")),
	index("admins_status_idx").using("btree", table.status.asc().nullsLast().op("text_ops")),
	pgPolicy("admins_允许公开删除", { as: "permissive", for: "delete", to: ["public"] }),
	pgPolicy("admins_允许公开更新", { as: "permissive", for: "update", to: ["public"] }),
	pgPolicy("admins_允许公开写入", { as: "permissive", for: "insert", to: ["public"] }),
	pgPolicy("admins_允许公开读取", { as: "permissive", for: "select", to: ["public"] }),
]);

// 管理员操作日志
export const adminLogs = pgTable("admin_logs", {
	id: uuid().defaultRandom().primaryKey().notNull(),
	adminId: uuid("admin_id").notNull(),
	action: varchar({ length: 50 }).notNull(),
	target: varchar({ length: 100 }),
	targetId: varchar("target_id", { length: 100 }),
	details: text(),
	ipAddress: varchar("ip_address", { length: 50 }),
	createdAt: timestamp("created_at", { withTimezone: true, mode: 'string' }).defaultNow().notNull(),
}, (table) => [
	index("admin_logs_action_idx").using("btree", table.action.asc().nullsLast().op("text_ops")),
	index("admin_logs_admin_id_idx").using("btree", table.adminId.asc().nullsLast().op("uuid_ops")),
	index("admin_logs_created_at_idx").using("btree", table.createdAt.asc().nullsLast().op("timestamptz_ops")),
	foreignKey({
			columns: [table.adminId],
			foreignColumns: [admins.id],
			name: "admin_logs_admin_id_fkey"
		}).onDelete("cascade"),
	pgPolicy("admin_logs_允许公开删除", { as: "permissive", for: "delete", to: ["public"] }),
	pgPolicy("admin_logs_允许公开更新", { as: "permissive", for: "update", to: ["public"] }),
	pgPolicy("admin_logs_允许公开写入", { as: "permissive", for: "insert", to: ["public"] }),
	pgPolicy("admin_logs_允许公开读取", { as: "permissive", for: "select", to: ["public"] }),
]);

// 系统配置表
export const systemConfigs = pgTable("system_configs", {
	id: serial().primaryKey().notNull(),
	configKey: varchar("config_key", { length: 100 }).notNull().unique(),
	configValue: text("config_value"),
	configType: varchar("config_type", { length: 50 }).default('text').notNull(),
	category: varchar({ length: 50 }).default('general').notNull(),
	description: text(),
	isSecret: boolean("is_secret").default(false).notNull(),
	createdAt: timestamp("created_at", { withTimezone: true, mode: 'string' }).defaultNow().notNull(),
	updatedAt: timestamp("updated_at", { withTimezone: true, mode: 'string' }),
}, (table) => [
	index("system_configs_config_key_idx").using("btree", table.configKey.asc().nullsLast().op("text_ops")),
	index("system_configs_category_idx").using("btree", table.category.asc().nullsLast().op("text_ops")),
	pgPolicy("system_configs_允许公开删除", { as: "permissive", for: "delete", to: ["public"] }),
	pgPolicy("system_configs_允许公开更新", { as: "permissive", for: "update", to: ["public"] }),
	pgPolicy("system_configs_允许公开写入", { as: "permissive", for: "insert", to: ["public"] }),
	pgPolicy("system_configs_允许公开读取", { as: "permissive", for: "select", to: ["public"] }),
]);

// 系统配置更新日志
export const systemConfigLogs = pgTable("system_config_logs", {
	id: serial().primaryKey().notNull(),
	configKey: varchar("config_key", { length: 100 }).notNull(),
	oldValue: text("old_value"),
	newValue: text("new_value"),
	operatorId: varchar("operator_id", { length: 50 }),
	operatorName: varchar("operator_name", { length: 100 }),
	createdAt: timestamp("created_at", { withTimezone: true, mode: 'string' }).defaultNow().notNull(),
}, (table) => [
	index("system_config_logs_config_key_idx").using("btree", table.configKey.asc().nullsLast().op("text_ops")),
	index("system_config_logs_created_at_idx").using("btree", table.createdAt.asc().nullsLast().op("timestamptz_ops")),
	pgPolicy("system_config_logs_允许公开删除", { as: "permissive", for: "delete", to: ["public"] }),
	pgPolicy("system_config_logs_允许公开更新", { as: "permissive", for: "update", to: ["public"] }),
	pgPolicy("system_config_logs_允许公开写入", { as: "permissive", for: "insert", to: ["public"] }),
	pgPolicy("system_config_logs_允许公开读取", { as: "permissive", for: "select", to: ["public"] }),
]);

// 积分商品表
export const pointsProducts = pgTable("points_products", {
	id: uuid().defaultRandom().primaryKey().notNull(),
	name: varchar({ length: 100 }).notNull(),
	description: text(),
	imageUrl: varchar("image_url", { length: 500 }),
	pointsPrice: integer("points_price").notNull().default(0),
	originalPrice: numeric("original_price", { precision: 10, scale: 2 }),
	stock: integer().notNull().default(0),
	totalCount: integer("total_count").notNull().default(0),
	exchangeCount: integer("exchange_count").notNull().default(0),
	category: varchar({ length: 50 }).default('other'),
	region: varchar({ length: 20 }),
	isActive: boolean("is_active").notNull().default(true),
	sortOrder: integer("sort_order").default(0),
	createdAt: timestamp("created_at", { withTimezone: true, mode: 'string' }).defaultNow().notNull(),
	updatedAt: timestamp("updated_at", { withTimezone: true, mode: 'string' }),
}, (table) => [
	index("points_products_category_idx").using("btree", table.category.asc().nullsLast().op("text_ops")),
	index("points_products_is_active_idx").using("btree", table.isActive.asc().nullsLast().op("bool_ops")),
	index("points_products_region_idx").using("btree", table.region.asc().nullsLast().op("text_ops")),
	pgPolicy("points_products_允许公开删除", { as: "permissive", for: "delete", to: ["public"] }),
	pgPolicy("points_products_允许公开更新", { as: "permissive", for: "update", to: ["public"] }),
	pgPolicy("points_products_允许公开写入", { as: "permissive", for: "insert", to: ["public"] }),
	pgPolicy("points_products_允许公开读取", { as: "permissive", for: "select", to: ["public"] }),
]);

// 积分兑换记录表
export const pointsExchangeRecords = pgTable("points_exchange_records", {
	id: uuid().defaultRandom().primaryKey().notNull(),
	userId: uuid("user_id").notNull(),
	productId: uuid("product_id").notNull(),
	productName: varchar("product_name", { length: 100 }).notNull(),
	pointsCost: integer("points_cost").notNull(),
	quantity: integer().notNull().default(1),
	status: varchar({ length: 20 }).notNull().default('pending'),
	receiverName: varchar("receiver_name", { length: 50 }),
	receiverPhone: varchar("receiver_phone", { length: 20 }),
	receiverAddress: text("receiver_address"),
	trackingNo: varchar("tracking_no", { length: 100 }),
	shippedAt: timestamp("shipped_at", { withTimezone: true, mode: 'string' }),
	completedAt: timestamp("completed_at", { withTimezone: true, mode: 'string' }),
	createdAt: timestamp("created_at", { withTimezone: true, mode: 'string' }).defaultNow().notNull(),
}, (table) => [
	index("points_exchange_records_user_id_idx").using("btree", table.userId.asc().nullsLast().op("uuid_ops")),
	index("points_exchange_records_status_idx").using("btree", table.status.asc().nullsLast().op("text_ops")),
	index("points_exchange_records_product_id_idx").using("btree", table.productId.asc().nullsLast().op("uuid_ops")),
	foreignKey({
		columns: [table.userId],
		foreignColumns: [users.id],
		name: "points_exchange_records_user_id_fkey"
	}).onDelete("cascade"),
	pgPolicy("points_exchange_records_允许公开删除", { as: "permissive", for: "delete", to: ["public"] }),
	pgPolicy("points_exchange_records_允许公开更新", { as: "permissive", for: "update", to: ["public"] }),
	pgPolicy("points_exchange_records_允许公开写入", { as: "permissive", for: "insert", to: ["public"] }),
	pgPolicy("points_exchange_records_允许公开读取", { as: "permissive", for: "select", to: ["public"] }),
]);

// 积分明细表
export const pointsRecords = pgTable("points_records", {
	id: uuid().defaultRandom().primaryKey().notNull(),
	userId: uuid("user_id").notNull(),
	points: integer().notNull(),
	type: varchar({ length: 20 }).notNull(),
	description: varchar({ length: 200 }),
	relatedId: uuid("related_id"),
	balanceAfter: integer("balance_after").default(0),
	createdAt: timestamp("created_at", { withTimezone: true, mode: 'string' }).defaultNow().notNull(),
}, (table) => [
	index("points_records_user_id_idx").using("btree", table.userId.asc().nullsLast().op("uuid_ops")),
	index("points_records_type_idx").using("btree", table.type.asc().nullsLast().op("text_ops")),
	index("points_records_created_at_idx").using("btree", table.createdAt.asc().nullsLast().op("timestamptz_ops")),
	foreignKey({
		columns: [table.userId],
		foreignColumns: [users.id],
		name: "points_records_user_id_fkey"
	}).onDelete("cascade"),
	pgPolicy("points_records_允许公开删除", { as: "permissive", for: "delete", to: ["public"] }),
	pgPolicy("points_records_允许公开更新", { as: "permissive", for: "update", to: ["public"] }),
	pgPolicy("points_records_允许公开写入", { as: "permissive", for: "insert", to: ["public"] }),
	pgPolicy("points_records_允许公开读取", { as: "permissive", for: "select", to: ["public"] }),
]);
