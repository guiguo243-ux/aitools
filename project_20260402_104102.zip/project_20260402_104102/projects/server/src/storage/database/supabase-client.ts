import { createClient, SupabaseClient } from '@supabase/supabase-js';

// Supabase 配置（Coze 平台使用 COZE_ 前缀的环境变量）
const supabaseUrl = process.env.COZE_SUPABASE_URL || process.env.SUPABASE_URL || '';
const supabaseKey = process.env.COZE_SUPABASE_ANON_KEY || process.env.SUPABASE_ANON_KEY || '';

console.log('[Supabase] URL:', supabaseUrl ? supabaseUrl.substring(0, 30) + '...' : 'NOT SET');
console.log('[Supabase] Key:', supabaseKey ? 'SET (length: ' + supabaseKey.length + ')' : 'NOT SET');

if (!supabaseUrl || !supabaseKey) {
  console.warn('⚠️ Supabase configuration is missing. Please set COZE_SUPABASE_URL and COZE_SUPABASE_ANON_KEY environment variables.');
}

// 创建 Supabase 客户端
let supabaseClient: SupabaseClient | null = null;

export function getSupabaseClient(): SupabaseClient {
  if (!supabaseClient && supabaseUrl && supabaseKey) {
    supabaseClient = createClient(supabaseUrl, supabaseKey, {
      auth: {
        autoRefreshToken: false,
        persistSession: false,
      },
    });
  }

  if (!supabaseClient) {
    // 返回一个 mock 客户端，避免运行时错误
    console.warn('⚠️ Using mock Supabase client. Data operations will not persist.');
    return createMockClient() as unknown as SupabaseClient;
  }

  return supabaseClient;
}

// Mock 客户端（开发环境使用）
function createMockClient(): any {
  const createChain = (): any => {
    const chain: any = {
      eq: () => chain,
      neq: () => chain,
      gt: () => chain,
      gte: () => chain,
      lt: () => chain,
      lte: () => chain,
      in: () => chain,
      or: () => chain,
      and: () => chain,
      order: () => chain,
      limit: () => chain,
      range: () => chain,
      single: async () => ({ data: null, error: null }),
      maybeSingle: async () => ({ data: null, error: null }),
      select: () => chain,
    };
    return Object.assign(Promise.resolve({ data: [], error: null, count: 0 }), chain);
  };

  return {
    from: (table: string) => ({
      select: (columns?: string) => createChain(),
      insert: (data: any) => ({
        select: () => ({
          single: async () => ({ data: { id: 'mock-id', ...data }, error: null }),
        }),
      }),
      update: (data: any) => ({
        eq: () => ({
          select: () => ({
            single: async () => ({ data: { id: 'mock-id', ...data }, error: null }),
          }),
        }),
      }),
      upsert: (data: any) => Promise.resolve({ data, error: null }),
      delete: () => createChain(),
    }),
    rpc: (fn: string, params?: any) => Promise.resolve({ data: null, error: null }),
    auth: {
      getUser: async () => ({ data: { user: null }, error: null }),
      signInWithOAuth: async () => ({ data: null, error: null }),
      signOut: async () => ({ error: null }),
    },
  };
}
