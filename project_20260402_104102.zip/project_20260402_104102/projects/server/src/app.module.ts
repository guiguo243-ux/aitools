import { Module } from '@nestjs/common';
import { ConfigModule } from '@nestjs/config';
import { AppController } from '@/app.controller';
import { AppService } from '@/app.service';
import { AuthModule } from '@/modules/auth/auth.module';
import { UserModule } from '@/modules/user/user.module';
import { MerchantModule } from '@/modules/merchant/merchant.module';
import { AIGuideModule } from '@/modules/ai-guide/ai-guide.module';
import { ReferralModule } from '@/modules/referral/referral.module';
import { OrderModule } from '@/modules/order/order.module';
import { PosterModule } from '@/modules/poster/poster.module';
import { RankingModule } from '@/modules/ranking/ranking.module';
import { UrgencyModule } from '@/modules/urgency/urgency.module';
import { WalletModule } from '@/modules/wallet/wallet.module';
import { AddressModule } from '@/modules/address/address.module';
import { RegionLockModule } from '@/modules/region-lock/region-lock.module';
import { MerchantIncentiveModule } from '@/modules/merchant-incentive/merchant-incentive.module';
import { InstoreVerificationModule } from '@/modules/instore-verification/instore-verification.module';
import { PaymentModule } from '@/modules/payment/payment.module';
import { MessageModule } from '@/modules/message/message.module';
import { ReviewModule } from '@/modules/review/review.module';
import { RefundModule } from '@/modules/refund/refund.module';
import { SearchModule } from '@/modules/search/search.module';
import { FavoriteModule } from '@/modules/favorite/favorite.module';
import { CouponModule } from '@/modules/coupon/coupon.module';
import { MerchantBackendModule } from '@/modules/merchant-backend/merchant-backend.module';
import { AdminModule } from '@/modules/admin/admin.module';
import { UploadModule } from '@/modules/upload/upload.module';
import { SystemConfigModule } from '@/modules/system-config/system-config.module';
import { WebsocketModule } from '@/modules/websocket/websocket.module';
import { PointsShopModule } from '@/modules/points-shop/points-shop.module';
import { MemberModule } from '@/modules/member/member.module';
import { GroupBuyModule } from '@/modules/group-buy/group-buy.module';
import { FlashSaleModule } from '@/modules/flash-sale/flash-sale.module';

@Module({
  imports: [
    // 加载环境变量
    ConfigModule.forRoot({
      isGlobal: true,
      envFilePath: ['.env', 'server/.env'],
    }),
    AuthModule,
    UserModule,
    MerchantModule,
    AIGuideModule,
    MessageModule,
    ReviewModule,
    ReferralModule,
    OrderModule,
    PosterModule,
    RankingModule,
    UrgencyModule,
    WalletModule,
    AddressModule,
    RegionLockModule,
    MerchantIncentiveModule,
    InstoreVerificationModule,
    PaymentModule,
    RefundModule,
    SearchModule,
    FavoriteModule,
    CouponModule,
    MerchantBackendModule,
    AdminModule,
    UploadModule,
    SystemConfigModule,
    WebsocketModule,
    PointsShopModule,
    MemberModule,
    GroupBuyModule,
    FlashSaleModule,
  ],
  controllers: [AppController],
  providers: [AppService],
})
export class AppModule {}
