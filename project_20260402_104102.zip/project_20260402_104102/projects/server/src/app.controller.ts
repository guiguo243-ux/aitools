import { Controller, Get } from '@nestjs/common';
import { AppService } from '@/app.service';
import { getSupabaseClient } from '@/storage/database/supabase-client';

@Controller()
export class AppController {
  constructor(private readonly appService: AppService) {}

  @Get('hello')
  getHello(): { status: string; data: string } {
    return {
      status: 'success',
      data: this.appService.getHello()
    };
  }

  @Get('health')
  getHealth(): { status: string; data: string } {
    return {
      status: 'success',
      data: new Date().toISOString(),
    };
  }

  @Get('test-db')
  async testDb(): Promise<{ status: string; data: any }> {
    try {
      const client = getSupabaseClient();
      const { data, error } = await client.from('merchants').select('id, name, status').limit(3);
      
      return {
        status: error ? 'error' : 'success',
        data: {
          merchants: data,
          error: error?.message,
          env: {
            hasUrl: !!process.env.COZE_SUPABASE_URL,
            hasKey: !!process.env.COZE_SUPABASE_ANON_KEY,
          }
        }
      };
    } catch (err) {
      return {
        status: 'error',
        data: { message: err instanceof Error ? err.message : 'Unknown error' }
      };
    }
  }
}
