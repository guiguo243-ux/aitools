import { NestFactory } from '@nestjs/core';
import { AppModule } from '@/app.module';
import * as express from 'express';
import { HttpStatusInterceptor } from '@/interceptors/http-status.interceptor';
import { join } from 'path';

function parsePort(): number {
  const args = process.argv.slice(2);
  const portIndex = args.indexOf('-p');
  if (portIndex !== -1 && args[portIndex + 1]) {
    const port = parseInt(args[portIndex + 1], 10);
    if (!isNaN(port) && port > 0 && port < 65536) {
      return port;
    }
  }
  return 3000;
}

async function bootstrap() {
  const app = await NestFactory.create(AppModule);

  app.enableCors({
    origin: true,
    credentials: true,
  });

  // 1. 先设置 API 全局前缀
  app.setGlobalPrefix('api');
  app.use(express.json({ limit: '50mb' }));
  app.use(express.urlencoded({ limit: '50mb', extended: true }));

  // 2. 静态文件托管
  const distWebPath = join(__dirname, '..', 'dist-web');
  const adminDistPath = join(__dirname, '..', 'admin-web');
  
  // 用户端H5静态文件
  app.use('/', express.static(distWebPath));
  // PC管理后台静态文件
  app.use('/console', express.static(adminDistPath));

  // 3. SPA路由回退（放在最后，让 NestJS 路由优先匹配）
  app.use((req, res, next) => {
    // 如果是 API 路由，交给 NestJS 处理
    if (req.path.startsWith('/api/')) {
      return next();
    }
    // 如果是 /console/* 路径，返回管理后台 index.html
    if (req.path.startsWith('/console/')) {
      return res.sendFile(join(adminDistPath, 'index.html'));
    }
    // 其他路径返回用户端 H5 index.html
    res.sendFile(join(distWebPath, 'index.html'));
  });

  // 全局拦截器：统一将 POST 请求的 201 状态码改为 200
  app.useGlobalInterceptors(new HttpStatusInterceptor());
  // 开启优雅关闭 Hooks
  app.enableShutdownHooks();

  // 2. 解析端口
  const port = parsePort();
  try {
    await app.listen(port);
    console.log(`Server running on http://localhost:${port}`);
    console.log(`Admin Panel: http://localhost:${port}/console/`);
  } catch (err) {
    if (err.code === 'EADDRINUSE') {
      console.error(`❌ 端口 \({port} 被占用! 请运行 'npx kill-port \){port}' 然后重试。`);
      process.exit(1);
    } else {
      throw err;
    }
  }
  console.log(`Application is running on: http://localhost:3000`);
}
bootstrap();
