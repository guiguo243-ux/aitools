import { Injectable } from '@nestjs/common';
import { LLMClient, Config } from 'coze-coding-dev-sdk';

// 逼单场景类型
export type UrgencyScenario = 
  | 'low_stock'       // 库存紧张
  | 'price_drop'      // 降价优惠
  | 'time_limited'    // 限时活动
  | 'social_proof'    // 社交认同（好友购买）
  | 'high_demand'     // 高需求
  | 'region_exclusive'; // 区域专属

// 逼单请求参数
export interface UrgencyRequest {
  merchantId: string;
  merchantName: string;
  category: string;
  region: string;
  currentPrice?: number;
  originalPrice?: number;
  stock?: number;
  soldCount?: number;
  rating?: number;
  reviewCount?: number;
  friendBought?: boolean;
  scenarios?: UrgencyScenario[];
}

// 逼单文案结果
export interface UrgencyResult {
  headlines: string[];     // 标题式文案（用于弹窗/推送）
  descriptions: string[];  // 描述式文案（用于商品详情）
  badges: string[];        // 徽章式文案（用于标签）
  urgencyLevel: 'low' | 'medium' | 'high'; // 紧迫程度
  expireMinutes?: number;  // 推荐过期时间（分钟）
}

@Injectable()
export class UrgencyService {
  private llmClient: LLMClient;

  constructor() {
    const config = new Config();
    this.llmClient = new LLMClient(config);
  }

  /**
   * 生成AI逼单文案
   */
  async generateUrgencyCopy(request: UrgencyRequest): Promise<UrgencyResult> {
    const { 
      merchantName, 
      category, 
      region, 
      currentPrice, 
      originalPrice, 
      stock, 
      soldCount, 
      rating,
      reviewCount,
      friendBought,
      scenarios 
    } = request;

    // 构建上下文信息
    const contextInfo: string[] = [];
    if (stock !== undefined && stock <= 10) contextInfo.push(`库存仅剩${stock}份`);
    if (soldCount && soldCount >= 100) contextInfo.push(`已售${soldCount}单`);
    if (rating && rating >= 4.8) contextInfo.push(`评分${rating}分`);
    if (currentPrice && originalPrice && originalPrice > currentPrice) {
      const discount = Math.round((1 - currentPrice / originalPrice) * 100);
      contextInfo.push(`立省${originalPrice - currentPrice}元(${discount}%OFF)`);
    }
    if (friendBought) contextInfo.push('好友已购买');

    const regionText = region === 'island_inside' ? '岛内（思明/湖里）' : '岛外（集美/海沧/同安/翔安）';

    // 使用LLM生成文案
    const systemPrompt = `你是厦门本地生活平台的AI营销文案专家。你的任务是根据商家和商品信息，生成有说服力的逼单文案。

规则：
1. 文案要简洁有力，每条不超过20字
2. 突出紧迫感和稀缺性
3. 融入厦门本地元素和区域特色
4. 文案要有情感温度，避免生硬
5. 生成3-5条标题、3-5条描述、2-3个徽章`;

    const userPrompt = `请为以下商家生成逼单文案：

商家：${merchantName}
分类：${category}
区域：${regionText}
${contextInfo.length > 0 ? '关键信息：' + contextInfo.join('、') : ''}

请生成JSON格式：
{
  "headlines": ["标题文案1", "标题文案2", ...],
  "descriptions": ["描述文案1", "描述文案2", ...],
  "badges": ["徽章文案1", "徽章文案2", ...],
  "urgencyLevel": "low/medium/high"
}`;

    try {
      const messages = [
        { role: 'system' as const, content: systemPrompt },
        { role: 'user' as const, content: userPrompt }
      ];

      const response = await this.llmClient.invoke(messages, {
        model: 'doubao-seed-1-6-lite-251015',
        temperature: 0.8,
      });

      // 解析JSON响应
      const content = response.content.trim();
      const jsonMatch = content.match(/\{[\s\S]*\}/);
      
      if (jsonMatch) {
        const result = JSON.parse(jsonMatch[0]);
        return {
          headlines: result.headlines || this.getDefaultHeadlines(merchantName, category, region),
          descriptions: result.descriptions || this.getDefaultDescriptions(merchantName, category, region),
          badges: result.badges || this.getDefaultBadges(region),
          urgencyLevel: result.urgencyLevel || this.calculateUrgencyLevel(stock, soldCount),
        };
      }
    } catch (error) {
      console.error('Generate urgency copy error:', error);
    }

    // 降级到规则文案
    return {
      headlines: this.getDefaultHeadlines(merchantName, category, region),
      descriptions: this.getDefaultDescriptions(merchantName, category, region),
      badges: this.getDefaultBadges(region),
      urgencyLevel: this.calculateUrgencyLevel(stock, soldCount),
    };
  }

  /**
   * 生成快速逼单文案（不调用LLM）
   */
  generateQuickUrgencyCopy(request: UrgencyRequest): UrgencyResult {
    const { merchantName, category, region, stock, soldCount, currentPrice, originalPrice, friendBought } = request;

    const headlines: string[] = [];
    const descriptions: string[] = [];
    const badges: string[] = [];

    // 库存紧迫
    if (stock !== undefined && stock <= 5) {
      headlines.push(`⚠️ 仅剩${stock}份！手慢无`);
      descriptions.push(`${merchantName}超火爆，库存告急`);
    }

    // 销量认同
    if (soldCount && soldCount >= 100) {
      headlines.push(`🔥 已售${soldCount}单，品质保障`);
      descriptions.push(`${soldCount}人选择，好评如潮`);
    }

    // 价格优势
    if (currentPrice && originalPrice && originalPrice > currentPrice) {
      const saveAmount = originalPrice - currentPrice;
      headlines.push(`💰 今日立省${saveAmount}元`);
      descriptions.push(`限时优惠，错过等一年`);
    }

    // 社交认同
    if (friendBought) {
      headlines.push(`👥 好友也在这家下过单`);
      descriptions.push(`口碑好评，放心选择`);
    }

    // 区域专属
    const regionText = region === 'island_inside' ? '岛内' : '岛外';
    headlines.push(`📍 ${regionText}用户首选`);
    descriptions.push(`${regionText}就近服务，快速响应`);

    // 默认文案
    if (headlines.length === 0) {
      headlines.push(`✨ ${merchantName}优质推荐`);
      headlines.push(`🎉 新人下单享优惠`);
      descriptions.push(`${category}优质商家，AI精选推荐`);
    }

    // 徽章
    badges.push(region === 'island_inside' ? '岛内优选' : '岛外优选');
    if (soldCount && soldCount >= 50) badges.push('人气爆款');
    if (currentPrice && originalPrice && originalPrice > currentPrice) badges.push('限时特惠');

    return {
      headlines,
      descriptions,
      badges,
      urgencyLevel: this.calculateUrgencyLevel(stock, soldCount),
      expireMinutes: stock && stock <= 5 ? 10 : undefined,
    };
  }

  /**
   * 获取场景化逼单模板
   */
  getScenarioTemplates(scenario: UrgencyScenario, merchantName: string, region: string): {
    headline: string;
    description: string;
    badge: string;
  } {
    const regionText = region === 'island_inside' ? '岛内' : '岛外';

    const templates: Record<UrgencyScenario, { headline: string; description: string; badge: string }> = {
      low_stock: {
        headline: '⚠️ 库存告急，速抢！',
        description: `${merchantName}仅剩少量名额`,
        badge: '即将售罄',
      },
      price_drop: {
        headline: '💰 限时降价，立省优惠',
        description: '今日下单享超低价',
        badge: '限时特惠',
      },
      time_limited: {
        headline: '⏰ 活动倒计时，错过无',
        description: '优惠即将结束',
        badge: '限时抢购',
      },
      social_proof: {
        headline: '👥 好友也在买',
        description: `${regionText}用户都在抢`,
        badge: '口碑推荐',
      },
      high_demand: {
        headline: '🔥 爆款热卖中',
        description: `${merchantName}超火爆`,
        badge: '人气爆款',
      },
      region_exclusive: {
        headline: `📍 ${regionText}专属福利`,
        description: `${regionText}用户专属优惠`,
        badge: `${regionText}优选`,
      },
    };

    return templates[scenario];
  }

  /**
   * 计算紧迫程度
   */
  private calculateUrgencyLevel(stock?: number, soldCount?: number): 'low' | 'medium' | 'high' {
    if (stock !== undefined && stock <= 3) return 'high';
    if (stock !== undefined && stock <= 10) return 'medium';
    if (soldCount && soldCount >= 100) return 'medium';
    return 'low';
  }

  /**
   * 获取默认标题
   */
  private getDefaultHeadlines(merchantName: string, category: string, region: string): string[] {
    const regionText = region === 'island_inside' ? '岛内' : '岛外';
    return [
      `✨ ${merchantName}优质推荐`,
      `🔥 ${regionText}${category}热门`,
      `🎉 新人下单享优惠`,
    ];
  }

  /**
   * 获取默认描述
   */
  private getDefaultDescriptions(merchantName: string, category: string, region: string): string[] {
    const regionText = region === 'island_inside' ? '岛内' : '岛外';
    return [
      `${category}优质商家，AI精选推荐`,
      `${regionText}就近服务，快速响应`,
      `新人专享红包，下单立减`,
    ];
  }

  /**
   * 获取默认徽章
   */
  private getDefaultBadges(region: string): string[] {
    const regionText = region === 'island_inside' ? '岛内优选' : '岛外优选';
    return [regionText, '品质保障'];
  }

  /**
   * 智能推荐逼单时机
   */
  recommendUrgencyTiming(params: {
    viewCount: number;
    staySeconds: number;
    cartAdded: boolean;
    hasRedPacket: boolean;
  }): { shouldShow: boolean; scenario: UrgencyScenario; delay: number } {
    const { viewCount, staySeconds, cartAdded, hasRedPacket } = params;

    // 加入购物车但未下单
    if (cartAdded && staySeconds > 60) {
      return { shouldShow: true, scenario: 'time_limited', delay: 0 };
    }

    // 多次浏览但未下单
    if (viewCount >= 3 && staySeconds > 30) {
      return { shouldShow: true, scenario: 'high_demand', delay: 0 };
    }

    // 停留较长时间
    if (staySeconds > 180) {
      return { shouldShow: true, scenario: 'price_drop', delay: 0 };
    }

    // 有红包未使用
    if (hasRedPacket && staySeconds > 60) {
      return { shouldShow: true, scenario: 'time_limited', delay: 0 };
    }

    return { shouldShow: false, scenario: 'time_limited', delay: 0 };
  }
}
