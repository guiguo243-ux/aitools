import { Controller, Get, Post, Query, Body } from '@nestjs/common';
import { UrgencyService, UrgencyRequest, UrgencyScenario } from './urgency.service';

@Controller('urgency')
export class UrgencyController {
  constructor(private readonly urgencyService: UrgencyService) {}

  /**
   * 生成AI逼单文案
   */
  @Post('generate')
  async generateUrgencyCopy(@Body() body: UrgencyRequest) {
    try {
      const result = await this.urgencyService.generateUrgencyCopy(body);
      return { code: 200, msg: 'success', data: result };
    } catch (error) {
      console.error('Generate urgency copy error:', error);
      return { code: 500, msg: '生成逼单文案失败', data: null };
    }
  }

  /**
   * 生成快速逼单文案（不调用LLM）
   */
  @Post('quick')
  async generateQuickUrgencyCopy(@Body() body: UrgencyRequest) {
    try {
      const result = this.urgencyService.generateQuickUrgencyCopy(body);
      return { code: 200, msg: 'success', data: result };
    } catch (error) {
      console.error('Generate quick urgency copy error:', error);
      return { code: 500, msg: '生成逼单文案失败', data: null };
    }
  }

  /**
   * 获取场景化逼单模板
   */
  @Get('scenario-template')
  async getScenarioTemplate(
    @Query('scenario') scenario: UrgencyScenario,
    @Query('merchantName') merchantName: string,
    @Query('region') region: string
  ) {
    try {
      const result = this.urgencyService.getScenarioTemplates(scenario, merchantName, region);
      return { code: 200, msg: 'success', data: result };
    } catch (error) {
      console.error('Get scenario template error:', error);
      return { code: 500, msg: '获取模板失败', data: null };
    }
  }

  /**
   * 智能推荐逼单时机
   */
  @Post('recommend-timing')
  async recommendUrgencyTiming(
    @Body() body: {
      viewCount: number;
      staySeconds: number;
      cartAdded: boolean;
      hasRedPacket: boolean;
    }
  ) {
    try {
      const result = this.urgencyService.recommendUrgencyTiming(body);
      return { code: 200, msg: 'success', data: result };
    } catch (error) {
      console.error('Recommend urgency timing error:', error);
      return { code: 500, msg: '推荐时机失败', data: null };
    }
  }
}
