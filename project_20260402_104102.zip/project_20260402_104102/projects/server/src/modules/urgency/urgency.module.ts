import { Module } from '@nestjs/common';
import { UrgencyController } from './urgency.controller';
import { UrgencyService } from './urgency.service';

@Module({
  controllers: [UrgencyController],
  providers: [UrgencyService],
  exports: [UrgencyService],
})
export class UrgencyModule {}
