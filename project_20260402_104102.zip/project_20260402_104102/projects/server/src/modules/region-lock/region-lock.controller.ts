import { Controller, Get, Post, Body, Query } from '@nestjs/common'

@Controller('region-lock')
export class RegionLockController {
  @Post('bind')
  bindUserRegion(
    @Body() body: {
      userId: string
      phone: string
      district: string
    }
  ) {
    const { userId, phone, district } = body
    
    const binding = {
      userId,
      phone,
      primaryDistrict: district,
      secondaryDistricts: [],
      bindTime: new Date().toISOString(),
      lastVerifyTime: new Date().toISOString(),
      verifyCount: 1
    }

    console.log('[RegionLock] 用户区域绑定（到店核销版）:', binding)

    return {
      code: 200,
      msg: '绑定成功',
      data: {
        binding,
        message: `已将您的常驻区域绑定至${district}，到店优惠券将按此区域发放`
      }
    }
  }

  @Get('verify')
  verifyUserRegion(
    @Query('userId') userId: string,
    @Query('currentDistrict') currentDistrict: string
  ) {
    const islandInside = ['思明区', '湖里区']
    
    const isValid = true
    const reason = isValid ? undefined : '定位区域与绑定区域不一致，到店券可能无法核销'

    return {
      code: 200,
      msg: 'success',
      data: {
        isValid,
        reason,
        currentDistrict,
        regionType: islandInside.includes(currentDistrict) ? 'island_inside' : 'island_outside'
      }
    }
  }

  @Post('instore-coupon/verify')
  verifyInstoreCouponRegion(
    @Body() body: {
      couponId: string
      userDistrict: string
      merchantDistrict: string
    }
  ) {
    const { couponId, userDistrict, merchantDistrict } = body
    
    // 模拟到店券区域限制
    const couponRegionType = 'island_inside' as const
    
    const islandInside = ['思明区', '湖里区']
    const userRegion = islandInside.includes(userDistrict) ? 'island_inside' as const : 'island_outside' as const
    const merchantRegion = islandInside.includes(merchantDistrict) ? 'island_inside' as const : 'island_outside' as const
    
    let isValid = true
    let reason = ''
    
    // 到店券验证：用户区域和商家区域必须匹配
    if (userRegion !== couponRegionType) {
      isValid = false
      reason = `此到店券仅限${couponRegionType === 'island_inside' ? '岛内' : '岛外'}用户使用`
    } else if (merchantRegion !== couponRegionType) {
      isValid = false
      reason = `此到店券仅限${couponRegionType === 'island_inside' ? '岛内' : '岛外'}商家到店核销，跨区无法使用`
    }

    // 跨区不可核销
    const canVerify = isValid && userRegion === merchantRegion

    return {
      code: 200,
      msg: 'success',
      data: {
        isValid,
        reason: isValid ? undefined : reason,
        canVerify,
        couponRegionType,
        userRegion,
        merchantRegion,
        notice: canVerify ? '到店券可正常核销' : '跨区到店券无法核销'
      }
    }
  }

  @Post('cross-region/check-instore')
  checkCrossRegionInstore(
    @Body() body: {
      userDistrict: string
      userRealtimeDistrict: string
      merchantDistrict: string
      merchantName: string
    }
  ) {
    const { userDistrict, userRealtimeDistrict, merchantDistrict, merchantName } = body
    
    const islandInside = ['思明区', '湖里区']
    const userRegion = islandInside.includes(userDistrict) ? 'island_inside' : 'island_outside'
    const userRealtimeRegion = islandInside.includes(userRealtimeDistrict) ? 'island_inside' : 'island_outside'
    const merchantRegion = islandInside.includes(merchantDistrict) ? 'island_inside' : 'island_outside'
    
    // 三重核验：注册区域 + 实时定位 + 商家区域
    const isUserRegionMatch = userRegion === merchantRegion
    const isRealtimeMatch = userRealtimeRegion === merchantRegion
    const isCrossRegion = !isUserRegionMatch || !isRealtimeMatch
    
    if (!isCrossRegion) {
      return {
        code: 200,
        msg: 'success',
        data: {
          isCrossRegion: false,
          canVerify: true,
          restrictionMessage: ''
        }
      }
    }

    // 跨区不可核销
    const userRegionName = userRegion === 'island_inside' ? '岛内' : '岛外'
    const merchantRegionName = merchantRegion === 'island_inside' ? '岛内' : '岛外'

    const restrictionMessage = 
      `⚠️ 此券仅限${merchantRegionName}到店核销\n\n` +
      `您当前在${userRegionName}（${userDistrict}），商家位于${merchantRegionName}（${merchantDistrict}）\n\n` +
      `跨区域到店券无法核销，建议选择您所在区域的到店商家～`

    return {
      code: 200,
      msg: 'success',
      data: {
        isCrossRegion: true,
        canVerify: false,
        userRegion,
        merchantRegion,
        restrictionMessage,
        suggestedMerchants: userRegion === 'island_inside' 
          ? ['思明区老厦门沙茶面', '湖里区五缘湾私房菜']
          : ['集美区集美大排档', '海沧区海沧渔家乐']
      }
    }
  }

  @Post('verification/execute')
  executeInstoreVerification(
    @Body() body: {
      userId: string
      userDistrict: string
      userRealtimeDistrict: string
      merchantDistrict: string
      couponId: string
    }
  ) {
    const { userId, userDistrict, userRealtimeDistrict, merchantDistrict, couponId } = body
    
    const islandInside = ['思明区', '湖里区']
    const userRegion = islandInside.includes(userDistrict) ? 'island_inside' : 'island_outside'
    const userRealtimeRegion = islandInside.includes(userRealtimeDistrict) ? 'island_inside' : 'island_outside'
    const merchantRegion = islandInside.includes(merchantDistrict) ? 'island_inside' : 'island_outside'
    
    // 三重核验
    const isUserRegionMatch = userRegion === merchantRegion
    const isRealtimeMatch = userRealtimeRegion === merchantRegion
    const canVerify = isUserRegionMatch && isRealtimeMatch

    if (!canVerify) {
      return {
        code: 200,
        msg: 'success',
        data: {
          isValid: false,
          canVerify: false,
          reason: '跨区域到店券无法核销',
          verificationDetails: {
            userRegion,
            userRealtimeRegion,
            merchantRegion,
            matchStatus: {
              userRegionMatch: isUserRegionMatch,
              realtimeMatch: isRealtimeMatch
            }
          }
        }
      }
    }

    return {
      code: 200,
      msg: 'success',
      data: {
        isValid: true,
        canVerify: true,
        reason: '验证通过，可到店核销',
        verificationDetails: {
          userRegion,
          userRealtimeRegion,
          merchantRegion,
          matchStatus: {
            userRegionMatch: isUserRegionMatch,
            realtimeMatch: isRealtimeMatch
          }
        }
      }
    }
  }

  @Get('instore-coupons/available')
  getAvailableInstoreCoupons(
    @Query('userId') userId: string,
    @Query('merchantDistrict') merchantDistrict: string
  ) {
    // 模拟到店券数据
    const coupons = [
      {
        id: '1',
        title: '岛内新用户到店专享券',
        amount: 20,
        minAmount: 50,
        regionType: 'island_inside',
        couponType: 'instore_discount',
        validFrom: '2024-01-01',
        validTo: '2024-12-31',
        description: '仅限思明区、湖里区到店核销'
      },
      {
        id: '2',
        title: '岛外到店生鲜专享券',
        amount: 15,
        minAmount: 30,
        regionType: 'island_outside',
        couponType: 'instore_cash',
        validFrom: '2024-01-01',
        validTo: '2024-12-31',
        description: '仅限集美区、海沧区、同安区、翔安区到店自提'
      },
      {
        id: '3',
        title: '全城到店通用券',
        amount: 10,
        minAmount: 30,
        regionType: 'all',
        couponType: 'instore_discount',
        validFrom: '2024-01-01',
        validTo: '2024-12-31',
        description: '全市到店通用'
      }
    ]

    const islandInside = ['思明区', '湖里区']
    const merchantRegion = islandInside.includes(merchantDistrict) ? 'island_inside' : 'island_outside'

    // 过滤可用的到店券
    const availableCoupons = coupons.filter(c => 
      c.regionType === 'all' || c.regionType === merchantRegion
    )

    return {
      code: 200,
      msg: 'success',
      data: {
        coupons: availableCoupons,
        merchantDistrict,
        merchantRegion,
        notice: '到店券仅限对应区域核销，跨区无法使用'
      }
    }
  }
}
