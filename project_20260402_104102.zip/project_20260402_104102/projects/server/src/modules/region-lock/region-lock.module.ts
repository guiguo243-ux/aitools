import { Module } from '@nestjs/common'
import { RegionLockController } from './region-lock.controller'

@Module({
  controllers: [RegionLockController],
  providers: [],
})
export class RegionLockModule {}
