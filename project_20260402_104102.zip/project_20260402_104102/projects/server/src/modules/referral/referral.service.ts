import { Injectable } from '@nestjs/common';
import { getSupabaseClient } from '@/storage/database/supabase-client';

@Injectable()
export class ReferralService {
  /**
   * 发放新人注册礼
   */
  async grantNewUserGifts(userId: string, region: string) {
    const client = getSupabaseClient();

    // 查询新人注册相关的红包配置
    const { data: configs, error: configError } = await client
      .from('red_packet_configs')
      .select('*')
      .in('scene', ['new_user_register', 'first_location', 'first_ai_chat'])
      .eq('is_active', true)
      .order('priority', { ascending: false });

    if (configError) {
      console.error('Get red packet configs error:', configError);
      throw new Error(`获取红包配置失败: ${configError.message}`);
    }

    if (!configs || configs.length === 0) {
      return { granted: [], msg: '暂无可用新人礼包' };
    }

    // 检查用户是否已领取过新人礼包
    const { data: existingPackets, error: existingError } = await client
      .from('user_red_packets')
      .select('*')
      .eq('user_id', userId)
      .in('source', ['register', 'first_location', 'first_ai_chat']);

    if (existingError) {
      console.error('Check existing packets error:', existingError);
    }

    const existingScenes = new Set((existingPackets || []).map((p: {source: string}) => p.source));

    // 发放红包
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    const grantedPackets: any[] = [];

    for (const config of configs) {
      // 跳过已领取的场景
      if (existingScenes.has(config.scene)) continue;

      // 计算过期时间
      const expireAt = new Date();
      expireAt.setDate(expireAt.getDate() + (config.valid_days || 7));

      // 插入用户红包记录
      const { data: packet, error: insertError } = await client
        .from('user_red_packets')
        .insert({
          user_id: userId,
          config_id: config.id,
          type: config.type,
          amount: config.amount,
          min_spend: config.min_spend || 0,
          source: config.scene,
          region,
          status: 'unused',
          expire_at: expireAt.toISOString(),
        })
        .select()
        .maybeSingle();

      if (insertError) {
        console.error('Insert red packet error:', insertError);
      } else if (packet) {
        grantedPackets.push({
          id: packet.id,
          name: config.name,
          type: config.type,
          amount: config.amount,
          minSpend: config.min_spend,
          validDays: config.valid_days,
        });
      }
    }

    return {
      granted: grantedPackets,
      msg: grantedPackets.length > 0 ? '新人礼包发放成功' : '已领取过新人礼包',
    };
  }

  /**
   * 绑定推荐关系并发放奖励
   */
  async bindReferral(userId: string, referralCode: string, region: string) {
    const client = getSupabaseClient();

    // 查询推荐人
    const { data: referrer, error: referrerError } = await client
      .from('users')
      .select('*')
      .eq('referral_code', referralCode)
      .maybeSingle();

    if (referrerError) {
      console.error('Get referrer error:', referrerError);
      throw new Error(`查询推荐人失败: ${referrerError.message}`);
    }

    if (!referrer) {
      return { success: false, msg: '推荐码无效' };
    }

    // 检查用户是否已有推荐人
    const { data: user, error: userError } = await client
      .from('users')
      .select('referrer_id')
      .eq('id', userId)
      .maybeSingle();

    if (userError) {
      console.error('Get user error:', userError);
      throw new Error(`查询用户失败: ${userError.message}`);
    }

    if (user?.referrer_id) {
      return { success: false, msg: '已有推荐人' };
    }

    // 不能自己绑定自己
    if (referrer.id === userId) {
      return { success: false, msg: '不能绑定自己' };
    }

    // 检查每日领取上限
    const dailyLimit = await this.getSystemConfig('daily_referral_limit', '3');
    const today = new Date().toISOString().split('T')[0];
    
    const { count: todayCount, error: countError } = await client
      .from('user_red_packets')
      .select('*', { count: 'exact', head: true })
      .eq('user_id', userId)
      .eq('source', 'referral_bind_referee')
      .gte('created_at', today);

    if (countError) {
      console.error('Check daily limit error:', countError);
    }

    if (todayCount && todayCount >= parseInt(dailyLimit)) {
      return { success: false, msg: '今日领取次数已达上限' };
    }

    // 检查月度补贴上限
    const monthlyLimit = await this.getSystemConfig('monthly_subsidy_limit', '200');
    const monthStart = new Date();
    monthStart.setDate(1);
    monthStart.setHours(0, 0, 0, 0);

    const { data: monthRecords, error: monthError } = await client
      .from('user_red_packets')
      .select('amount')
      .eq('user_id', userId)
      .gte('created_at', monthStart.toISOString());

    if (monthError) {
      console.error('Check monthly limit error:', monthError);
    }

    const monthTotal = (monthRecords || []).reduce((sum: number, r: {amount: string}) => sum + parseFloat(r.amount), 0);
    if (monthTotal >= parseFloat(monthlyLimit)) {
      return { success: false, msg: '本月补贴已达上限' };
    }

    // 绑定推荐关系
    const { error: updateError } = await client
      .from('users')
      .update({ referrer_id: referrer.id })
      .eq('id', userId);

    if (updateError) {
      console.error('Bind referrer error:', updateError);
      throw new Error(`绑定推荐人失败: ${updateError.message}`);
    }

    // 发放奖励
    const rewards = await this.grantReferralRewards(userId, referrer.id, region);

    return {
      success: true,
      msg: '绑定成功',
      rewards: {
        referrer: rewards.referrerRewards,
        referee: rewards.refereeRewards,
      },
    };
  }

  /**
   * 发放裂变奖励
   */
  private async grantReferralRewards(userId: string, referrerId: string, region: string) {
    const client = getSupabaseClient();

    // 查询裂变奖励规则
    const { data: rules, error: rulesError } = await client
      .from('referral_reward_rules')
      .select('*')
      .eq('action', 'bind')
      .eq('is_active', true);

    if (rulesError || !rules || rules.length === 0) {
      console.error('Get referral rules error:', rulesError);
      return { referrerRewards: [], refereeRewards: [] };
    }

    const rule = rules[0];

    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    const referrerRewards: any[] = [];
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    const refereeRewards: any[] = [];

    // 解析奖励配置
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    const referrerRewardList: any[] = JSON.parse(rule.referrer_reward || '[]');
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    const refereeRewardList: any[] = JSON.parse(rule.referee_reward || '[]');

    // 发放推荐人奖励
    for (const reward of referrerRewardList) {
      const expireAt = new Date();
      expireAt.setDate(expireAt.getDate() + (reward.validDays || 7));

      const { error: insertError } = await client
        .from('user_red_packets')
        .insert({
          user_id: referrerId,
          type: reward.type,
          amount: reward.amount,
          min_spend: reward.minSpend || 0,
          source: 'referral_bind_referrer',
          related_user_id: userId,
          region,
          status: 'unused',
          expire_at: expireAt.toISOString(),
        });

      if (!insertError) {
        referrerRewards.push(reward);
      }
    }

    // 发放新人奖励
    for (const reward of refereeRewardList) {
      const expireAt = new Date();
      expireAt.setDate(expireAt.getDate() + (reward.validDays || 7));

      const { error: insertError } = await client
        .from('user_red_packets')
        .insert({
          user_id: userId,
          type: reward.type,
          amount: reward.amount,
          min_spend: reward.minSpend || 0,
          source: 'referral_bind_referee',
          related_user_id: referrerId,
          region,
          status: 'unused',
          expire_at: expireAt.toISOString(),
        });

      if (!insertError) {
        refereeRewards.push(reward);
      }
    }

    return { referrerRewards, refereeRewards };
  }

  /**
   * 获取系统配置
   */
  private async getSystemConfig(key: string, defaultValue: string): Promise<string> {
    const client = getSupabaseClient();

    const { data, error } = await client
      .from('system_configs')
      .select('value')
      .eq('key', key)
      .maybeSingle();

    if (error || !data) {
      return defaultValue;
    }

    return data.value;
  }

  /**
   * 获取用户红包列表
   */
  async getUserRedPackets(userId: string, status?: string) {
    const client = getSupabaseClient();

    let query = client
      .from('user_red_packets')
      .select('*')
      .eq('user_id', userId);

    if (status) {
      query = query.eq('status', status);
    }

    const { data, error } = await query.order('created_at', { ascending: false });

    if (error) {
      console.error('Get user red packets error:', error);
      throw new Error(`获取红包列表失败: ${error.message}`);
    }

    // 自动标记过期的红包
    const now = new Date().toISOString();
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    const expiredPackets = (data || []).filter((p: any) => p.status === 'unused' && p.expire_at < now);
    
    if (expiredPackets.length > 0) {
      // eslint-disable-next-line @typescript-eslint/no-explicit-any
      const expiredIds = expiredPackets.map((p: any) => p.id);
      await client
        .from('user_red_packets')
        .update({ status: 'expired' })
        .in('id', expiredIds);
    }

    return data || [];
  }

  /**
   * 检查红包是否可用（区域限制）
   */
  async checkRedPacketUsable(redPacketId: string, userRegion: string) {
    const client = getSupabaseClient();

    const { data: packet, error } = await client
      .from('user_red_packets')
      .select('*')
      .eq('id', redPacketId)
      .eq('status', 'unused')
      .maybeSingle();

    if (error) {
      console.error('Get red packet error:', error);
      return { usable: false, msg: '红包不存在' };
    }

    if (!packet) {
      return { usable: false, msg: '红包不存在或已使用' };
    }

    // 检查是否过期
    if (new Date(packet.expire_at) < new Date()) {
      return { usable: false, msg: '红包已过期' };
    }

    // 检查区域限制
    if (packet.region && packet.region !== userRegion) {
      return { 
        usable: false, 
        msg: `此红包仅限${packet.region === 'island_inside' ? '岛内' : '岛外'}使用`,
        regionLocked: true 
      };
    }

    return { 
      usable: true, 
      packet: {
        id: packet.id,
        type: packet.type,
        amount: packet.amount,
        minSpend: packet.min_spend,
      }
    };
  }

  /**
   * 使用红包
   */
  async useRedPacket(redPacketId: string, orderId: string) {
    const client = getSupabaseClient();

    const { error } = await client
      .from('user_red_packets')
      .update({
        status: 'used',
        used_at: new Date().toISOString(),
        order_id: orderId,
      })
      .eq('id', redPacketId)
      .eq('status', 'unused');

    if (error) {
      console.error('Use red packet error:', error);
      throw new Error(`使用红包失败: ${error.message}`);
    }

    return { success: true };
  }

  /**
   * 发放下单挽留券
   */
  async grantStayCoupon(userId: string, region: string, stayMinutes: number) {
    const client = getSupabaseClient();

    const triggerMinutes = parseInt(await this.getSystemConfig('stay_minutes_trigger', '5'));
    
    if (stayMinutes < triggerMinutes) {
      return { granted: null, msg: '未达到触发条件' };
    }

    // 检查是否已发放过
    const { data: existing, error: existingError } = await client
      .from('user_red_packets')
      .select('*')
      .eq('user_id', userId)
      .eq('source', 'stay_5min')
      .gte('created_at', new Date(Date.now() - 30 * 60 * 1000).toISOString()) // 30分钟内
      .maybeSingle();

    if (existingError) {
      console.error('Check existing stay coupon error:', existingError);
    }

    if (existing) {
      return { granted: null, msg: '已发放过挽留券' };
    }

    // 查询挽留券配置
    const { data: config, error: configError } = await client
      .from('red_packet_configs')
      .select('*')
      .eq('scene', 'stay_5min')
      .eq('is_active', true)
      .maybeSingle();

    if (configError || !config) {
      return { granted: null, msg: '暂无可用挽留券' };
    }

    // 发放紧急券（10分钟有效）
    const validMinutes = config.valid_minutes || 10;
    const expireAt = new Date(Date.now() + validMinutes * 60 * 1000);

    const { data: packet, error: insertError } = await client
      .from('user_red_packets')
      .insert({
        user_id: userId,
        config_id: config.id,
        type: config.type,
        amount: config.amount,
        min_spend: config.min_spend || 0,
        source: 'stay_5min',
        region,
        status: 'unused',
        expire_at: expireAt.toISOString(),
      })
      .select()
      .maybeSingle();

    if (insertError) {
      console.error('Insert stay coupon error:', insertError);
      throw new Error(`发放挽留券失败: ${insertError.message}`);
    }

    return {
      granted: {
        id: packet.id,
        name: config.name,
        amount: config.amount,
        minSpend: config.min_spend,
        validMinutes,
      },
      msg: '挽留券发放成功',
    };
  }

  /**
   * 获取推荐统计
   */
  async getReferralStats(userId: string) {
    const client = getSupabaseClient();

    // 获取推荐人数
    const { count: totalReferrals, error: countError } = await client
      .from('users')
      .select('*', { count: 'exact', head: true })
      .eq('referrer_id', userId);

    if (countError) {
      console.error('Get referral count error:', countError);
    }

    // 获取推荐奖励总额
    const { data: rewards, error: rewardsError } = await client
      .from('user_red_packets')
      .select('amount')
      .eq('related_user_id', userId)
      .eq('source', 'referral_bind_referee');

    if (rewardsError) {
      console.error('Get referral rewards error:', rewardsError);
    }

    const totalRewards = (rewards || []).reduce((sum: number, r: {amount: string}) => sum + parseFloat(r.amount), 0);

    // 获取推荐码
    const { data: user, error: userError } = await client
      .from('users')
      .select('referral_code')
      .eq('id', userId)
      .maybeSingle();

    if (userError) {
      console.error('Get user referral code error:', userError);
    }

    return {
      referralCode: user?.referral_code || '',
      totalReferrals: totalReferrals || 0,
      totalRewards,
    };
  }

  /**
   * 生成或获取推荐码
   */
  async generateReferralCode(userId: string) {
    const client = getSupabaseClient();

    // 检查是否已有推荐码
    const { data: user, error: userError } = await client
      .from('users')
      .select('referral_code')
      .eq('id', userId)
      .maybeSingle();

    if (userError) {
      console.error('Get user error:', userError);
      throw new Error(`获取用户失败: ${userError.message}`);
    }

    if (user?.referral_code) {
      return user.referral_code;
    }

    // 生成推荐码
    const referralCode = `R${userId.substring(0, 8).toUpperCase()}`;

    const { error: updateError } = await client
      .from('users')
      .update({ referral_code: referralCode })
      .eq('id', userId);

    if (updateError) {
      console.error('Update referral code error:', updateError);
      throw new Error(`更新推荐码失败: ${updateError.message}`);
    }

    return referralCode;
  }
}
