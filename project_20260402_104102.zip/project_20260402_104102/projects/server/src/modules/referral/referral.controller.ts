import { Controller, Get, Post, Query, Body } from '@nestjs/common';
import { ReferralService } from './referral.service';

@Controller('referral')
export class ReferralController {
  constructor(private readonly referralService: ReferralService) {}

  /**
   * 发放新人注册礼
   */
  @Post('new-user-gift')
  async grantNewUserGift(@Body() body: { userId: string; region: string }) {
    try {
      const result = await this.referralService.grantNewUserGifts(body.userId, body.region);
      return { code: 200, msg: result.msg, data: result };
    } catch (error) {
      console.error('Grant new user gift error:', error);
      return { code: 500, msg: '发放新人礼包失败', data: null };
    }
  }

  /**
   * 绑定推荐关系
   */
  @Post('bind')
  async bindReferral(@Body() body: { userId: string; referralCode: string; region: string }) {
    try {
      const result = await this.referralService.bindReferral(
        body.userId,
        body.referralCode,
        body.region
      );
      return { code: result.success ? 200 : 400, msg: result.msg, data: result };
    } catch (error) {
      console.error('Bind referral error:', error);
      return { code: 500, msg: '绑定推荐关系失败', data: null };
    }
  }

  /**
   * 获取用户红包列表
   */
  @Get('red-packets')
  async getUserRedPackets(@Query('userId') userId: string, @Query('status') status: string) {
    try {
      const packets = await this.referralService.getUserRedPackets(userId, status);
      return { code: 200, msg: 'success', data: packets };
    } catch (error) {
      console.error('Get user red packets error:', error);
      return { code: 500, msg: '获取红包列表失败', data: null };
    }
  }

  /**
   * 检查红包是否可用
   */
  @Get('red-packet/check')
  async checkRedPacketUsable(
    @Query('redPacketId') redPacketId: string,
    @Query('userRegion') userRegion: string
  ) {
    try {
      const result = await this.referralService.checkRedPacketUsable(redPacketId, userRegion);
      return { code: 200, msg: result.msg, data: result };
    } catch (error) {
      console.error('Check red packet usable error:', error);
      return { code: 500, msg: '检查红包失败', data: null };
    }
  }

  /**
   * 使用红包
   */
  @Post('red-packet/use')
  async useRedPacket(@Body() body: { redPacketId: string; orderId: string }) {
    try {
      const result = await this.referralService.useRedPacket(body.redPacketId, body.orderId);
      return { code: 200, msg: '使用成功', data: result };
    } catch (error) {
      console.error('Use red packet error:', error);
      return { code: 500, msg: '使用红包失败', data: null };
    }
  }

  /**
   * 发放下单挽留券
   */
  @Post('stay-coupon')
  async grantStayCoupon(@Body() body: { userId: string; region: string; stayMinutes: number }) {
    try {
      const result = await this.referralService.grantStayCoupon(
        body.userId,
        body.region,
        body.stayMinutes
      );
      return { code: 200, msg: result.msg, data: result };
    } catch (error) {
      console.error('Grant stay coupon error:', error);
      return { code: 500, msg: '发放挽留券失败', data: null };
    }
  }

  /**
   * 获取推荐统计
   */
  @Get('stats')
  async getReferralStats(@Query('userId') userId: string) {
    try {
      const stats = await this.referralService.getReferralStats(userId);
      return { code: 200, msg: 'success', data: stats };
    } catch (error) {
      console.error('Get referral stats error:', error);
      return { code: 500, msg: '获取推荐统计失败', data: null };
    }
  }

  /**
   * 生成推荐码
   */
  @Post('generate-code')
  async generateReferralCode(@Body() body: { userId: string }) {
    try {
      const code = await this.referralService.generateReferralCode(body.userId);
      return { code: 200, msg: 'success', data: { referralCode: code } };
    } catch (error) {
      console.error('Generate referral code error:', error);
      return { code: 500, msg: '生成推荐码失败', data: null };
    }
  }

  /**
   * 获取红包配置列表（管理端）
   */
  @Get('configs')
  async getRedPacketConfigs() {
    try {
      const client = getSupabaseClient();
      const { data, error } = await client
        .from('red_packet_configs')
        .select('*')
        .eq('is_active', true)
        .order('priority', { ascending: false });

      if (error) {
        throw new Error(`获取配置失败: ${error.message}`);
      }

      return { code: 200, msg: 'success', data };
    } catch (error) {
      console.error('Get red packet configs error:', error);
      return { code: 500, msg: '获取配置失败', data: null };
    }
  }

  /**
   * 获取裂变分享文案
   */
  @Get('share-copy')
  async getShareCopy(@Query('type') type: string, @Query('region') region: string) {
    // 预定义的分享文案
    const copywritingMap: Record<string, Record<string, string[]>> = {
      general: {
        all: [
          '🔥厦门人专属！AI本地生活平台上线啦\n美食/家政/维修/民宿/丽人全行业全覆盖\n✅AI智能导购，一句话帮你选店、比价、省钱\n✅岛内岛外精准分区，就近匹配优质商家\n✅扫码领新人红包，分享好友双方都能赚\n找吃的、找服务、订民宿，问AI就够省事！',
        ],
      },
      island_inside: {
        all: [
          '✨厦门岛内福利｜AI省钱神器\n思明、湖里本地人专用！\n聚餐、美甲、保洁、租房、亲子遛娃\n直接喊AI导购帮你挑最优、最便宜的店\n✔新人领5元无门槛红包\n✔分享好友双向领补贴\n✔所有商家正规入驻，订单售后有保障\n岛内就近接单，半小时快速响应，薅羊毛抓紧！',
        ],
      },
      island_outside: {
        all: [
          '📣岛外街坊专属！AI本地生活便民平台\n集美、海沧、同安、翔安全适配\n上门维修、保洁开荒、农家乐、民宿游玩、日常买菜\nAI帮你避开坑、比对价格、推荐靠谱老店\n注册就领专属便民红包，组队拼单更划算\n不用来回比价，问AI一秒匹配岛外就近商家！',
        ],
      },
    };

    const regionKey = region || 'general';
    const typeKey = type || 'all';
    const copywritingList = copywritingMap[regionKey]?.[typeKey] || copywritingMap.general.all;

    return {
      code: 200,
      msg: 'success',
      data: {
        copywritingList,
        shortCopywriting: [
          '厦门AI生活平台，岛内岛外全覆盖，扫码领新人现金红包，下单直接抵钱～',
          '不想选店纠结？直接用AI导购，帮你比价选最优，分享还能赚补贴！',
          '全行业商家入驻，订单透明抽佣，日常吃喝玩乐便民服务一键搞定',
        ],
        posterCopywriting: '我挖到厦门宝藏平台了！\nAI帮选店、帮比价，岛内岛外都能用\n扫码领我专属福利，咱俩都能领红包，超划算！',
      },
    };
  }
}

import { getSupabaseClient } from '@/storage/database/supabase-client';
