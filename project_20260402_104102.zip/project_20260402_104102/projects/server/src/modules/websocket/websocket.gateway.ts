import {
  WebSocketGateway,
  WebSocketServer,
  SubscribeMessage,
  OnGatewayConnection,
  OnGatewayDisconnect,
  OnGatewayInit,
  ConnectedSocket,
  MessageBody,
} from '@nestjs/websockets';
import { Logger } from '@nestjs/common';
import { Server, Socket } from 'socket.io';

@WebSocketGateway({
  cors: {
    origin: '*', // 生产环境应配置具体域名
    credentials: true,
  },
  namespace: '/admin',
})
export class WebsocketGateway
  implements OnGatewayInit, OnGatewayConnection, OnGatewayDisconnect
{
  @WebSocketServer()
  server: Server;

  private logger: Logger = new Logger('WebsocketGateway');
  private connectedClients: Map<string, Set<string>> = new Map(); // adminId -> socketIds

  afterInit(server: Server) {
    this.logger.log('WebSocket Gateway initialized');
  }

  handleConnection(client: Socket, ...args: any[]) {
    this.logger.log(`Client connected: ${client.id}`);
    
    // 可以在这里验证token
    const token = client.handshake.auth.token;
    if (!token) {
      this.logger.warn(`Client ${client.id} disconnected: no token`);
      client.disconnect();
      return;
    }
  }

  handleDisconnect(client: Socket) {
    this.logger.log(`Client disconnected: ${client.id}`);
    
    // 清理连接映射
    this.connectedClients.forEach((socketIds, adminId) => {
      socketIds.delete(client.id);
      if (socketIds.size === 0) {
        this.connectedClients.delete(adminId);
      }
    });
  }

  @SubscribeMessage('join')
  handleJoin(
    @ConnectedSocket() client: Socket,
    @MessageBody() data: { adminId: string; role: string }
  ) {
    this.logger.log(`Admin ${data.adminId} joined with role ${data.role}`);
    
    // 加入管理员专属房间
    client.join(`admin:${data.adminId}`);
    client.join(`role:${data.role}`);
    
    // 记录连接
    if (!this.connectedClients.has(data.adminId)) {
      this.connectedClients.set(data.adminId, new Set());
    }
    this.connectedClients.get(data.adminId)!.add(client.id);

    client.emit('joined', { message: 'Successfully joined admin room' });
  }

  @SubscribeMessage('leave')
  handleLeave(
    @ConnectedSocket() client: Socket,
    @MessageBody() data: { adminId: string; role: string }
  ) {
    client.leave(`admin:${data.adminId}`);
    client.leave(`role:${data.role}`);
  }

  // ========== 服务端推送方法 ==========

  /**
   * 向所有管理员广播消息
   */
  broadcastToAll(event: string, data: any) {
    this.server.emit(event, data);
  }

  /**
   * 向特定管理员发送消息
   */
  sendToAdmin(adminId: string, event: string, data: any) {
    this.server.to(`admin:${adminId}`).emit(event, data);
  }

  /**
   * 向特定角色的管理员发送消息
   */
  sendToRole(role: string, event: string, data: any) {
    this.server.to(`role:${role}`).emit(event, data);
  }

  /**
   * 通知新订单
   */
  notifyNewOrder(order: any) {
    this.broadcastToAll('new_order', {
      type: 'order',
      message: '您有新的订单',
      data: order,
      timestamp: new Date().toISOString(),
    });
  }

  /**
   * 通知新商家入驻申请
   */
  notifyNewMerchantApplication(merchant: any) {
    this.sendToRole('super_admin', 'new_merchant_application', {
      type: 'merchant',
      message: '有新的商家入驻申请',
      data: merchant,
      timestamp: new Date().toISOString(),
    });
  }

  /**
   * 通知订单退款申请
   */
  notifyRefundRequest(order: any) {
    this.broadcastToAll('refund_request', {
      type: 'refund',
      message: '有新的退款申请',
      data: order,
      timestamp: new Date().toISOString(),
    });
  }

  /**
   * 通知系统告警
   */
  notifySystemAlert(alert: { level: string; message: string; details?: any }) {
    this.sendToRole('super_admin', 'system_alert', {
      type: 'alert',
      level: alert.level,
      message: alert.message,
      details: alert.details,
      timestamp: new Date().toISOString(),
    });
  }

  /**
   * 获取在线管理员数量
   */
  getOnlineCount(): number {
    return this.connectedClients.size;
  }

  /**
   * 获取在线管理员列表
   */
  getOnlineAdmins(): string[] {
    return Array.from(this.connectedClients.keys());
  }
}
