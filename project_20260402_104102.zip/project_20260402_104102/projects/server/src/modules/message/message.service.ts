import { Injectable } from '@nestjs/common';
import { getSupabaseClient } from '@/storage/database/supabase-client';

// 消息类型
export type MessageType = 'system' | 'order' | 'promotion' | 'activity';

// 消息状态
export type MessageStatus = 'unread' | 'read';

// 消息信息
export interface Message {
  id: string;
  user_id: string;
  type: MessageType;
  title: string;
  content: string;
  data?: Record<string, any>;
  status: MessageStatus;
  created_at: string;
  read_at?: string;
}

// 对话信息
export interface Conversation {
  id: string;
  user_id: string;
  title: string;
  last_message: string;
  last_time: string;
  unread: number;
  messages: ConversationMessage[];
}

// 对话消息
export interface ConversationMessage {
  id: string;
  role: 'user' | 'assistant';
  content: string;
  created_at: string;
}

@Injectable()
export class MessageService {
  /**
   * 获取用户消息列表
   */
  async getMessages(
    userId: string,
    type?: MessageType,
    page: number = 1,
    pageSize: number = 20
  ): Promise<{ messages: Message[]; total: number; unreadCount: number }> {
    const client = getSupabaseClient();
    const offset = (page - 1) * pageSize;

    // 构建查询
    let query = client
      .from('user_messages')
      .select('*', { count: 'exact' })
      .eq('user_id', userId)
      .order('created_at', { ascending: false })
      .range(offset, offset + pageSize - 1);

    if (type) {
      query = query.eq('type', type);
    }

    const { data, count, error } = await query;

    if (error) {
      console.error('Get messages error:', error);
      return { messages: [], total: 0, unreadCount: 0 };
    }

    // 获取未读数量
    const { count: unreadCount } = await client
      .from('user_messages')
      .select('*', { count: 'exact' })
      .eq('user_id', userId)
      .eq('status', 'unread');

    return {
      messages: data || [],
      total: count || 0,
      unreadCount: unreadCount || 0
    };
  }

  /**
   * 获取未读消息数量
   */
  async getUnreadCount(userId: string): Promise<number> {
    const client = getSupabaseClient();

    const { count } = await client
      .from('user_messages')
      .select('*', { count: 'exact' })
      .eq('user_id', userId)
      .eq('status', 'unread');

    return count || 0;
  }

  /**
   * 标记消息为已读
   */
  async markAsRead(userId: string, messageIds: string[]): Promise<{ success: boolean; msg: string }> {
    const client = getSupabaseClient();

    const { error } = await client
      .from('user_messages')
      .update({
        status: 'read',
        read_at: new Date().toISOString()
      })
      .in('id', messageIds)
      .eq('user_id', userId);

    if (error) {
      console.error('Mark as read error:', error);
      return { success: false, msg: '标记失败' };
    }

    return { success: true, msg: '标记成功' };
  }

  /**
   * 全部标记为已读
   */
  async markAllAsRead(userId: string): Promise<{ success: boolean; msg: string }> {
    const client = getSupabaseClient();

    const { error } = await client
      .from('user_messages')
      .update({
        status: 'read',
        read_at: new Date().toISOString()
      })
      .eq('user_id', userId)
      .eq('status', 'unread');

    if (error) {
      console.error('Mark all as read error:', error);
      return { success: false, msg: '标记失败' };
    }

    return { success: true, msg: '全部已读' };
  }

  /**
   * 发送消息
   */
  async sendMessage(data: {
    userId: string;
    type: MessageType;
    title: string;
    content: string;
    data?: Record<string, any>;
  }): Promise<{ success: boolean; msg: string; message?: Message }> {
    const client = getSupabaseClient();

    const { data: message, error } = await client
      .from('user_messages')
      .insert({
        user_id: data.userId,
        type: data.type,
        title: data.title,
        content: data.content,
        data: data.data,
        status: 'unread',
        created_at: new Date().toISOString()
      })
      .select()
      .single();

    if (error) {
      console.error('Send message error:', error);
      return { success: false, msg: '发送失败' };
    }

    return { success: true, msg: '发送成功', message };
  }

  /**
   * 批量发送消息（系统通知）
   */
  async broadcastMessage(data: {
    type: MessageType;
    title: string;
    content: string;
    userIds?: string[];
  }): Promise<{ success: boolean; msg: string; count?: number }> {
    const client = getSupabaseClient();

    let userIds = data.userIds;

    // 如果没有指定用户，发送给所有用户
    if (!userIds || userIds.length === 0) {
      const { data: users } = await client
        .from('users')
        .select('id');
      userIds = users?.map((u: any) => u.id) || [];
    }

    if (userIds.length === 0) {
      return { success: false, msg: '没有目标用户' };
    }

    const messages = userIds.map(userId => ({
      user_id: userId,
      type: data.type,
      title: data.title,
      content: data.content,
      status: 'unread',
      created_at: new Date().toISOString()
    }));

    const { error } = await client
      .from('user_messages')
      .insert(messages);

    if (error) {
      console.error('Broadcast message error:', error);
      return { success: false, msg: '发送失败' };
    }

    return { success: true, msg: '发送成功', count: userIds.length };
  }

  /**
   * 获取AI对话历史
   */
  async getConversations(userId: string): Promise<Conversation[]> {
    const client = getSupabaseClient();

    const { data, error } = await client
      .from('ai_conversations')
      .select('*')
      .eq('user_id', userId)
      .order('updated_at', { ascending: false });

    if (error) {
      console.error('Get conversations error:', error);
      return [];
    }

    return data || [];
  }

  /**
   * 创建/更新对话
   */
  async saveConversation(data: {
    userId: string;
    sessionId?: string;
    title: string;
    message: ConversationMessage;
  }): Promise<{ success: boolean; sessionId: string }> {
    const client = getSupabaseClient();

    if (data.sessionId) {
      // 更新现有对话
      const { data: conv } = await client
        .from('ai_conversations')
        .select('messages')
        .eq('id', data.sessionId)
        .maybeSingle();

      if (conv) {
        const messages = [...(conv.messages || []), data.message];
        await client
          .from('ai_conversations')
          .update({
            messages,
            last_message: data.message.content,
            updated_at: new Date().toISOString()
          })
          .eq('id', data.sessionId);

        return { success: true, sessionId: data.sessionId };
      }
    }

    // 创建新对话
    const sessionId = `conv_${Date.now()}_${Math.random().toString(36).substr(2, 8)}`;
    
    await client
      .from('ai_conversations')
      .insert({
        id: sessionId,
        user_id: data.userId,
        title: data.title,
        last_message: data.message.content,
        messages: [data.message],
        created_at: new Date().toISOString(),
        updated_at: new Date().toISOString()
      });

    return { success: true, sessionId };
  }

  /**
   * 删除对话
   */
  async deleteConversation(userId: string, sessionId: string): Promise<{ success: boolean; msg: string }> {
    const client = getSupabaseClient();

    const { error } = await client
      .from('ai_conversations')
      .delete()
      .eq('id', sessionId)
      .eq('user_id', userId);

    if (error) {
      console.error('Delete conversation error:', error);
      return { success: false, msg: '删除失败' };
    }

    return { success: true, msg: '删除成功' };
  }
}
