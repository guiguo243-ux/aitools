import { Controller, Get, Post, Delete, Body, Query, Param } from '@nestjs/common';
import { MessageService, MessageType } from './message.service';

@Controller('message')
export class MessageController {
  constructor(private readonly messageService: MessageService) {}

  /**
   * 获取消息列表
   */
  @Get('list')
  async getMessages(
    @Query('userId') userId: string,
    @Query('type') type: MessageType,
    @Query('page') page: string,
    @Query('pageSize') pageSize: string
  ) {
    try {
      console.log(`[API] GET /api/message/list?userId=${userId}&type=${type}`);

      if (!userId) {
        return { code: 400, msg: '缺少用户ID', data: null };
      }

      const result = await this.messageService.getMessages(
        userId,
        type || undefined,
        parseInt(page) || 1,
        parseInt(pageSize) || 20
      );

      return { code: 200, msg: 'success', data: result };
    } catch (error) {
      console.error('Get messages error:', error);
      return { code: 500, msg: '获取消息失败', data: null };
    }
  }

  /**
   * 获取未读数量
   */
  @Get('unread-count')
  async getUnreadCount(@Query('userId') userId: string) {
    try {
      console.log(`[API] GET /api/message/unread-count?userId=${userId}`);

      if (!userId) {
        return { code: 400, msg: '缺少用户ID', data: null };
      }

      const count = await this.messageService.getUnreadCount(userId);
      return { code: 200, msg: 'success', data: { count } };
    } catch (error) {
      console.error('Get unread count error:', error);
      return { code: 500, msg: '获取未读数量失败', data: null };
    }
  }

  /**
   * 标记消息已读
   */
  @Post('mark-read')
  async markAsRead(@Body() body: { userId: string; messageIds: string[] }) {
    try {
      console.log('[API] POST /api/message/mark-read', JSON.stringify(body));

      if (!body.userId || !body.messageIds?.length) {
        return { code: 400, msg: '参数不完整', data: null };
      }

      const result = await this.messageService.markAsRead(body.userId, body.messageIds);
      return { code: result.success ? 200 : 400, msg: result.msg, data: null };
    } catch (error) {
      console.error('Mark as read error:', error);
      return { code: 500, msg: '标记失败', data: null };
    }
  }

  /**
   * 全部标记已读
   */
  @Post('mark-all-read')
  async markAllAsRead(@Body() body: { userId: string }) {
    try {
      console.log('[API] POST /api/message/mark-all-read');

      if (!body.userId) {
        return { code: 400, msg: '缺少用户ID', data: null };
      }

      const result = await this.messageService.markAllAsRead(body.userId);
      return { code: result.success ? 200 : 400, msg: result.msg, data: null };
    } catch (error) {
      console.error('Mark all as read error:', error);
      return { code: 500, msg: '标记失败', data: null };
    }
  }

  /**
   * 发送消息
   */
  @Post('send')
  async sendMessage(
    @Body() body: { userId: string; type: MessageType; title: string; content: string; data?: any }
  ) {
    try {
      console.log('[API] POST /api/message/send', JSON.stringify(body));

      if (!body.userId || !body.title || !body.content) {
        return { code: 400, msg: '参数不完整', data: null };
      }

      const result = await this.messageService.sendMessage(body);
      return { code: result.success ? 200 : 400, msg: result.msg, data: result.message };
    } catch (error) {
      console.error('Send message error:', error);
      return { code: 500, msg: '发送失败', data: null };
    }
  }

  /**
   * 获取AI对话历史
   */
  @Get('conversations')
  async getConversations(@Query('userId') userId: string) {
    try {
      console.log(`[API] GET /api/message/conversations?userId=${userId}`);

      if (!userId) {
        return { code: 400, msg: '缺少用户ID', data: null };
      }

      const conversations = await this.messageService.getConversations(userId);
      return { code: 200, msg: 'success', data: conversations };
    } catch (error) {
      console.error('Get conversations error:', error);
      return { code: 500, msg: '获取对话历史失败', data: null };
    }
  }

  /**
   * 删除对话
   */
  @Delete('conversation/:sessionId')
  async deleteConversation(
    @Param('sessionId') sessionId: string,
    @Query('userId') userId: string
  ) {
    try {
      console.log(`[API] DELETE /api/message/conversation/${sessionId}`);

      if (!userId || !sessionId) {
        return { code: 400, msg: '参数不完整', data: null };
      }

      const result = await this.messageService.deleteConversation(userId, sessionId);
      return { code: result.success ? 200 : 400, msg: result.msg, data: null };
    } catch (error) {
      console.error('Delete conversation error:', error);
      return { code: 500, msg: '删除失败', data: null };
    }
  }
}
