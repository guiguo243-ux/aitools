import { Injectable } from '@nestjs/common';
import { getSupabaseClient } from '@/storage/database/supabase-client';

@Injectable()
export class MerchantBackendService {
  /**
   * 获取商家状态
   */
  async getMerchantStatus(userId: string): Promise<any> {
    const client = getSupabaseClient();

    const { data, error } = await client
      .from('merchants')
      .select('id, name, status')
      .eq('user_id', userId)
      .maybeSingle();

    if (error) {
      console.error('Get merchant status error:', error);
      return null;
    }

    return data;
  }

  /**
   * 商家入驻申请
   */
  async applyMerchant(data: {
    userId: string;
    name: string;
    category: string;
    region: string;
    address: string;
    phone: string;
    businessHours: string;
    description?: string;
    licenseUrl?: string;
    coverUrl?: string;
  }): Promise<{ success: boolean; msg: string; merchantId?: string }> {
    const client = getSupabaseClient();

    // 检查是否已申请
    const { data: existing } = await client
      .from('merchants')
      .select('id')
      .eq('user_id', data.userId)
      .maybeSingle();

    if (existing) {
      return { success: false, msg: '您已申请过商家入驻' };
    }

    // 根据区域判断岛内岛外
    const regionType = ['siming', 'huli'].includes(data.region) ? 'island_inside' : 'island_outside';

    const { data: result, error } = await client.from('merchants').insert({
      user_id: data.userId,
      name: data.name,
      category: data.category,
      region: regionType,
      district: this.getDistrictName(data.region),
      address: data.address,
      phone: data.phone,
      business_hours: data.businessHours,
      description: data.description,
      image_url: data.coverUrl,
      cover_image: data.coverUrl,
      status: 'pending',
      rating: '5.0',
      is_verified: false
    }).select('id').single();

    if (error) {
      console.error('Apply merchant error:', error);
      return { success: false, msg: '申请失败: ' + error.message };
    }

    return { success: true, msg: '申请成功，请等待审核', merchantId: result?.id };
  }

  /**
   * 获取区域名称
   */
  private getDistrictName(region: string): string {
    const districtMap: Record<string, string> = {
      siming: '思明区',
      huli: '湖里区',
      jimei: '集美区',
      haicang: '海沧区',
      tongan: '同安区',
      xiangan: '翔安区'
    };
    return districtMap[region] || region;
  }

  /**
   * 获取商家数据看板
   */
  async getDashboard(merchantId: string): Promise<any> {
    const client = getSupabaseClient();
    const today = new Date().toISOString().split('T')[0];
    const monthStart = new Date(new Date().getFullYear(), new Date().getMonth(), 1).toISOString();

    // 今日订单
    const { data: todayOrders } = await client
      .from('orders')
      .select('pay_amount, status')
      .eq('merchant_id', merchantId)
      .gte('created_at', today);

    // 本月订单
    const { data: monthOrders } = await client
      .from('orders')
      .select('pay_amount, status')
      .eq('merchant_id', merchantId)
      .gte('created_at', monthStart);

    const todayRevenue = (todayOrders || [])
      .filter((o: any) => o.status === 'completed')
      .reduce((sum: number, o: any) => sum + parseFloat(o.pay_amount || '0'), 0);

    const monthRevenue = (monthOrders || [])
      .filter((o: any) => o.status === 'completed')
      .reduce((sum: number, o: any) => sum + parseFloat(o.pay_amount || '0'), 0);

    return {
      todayRevenue,
      todayOrders: todayOrders?.length || 0,
      todayVerified: (todayOrders || []).filter((o: any) => o.status === 'completed').length,
      newCustomers: 0,
      monthRevenue,
      monthOrders: monthOrders?.length || 0,
      monthVerified: (monthOrders || []).filter((o: any) => o.status === 'completed').length,
      revenueTrend: this.getMockTrend(),
      topProducts: []
    };
  }

  private getMockTrend() {
    return [
      { date: '周一', amount: 2100 },
      { date: '周二', amount: 2400 },
      { date: '周三', amount: 1980 },
      { date: '周四', amount: 2600 },
      { date: '周五', amount: 3100 },
      { date: '周六', amount: 4200 },
      { date: '周日', amount: 3800 }
    ];
  }

  /**
   * 获取商家商品列表
   */
  async getProducts(merchantId: string): Promise<any[]> {
    const client = getSupabaseClient();

    const { data, error } = await client
      .from('products')
      .select('*')
      .eq('merchant_id', merchantId)
      .order('created_at', { ascending: false });

    if (error) {
      console.error('Get products error:', error);
      return [];
    }

    return data || [];
  }

  /**
   * 创建商品
   */
  async createProduct(data: {
    merchantId: string;
    name: string;
    category: string;
    price: number;
    originalPrice?: number;
    stock: number;
    description?: string;
    coverImage?: string;
  }): Promise<{ success: boolean; productId?: string }> {
    const client = getSupabaseClient();

    const { data: result, error } = await client.from('products').insert({
      merchant_id: data.merchantId,
      name: data.name,
      price: data.price.toString(),
      original_price: data.originalPrice?.toString(),
      stock: data.stock,
      sales_count: 0,
      description: data.description,
      image_url: data.coverImage,
      is_active: true
    }).select('id').single();

    if (error) {
      console.error('Create product error:', error);
      return { success: false };
    }

    return { success: true, productId: result?.id };
  }

  /**
   * 更新商品
   */
  async updateProduct(productId: string, data: Partial<{
    name: string;
    category: string;
    price: number;
    originalPrice: number;
    stock: number;
    description: string;
    coverImage: string;
  }>): Promise<{ success: boolean }> {
    const client = getSupabaseClient();

    const updateData: any = {};
    if (data.name) updateData.name = data.name;
    if (data.price !== undefined) updateData.price = data.price.toString();
    if (data.originalPrice !== undefined) updateData.original_price = data.originalPrice.toString();
    if (data.stock !== undefined) updateData.stock = data.stock;
    if (data.description) updateData.description = data.description;
    if (data.coverImage) updateData.image_url = data.coverImage;

    const { error } = await client
      .from('products')
      .update(updateData)
      .eq('id', productId);

    if (error) {
      console.error('Update product error:', error);
      return { success: false };
    }

    return { success: true };
  }

  /**
   * 删除商品
   */
  async deleteProduct(productId: string): Promise<{ success: boolean }> {
    const client = getSupabaseClient();

    const { error } = await client
      .from('products')
      .delete()
      .eq('id', productId);

    if (error) {
      console.error('Delete product error:', error);
      return { success: false };
    }

    return { success: true };
  }

  /**
   * 切换商品状态
   */
  async toggleProductStatus(productId: string, status: string): Promise<{ success: boolean }> {
    const client = getSupabaseClient();

    const { error } = await client
      .from('products')
      .update({ is_active: status === 'active' })
      .eq('id', productId);

    if (error) {
      console.error('Toggle product status error:', error);
      return { success: false };
    }

    return { success: true };
  }

  /**
   * 获取待核销订单
   */
  async getPendingOrders(merchantId: string): Promise<any[]> {
    const client = getSupabaseClient();

    const { data, error } = await client
      .from('orders')
      .select(`
        id,
        order_no,
        user_id,
        total_price,
        status,
        verify_code,
        created_at,
        order_items(name, quantity, price)
      `)
      .eq('merchant_id', merchantId)
      .eq('status', 'paid')
      .order('created_at', { ascending: false });

    if (error) {
      console.error('Get pending orders error:', error);
      return [];
    }

    return data || [];
  }

  /**
   * 获取核销历史
   */
  async getOrderHistory(merchantId: string): Promise<any[]> {
    const client = getSupabaseClient();

    const { data, error } = await client
      .from('orders')
      .select(`
        id,
        order_no,
        user_id,
        total_price,
        status,
        verify_code,
        created_at,
        verified_at,
        order_items(name, quantity, price)
      `)
      .eq('merchant_id', merchantId)
      .eq('status', 'verified')
      .order('verified_at', { ascending: false })
      .limit(50);

    if (error) {
      console.error('Get order history error:', error);
      return [];
    }

    return data || [];
  }

  /**
   * 核销订单
   */
  async verifyOrder(orderId: string, merchantId: string, verifyCode: string): Promise<{ success: boolean; msg: string }> {
    const client = getSupabaseClient();

    // 验证订单
    const { data: order, error: orderError } = await client
      .from('orders')
      .select('*')
      .eq('id', orderId)
      .eq('merchant_id', merchantId)
      .maybeSingle();

    if (orderError || !order) {
      return { success: false, msg: '订单不存在' };
    }

    if (order.status !== 'paid') {
      return { success: false, msg: '订单状态不正确' };
    }

    if (order.verify_code !== verifyCode) {
      return { success: false, msg: '核销码错误' };
    }

    // 更新订单状态
    const { error } = await client
      .from('orders')
      .update({
        status: 'verified',
        verified_at: new Date().toISOString()
      })
      .eq('id', orderId);

    if (error) {
      console.error('Verify order error:', error);
      return { success: false, msg: '核销失败' };
    }

    return { success: true, msg: '核销成功' };
  }
}
