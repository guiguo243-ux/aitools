import { Module } from '@nestjs/common';
import { MerchantBackendController } from './merchant-backend.controller';
import { MerchantBackendService } from './merchant-backend.service';

@Module({
  controllers: [MerchantBackendController],
  providers: [MerchantBackendService],
  exports: [MerchantBackendService]
})
export class MerchantBackendModule {}
