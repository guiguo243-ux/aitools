import { Controller, Get, Post, Delete, Body, Query, Param } from '@nestjs/common';
import { MerchantBackendService } from './merchant-backend.service';
import { getSupabaseClient } from '@/storage/database/supabase-client';

@Controller('merchant')
export class MerchantBackendController {
  constructor(private readonly merchantService: MerchantBackendService) {}

  // ========== 商家状态 ==========
  
  @Get('status')
  async getMerchantStatus(@Query('userId') userId: string) {
    console.log(`[API] GET /api/merchant/status?userId=${userId}`);
    
    const merchant = await this.merchantService.getMerchantStatus(userId);
    return { code: 200, msg: 'success', data: merchant };
  }

  // ========== 商家入驻 ==========
  
  @Post('apply')
  async applyMerchant(@Body() body: any) {
    console.log('[API] POST /api/merchant/apply', JSON.stringify(body));
    
    if (!body.userId || !body.name || !body.region || !body.address || !body.phone) {
      return { code: 400, msg: '参数不完整', data: null };
    }

    const result = await this.merchantService.applyMerchant(body);
    return { code: result.success ? 200 : 400, msg: result.msg, data: { merchantId: result.merchantId } };
  }

  // ========== 数据看板 ==========
  
  @Get('dashboard')
  async getDashboard(@Query('merchantId') merchantId: string) {
    console.log(`[API] GET /api/merchant/dashboard?merchantId=${merchantId}`);
    
    const data = await this.merchantService.getDashboard(merchantId);
    return { code: 200, msg: 'success', data };
  }

  // ========== 商品管理 ==========
  
  @Get('products')
  async getProducts(@Query('merchantId') merchantId: string) {
    console.log(`[API] GET /api/merchant/products?merchantId=${merchantId}`);
    
    const products = await this.merchantService.getProducts(merchantId);
    return { code: 200, msg: 'success', data: products };
  }

  @Get('product/detail')
  async getProductDetail(@Query('productId') productId: string) {
    console.log(`[API] GET /api/merchant/product/detail?productId=${productId}`);
    
    const client = getSupabaseClient();
    const { data, error } = await client
      .from('products')
      .select('*')
      .eq('id', productId)
      .maybeSingle();

    if (error) {
      return { code: 500, msg: '获取失败', data: null };
    }

    return { code: 200, msg: 'success', data };
  }

  @Post('product/create')
  async createProduct(@Body() body: any) {
    console.log('[API] POST /api/merchant/product/create', JSON.stringify(body));
    
    if (!body.merchantId || !body.name || !body.price) {
      return { code: 400, msg: '参数不完整', data: null };
    }

    const result = await this.merchantService.createProduct(body);
    return { code: result.success ? 200 : 500, msg: result.success ? '创建成功' : '创建失败', data: result };
  }

  @Post('product/update')
  async updateProduct(@Body() body: any) {
    console.log('[API] POST /api/merchant/product/update', JSON.stringify(body));
    
    if (!body.productId) {
      return { code: 400, msg: '缺少商品ID', data: null };
    }

    const result = await this.merchantService.updateProduct(body.productId, body);
    return { code: result.success ? 200 : 500, msg: result.success ? '更新成功' : '更新失败', data: null };
  }

  @Post('product/delete')
  async deleteProduct(@Body() body: { productId: string }) {
    console.log('[API] POST /api/merchant/product/delete', JSON.stringify(body));
    
    const result = await this.merchantService.deleteProduct(body.productId);
    return { code: result.success ? 200 : 500, msg: result.success ? '删除成功' : '删除失败', data: null };
  }

  @Post('product/toggle')
  async toggleProductStatus(@Body() body: { productId: string; status: string }) {
    console.log('[API] POST /api/merchant/product/toggle', JSON.stringify(body));
    
    const result = await this.merchantService.toggleProductStatus(body.productId, body.status);
    return { code: result.success ? 200 : 500, msg: result.success ? '操作成功' : '操作失败', data: null };
  }

  // ========== 订单核销 ==========
  
  @Get('orders/pending')
  async getPendingOrders(@Query('merchantId') merchantId: string) {
    console.log(`[API] GET /api/merchant/orders/pending?merchantId=${merchantId}`);
    
    const orders = await this.merchantService.getPendingOrders(merchantId);
    return { code: 200, msg: 'success', data: orders };
  }

  @Get('orders/history')
  async getOrderHistory(@Query('merchantId') merchantId: string) {
    console.log(`[API] GET /api/merchant/orders/history?merchantId=${merchantId}`);
    
    const orders = await this.merchantService.getOrderHistory(merchantId);
    return { code: 200, msg: 'success', data: orders };
  }

  @Post('order/verify')
  async verifyOrder(@Body() body: { orderId: string; merchantId: string; verifyCode: string }) {
    console.log('[API] POST /api/merchant/order/verify', JSON.stringify(body));
    
    const result = await this.merchantService.verifyOrder(
      body.orderId,
      body.merchantId,
      body.verifyCode
    );
    return { code: result.success ? 200 : 400, msg: result.msg, data: null };
  }
}
