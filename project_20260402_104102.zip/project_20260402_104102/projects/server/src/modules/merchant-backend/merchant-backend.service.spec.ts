import { Test, TestingModule } from '@nestjs/testing';
import { MerchantBackendService } from './merchant-backend.service';
import { createMockSupabaseClient, createMockMerchant, createMockOrder } from '@/testing/test-utils';

describe('MerchantBackendService', () => {
  let service: MerchantBackendService;
  let mockClient: any;

  beforeEach(async () => {
    mockClient = createMockSupabaseClient();

    const module: TestingModule = await Test.createTestingModule({
      providers: [
        MerchantBackendService,
        {
          provide: 'SupabaseClient',
          useValue: mockClient,
        },
      ],
    }).compile();

    service = module.get<MerchantBackendService>(MerchantBackendService);
  });

  it('should be defined', () => {
    expect(service).toBeDefined();
  });

  describe('getMerchantStatus', () => {
    it('should return merchant status when exists', async () => {
      const mockMerchant = createMockMerchant({ status: 'approved' });

      mockClient.from().select().eq().maybeSingle.mockResolvedValue({
        data: mockMerchant,
        error: null,
      });

      const result = await service.getMerchantStatus('test-user-id');

      expect(result).toEqual(mockMerchant);
      expect(mockClient.from).toHaveBeenCalledWith('merchants');
    });

    it('should return null when merchant not found', async () => {
      mockClient.from().select().eq().maybeSingle.mockResolvedValue({
        data: null,
        error: null,
      });

      const result = await service.getMerchantStatus('non-existent-user');

      expect(result).toBeNull();
    });
  });

  describe('applyMerchant', () => {
    it('should create merchant application successfully', async () => {
      const mockMerchant = createMockMerchant();
      const applicationData = {
        userId: 'test-user-id',
        name: '测试商家',
        category: '美食餐饮',
        region: 'siming',
        address: '测试地址',
        phone: '13800138000',
      };

      mockClient.from().select().eq().maybeSingle.mockResolvedValue({
        data: null,
        error: null,
      });

      mockClient.from().insert().select().single.mockResolvedValue({
        data: { id: mockMerchant.id },
        error: null,
      });

      const result = await service.applyMerchant(applicationData);

      expect(result.success).toBe(true);
      expect(result.merchantId).toBeDefined();
    });

    it('should fail when already applied', async () => {
      const existingMerchant = createMockMerchant();

      mockClient.from().select().eq().maybeSingle.mockResolvedValue({
        data: existingMerchant,
        error: null,
      });

      const result = await service.applyMerchant({
        userId: 'test-user-id',
        name: '测试商家',
        category: '美食餐饮',
        region: 'siming',
        address: '测试地址',
        phone: '13800138000',
      });

      expect(result.success).toBe(false);
      expect(result.msg).toContain('已申请过');
    });
  });

  describe('getDashboard', () => {
    it('should return dashboard data', async () => {
      const mockMerchant = createMockMerchant();
      const mockOrders = [
        createMockOrder({ status: 'completed', pay_amount: '100.00' }),
        createMockOrder({ status: 'completed', pay_amount: '200.00' }),
      ];

      mockClient.from().select().eq().gte.mockResolvedValue({
        data: mockOrders,
        error: null,
      });

      const result = await service.getDashboard(mockMerchant.id);

      expect(result).toHaveProperty('todayRevenue');
      expect(result).toHaveProperty('todayOrders');
      expect(result).toHaveProperty('monthRevenue');
      expect(result).toHaveProperty('revenueTrend');
    });
  });

  describe('verifyOrder', () => {
    it('should verify order successfully', async () => {
      const mockOrder = createMockOrder({
        status: 'paid',
        verify_code: '123456',
      });

      mockClient.from().select().eq().eq().maybeSingle.mockResolvedValue({
        data: mockOrder,
        error: null,
      });

      mockClient.from().update().eq().mockResolvedValue({
        data: null,
        error: null,
      });

      const result = await service.verifyOrder(
        mockOrder.id,
        mockOrder.merchant_id,
        '123456'
      );

      expect(result.success).toBe(true);
      expect(result.msg).toBe('核销成功');
    });

    it('should fail with wrong verify code', async () => {
      const mockOrder = createMockOrder({
        status: 'paid',
        verify_code: '123456',
      });

      mockClient.from().select().eq().eq().maybeSingle.mockResolvedValue({
        data: mockOrder,
        error: null,
      });

      const result = await service.verifyOrder(
        mockOrder.id,
        mockOrder.merchant_id,
        'wrong_code'
      );

      expect(result.success).toBe(false);
      expect(result.msg).toContain('核销码错误');
    });

    it('should fail when order already verified', async () => {
      const mockOrder = createMockOrder({
        status: 'verified',
        verify_code: '123456',
      });

      mockClient.from().select().eq().eq().maybeSingle.mockResolvedValue({
        data: mockOrder,
        error: null,
      });

      const result = await service.verifyOrder(
        mockOrder.id,
        mockOrder.merchant_id,
        '123456'
      );

      expect(result.success).toBe(false);
      expect(result.msg).toContain('订单状态不正确');
    });
  });
});
