import { Injectable } from '@nestjs/common';
import { getSupabaseClient } from '@/storage/database/supabase-client';

@Injectable()
export class PointsShopService {
  // ========== 商品管理 ==========

  async getProducts(params: { category?: string; region?: string }) {
    const client = getSupabaseClient();
    
    let query = client
      .from('points_products')
      .select('*')
      .eq('is_active', true)
      .gt('stock', 0)
      .order('sort_order', { ascending: false })
      .order('created_at', { ascending: false });

    if (params.category) {
      query = query.eq('category', params.category);
    }
    if (params.region) {
      query = query.or(`region.is.null,region.eq.${params.region}`);
    }

    const { data, error } = await query;

    if (error) {
      console.error('Get products error:', error);
      return [];
    }

    return data;
  }

  async getProductDetail(productId: string) {
    const client = getSupabaseClient();
    
    const { data, error } = await client
      .from('points_products')
      .select('*')
      .eq('id', productId)
      .single();

    if (error) {
      console.error('Get product detail error:', error);
      return null;
    }

    return data;
  }

  async getCategories() {
    const client = getSupabaseClient();
    
    const { data, error } = await client
      .from('points_products')
      .select('category')
      .eq('is_active', true);

    if (error || !data) {
      return this.getDefaultCategories();
    }

    // 提取唯一分类
    const categories = [...new Set(data.map(p => p.category || 'other'))];
    
    return categories.map(cat => ({
      key: cat,
      name: this.getCategoryName(cat),
    }));
  }

  private getDefaultCategories() {
    return [
      { key: 'coupon', name: '优惠券' },
      { key: 'virtual', name: '虚拟商品' },
      { key: 'ticket', name: '票券' },
      { key: 'physical', name: '实物商品' },
      { key: 'other', name: '其他' },
    ];
  }

  private getCategoryName(key: string): string {
    const names: Record<string, string> = {
      coupon: '优惠券',
      virtual: '虚拟商品',
      ticket: '票券',
      physical: '实物商品',
      other: '其他',
    };
    return names[key] || key;
  }

  // ========== 兑换逻辑 ==========

  async exchangeProduct(params: {
    userId: string;
    productId: string;
    quantity?: number;
    receiverName?: string;
    receiverPhone?: string;
    receiverAddress?: string;
  }) {
    const client = getSupabaseClient();
    const quantity = params.quantity || 1;

    // 1. 获取商品信息
    const { data: product, error: productError } = await client
      .from('points_products')
      .select('*')
      .eq('id', params.productId)
      .single();

    if (productError || !product) {
      return { success: false, msg: '商品不存在' };
    }

    if (!product.is_active) {
      return { success: false, msg: '商品已下架' };
    }

    if (product.stock < quantity) {
      return { success: false, msg: '库存不足' };
    }

    // 2. 获取用户积分
    const { data: user, error: userError } = await client
      .from('users')
      .select('id, points, nickname')
      .eq('id', params.userId)
      .single();

    if (userError || !user) {
      return { success: false, msg: '用户不存在' };
    }

    const totalPoints = product.points_price * quantity;
    if (user.points < totalPoints) {
      return { success: false, msg: `积分不足，当前积分 ${user.points}，需要 ${totalPoints}` };
    }

    // 3. 扣减库存
    const { error: updateStockError } = await client
      .from('points_products')
      .update({
        stock: product.stock - quantity,
        exchange_count: product.exchange_count + quantity,
      })
      .eq('id', params.productId);

    if (updateStockError) {
      console.error('Update stock error:', updateStockError);
      return { success: false, msg: '库存更新失败' };
    }

    // 4. 扣减用户积分
    const newPoints = user.points - totalPoints;
    const { error: updateUserError } = await client
      .from('users')
      .update({ points: newPoints })
      .eq('id', params.userId);

    if (updateUserError) {
      // 回滚库存
      await client
        .from('points_products')
        .update({
          stock: product.stock,
          exchange_count: product.exchange_count,
        })
        .eq('id', params.productId);
      
      return { success: false, msg: '积分扣减失败' };
    }

    // 5. 创建兑换记录
    const { data: exchangeRecord, error: recordError } = await client
      .from('points_exchange_records')
      .insert({
        user_id: params.userId,
        product_id: params.productId,
        product_name: product.name,
        points_cost: totalPoints,
        quantity,
        status: product.category === 'physical' ? 'pending' : 'completed',
        receiver_name: params.receiverName,
        receiver_phone: params.receiverPhone,
        receiver_address: params.receiverAddress,
        completed_at: product.category !== 'physical' ? new Date().toISOString() : null,
      })
      .select()
      .single();

    if (recordError) {
      console.error('Create exchange record error:', recordError);
      // 回滚
      await client
        .from('points_products')
        .update({
          stock: product.stock,
          exchange_count: product.exchange_count,
        })
        .eq('id', params.productId);
      await client
        .from('users')
        .update({ points: user.points })
        .eq('id', params.userId);
      
      return { success: false, msg: '兑换记录创建失败' };
    }

    // 6. 记录积分明细
    await client
      .from('points_records')
      .insert({
        user_id: params.userId,
        points: -totalPoints,
        type: 'exchange',
        description: `兑换${product.name} x${quantity}`,
        related_id: exchangeRecord.id,
        balance_after: newPoints,
      });

    return {
      success: true,
      msg: '兑换成功',
      data: {
        exchangeId: exchangeRecord.id,
        productName: product.name,
        pointsCost: totalPoints,
        remainingPoints: newPoints,
      },
    };
  }

  // ========== 兑换记录 ==========

  async getExchangeRecords(params: {
    userId: string;
    status?: string;
    page: number;
    pageSize: number;
  }) {
    const client = getSupabaseClient();
    
    const offset = (params.page - 1) * params.pageSize;

    let query = client
      .from('points_exchange_records')
      .select('*', { count: 'exact' })
      .eq('user_id', params.userId)
      .order('created_at', { ascending: false })
      .range(offset, offset + params.pageSize - 1);

    if (params.status) {
      query = query.eq('status', params.status);
    }

    const { data, count, error } = await query;

    if (error) {
      console.error('Get exchange records error:', error);
      return { records: [], total: 0 };
    }

    return { records: data || [], total: count || 0 };
  }

  // ========== 积分明细 ==========

  async getPointsRecords(params: {
    userId: string;
    type?: string;
    page: number;
    pageSize: number;
  }) {
    const client = getSupabaseClient();
    
    const offset = (params.page - 1) * params.pageSize;

    let query = client
      .from('points_records')
      .select('*', { count: 'exact' })
      .eq('user_id', params.userId)
      .order('created_at', { ascending: false })
      .range(offset, offset + params.pageSize - 1);

    if (params.type) {
      query = query.eq('type', params.type);
    }

    const { data, count, error } = await query;

    if (error) {
      console.error('Get points records error:', error);
      return { records: [], total: 0 };
    }

    return { records: data || [], total: count || 0 };
  }

  // ========== 用户积分概览 ==========

  async getUserPointsOverview(userId: string) {
    const client = getSupabaseClient();
    
    // 获取用户信息
    const { data: user, error: userError } = await client
      .from('users')
      .select('points, level')
      .eq('id', userId)
      .single();

    if (userError || !user) {
      return {
        points: 0,
        level: 1,
        totalEarned: 0,
        totalSpent: 0,
        exchangeCount: 0,
      };
    }

    // 获取累计获得积分
    const { data: earnedRecords } = await client
      .from('points_records')
      .select('points')
      .eq('user_id', userId)
      .gt('points', 0);

    const totalEarned = earnedRecords?.reduce((sum, r) => sum + r.points, 0) || 0;

    // 获取累计消耗积分
    const { data: spentRecords } = await client
      .from('points_records')
      .select('points')
      .eq('user_id', userId)
      .lt('points', 0);

    const totalSpent = Math.abs(spentRecords?.reduce((sum, r) => sum + r.points, 0) || 0);

    // 获取兑换次数
    const { count: exchangeCount } = await client
      .from('points_exchange_records')
      .select('*', { count: 'exact', head: true })
      .eq('user_id', userId);

    return {
      points: user.points || 0,
      level: user.level || 1,
      totalEarned,
      totalSpent,
      exchangeCount: exchangeCount || 0,
    };
  }
}
