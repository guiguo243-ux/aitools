import { Controller, Get, Post, Body, Query, Param } from '@nestjs/common';
import { PointsShopService } from './points-shop.service';

@Controller('points-shop')
export class PointsShopController {
  constructor(private readonly pointsShopService: PointsShopService) {}

  // ========== 商品列表 ==========

  @Get('products')
  async getProducts(
    @Query('category') category?: string,
    @Query('region') region?: string
  ) {
    console.log('[PointsShop API] GET /api/points-shop/products');
    
    const products = await this.pointsShopService.getProducts({ category, region });
    return { code: 200, msg: 'success', data: products };
  }

  @Get('product/:id')
  async getProductDetail(@Param('id') productId: string) {
    console.log(`[PointsShop API] GET /api/points-shop/product/${productId}`);
    
    const product = await this.pointsShopService.getProductDetail(productId);
    if (!product) {
      return { code: 404, msg: '商品不存在', data: null };
    }
    return { code: 200, msg: 'success', data: product };
  }

  // ========== 兑换相关 ==========

  @Post('exchange')
  async exchangeProduct(
    @Body() body: {
      userId: string;
      productId: string;
      quantity?: number;
      receiverName?: string;
      receiverPhone?: string;
      receiverAddress?: string;
    }
  ) {
    console.log('[PointsShop API] POST /api/points-shop/exchange', body);
    
    const result = await this.pointsShopService.exchangeProduct(body);
    return { code: result.success ? 200 : 400, msg: result.msg, data: result.data };
  }

  // ========== 兑换记录 ==========

  @Get('exchange-records')
  async getExchangeRecords(
    @Query('userId') userId: string,
    @Query('status') status?: string,
    @Query('page') page: string = '1',
    @Query('pageSize') pageSize: string = '20'
  ) {
    console.log(`[PointsShop API] GET /api/points-shop/exchange-records?userId=${userId}`);
    
    const result = await this.pointsShopService.getExchangeRecords({
      userId,
      status,
      page: parseInt(page),
      pageSize: parseInt(pageSize),
    });
    
    return { code: 200, msg: 'success', data: result };
  }

  // ========== 积分明细 ==========

  @Get('points-records')
  async getPointsRecords(
    @Query('userId') userId: string,
    @Query('type') type?: string,
    @Query('page') page: string = '1',
    @Query('pageSize') pageSize: string = '20'
  ) {
    console.log(`[PointsShop API] GET /api/points-shop/points-records?userId=${userId}`);
    
    const result = await this.pointsShopService.getPointsRecords({
      userId,
      type,
      page: parseInt(page),
      pageSize: parseInt(pageSize),
    });
    
    return { code: 200, msg: 'success', data: result };
  }

  // ========== 用户积分概览 ==========

  @Get('user-overview')
  async getUserOverview(@Query('userId') userId: string) {
    console.log(`[PointsShop API] GET /api/points-shop/user-overview?userId=${userId}`);
    
    const overview = await this.pointsShopService.getUserPointsOverview(userId);
    return { code: 200, msg: 'success', data: overview };
  }

  // ========== 商品分类 ==========

  @Get('categories')
  async getCategories() {
    console.log('[PointsShop API] GET /api/points-shop/categories');
    
    const categories = await this.pointsShopService.getCategories();
    return { code: 200, msg: 'success', data: categories };
  }
}
