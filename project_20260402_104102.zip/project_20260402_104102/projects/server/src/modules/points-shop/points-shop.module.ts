import { Module } from '@nestjs/common';
import { PointsShopController } from './points-shop.controller';
import { PointsShopService } from './points-shop.service';

@Module({
  controllers: [PointsShopController],
  providers: [PointsShopService],
  exports: [PointsShopService],
})
export class PointsShopModule {}
