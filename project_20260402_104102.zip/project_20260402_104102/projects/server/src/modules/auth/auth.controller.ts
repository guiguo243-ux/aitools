import { Controller, Post, Get, Body, Query, Headers } from '@nestjs/common';
import { AuthService } from './auth.service';

@Controller('auth')
export class AuthController {
  constructor(private readonly authService: AuthService) {}

  /**
   * 微信小程序登录
   */
  @Post('weapp-login')
  async weappLogin(@Body() body: { code: string }) {
    try {
      console.log('[API] POST /api/auth/weapp-login', JSON.stringify(body));

      if (!body.code) {
        return { code: 400, msg: '缺少登录凭证', data: null };
      }

      const result = await this.authService.weappLogin(body.code);
      return { code: result.success ? 200 : 400, msg: result.msg, data: result };
    } catch (error) {
      console.error('Weapp login error:', error);
      return { code: 500, msg: '登录失败', data: null };
    }
  }

  /**
   * 手机号登录
   */
  @Post('phone-login')
  async phoneLogin(@Body() body: { phone: string; code: string }) {
    try {
      console.log('[API] POST /api/auth/phone-login', { phone: body.phone });

      if (!body.phone || !body.code) {
        return { code: 400, msg: '参数不完整', data: null };
      }

      if (!/^1[3-9]\d{9}$/.test(body.phone)) {
        return { code: 400, msg: '手机号格式不正确', data: null };
      }

      const result = await this.authService.phoneLogin(body.phone, body.code);
      return { code: result.success ? 200 : 400, msg: result.msg, data: result };
    } catch (error) {
      console.error('Phone login error:', error);
      return { code: 500, msg: '登录失败', data: null };
    }
  }

  /**
   * 发送验证码
   */
  @Post('send-code')
  async sendSmsCode(@Body() body: { phone: string }) {
    try {
      console.log('[API] POST /api/auth/send-code', { phone: body.phone });

      if (!body.phone || !/^1[3-9]\d{9}$/.test(body.phone)) {
        return { code: 400, msg: '手机号格式不正确', data: null };
      }

      const result = await this.authService.sendSmsCode(body.phone);
      return { code: result.success ? 200 : 400, msg: result.msg, data: null };
    } catch (error) {
      console.error('Send sms code error:', error);
      return { code: 500, msg: '发送失败', data: null };
    }
  }

  /**
   * 模拟登录（开发环境）
   */
  @Post('mock-login')
  async mockLogin(@Body() body: { userId?: string }) {
    try {
      console.log('[API] POST /api/auth/mock-login');

      const userId = body.userId || 'user_001';
      const result = await this.authService.mockLogin(userId);
      return { code: result.success ? 200 : 400, msg: result.msg, data: result };
    } catch (error) {
      console.error('Mock login error:', error);
      return { code: 500, msg: '登录失败', data: null };
    }
  }

  /**
   * 获取用户信息
   */
  @Get('user-info')
  async getUserInfo(@Query('userId') userId: string) {
    try {
      console.log(`[API] GET /api/auth/user-info?userId=${userId}`);

      if (!userId) {
        return { code: 400, msg: '缺少用户ID', data: null };
      }

      const user = await this.authService.getUserInfo(userId);
      if (!user) {
        return { code: 404, msg: '用户不存在', data: null };
      }

      return { code: 200, msg: 'success', data: user };
    } catch (error) {
      console.error('Get user info error:', error);
      return { code: 500, msg: '获取用户信息失败', data: null };
    }
  }

  /**
   * 更新用户信息
   */
  @Post('update-user')
  async updateUserInfo(
    @Body() body: { userId: string; nickname?: string; avatar?: string; region?: string }
  ) {
    try {
      console.log('[API] POST /api/auth/update-user', JSON.stringify(body));

      if (!body.userId) {
        return { code: 400, msg: '缺少用户ID', data: null };
      }

      const result = await this.authService.updateUserInfo(body.userId, {
        nickname: body.nickname,
        avatar: body.avatar,
        region: body.region
      });

      return { code: result.success ? 200 : 400, msg: result.msg, data: result.user };
    } catch (error) {
      console.error('Update user info error:', error);
      return { code: 500, msg: '更新失败', data: null };
    }
  }

  /**
   * 绑定推荐人
   */
  @Post('bind-referrer')
  async bindReferrer(@Body() body: { userId: string; referrerId: string }) {
    try {
      console.log('[API] POST /api/auth/bind-referrer', JSON.stringify(body));

      if (!body.userId || !body.referrerId) {
        return { code: 400, msg: '参数不完整', data: null };
      }

      const result = await this.authService.bindReferrer(body.userId, body.referrerId);
      return { code: result.success ? 200 : 400, msg: result.msg, data: null };
    } catch (error) {
      console.error('Bind referrer error:', error);
      return { code: 500, msg: '绑定失败', data: null };
    }
  }

  /**
   * 验证 Token
   */
  @Get('verify-token')
  async verifyToken(@Query('token') token: string) {
    try {
      console.log(`[API] GET /api/auth/verify-token`);

      if (!token) {
        return { code: 400, msg: '缺少Token', data: { valid: false } };
      }

      const result = await this.authService.verifyToken(token);
      return { code: 200, msg: 'success', data: result };
    } catch (error) {
      console.error('Verify token error:', error);
      return { code: 500, msg: '验证失败', data: { valid: false } };
    }
  }

  /**
   * 退出登录
   */
  @Post('logout')
  async logout(@Body() body: { userId: string }) {
    try {
      console.log('[API] POST /api/auth/logout', body.userId);

      // JWT 是无状态的，服务端不需要维护 token
      // 这里只是记录退出日志，返回成功即可
      // 如果需要 token 黑名单机制，可以在这里实现

      return { code: 200, msg: '退出成功', data: null };
    } catch (error) {
      console.error('Logout error:', error);
      return { code: 500, msg: '退出失败', data: null };
    }
  }

  /**
   * 绑定/更换手机号
   */
  @Post('bind-phone')
  async bindPhone(@Body() body: { userId: string; phone: string; code: string }) {
    try {
      console.log('[API] POST /api/auth/bind-phone', { userId: body.userId, phone: body.phone });

      if (!body.userId || !body.phone || !body.code) {
        return { code: 400, msg: '参数不完整', data: null };
      }

      if (!/^1[3-9]\d{9}$/.test(body.phone)) {
        return { code: 400, msg: '手机号格式不正确', data: null };
      }

      const result = await this.authService.bindPhone(body.userId, body.phone, body.code);
      return { code: result.success ? 200 : 400, msg: result.msg, data: null };
    } catch (error) {
      console.error('Bind phone error:', error);
      return { code: 500, msg: '绑定失败', data: null };
    }
  }

  /**
   * 设置/修改登录密码
   */
  @Post('set-password')
  async setPassword(@Body() body: { userId: string; password: string; code: string }) {
    try {
      console.log('[API] POST /api/auth/set-password', { userId: body.userId });

      if (!body.userId || !body.password || !body.code) {
        return { code: 400, msg: '参数不完整', data: null };
      }

      if (body.password.length < 6 || body.password.length > 20) {
        return { code: 400, msg: '密码长度需要6-20位', data: null };
      }

      const result = await this.authService.setPassword(body.userId, body.password, body.code);
      return { code: result.success ? 200 : 400, msg: result.msg, data: null };
    } catch (error) {
      console.error('Set password error:', error);
      return { code: 500, msg: '设置失败', data: null };
    }
  }

  /**
   * 修改登录密码
   */
  @Post('change-password')
  async changePassword(@Body() body: { userId: string; oldPassword: string; newPassword: string }) {
    try {
      console.log('[API] POST /api/auth/change-password', { userId: body.userId });

      if (!body.userId || !body.oldPassword || !body.newPassword) {
        return { code: 400, msg: '参数不完整', data: null };
      }

      if (body.newPassword.length < 6 || body.newPassword.length > 20) {
        return { code: 400, msg: '密码长度需要6-20位', data: null };
      }

      const result = await this.authService.changePassword(body.userId, body.oldPassword, body.newPassword);
      return { code: result.success ? 200 : 400, msg: result.msg, data: null };
    } catch (error) {
      console.error('Change password error:', error);
      return { code: 500, msg: '修改失败', data: null };
    }
  }

  /**
   * 获取账号安全信息
   */
  @Get('security-info')
  async getSecurityInfo(@Query('userId') userId: string) {
    try {
      console.log(`[API] GET /api/auth/security-info?userId=${userId}`);

      if (!userId) {
        return { code: 400, msg: '缺少用户ID', data: null };
      }

      const result = await this.authService.getSecurityInfo(userId);
      return { code: 200, msg: 'success', data: result };
    } catch (error) {
      console.error('Get security info error:', error);
      return { code: 500, msg: '获取失败', data: null };
    }
  }
}
