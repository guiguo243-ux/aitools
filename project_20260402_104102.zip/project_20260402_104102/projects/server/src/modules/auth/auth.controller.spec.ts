import { Test, TestingModule } from '@nestjs/testing';
import { AuthController } from './auth.controller';
import { AuthService } from './auth.service';
import { createMockSupabaseClient, createMockUser } from '@/testing/test-utils';

describe('AuthController', () => {
  let controller: AuthController;
  let service: AuthService;

  beforeEach(async () => {
    const module: TestingModule = await Test.createTestingModule({
      controllers: [AuthController],
      providers: [
        AuthService,
        {
          provide: 'SupabaseClient',
          useValue: createMockSupabaseClient(),
        },
      ],
    }).compile();

    controller = module.get<AuthController>(AuthController);
    service = module.get<AuthService>(AuthService);
  });

  it('should be defined', () => {
    expect(controller).toBeDefined();
  });

  describe('sendCode', () => {
    it('should send verification code successfully', async () => {
      const phone = '13800138000';
      const result = await controller.sendCode(phone);

      expect(result.code).toBe(200);
      expect(result.msg).toBe('发送成功');
    });

    it('should fail with invalid phone number', async () => {
      const phone = '123';
      const result = await controller.sendCode(phone);

      expect(result.code).toBe(400);
    });
  });

  describe('login', () => {
    it('should login successfully with valid credentials', async () => {
      const mockUser = createMockUser();
      const body = { phone: mockUser.phone, code: '123456' };

      jest.spyOn(service, 'verifyCode').mockResolvedValue(true);
      jest.spyOn(service, 'findOrCreateUser').mockResolvedValue(mockUser);

      const result = await controller.login(body);

      expect(result.code).toBe(200);
      expect(result.data).toBeDefined();
    });

    it('should fail with invalid verification code', async () => {
      const body = { phone: '13800138000', code: 'wrong' };

      jest.spyOn(service, 'verifyCode').mockResolvedValue(false);

      const result = await controller.login(body);

      expect(result.code).toBe(400);
    });
  });

  describe('logout', () => {
    it('should logout successfully', async () => {
      const result = await controller.logout();

      expect(result.code).toBe(200);
      expect(result.msg).toBe('退出成功');
    });
  });
});
