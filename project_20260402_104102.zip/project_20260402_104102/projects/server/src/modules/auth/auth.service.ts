import { Injectable, Inject, Optional } from '@nestjs/common';
import { getSupabaseClient } from '@/storage/database/supabase-client';

// 用户信息
export interface UserInfo {
  id: string;
  openid?: string;
  nickname: string;
  avatar?: string;
  phone?: string;
  region: string;
  referrer_id?: string;
  points: number;
  balance: number;
  created_at: string;
}

// 登录结果
export interface LoginResult {
  success: boolean;
  msg: string;
  token?: string;
  user?: UserInfo;
}

// 微信登录响应
interface WeChatSessionResponse {
  openid?: string;
  session_key?: string;
  unionid?: string;
  errcode?: number;
  errmsg?: string;
}

@Injectable()
export class AuthService {
  private weappAppId: string;
  private weappSecret: string;

  constructor() {
    // 从环境变量读取微信小程序配置
    this.weappAppId = process.env.WEAPP_APPID || '';
    this.weappSecret = process.env.WEAPP_SECRET || '';
    console.log('[AuthService] WeApp AppID:', this.weappAppId ? '已配置' : '未配置');
  }

  /**
   * 微信小程序登录
   */
  async weappLogin(code: string): Promise<LoginResult> {
    const client = getSupabaseClient();

    // 检查配置
    if (!this.weappAppId || !this.weappSecret) {
      console.error('[WeappLogin] 微信小程序未配置，使用模拟登录');
      return this.mockLogin('');
    }

    try {
      // 调用微信API获取openid
      const wechatUrl = `https://api.weixin.qq.com/sns/jscode2session?appid=${this.weappAppId}&secret=${this.weappSecret}&js_code=${code}&grant_type=authorization_code`;
      
      console.log('[WeappLogin] Calling WeChat API...');
      
      const response = await fetch(wechatUrl);
      const data: WeChatSessionResponse = await response.json();

      console.log('[WeappLogin] WeChat response:', { 
        openid: data.openid ? `${data.openid.slice(0, 8)}...` : undefined,
        errcode: data.errcode,
        errmsg: data.errmsg 
      });

      // 检查微信API返回的错误
      if (data.errcode) {
        console.error('[WeappLogin] WeChat API error:', data.errcode, data.errmsg);
        return { 
          success: false, 
          msg: this.getWeChatErrorMessage(data.errcode, data.errmsg || '') 
        };
      }

      if (!data.openid) {
        return { success: false, msg: '获取用户标识失败' };
      }

      const openid = data.openid;
      const sessionKey = data.session_key;

      // 查询用户是否存在
      const { data: existingUser, error: queryError } = await client
        .from('users')
        .select('*')
        .eq('openid', openid)
        .maybeSingle();

      if (queryError) {
        console.error('[WeappLogin] Query user error:', queryError);
      }

      if (existingUser) {
        // 用户已存在，更新登录时间和session_key
        await client
          .from('users')
          .update({ 
            last_sign_in_at: new Date().toISOString(),
            // 可以存储session_key用于后续解密用户信息
          })
          .eq('id', existingUser.id);

        console.log('[WeappLogin] User logged in:', existingUser.id);

        return {
          success: true,
          msg: '登录成功',
          token: this.generateToken(existingUser.id),
          user: existingUser
        };
      }

      // 新用户，创建账号
      const { data: newUser, error: insertError } = await client
        .from('users')
        .insert({
          openid,
          nickname: '微信用户',
          region: 'island_inside',
          points: 0,
          level: 1,
          is_new_user: true
        })
        .select()
        .single();

      if (insertError) {
        console.error('[WeappLogin] Create user error:', insertError);
        return { success: false, msg: `创建用户失败: ${insertError.message}` };
      }

      console.log('[WeappLogin] New user created:', newUser.id);

      return {
        success: true,
        msg: '注册成功',
        token: this.generateToken(newUser.id),
        user: newUser
      };

    } catch (error) {
      console.error('[WeappLogin] Error:', error);
      return { success: false, msg: '登录失败，请稍后重试' };
    }
  }

  /**
   * 获取微信错误信息
   */
  private getWeChatErrorMessage(errcode: number, errmsg: string): string {
    const errorMessages: Record<string, string> = {
      '40029': 'code无效，请重新登录',
      '45011': '频率限制，请稍后重试',
      '40163': 'code已被使用，请重新登录',
      '40013': 'AppID无效',
      '40125': 'AppSecret错误',
      '-1': '系统繁忙，请稍后重试'
    };
    return errorMessages[String(errcode)] || errmsg || '登录失败';
  }

  /**
   * 手机号登录
   */
  async phoneLogin(phone: string, code: string): Promise<LoginResult> {
    const client = getSupabaseClient();

    // 验证验证码（模拟）
    if (code !== '123456') {
      return { success: false, msg: '验证码错误' };
    }

    // 查询用户
    const { data: existingUser } = await client
      .from('users')
      .select('*')
      .eq('phone', phone)
      .maybeSingle();

    if (existingUser) {
      await client
        .from('users')
        .update({ last_login_at: new Date().toISOString() })
        .eq('id', existingUser.id);

      return {
        success: true,
        msg: '登录成功',
        token: this.generateToken(existingUser.id),
        user: existingUser
      };
    }

    // 新用户注册
    const { data: newUser, error } = await client
      .from('users')
      .insert({
        phone,
        nickname: `用户${phone.slice(-4)}`,
        region: 'island_inside',
        points: 0,
        balance: 0,
        created_at: new Date().toISOString(),
        last_login_at: new Date().toISOString()
      })
      .select()
      .single();

    if (error || !newUser) {
      return { success: false, msg: '创建用户失败' };
    }

    return {
      success: true,
      msg: '注册成功',
      token: this.generateToken(newUser.id),
      user: newUser
    };
  }

  /**
   * 模拟登录（开发环境）
   */
  async mockLogin(userId: string): Promise<LoginResult> {
    const client = getSupabaseClient();

    // 如果没有传入userId，生成一个新的UUID
    if (!userId || userId === 'user_001') {
      userId = crypto.randomUUID();
    }

    // 查询用户
    const { data: existingUser, error: queryError } = await client
      .from('users')
      .select('*')
      .eq('id', userId)
      .maybeSingle();

    if (queryError) {
      console.error('[MockLogin] Query user error:', queryError);
    }

    if (existingUser) {
      // 用户存在，返回登录信息
      return {
        success: true,
        msg: '登录成功',
        token: this.generateToken(existingUser.id),
        user: existingUser
      };
    }

    // 用户不存在，创建新用户（不指定id，让数据库自动生成）
    const { data: newUser, error: insertError } = await client
      .from('users')
      .insert({
        nickname: '测试用户',
        phone: `138${Date.now().toString().slice(-8)}`,
        region: 'island_inside',
        points: 100,
        level: 1
      })
      .select()
      .single();

    if (insertError) {
      console.error('[MockLogin] Create user error:', insertError);
      return { success: false, msg: `创建用户失败: ${insertError.message}` };
    }

    console.log('[MockLogin] Created new user:', newUser);

    return {
      success: true,
      msg: '注册成功',
      token: this.generateToken(newUser.id),
      user: newUser
    };
  }

  /**
   * 获取用户信息
   */
  async getUserInfo(userId: string): Promise<UserInfo | null> {
    const client = getSupabaseClient();

    const { data, error } = await client
      .from('users')
      .select('*')
      .eq('id', userId)
      .maybeSingle();

    if (error || !data) {
      return null;
    }

    return data;
  }

  /**
   * 更新用户信息
   */
  async updateUserInfo(userId: string, data: {
    nickname?: string;
    avatar?: string;
    region?: string;
  }): Promise<{ success: boolean; msg: string; user?: UserInfo }> {
    const client = getSupabaseClient();

    const { data: user, error } = await client
      .from('users')
      .update(data)
      .eq('id', userId)
      .select()
      .single();

    if (error) {
      return { success: false, msg: '更新失败' };
    }

    return { success: true, msg: '更新成功', user };
  }

  /**
   * 发送验证码（模拟）
   */
  async sendSmsCode(phone: string): Promise<{ success: boolean; msg: string }> {
    // 模拟发送验证码
    console.log(`[SMS] Sending code to ${phone}: 123456`);
    return { success: true, msg: '验证码已发送' };
  }

  /**
   * 生成 Token（简化版）
   */
  private generateToken(userId: string): string {
    return `token_${userId}_${Date.now()}`;
  }

  /**
   * 验证 Token（简化版）
   */
  async verifyToken(token: string): Promise<{ valid: boolean; userId?: string }> {
    // 简化验证，实际应使用 JWT
    const parts = token.split('_');
    if (parts.length < 2) {
      return { valid: false };
    }
    return { valid: true, userId: parts[1] };
  }

  /**
   * 绑定推荐人
   */
  async bindReferrer(userId: string, referrerId: string): Promise<{ success: boolean; msg: string }> {
    const client = getSupabaseClient();

    // 检查用户是否已有推荐人
    const { data: user } = await client
      .from('users')
      .select('referrer_id')
      .eq('id', userId)
      .maybeSingle();

    if (user?.referrer_id) {
      return { success: false, msg: '已绑定推荐人' };
    }

    // 检查推荐人是否存在
    const { data: referrer } = await client
      .from('users')
      .select('id')
      .eq('id', referrerId)
      .maybeSingle();

    if (!referrer) {
      return { success: false, msg: '推荐人不存在' };
    }

    // 绑定推荐人
    const { error } = await client
      .from('users')
      .update({ referrer_id: referrerId })
      .eq('id', userId);

    if (error) {
      return { success: false, msg: '绑定失败' };
    }

    return { success: true, msg: '绑定成功' };
  }

  /**
   * 绑定/更换手机号
   */
  async bindPhone(userId: string, phone: string, code: string): Promise<{ success: boolean; msg: string }> {
    const client = getSupabaseClient();

    // 验证验证码（模拟）
    if (code !== '123456') {
      return { success: false, msg: '验证码错误' };
    }

    // 检查手机号是否已被使用
    const { data: existingUser } = await client
      .from('users')
      .select('id')
      .eq('phone', phone)
      .neq('id', userId)
      .maybeSingle();

    if (existingUser) {
      return { success: false, msg: '该手机号已被其他账号绑定' };
    }

    // 更新手机号
    const { error } = await client
      .from('users')
      .update({ phone, updated_at: new Date().toISOString() })
      .eq('id', userId);

    if (error) {
      return { success: false, msg: '绑定失败' };
    }

    return { success: true, msg: '绑定成功' };
  }

  /**
   * 设置密码（首次设置或忘记密码）
   */
  async setPassword(userId: string, password: string, code: string): Promise<{ success: boolean; msg: string }> {
    const client = getSupabaseClient();

    // 验证验证码（这里简化处理，实际应该验证手机验证码）
    if (code !== '123456') {
      return { success: false, msg: '验证码错误' };
    }

    // 获取用户信息
    const { data: user } = await client
      .from('users')
      .select('phone')
      .eq('id', userId)
      .maybeSingle();

    if (!user) {
      return { success: false, msg: '用户不存在' };
    }

    // 加密密码（实际应使用 bcrypt）
    const hashedPassword = this.hashPassword(password);

    // 更新密码
    const { error } = await client
      .from('users')
      .update({ password: hashedPassword, updated_at: new Date().toISOString() })
      .eq('id', userId);

    if (error) {
      return { success: false, msg: '设置失败' };
    }

    return { success: true, msg: '设置成功' };
  }

  /**
   * 修改密码
   */
  async changePassword(userId: string, oldPassword: string, newPassword: string): Promise<{ success: boolean; msg: string }> {
    const client = getSupabaseClient();

    // 获取用户密码
    const { data: user } = await client
      .from('users')
      .select('password')
      .eq('id', userId)
      .maybeSingle();

    if (!user) {
      return { success: false, msg: '用户不存在' };
    }

    // 验证旧密码
    if (user.password && !this.verifyPassword(oldPassword, user.password)) {
      return { success: false, msg: '原密码错误' };
    }

    // 更新密码
    const hashedPassword = this.hashPassword(newPassword);
    const { error } = await client
      .from('users')
      .update({ password: hashedPassword, updated_at: new Date().toISOString() })
      .eq('id', userId);

    if (error) {
      return { success: false, msg: '修改失败' };
    }

    return { success: true, msg: '修改成功' };
  }

  /**
   * 获取账号安全信息
   */
  async getSecurityInfo(userId: string): Promise<{
    hasPassword: boolean;
    hasPhone: boolean;
    phone?: string;
    lastLoginAt?: string;
    loginDevices: any[];
  }> {
    const client = getSupabaseClient();

    const { data: user } = await client
      .from('users')
      .select('phone, password, last_sign_in_at')
      .eq('id', userId)
      .maybeSingle();

    return {
      hasPassword: !!user?.password,
      hasPhone: !!user?.phone,
      phone: user?.phone ? this.maskPhone(user.phone) : undefined,
      lastLoginAt: user?.last_sign_in_at,
      loginDevices: [] // 暂时返回空数组，后续可实现设备管理
    };
  }

  /**
   * 哈希密码（简化版）
   */
  private hashPassword(password: string): string {
    // 实际应使用 bcrypt.hashSync(password, 10)
    return `hashed_${password}`;
  }

  /**
   * 验证密码（简化版）
   */
  private verifyPassword(password: string, hashedPassword: string): boolean {
    // 实际应使用 bcrypt.compareSync(password, hashedPassword)
    return hashedPassword === `hashed_${password}`;
  }

  /**
   * 手机号脱敏
   */
  private maskPhone(phone: string): string {
    return phone.replace(/(\d{3})\d{4}(\d{4})/, '$1****$2');
  }
}
