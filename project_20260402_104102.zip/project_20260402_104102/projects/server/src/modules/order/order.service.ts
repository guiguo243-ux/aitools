import { Injectable } from '@nestjs/common';
import { getSupabaseClient } from '@/storage/database/supabase-client';

// 订单状态
export type OrderStatus = 'pending' | 'paid' | 'serving' | 'completed' | 'cancelled';

// 订单商品
interface OrderProduct {
  id: string;
  name: string;
  price: number;
  quantity: number;
}

// 创建订单参数
export interface CreateOrderParams {
  userId: string;
  merchantId: string;
  products: OrderProduct[];
  addressId?: string;
  redPacketId?: string;
  remark?: string;
  region: string;
  totalAmount: number;
  discountAmount: number;
  payableAmount: number;
}

@Injectable()
export class OrderService {
  /**
   * 创建订单
   */
  async createOrder(params: {
    userId: string;
    merchantId: string;
    productId: string;
    quantity: number;
    totalAmount: number;
    couponId?: string;
  }) {
    const client: any = getSupabaseClient();

    // 获取用户信息
    const { data: user } = await client
      .from('users')
      .select('*')
      .eq('id', params.userId)
      .single();

    // 获取商品信息
    const { data: product } = await client
      .from('products')
      .select('*, merchants(*)')
      .eq('id', params.productId)
      .single();

    if (!product) {
      return { success: false, msg: '商品不存在' };
    }

    // 检查商家区域限制
    const merchant = product.merchants as any;
    if (merchant?.region && merchant.region !== user?.region) {
      // 允许跨区域购买，但不享受区域专属优惠
    }

    // 计算优惠金额
    let discountAmount = 0;
    if (params.couponId) {
      const { data: userCoupon } = await client
        .from('user_coupons')
        .select('*, coupons(*)')
        .eq('id', params.couponId)
        .eq('user_id', params.userId)
        .eq('status', 'unused')
        .single();

      if (userCoupon) {
        const coupon = userCoupon.coupons as any;
        // 检查区域限制
        if (coupon.region && coupon.region !== user?.region) {
          // 区域不匹配，不能使用
        } else {
          discountAmount = coupon.discount_amount || 0;
        }
      }
    }

    // 计算实付金额
    const actualAmount = Math.max(0, params.totalAmount - discountAmount);

    // 计算佣金
    const commissionData = this.calculateCommission(
      actualAmount,
      params.userId,
      merchant
    );

    // 创建订单
    const orderNo = `ORD${Date.now()}${Math.random().toString(36).substr(2, 6).toUpperCase()}`;

    const { data: order, error } = await client
      .from('orders')
      .insert([
        {
          order_no: orderNo,
          user_id: params.userId,
          merchant_id: params.merchantId,
          product_id: params.productId,
          quantity: params.quantity,
          total_amount: params.totalAmount,
          discount_amount: discountAmount,
          pay_amount: actualAmount,
          platform_commission: commissionData.platformCommission,
          referrer_commission: commissionData.referrerCommission,
          merchant_commission: commissionData.merchantCommission,
          status: 'pending',
        },
      ])
      .select()
      .single();

    if (error) {
      console.error('Create order error:', error);
      return { success: false, msg: '创建订单失败' };
    }

    // 标记优惠券已使用
    if (params.couponId) {
      await client
        .from('user_coupons')
        .update({ status: 'used', used_at: new Date().toISOString() })
        .eq('id', params.couponId);
    }

    return {
      success: true,
      order,
      payment: {
        orderNo,
        amount: actualAmount,
        merchantName: merchant?.name,
      },
    };
  }

  /**
   * 计算佣金
   */
  private calculateCommission(
    amount: number,
    userId: string,
    merchant: any
  ): {
    platformCommission: number;
    referrerCommission: number;
    merchantCommission: number;
  } {
    // 平台佣金比例（默认5%）
    const platformRate = merchant?.platform_rate || 0.05;
    // 推荐人佣金比例（默认2%）
    const referrerRate = merchant?.referrer_rate || 0.02;
    // 商家推广佣金比例（如果有推广码）
    const merchantPromoRate = merchant?.promo_rate || 0.01;

    const platformCommission = Math.floor(amount * platformRate * 100) / 100;
    const referrerCommission = Math.floor(amount * referrerRate * 100) / 100;
    const merchantCommission = Math.floor(amount * merchantPromoRate * 100) / 100;

    return {
      platformCommission,
      referrerCommission,
      merchantCommission,
    };
  }

  /**
   * 支付成功回调
   */
  async paymentSuccess(orderNo: string) {
    const client: any = getSupabaseClient();

    // 更新订单状态
    const { data: order, error } = await client
      .from('orders')
      .update({
        status: 'paid',
        paid_at: new Date().toISOString(),
      })
      .eq('order_no', orderNo)
      .select()
      .single();

    if (error || !order) {
      return { success: false, msg: '订单不存在' };
    }

    // 发放推荐人佣金
    if (order.referrer_commission > 0) {
      await this.grantReferrerCommission(
        order.user_id,
        order.id,
        order.referrer_commission
      );
    }

    // 更新商家销售额
    await client.rpc('increment_merchant_sales', {
      merchant_id: order.merchant_id,
      amount: order.actual_amount,
    });

    return { success: true, order };
  }

  /**
   * 发放推荐人佣金
   */
  private async grantReferrerCommission(
    userId: string,
    orderId: string,
    amount: number
  ) {
    const client: any = getSupabaseClient();

    // 获取推荐人
    const { data: user } = await client
      .from('users')
      .select('referrer_id')
      .eq('id', userId)
      .single();

    if (!user?.referrer_id) {
      return;
    }

    // 记录佣金
    await client.from('commissions').insert([
      {
        user_id: user.referrer_id,
        order_id: orderId,
        type: 'order',
        amount,
        status: 'pending',
        description: '订单佣金',
      },
    ]);
  }

  /**
   * 核销订单
   */
  async verifyOrder(orderNo: string, merchantId: string) {
    const client: any = getSupabaseClient();

    const { data: order, error } = await client
      .from('orders')
      .select('*')
      .eq('order_no', orderNo)
      .eq('merchant_id', merchantId)
      .single();

    if (error || !order) {
      return { success: false, msg: '订单不存在' };
    }

    if (order.status !== 'paid') {
      return { success: false, msg: '订单状态不正确' };
    }

    // 更新订单状态
    await client
      .from('orders')
      .update({
        status: 'verified',
        verified_at: new Date().toISOString(),
      })
      .eq('id', order.id);

    // 结算佣金
    await this.settleCommissions(order.id);

    return { success: true, msg: '核销成功' };
  }

  /**
   * 结算佣金
   */
  private async settleCommissions(orderId: string) {
    const client: any = getSupabaseClient();

    // 获取订单佣金
    const { data: commissions } = await client
      .from('commissions')
      .select('*')
      .eq('order_id', orderId)
      .eq('status', 'pending');

    if (!commissions || commissions.length === 0) {
      return;
    }

    for (const commission of commissions) {
      // 更新佣金状态
      await client
        .from('commissions')
        .update({
          status: 'settled',
          settled_at: new Date().toISOString(),
        })
        .eq('id', commission.id);

      // 更新用户余额
      await client.rpc('increment_user_balance', {
        user_id: commission.user_id,
        amount: commission.amount,
      });
    }
  }

  /**
   * 获取订单列表
   */
  async getOrderList(params: {
    userId?: string;
    merchantId?: string;
    status?: string;
    page?: number;
    pageSize?: number;
  }) {
    const client: any = getSupabaseClient();
    const page = params.page || 1;
    const pageSize = params.pageSize || 20;
    const offset = (page - 1) * pageSize;

    let query = client
      .from('orders')
      .select(
        `
        *,
        products (id, name, cover_image),
        merchants (id, name, cover_image)
      `,
        { count: 'exact' }
      )
      .order('created_at', { ascending: false })
      .range(offset, offset + pageSize - 1);

    if (params.userId) {
      query = query.eq('user_id', params.userId);
    }

    if (params.merchantId) {
      query = query.eq('merchant_id', params.merchantId);
    }

    if (params.status) {
      query = query.eq('status', params.status);
    }

    const { data, count, error } = await query;

    if (error) {
      console.error('Get order list error:', error);
      return { orders: [], total: 0 };
    }

    return {
      orders: data || [],
      total: count || 0,
      page,
      pageSize,
    };
  }

  /**
   * 获取订单详情
   */
  async getOrderDetail(orderId: string) {
    const client = getSupabaseClient();

    const { data, error } = await client
      .from('orders')
      .select(`
        *,
        merchants (id, name, cover_image, address, phone, district, region),
        products (id, name, image_url, price)
      `)
      .eq('id', orderId)
      .maybeSingle();

    if (error) {
      console.error('Get order detail error:', error);
      return null;
    }

    if (!data) {
      return null;
    }

    // 生成核销码
    const verificationCode = data.order_no.slice(-12).toUpperCase();
    const verificationQRCode = `INSTORE:${data.id}:${verificationCode}:${data.merchant_id}`;

    // 构造商品列表
    const productList = data.products ? [{
      id: data.products.id,
      name: data.products.name,
      price: data.products.price,
      quantity: 1
    }] : [];

    return {
      id: data.id,
      orderNo: data.order_no,
      merchantId: data.merchant_id,
      merchantName: data.merchants?.name,
      merchantAddress: data.merchants?.address,
      merchantPhone: data.merchants?.phone,
      merchantDistrict: data.merchants?.district,
      merchantRegion: data.merchants?.region,
      products: productList,
      totalAmount: data.total_amount,
      discountAmount: data.coupon_amount || 0,
      payableAmount: data.pay_amount,
      status: data.status,
      region: data.merchants?.region,
      district: data.merchants?.district,
      verificationCode,
      verificationQRCode,
      verifiedAt: data.completed_at,
      createdAt: data.created_at,
      paidAt: data.paid_at,
      userName: '用户',
      userPhone: '***'
    };
  }

  /**
   * 创建订单（新版本）
   */
  async createOrderV2(params: CreateOrderParams) {
    const client = getSupabaseClient();
    const {
      userId,
      merchantId,
      products,
      addressId,
      redPacketId,
      remark,
      region,
      totalAmount,
      discountAmount,
      payableAmount
    } = params;

    // 获取用户信息
    const { data: user, error: userError } = await client
      .from('users')
      .select('*')
      .eq('id', userId)
      .maybeSingle();

    if (userError) {
      console.error('Get user error:', userError);
    }

    // 获取商家信息
    const { data: merchant, error: merchantError } = await client
      .from('merchants')
      .select('*')
      .eq('id', merchantId)
      .maybeSingle();

    if (merchantError) {
      console.error('Get merchant error:', merchantError);
    }

    // 检查并使用红包
    let usedRedPacket: { amount?: number; id?: string; region?: string } | null = null;
    if (redPacketId) {
      const { data: redPacket, error: rpError } = await client
        .from('user_red_packets')
        .select('*')
        .eq('id', redPacketId)
        .eq('user_id', userId)
        .eq('status', 'unused')
        .maybeSingle();

      if (rpError) {
        console.error('Get red packet error:', rpError);
      }

      if (redPacket) {
        // 检查区域限制
        if (redPacket.region && redPacket.region !== region) {
          return { success: false, msg: '红包区域限制不匹配' };
        }
        usedRedPacket = redPacket;
      }
    }

    // 生成订单号
    const orderNo = `ORD${Date.now()}${Math.random().toString(36).substr(2, 6).toUpperCase()}`;

    // 计算佣金
    const commissionData = this.calculateCommissionV2(payableAmount, merchant);

    // 创建订单
    const { data: order, error: orderError } = await client
      .from('orders')
      .insert({
        order_no: orderNo,
        user_id: userId,
        merchant_id: merchantId,
        product_id: products[0]?.id || null,
        total_amount: totalAmount,
        pay_amount: payableAmount,
        coupon_amount: discountAmount,
        commission_amount: commissionData.platformCommission,
        referrer_commission: commissionData.referrerCommission,
        status: 'pending',
      })
      .select()
      .single();

    if (orderError) {
      console.error('Create order error:', orderError);
      return { success: false, msg: `创建订单失败: ${orderError.message}` };
    }

    // 标记红包已使用
    if (usedRedPacket) {
      await client
        .from('user_red_packets')
        .update({
          status: 'used',
          used_at: new Date().toISOString(),
          order_id: order.id
        })
        .eq('id', redPacketId);
    }

    return {
      success: true,
      order: {
        id: order.id,
        orderNo: order.order_no,
        payableAmount: order.pay_amount,
        status: order.status,
        merchantName: merchant?.name,
      },
    };
  }

  /**
   * 计算佣金（新版本）
   */
  private calculateCommissionV2(
    amount: number,
    merchant: { platform_rate?: number; referrer_rate?: number; promo_rate?: number } | null
  ): {
    platformCommission: number;
    referrerCommission: number;
    merchantCommission: number;
  } {
    // 平台佣金比例（默认5%）
    const platformRate = merchant?.platform_rate || 0.05;
    // 推荐人佣金比例（默认2%）
    const referrerRate = merchant?.referrer_rate || 0.02;
    // 商家推广佣金比例（默认1%）
    const merchantPromoRate = merchant?.promo_rate || 0.01;

    const platformCommission = Math.floor(amount * platformRate * 100) / 100;
    const referrerCommission = Math.floor(amount * referrerRate * 100) / 100;
    const merchantCommission = Math.floor(amount * merchantPromoRate * 100) / 100;

    return {
      platformCommission,
      referrerCommission,
      merchantCommission,
    };
  }

  /**
   * 取消订单
   */
  async cancelOrder(params: { orderId: string; userId: string }) {
    const client = getSupabaseClient();
    const { orderId, userId } = params;

    // 查询订单
    const { data: order, error: orderError } = await client
      .from('orders')
      .select('*')
      .eq('id', orderId)
      .eq('user_id', userId)
      .maybeSingle();

    if (orderError) {
      console.error('Get order error:', orderError);
      return { success: false, msg: '查询订单失败' };
    }

    if (!order) {
      return { success: false, msg: '订单不存在' };
    }

    // 只能取消待付款的订单
    if (order.status !== 'pending') {
      return { success: false, msg: '订单状态不允许取消' };
    }

    // 更新订单状态
    const { error: updateError } = await client
      .from('orders')
      .update({
        status: 'cancelled',
        cancelled_at: new Date().toISOString(),
        cancel_reason: '用户主动取消'
      })
      .eq('id', orderId);

    if (updateError) {
      console.error('Cancel order error:', updateError);
      return { success: false, msg: '取消订单失败' };
    }

    // 退回红包
    if (order.red_packet_id) {
      await client
        .from('user_red_packets')
        .update({
          status: 'unused',
          used_at: null,
          order_id: null
        })
        .eq('id', order.red_packet_id);
    }

    return { success: true, msg: '订单已取消' };
  }

  /**
   * 获取用户订单列表
   */
  async getUserOrders(params: {
    userId: string;
    status?: OrderStatus;
    page?: number;
    pageSize?: number;
  }) {
    const client = getSupabaseClient();
    const { userId, status, page = 1, pageSize = 20 } = params;
    const offset = (page - 1) * pageSize;

    let query = client
      .from('orders')
      .select('*', { count: 'exact' })
      .eq('user_id', userId)
      .order('created_at', { ascending: false })
      .range(offset, offset + pageSize - 1);

    if (status) {
      query = query.eq('status', status);
    }

    const { data, count, error } = await query;

    if (error) {
      console.error('Get user orders error:', error);
      return { orders: [], total: 0 };
    }

    return {
      orders: data || [],
      total: count || 0,
      page,
      pageSize,
    };
  }

  /**
   * 更新订单状态
   */
  async updateOrderStatus(params: {
    orderId: string;
    status: OrderStatus;
    operatorId?: string;
  }) {
    const client = getSupabaseClient();
    const { orderId, status, operatorId } = params;

    const updateData: Record<string, unknown> = { status };

    switch (status) {
      case 'paid':
        updateData.paid_at = new Date().toISOString();
        break;
      case 'completed':
        updateData.completed_at = new Date().toISOString();
        break;
      case 'cancelled':
        updateData.cancelled_at = new Date().toISOString();
        break;
    }

    const { error } = await client
      .from('orders')
      .update(updateData)
      .eq('id', orderId);

    if (error) {
      console.error('Update order status error:', error);
      return { success: false, msg: '更新订单状态失败' };
    }

    // 如果订单完成，发放好评返现等
    if (status === 'completed') {
      await this.grantOrderCompletionRewards(orderId);
    }

    return { success: true };
  }

  /**
   * 发放订单完成奖励
   */
  private async grantOrderCompletionRewards(orderId: string) {
    const client = getSupabaseClient();

    // 获取订单详情
    const { data: order } = await client
      .from('orders')
      .select('*')
      .eq('id', orderId)
      .maybeSingle();

    if (!order) return;

    // 查询好评返现配置
    const { data: config } = await client
      .from('red_packet_configs')
      .select('*')
      .eq('scene', 'good_review')
      .eq('is_active', true)
      .maybeSingle();

    if (config) {
      const expireAt = new Date();
      expireAt.setDate(expireAt.getDate() + (config.valid_days || 7));

      await client.from('user_red_packets').insert({
        user_id: order.user_id,
        config_id: config.id,
        type: config.type,
        amount: config.amount,
        min_spend: config.min_spend || 0,
        source: 'good_review',
        region: order.region,
        status: 'unused',
        expire_at: expireAt.toISOString(),
      });
    }
  }
}
