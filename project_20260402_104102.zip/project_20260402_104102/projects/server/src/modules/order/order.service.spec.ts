import { Test, TestingModule } from '@nestjs/testing';
import { OrderService } from './order.service';
import { createMockSupabaseClient, createMockOrder, createMockUser, createMockMerchant } from '@/testing/test-utils';

describe('OrderService', () => {
  let service: OrderService;
  let mockClient: any;

  beforeEach(async () => {
    mockClient = createMockSupabaseClient();

    const module: TestingModule = await Test.createTestingModule({
      providers: [
        OrderService,
        {
          provide: 'SupabaseClient',
          useValue: mockClient,
        },
      ],
    }).compile();

    service = module.get<OrderService>(OrderService);
  });

  it('should be defined', () => {
    expect(service).toBeDefined();
  });

  describe('createOrder', () => {
    it('should create order successfully', async () => {
      const mockUser = createMockUser();
      const mockMerchant = createMockMerchant();
      const orderData = {
        userId: mockUser.id,
        merchantId: mockMerchant.id,
        items: [
          { productId: 'prod_001', quantity: 1, price: 100 },
        ],
        totalAmount: 100,
        payAmount: 90,
      };

      const mockOrder = createMockOrder({
        user_id: orderData.userId,
        merchant_id: orderData.merchantId,
        total_amount: '100.00',
        pay_amount: '90.00',
      });

      mockClient.from().insert().select().single.mockResolvedValue({
        data: mockOrder,
        error: null,
      });

      const result = await service.createOrder(orderData);

      expect(result).toHaveProperty('orderId');
      expect(result).toHaveProperty('orderNo');
    });
  });

  describe('getOrderDetail', () => {
    it('should return order details', async () => {
      const mockOrder = createMockOrder();

      mockClient.from().select().eq().maybeSingle.mockResolvedValue({
        data: mockOrder,
        error: null,
      });

      const result = await service.getOrderDetail(mockOrder.id);

      expect(result).toEqual(mockOrder);
    });

    it('should return null for non-existent order', async () => {
      mockClient.from().select().eq().maybeSingle.mockResolvedValue({
        data: null,
        error: null,
      });

      const result = await service.getOrderDetail('non-existent-id');

      expect(result).toBeNull();
    });
  });

  describe('getUserOrders', () => {
    it('should return user orders list', async () => {
      const mockUser = createMockUser();
      const mockOrders = [
        createMockOrder({ user_id: mockUser.id }),
        createMockOrder({ user_id: mockUser.id }),
      ];

      mockClient.from().select().eq().order.mockResolvedValue({
        data: mockOrders,
        error: null,
      });

      const result = await service.getUserOrders(mockUser.id);

      expect(Array.isArray(result)).toBe(true);
    });
  });

  describe('updateOrderStatus', () => {
    it('should update order status successfully', async () => {
      const mockOrder = createMockOrder({ status: 'pending' });

      mockClient.from().select().eq().maybeSingle.mockResolvedValue({
        data: mockOrder,
        error: null,
      });

      mockClient.from().update().eq().mockResolvedValue({
        data: { ...mockOrder, status: 'paid' },
        error: null,
      });

      const result = await service.updateOrderStatus(mockOrder.id, 'paid');

      expect(result.success).toBe(true);
    });
  });
});
