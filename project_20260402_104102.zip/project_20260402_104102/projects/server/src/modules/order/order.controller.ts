import { Controller, Get, Post, Body, Query, Param } from '@nestjs/common';
import { OrderService, CreateOrderParams, OrderStatus } from './order.service';

@Controller('order')
export class OrderController {
  constructor(private readonly orderService: OrderService) {}

  /**
   * 创建订单（旧版本）
   */
  @Post('create')
  async createOrder(
    @Body()
    body: {
      userId: string;
      merchantId: string;
      productId: string;
      quantity: number;
      totalAmount: number;
      couponId?: string;
    }
  ) {
    try {
      if (!body.userId || !body.productId || !body.quantity || !body.totalAmount) {
        return { code: 400, msg: '参数不完整', data: null };
      }
      const result = await this.orderService.createOrder(body);
      return { code: 200, msg: result.msg, data: result };
    } catch (error) {
      console.error('Create order error:', error);
      return { code: 500, msg: '创建订单失败', data: null };
    }
  }

  /**
   * 创建订单（新版本，支持多商品、红包、优惠券）
   */
  @Post('create-v2')
  async createOrderV2(@Body() body: CreateOrderParams) {
    try {
      console.log('[API] POST /api/order/create-v2', JSON.stringify(body));
      
      const { userId, merchantId, products, totalAmount, payableAmount } = body;
      
      if (!userId || !merchantId || !products || products.length === 0) {
        return { code: 400, msg: '参数不完整', data: null };
      }
      
      if (!totalAmount || !payableAmount) {
        return { code: 400, msg: '金额参数不完整', data: null };
      }

      const result = await this.orderService.createOrderV2(body);
      console.log('[API] createOrderV2 result:', JSON.stringify(result));
      
      if (result.success) {
        return { code: 200, msg: '订单创建成功', data: result.order };
      } else {
        return { code: 400, msg: result.msg || '创建订单失败', data: null };
      }
    } catch (error) {
      console.error('Create order v2 error:', error);
      return { code: 500, msg: '创建订单失败', data: null };
    }
  }

  /**
   * 取消订单
   */
  @Post('cancel')
  async cancelOrder(@Body() body: { orderId: string; userId: string }) {
    try {
      console.log('[API] POST /api/order/cancel', JSON.stringify(body));
      
      if (!body.orderId || !body.userId) {
        return { code: 400, msg: '参数不完整', data: null };
      }

      const result = await this.orderService.cancelOrder(body);
      console.log('[API] cancelOrder result:', JSON.stringify(result));
      
      if (result.success) {
        return { code: 200, msg: result.msg, data: null };
      } else {
        return { code: 400, msg: result.msg, data: null };
      }
    } catch (error) {
      console.error('Cancel order error:', error);
      return { code: 500, msg: '取消订单失败', data: null };
    }
  }

  /**
   * 获取用户订单列表
   */
  @Get('user-orders')
  async getUserOrders(
    @Query('userId') userId: string,
    @Query('status') status: OrderStatus,
    @Query('page') page: string,
    @Query('pageSize') pageSize: string
  ) {
    try {
      console.log(`[API] GET /api/order/user-orders?userId=${userId}&status=${status}`);
      
      if (!userId) {
        return { code: 400, msg: '缺少用户ID', data: null };
      }

      const result = await this.orderService.getUserOrders({
        userId,
        status: status || undefined,
        page: parseInt(page) || 1,
        pageSize: parseInt(pageSize) || 20,
      });
      
      return { code: 200, msg: 'success', data: result };
    } catch (error) {
      console.error('Get user orders error:', error);
      return { code: 500, msg: '获取订单列表失败', data: null };
    }
  }

  /**
   * 更新订单状态
   */
  @Post('update-status')
  async updateOrderStatus(
    @Body() body: { orderId: string; status: OrderStatus; operatorId?: string }
  ) {
    try {
      console.log('[API] POST /api/order/update-status', JSON.stringify(body));
      
      if (!body.orderId || !body.status) {
        return { code: 400, msg: '参数不完整', data: null };
      }

      const result = await this.orderService.updateOrderStatus(body);
      
      if (result.success) {
        return { code: 200, msg: '更新成功', data: null };
      } else {
        return { code: 400, msg: result.msg, data: null };
      }
    } catch (error) {
      console.error('Update order status error:', error);
      return { code: 500, msg: '更新订单状态失败', data: null };
    }
  }

  /**
   * 支付成功回调
   */
  @Post('payment-success')
  async paymentSuccess(@Body() body: { orderNo: string }) {
    try {
      const result = await this.orderService.paymentSuccess(body.orderNo);
      return { code: 200, msg: result.msg, data: result };
    } catch (error) {
      console.error('Payment success error:', error);
      return { code: 500, msg: '支付回调处理失败', data: null };
    }
  }

  /**
   * 核销订单
   */
  @Post('verify')
  async verifyOrder(@Body() body: { orderNo: string; merchantId: string }) {
    try {
      const result = await this.orderService.verifyOrder(body.orderNo, body.merchantId);
      return { code: 200, msg: result.msg, data: result };
    } catch (error) {
      console.error('Verify order error:', error);
      return { code: 500, msg: '核销失败', data: null };
    }
  }

  /**
   * 获取订单列表（旧版本）
   */
  @Get('list')
  async getOrderList(
    @Query('userId') userId: string,
    @Query('merchantId') merchantId: string,
    @Query('status') status: string,
    @Query('page') page: string,
    @Query('pageSize') pageSize: string
  ) {
    try {
      const result = await this.orderService.getOrderList({
        userId,
        merchantId,
        status,
        page: parseInt(page) || 1,
        pageSize: parseInt(pageSize) || 20,
      });
      return { code: 200, msg: 'success', data: result };
    } catch (error) {
      console.error('Get order list error:', error);
      return { code: 500, msg: '获取订单列表失败', data: null };
    }
  }

  /**
   * 获取订单详情
   */
  @Get('detail/:orderId')
  async getOrderDetail(@Param('orderId') orderId: string) {
    try {
      console.log(`[API] GET /api/order/detail/${orderId}`);
      const result = await this.orderService.getOrderDetail(orderId);
      return { code: 200, msg: 'success', data: result };
    } catch (error) {
      console.error('Get order detail error:', error);
      return { code: 500, msg: '获取订单详情失败', data: null };
    }
  }
}
