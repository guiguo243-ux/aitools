import { Controller, Get, Post, Body, Query, Param } from '@nestjs/common';
import { ReviewService } from './review.service';

@Controller('review')
export class ReviewController {
  constructor(private readonly reviewService: ReviewService) {}

  /**
   * 创建评价
   */
  @Post('create')
  async createReview(
    @Body() body: {
      orderId: string;
      userId: string;
      merchantId?: string;
      rating: number;
      content: string;
      images?: string[];
      tags?: string[];
      isAnonymous?: boolean;
    }
  ) {
    try {
      console.log('[API] POST /api/review/create', JSON.stringify(body));

      if (!body.orderId || !body.userId || !body.rating || !body.content) {
        return { code: 400, msg: '参数不完整', data: null };
      }

      if (body.rating < 1 || body.rating > 5) {
        return { code: 400, msg: '评分必须在1-5之间', data: null };
      }

      const result = await this.reviewService.createReview(body);
      return { code: result.success ? 200 : 400, msg: result.msg, data: result.review };
    } catch (error) {
      console.error('Create review error:', error);
      return { code: 500, msg: '评价失败', data: null };
    }
  }

  /**
   * 获取评价列表
   */
  @Get('list')
  async getReviews(
    @Query('merchantId') merchantId: string,
    @Query('userId') userId: string,
    @Query('rating') rating: string,
    @Query('page') page: string,
    @Query('pageSize') pageSize: string
  ) {
    try {
      console.log(`[API] GET /api/review/list?merchantId=${merchantId}`);

      const result = await this.reviewService.getReviews({
        merchantId,
        userId,
        rating: rating ? parseInt(rating) : undefined,
        page: parseInt(page) || 1,
        pageSize: parseInt(pageSize) || 10
      });

      return { code: 200, msg: 'success', data: result };
    } catch (error) {
      console.error('Get reviews error:', error);
      return { code: 500, msg: '获取评价列表失败', data: null };
    }
  }

  /**
   * 获取评价详情
   */
  @Get('detail/:reviewId')
  async getReviewDetail(@Param('reviewId') reviewId: string) {
    try {
      console.log(`[API] GET /api/review/detail/${reviewId}`);

      const review = await this.reviewService.getReviewDetail(reviewId);
      
      if (!review) {
        return { code: 404, msg: '评价不存在', data: null };
      }

      return { code: 200, msg: 'success', data: review };
    } catch (error) {
      console.error('Get review detail error:', error);
      return { code: 500, msg: '获取评价详情失败', data: null };
    }
  }

  /**
   * 检查订单是否可评价
   */
  @Get('can-review')
  async canReview(
    @Query('orderId') orderId: string,
    @Query('userId') userId: string
  ) {
    try {
      console.log(`[API] GET /api/review/can-review?orderId=${orderId}`);

      if (!orderId || !userId) {
        return { code: 400, msg: '参数不完整', data: null };
      }

      const result = await this.reviewService.canReview(orderId, userId);
      return { code: 200, msg: 'success', data: result };
    } catch (error) {
      console.error('Check can review error:', error);
      return { code: 500, msg: '检查失败', data: null };
    }
  }

  /**
   * 商家回复评价
   */
  @Post('reply')
  async replyReview(
    @Body() body: { reviewId: string; merchantId: string; reply: string }
  ) {
    try {
      console.log('[API] POST /api/review/reply', JSON.stringify(body));

      if (!body.reviewId || !body.merchantId || !body.reply) {
        return { code: 400, msg: '参数不完整', data: null };
      }

      const result = await this.reviewService.replyReview(body);
      return { code: result.success ? 200 : 400, msg: result.msg, data: null };
    } catch (error) {
      console.error('Reply review error:', error);
      return { code: 500, msg: '回复失败', data: null };
    }
  }
}
