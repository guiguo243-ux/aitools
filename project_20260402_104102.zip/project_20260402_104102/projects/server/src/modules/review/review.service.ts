import { Injectable } from '@nestjs/common';
import { getSupabaseClient } from '@/storage/database/supabase-client';

// 评价信息
export interface Review {
  id: string;
  order_id: string;
  user_id: string;
  merchant_id: string;
  rating: number;
  content: string;
  images?: string[];
  tags?: string[];
  is_anonymous: boolean;
  reply?: string;
  reply_at?: string;
  created_at: string;
}

@Injectable()
export class ReviewService {
  /**
   * 创建评价
   */
  async createReview(data: {
    orderId: string;
    userId: string;
    merchantId?: string;
    rating: number;
    content: string;
    images?: string[];
    tags?: string[];
    isAnonymous?: boolean;
  }): Promise<{ success: boolean; msg: string; review?: Review }> {
    const client = getSupabaseClient();

    // 检查订单是否存在且已完成
    const { data: order, error: orderError } = await client
      .from('orders')
      .select('*')
      .eq('id', data.orderId)
      .eq('user_id', data.userId)
      .eq('status', 'verified')
      .maybeSingle();

    if (orderError || !order) {
      return { success: false, msg: '订单不存在或未完成' };
    }

    // 检查是否已评价
    const { data: existingReview } = await client
      .from('reviews')
      .select('id')
      .eq('order_id', data.orderId)
      .maybeSingle();

    if (existingReview) {
      return { success: false, msg: '该订单已评价' };
    }

    // 创建评价
    const { data: review, error } = await client
      .from('reviews')
      .insert({
        order_id: data.orderId,
        user_id: data.userId,
        merchant_id: data.merchantId || order.merchant_id,
        rating: data.rating,
        content: data.content,
        images: data.images || [],
        tags: data.tags || [],
        is_anonymous: data.isAnonymous || false,
        created_at: new Date().toISOString()
      })
      .select()
      .single();

    if (error || !review) {
      console.error('Create review error:', error);
      return { success: false, msg: '评价失败' };
    }

    // 更新商家评分
    await this.updateMerchantRating(data.merchantId || order.merchant_id);

    // 发放好评返现
    if (data.rating >= 4) {
      await this.grantReviewReward(data.userId, data.orderId);
    }

    return { success: true, msg: '评价成功', review };
  }

  /**
   * 获取评价列表
   */
  async getReviews(params: {
    merchantId?: string;
    userId?: string;
    rating?: number;
    page?: number;
    pageSize?: number;
  }): Promise<{ reviews: Review[]; total: number; avgRating?: number }> {
    const client = getSupabaseClient();
    const { merchantId, userId, rating, page = 1, pageSize = 10 } = params;
    const offset = (page - 1) * pageSize;

    let query = client
      .from('reviews')
      .select('*', { count: 'exact' })
      .order('created_at', { ascending: false })
      .range(offset, offset + pageSize - 1);

    if (merchantId) {
      query = query.eq('merchant_id', merchantId);
    }

    if (userId) {
      query = query.eq('user_id', userId);
    }

    if (rating) {
      query = query.eq('rating', rating);
    }

    const { data, count, error } = await query;

    if (error) {
      console.error('Get reviews error:', error);
      return { reviews: [], total: 0 };
    }

    // 获取平均评分
    let avgRating: number | undefined;
    if (merchantId) {
      const { data: stats } = await client
        .from('reviews')
        .select('rating')
        .eq('merchant_id', merchantId);

      if (stats && stats.length > 0) {
        avgRating = stats.reduce((sum, r) => sum + r.rating, 0) / stats.length;
      }
    }

    return {
      reviews: data || [],
      total: count || 0,
      avgRating: avgRating ? Math.round(avgRating * 10) / 10 : undefined
    };
  }

  /**
   * 获取评价详情
   */
  async getReviewDetail(reviewId: string): Promise<Review | null> {
    const client = getSupabaseClient();

    const { data, error } = await client
      .from('reviews')
      .select('*')
      .eq('id', reviewId)
      .maybeSingle();

    if (error) {
      console.error('Get review detail error:', error);
      return null;
    }

    return data;
  }

  /**
   * 商家回复评价
   */
  async replyReview(data: {
    reviewId: string;
    merchantId: string;
    reply: string;
  }): Promise<{ success: boolean; msg: string }> {
    const client = getSupabaseClient();

    // 检查评价是否存在
    const { data: review } = await client
      .from('reviews')
      .select('*')
      .eq('id', data.reviewId)
      .eq('merchant_id', data.merchantId)
      .maybeSingle();

    if (!review) {
      return { success: false, msg: '评价不存在' };
    }

    // 更新回复
    const { error } = await client
      .from('reviews')
      .update({
        reply: data.reply,
        reply_at: new Date().toISOString()
      })
      .eq('id', data.reviewId);

    if (error) {
      console.error('Reply review error:', error);
      return { success: false, msg: '回复失败' };
    }

    return { success: true, msg: '回复成功' };
  }

  /**
   * 检查订单是否可评价
   */
  async canReview(orderId: string, userId: string): Promise<{ canReview: boolean; msg: string }> {
    const client = getSupabaseClient();

    const { data: order } = await client
      .from('orders')
      .select('*')
      .eq('id', orderId)
      .eq('user_id', userId)
      .maybeSingle();

    if (!order) {
      return { canReview: false, msg: '订单不存在' };
    }

    if (order.status !== 'verified') {
      return { canReview: false, msg: '订单未完成，暂不可评价' };
    }

    const { data: existingReview } = await client
      .from('reviews')
      .select('id')
      .eq('order_id', orderId)
      .maybeSingle();

    if (existingReview) {
      return { canReview: false, msg: '该订单已评价' };
    }

    return { canReview: true, msg: '可以评价' };
  }

  /**
   * 更新商家评分
   */
  private async updateMerchantRating(merchantId: string): Promise<void> {
    const client = getSupabaseClient();

    const { data: reviews } = await client
      .from('reviews')
      .select('rating')
      .eq('merchant_id', merchantId);

    if (reviews && reviews.length > 0) {
      const avgRating = reviews.reduce((sum, r) => sum + r.rating, 0) / reviews.length;
      
      await client
        .from('merchants')
        .update({ rating: Math.round(avgRating * 10) / 10 })
        .eq('id', merchantId);
    }
  }

  /**
   * 发放好评返现
   */
  private async grantReviewReward(userId: string, orderId: string): Promise<void> {
    const client = getSupabaseClient();

    // 查询好评返现配置
    const { data: config } = await client
      .from('red_packet_configs')
      .select('*')
      .eq('scene', 'good_review')
      .eq('is_active', true)
      .maybeSingle();

    if (config) {
      const expireAt = new Date();
      expireAt.setDate(expireAt.getDate() + (config.valid_days || 7));

      await client.from('user_red_packets').insert({
        user_id: userId,
        config_id: config.id,
        type: config.type,
        amount: config.amount,
        min_spend: config.min_spend || 0,
        source: 'good_review',
        region: null,
        status: 'unused',
        expire_at: expireAt.toISOString(),
        order_id: orderId
      });
    }
  }
}
