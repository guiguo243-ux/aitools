import { Module } from '@nestjs/common'
import { MerchantIncentiveController } from './merchant-incentive.controller'

@Module({
  controllers: [MerchantIncentiveController],
  providers: [],
})
export class MerchantIncentiveModule {}
