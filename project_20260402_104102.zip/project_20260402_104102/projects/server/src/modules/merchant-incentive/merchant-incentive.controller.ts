import { Controller, Get, Post, Body, Query } from '@nestjs/common'

@Controller('merchant-incentive')
export class MerchantIncentiveController {
  @Get('commission/realtime')
  getRealtimeCommission(@Query('merchantId') merchantId: string) {
    // 模拟实时佣金数据（纯到店核销版）
    const data = {
      merchantId,
      today: {
        instoreOrders: 12,       // 到店核销订单数
        totalAmount: 1580.00,
        commission: 31.60,       // 平台佣金（到店核销订单抽佣更低）
        promoterCommission: 15.80,  // 推广人佣金
        actualIncome: 1532.60,   // 实际到账
        orders: [
          { orderId: 'ORD001', amount: 68.00, commission: 1.36, verifiedAt: '10:23', type: '到店核销' },
          { orderId: 'ORD002', amount: 125.00, commission: 2.50, verifiedAt: '11:45', type: '到店核销' },
          { orderId: 'ORD003', amount: 89.00, commission: 1.78, verifiedAt: '12:12', type: '到店核销' }
        ]
      },
      thisWeek: {
        instoreOrders: 86,
        totalAmount: 11250.00,
        commission: 225.00,
        actualIncome: 11025.00
      },
      thisMonth: {
        instoreOrders: 328,
        totalAmount: 42680.00,
        commission: 853.60,
        actualIncome: 41826.40
      },
      withdrawable: 41826.40,
      notice: '仅到店核销订单参与抽佣，无配送成本'
    }

    return {
      code: 200,
      msg: 'success',
      data
    }
  }

  @Get('top-merchants')
  getTopMerchants() {
    // 模拟前50家优质到店商家
    const merchants = Array.from({ length: 10 }, (_, i) => ({
      id: `merchant_${i + 1}`,
      name: ['老厦门沙茶面', '沙坡尾海鲜排档', '五缘湾私房菜', '集美大排档', '海沧渔家乐'][i % 5],
      category: ['闽南美食', '海鲜排档', '本地生鲜', '深夜食堂', '企业团餐'][i % 5],
      district: ['思明区', '湖里区', '集美区', '海沧区', '同安区'][i % 5],
      joinDate: new Date(Date.now() - (i + 1) * 24 * 60 * 60 * 1000).toISOString().split('T')[0],
      topDaysLeft: 7 - i,
      topPosition: i + 1,
      monthlyInstoreVisits: 3000 - i * 150,  // 月到店客流
      avgInstoreRating: (4.8 - i * 0.05).toFixed(1)
    }))

    return {
      code: 200,
      msg: 'success',
      data: {
        merchants,
        totalSlots: 50,
        usedSlots: 10,
        availableSlots: 40,
        message: '前50家入驻到店优质店可享7天免费置顶'
      }
    }
  }

  @Post('apply-top')
  applyForTop(
    @Body() body: {
      merchantId: string
      merchantName: string
      contactPhone: string
      category: string
      district: string
    }
  ) {
    const { merchantId, merchantName, contactPhone, category, district } = body

    const application = {
      merchantId,
      merchantName,
      contactPhone,
      category,
      district,
      applyTime: new Date().toISOString(),
      status: 'pending',
      estimatedReviewDays: 1
    }

    return {
      code: 200,
      msg: '申请成功',
      data: {
        application,
        message: '您的到店置顶申请已提交，预计1个工作日内审核完成'
      }
    }
  }

  @Post('generate-instore-content')
  generateInstoreMarketingContent(
    @Body() body: {
      merchantName: string
      category: string
      features: string[]
      targetAudience: string
      district: string
    }
  ) {
    const { merchantName, category, features, targetAudience, district } = body

    const islandInside = ['思明区', '湖里区']
    const regionType = islandInside.includes(district) ? 'island_inside' : 'island_outside'
    const regionName = regionType === 'island_inside' ? '岛内' : '岛外'

    // AI生成到店营销文案
    const contents = {
      oralScript: {
        title: '闽南语口播文案（到店版）',
        content: `【${merchantName}】来咯！\n` +
          `阮遮是正港的${category}，${features.join('、')}拢有！\n` +
          `你若是想吃好料的，就来阮遮！\n` +
          `${targetAudience}的朋友，阮特别优惠！\n` +
          `${regionName}到店核销，立享优惠价！\n` +
          `赶紧下单，慢来就无咯！`
      },
      posterText: {
        title: '门店到店海报文案',
        headline: `${merchantName} · ${regionName}到店优选`,
        highlights: [
          `🏆 ${features[0] || '本地老字号'}`,
          `⭐ 到店好评率95%+`,
          `📍 ${district}本地人气TOP`,
          `🎁 到店核销立享优惠`
        ],
        callToAction: '扫码锁优惠 · 到店核销享',
        qrHint: '微信扫码 · 到店即用',
        notice: '仅限本区域用户到店使用'
      },
      tableCard: {
        title: '桌贴文案（到店版）',
        content: [
          `${merchantName}`,
          `${category} · ${regionName}到店人气TOP`,
          `扫码下单 · 到店核销享优惠`,
          `本区域用户专享`
        ]
      },
      doorSign: {
        title: '门头文案（到店版）',
        content: [
          `${merchantName}`,
          `${category}`,
          `${regionName}到店优选`,
          `扫码下单 · 到店核销`
        ]
      },
      shareText: {
        title: '分享裂变文案',
        content: regionType === 'island_inside' 
          ? `厦门${district}本地福利！${merchantName}AI精选到店宝藏店，扫码领到店专属券，到店核销立减，分享好友双方都得红包～`
          : `${district}街坊看过来！${merchantName}AI推荐到店好店，到店专享价，扫码领券，到店即用，分享裂变多省一笔～`
      }
    }

    return {
      code: 200,
      msg: 'success',
      data: {
        merchantName,
        category,
        district,
        regionType,
        contents,
        generatedAt: new Date().toISOString(),
        tips: [
          '海报建议A4纸打印，张贴门店显眼位置',
          '桌贴建议10x10cm打印，放置餐桌',
          '分享文案可发微信群、朋友圈、业主群',
          '仅限对应区域用户到店核销，跨区不可用'
        ]
      }
    }
  }

  @Get('statistics')
  getStatistics(
    @Query('merchantId') merchantId: string,
    @Query('period') period: 'today' | 'week' | 'month'
  ) {
    const multiplier = period === 'today' ? 1 : period === 'week' ? 7 : 30
    
    const data = {
      merchantId,
      period,
      overview: {
        pageViews: 1250 * multiplier,
        uniqueVisitors: 890 * multiplier,
        instoreOrders: 12 * multiplier,    // 到店核销订单
        conversionRate: ((12 / 890) * 100).toFixed(2) + '%',
        revenue: 1580 * multiplier,
        avgInstoreValue: 131.67,
        avgWaitTime: 12                    // 平均等位时间
      },
      trafficSource: {
        aiRecommend: Math.floor(45 * multiplier),
        searchBar: Math.floor(25 * multiplier),
        shareLink: Math.floor(20 * multiplier),  // 裂变分享
        nearby: Math.floor(10 * multiplier)
      },
      peakInstoreHours: [
        { hour: '11:00', visits: 15 },
        { hour: '12:00', visits: 28 },
        { hour: '18:00', visits: 22 },
        { hour: '19:00', visits: 35 }
      ],
      topProducts: [
        { name: '招牌沙茶面', instoreSales: 45 * multiplier, revenue: 900 * multiplier },
        { name: '海鲜炒面', instoreSales: 32 * multiplier, revenue: 640 * multiplier },
        { name: '花生汤', instoreSales: 28 * multiplier, revenue: 140 * multiplier }
      ]
    }

    return {
      code: 200,
      msg: 'success',
      data
    }
  }

  @Get('new-store-bonus')
  getNewStoreBonus() {
    return {
      code: 200,
      msg: 'success',
      data: {
        policies: [
          {
            title: '7天免费置顶',
            description: '前50家入驻到店优质店，AI首页固定展示7天',
            value: '价值¥2000',
            type: 'instore'
          },
          {
            title: '首月佣金减半',
            description: '入驻首月到店核销订单抽佣从2%降至1%',
            value: '最高省¥800',
            type: 'instore'
          },
          {
            title: '到店专享红包',
            description: '平台发放到店专属红包，帮助拉新客到店',
            value: '价值¥500',
            type: 'instore'
          },
          {
            title: 'AI到店营销支持',
            description: '免费生成闽南语文案、到店海报、桌贴、门头',
            value: '价值¥300',
            type: 'instore'
          }
        ],
        advantages: [
          '零配送压力：纯到店核销，不增加工作量',
          '精准本地流量：AI只推周边辖区用户',
          '抽佣更低：到店核销订单抽佣比配送低',
          '免费裂变：AI帮您做老客带新客'
        ],
        totalValue: '价值¥3600+',
        applyDeadline: '2024-12-31',
        applyCount: 32,
        remainingSlots: 18
      }
    }
  }

  @Get('promo-code')
  getMerchantPromoCode(
    @Query('merchantId') merchantId: string
  ) {
    // 商家到店推广码
    const promoCode = {
      merchantId,
      merchantName: '老厦门沙茶面',
      instoreCode: 'INSTORE' + merchantId.substring(0, 6).toUpperCase(),
      qrContent: `INSTORE_PROMO:${merchantId}`,
      usageScenes: [
        { scene: '店内海报', description: '张贴店内显眼位置，顾客扫码领到店券' },
        { scene: '桌贴', description: '放置餐桌，顾客扫码下单到店核销' },
        { scene: '门头', description: '张贴门口，吸引路人到店' },
        { scene: '收银台', description: '放置收银台，引导顾客扫码' }
      ],
      shareText: {
        title: '到店专属优惠',
        content: '扫码领到店专属券，到店核销立享优惠，分享好友双方得红包～'
      },
      stats: {
        totalScans: 1250,
        totalOrders: 86,
        conversionRate: '6.88%'
      }
    }

    return {
      code: 200,
      msg: 'success',
      data: promoCode
    }
  }
}
