import { Injectable } from '@nestjs/common';
import { getSupabaseClient } from '@/storage/database/supabase-client';
import { LLMClient, Config } from 'coze-coding-dev-sdk';

@Injectable()
export class AIGuideService {
  private llmClient: LLMClient;
  private config: Config;

  constructor() {
    this.config = new Config();
    this.llmClient = new LLMClient(this.config);
  }

  /**
   * AI导购对话
   */
  async chat(userId: string, message: string, region: string, sessionId?: string) {
    const client = getSupabaseClient();
    
    // 获取用户历史对话
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    let history: any[] = [];
    if (sessionId) {
      const { data, error } = await client
        .from('ai_conversations')
        .select('*')
        .eq('session_id', sessionId)
        .order('created_at', { ascending: true })
        .limit(20);
      
      if (error) {
        console.error('Get conversation history error:', error);
      } else {
        history = data || [];
      }
    }

    // 获取推荐商家
    const { data: merchants, error: merchantsError } = await client
      .from('merchants')
      .select('*')
      .eq('status', 'active')
      .eq('region', region)
      .order('ai_weight', { ascending: false })
      .limit(10);

    if (merchantsError) {
      console.error('Get merchants error:', merchantsError);
    }

    // 构建系统提示
    const systemPrompt = this.buildSystemPrompt(region, merchants || []);

    // 构建消息
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    const messages: any[] = [
      { role: 'system', content: systemPrompt },
    ];

    // 添加历史消息
    for (const h of history) {
      messages.push({ role: h.role, content: h.content });
    }

    // 添加当前消息
    messages.push({ role: 'user', content: message });

    // 调用AI
    const response = await this.llmClient.invoke(messages, {
      model: 'doubao-seed-1-6-251015',
      temperature: 0.7,
    });

    // 保存对话
    const newSessionId = sessionId || `session_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
    
    const { error: insertError } = await client.from('ai_conversations').insert([
      {
        user_id: userId,
        session_id: newSessionId,
        role: 'user',
        content: message,
        region,
      },
      {
        user_id: userId,
        session_id: newSessionId,
        role: 'assistant',
        content: response.content,
        region,
      },
    ]);

    if (insertError) {
      console.error('Save conversation error:', insertError);
    }

    // 提取推荐的商家
    const recommendedMerchants = this.extractRecommendations(response.content, merchants || []);

    return {
      content: response.content,
      sessionId: newSessionId,
      recommendations: recommendedMerchants,
    };
  }

  /**
   * 构建系统提示
   */
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  private buildSystemPrompt(region: string, merchants: any[]): string {
    const regionName = region === 'island_inside' ? '岛内（思明、湖里）' : '岛外（集美、海沧、同安、翔安）';
    
    const merchantInfo = merchants.slice(0, 5).map((m) => 
      `- ${m.name}：${m.description?.substring(0, 50) || '优质商家'}，评分${m.rating}，地址：${m.district || ''}${m.address || ''}`
    ).join('\n');

    return `你是厦门本地生活AI导购助手，专门服务${regionName}的用户。

你的职责：
1. 推荐本地优质商家和优惠活动
2. 帮助用户找到最适合的服务
3. 主动推送限时优惠和补贴

当前区域热门商家：
${merchantInfo || '暂无推荐'}

回答要求：
1. 友好热情，像本地朋友一样
2. 推荐时要加"逼单话术"：如"今日仅剩3单"、"附近30分钟可上门"
3. 强调区域优势：如"岛内专属优惠"、"岛外用户专享"
4. 主动询问需求：如"您是想找餐饮还是家政服务？"
5. 推荐时附带商家信息：名称、地址、评分

示例回答：
"您好！我是您的厦门本地AI导购。${regionName}有超多优质商家等您发现！

今天推荐思明的XX餐厅，抖音评分4.9，今日仅剩5个优惠名额！您是想找餐饮、家政还是其他服务呢？我帮您精准推荐～"`;
  }

  /**
   * 提取推荐商家
   */
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  private extractRecommendations(content: string, merchants: any[]): any[] {
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    const recommendations: any[] = [];
    
    for (const merchant of merchants) {
      if (content.includes(merchant.name)) {
        recommendations.push({
          id: merchant.id,
          name: merchant.name,
          rating: merchant.rating,
          address: merchant.address,
          coverImage: merchant.cover_image,
        });
      }
    }
    
    return recommendations.slice(0, 3);
  }

  /**
   * 生成分享文案
   */
  async generateShareCopy(userId: string, merchantId: string, type: 'merchant' | 'product') {
    const client = getSupabaseClient();
    
    // 获取商家信息
    const { data: merchant, error: merchantError } = await client
      .from('merchants')
      .select('*')
      .eq('id', merchantId)
      .maybeSingle();

    if (merchantError) {
      console.error('Get merchant error:', merchantError);
      throw new Error(`获取商家失败: ${merchantError.message}`);
    }

    if (!merchant) {
      throw new Error('商家不存在');
    }

    // 获取用户信息
    const { data: user, error: userError } = await client
      .from('users')
      .select('*')
      .eq('id', userId)
      .maybeSingle();

    if (userError) {
      console.error('Get user error:', userError);
    }

    const regionText = merchant.region === 'island_inside' ? '岛内' : '岛外';

    const prompt = `请为以下商家生成一条分享文案，要求：
1. 突出"厦门${regionText}"区域特色
2. 包含用户昵称"${user?.nickname || '朋友'}"
3. 强调限时优惠
4. 引导扫码领取专属补贴
5. 字数50-80字

商家信息：
- 名称：${merchant.name}
- 类型：餐饮/服务/娱乐等
- 地址：${merchant.district || ''}${merchant.address || ''}
- 评分：${merchant.rating}`;

    const response = await this.llmClient.invoke([
      { role: 'user', content: prompt }
    ], {
      model: 'doubao-seed-1-6-lite-251015',
      temperature: 0.9,
    });

    return {
      copywriting: response.content,
      merchant: {
        id: merchant.id,
        name: merchant.name,
        coverImage: merchant.cover_image,
      },
    };
  }

  /**
   * AI逼单话术
   */
  async generateUrgencyMessage(userId: string, merchantId: string) {
    const client = getSupabaseClient();
    
    const { data: merchant, error: merchantError } = await client
      .from('merchants')
      .select('*')
      .eq('id', merchantId)
      .maybeSingle();

    if (merchantError) {
      console.error('Get merchant error:', merchantError);
      return null;
    }

    if (!merchant) {
      return null;
    }

    const { data: products, error: productsError } = await client
      .from('products')
      .select('*')
      .eq('merchant_id', merchantId)
      .eq('is_active', true)
      .limit(3);

    if (productsError) {
      console.error('Get products error:', productsError);
    }

    // 生成逼单话术
    const urgencyMessages = [
      `🔥 ${merchant.name}今日仅剩${Math.floor(Math.random() * 5) + 3}个优惠名额！`,
      `⏰ 您所在区域30分钟内可上门/核销，下单立享优惠！`,
      `📊 对比同区域5家，${merchant.name}性价比排名第一！`,
      `💰 限时补贴：现在下单再减${Math.floor(Math.random() * 10) + 5}元！`,
    ];

    return {
      messages: urgencyMessages,
      merchant: {
        id: merchant.id,
        name: merchant.name,
        rating: merchant.rating,
      },
      products: products || [],
    };
  }

  /**
   * 获取对话历史
   */
  async getConversationHistory(userId: string, sessionId: string) {
    const client = getSupabaseClient();
    
    const { data, error } = await client
      .from('ai_conversations')
      .select('*')
      .eq('user_id', userId)
      .eq('session_id', sessionId)
      .order('created_at', { ascending: true });

    if (error) {
      console.error('Get conversation history error:', error);
      throw new Error(`获取对话历史失败: ${error.message}`);
    }

    return data || [];
  }
}
