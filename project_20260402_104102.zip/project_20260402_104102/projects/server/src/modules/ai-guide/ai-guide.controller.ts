import { Controller, Get, Post, Body, Query } from '@nestjs/common'
import { AIGuideService } from './ai-guide.service'

@Controller('ai-guide')
export class AIGuideController {
  constructor(private readonly aiGuideService: AIGuideService) {}

  @Post('chat')
  async chat(
    @Body() body: { userId: string; message: string; region: string; sessionId?: string }
  ) {
    try {
      const result = await this.aiGuideService.chat(
        body.userId,
        body.message,
        body.region,
        body.sessionId
      )
      return { code: 200, msg: 'success', data: result }
    } catch (error) {
      console.error('AI chat error:', error)
      return { code: 500, msg: 'AI对话失败', data: null }
    }
  }

  @Get('districts')
  getDistricts() {
    return {
      code: 200,
      msg: 'success',
      data: {
        districts: [
          {
            district: '思明区',
            regionType: 'island_inside',
            businessAreas: ['中山路商圈', '沙坡尾', '曾厝垵', '软件园二期', '莲坂商圈', '瑞景商圈'],
            landmarks: ['鼓浪屿', '南普陀寺', '厦门大学', '环岛路'],
            storeDensity: '到店商家密集，老字号集中'
          },
          {
            district: '湖里区',
            regionType: 'island_inside',
            businessAreas: ['五缘湾', 'SM城市广场', '湖里老街', '高崎机场商圈', '江头商圈'],
            landmarks: ['五缘湾湿地公园', '厦门机场', '湖里公园'],
            storeDensity: '写字楼集中，企业团餐首选'
          },
          {
            district: '集美区',
            regionType: 'island_outside',
            businessAreas: ['集美学村', '杏林湾', '软件园三期', '万达广场'],
            landmarks: ['集美学村', '龙舟池', '园博苑'],
            storeDensity: '学村周边美食聚集'
          },
          {
            district: '海沧区',
            regionType: 'island_outside',
            businessAreas: ['海沧湾', '阿罗海城市广场', '新阳工业区'],
            landmarks: ['海沧大桥', '天竺山', '日月谷温泉'],
            storeDensity: '社区配套完善，家庭消费首选'
          },
          {
            district: '同安区',
            regionType: 'island_outside',
            businessAreas: ['同安老城区', '工业集中区', 'BRT沿线'],
            landmarks: ['同安古城', '梵天寺', '影视城'],
            storeDensity: '本地老字号众多，性价比高'
          },
          {
            district: '翔安区',
            regionType: 'island_outside',
            businessAreas: ['翔安新城', '新店商圈', '大学城'],
            landmarks: ['翔安隧道', '香山', '大嶝岛'],
            storeDensity: '新兴商圈，到店优惠多'
          }
        ]
      }
    }
  }

  @Get('categories')
  getCategories() {
    return {
      code: 200,
      msg: 'success',
      data: {
        categories: [
          { id: 'minnan_food', name: '闽南美食', icon: '🍜', description: '地道闽南味，到店堂食更香' },
          { id: 'seafood_stall', name: '海鲜排档', icon: '🦀', description: '新鲜海产，到店现点现做' },
          { id: 'local_fresh', name: '本地生鲜', icon: '🥬', description: '岛内外直供，到店自提更新鲜' },
          { id: 'night_food', name: '深夜食堂', icon: '🌙', description: '夜猫子福音，到店氛围好' },
          { id: 'life_service', name: '生活服务', icon: '💆', description: '到店体验，服务更专业' },
          { id: 'group_meal', name: '企业团餐', icon: '🍱', description: '写字楼专属，到店聚餐更实惠' }
        ]
      }
    }
  }

  @Get('merchant-tags')
  getMerchantTags() {
    return {
      code: 200,
      msg: 'success',
      data: {
        tags: [
          { id: 'old_brand', name: '本地老字号', icon: '🏆', color: '#FF6B35' },
          { id: 'top_rated', name: '到店好评如潮', icon: '⭐', color: '#EAB308' },
          { id: 'instore_hot', name: '到店人气王', icon: '🔥', color: '#EF4444' },
          { id: 'local_favorite', name: '本地人最爱', icon: '❤️', color: '#EC4899' },
          { id: 'new_store', name: '新店到店福利', icon: '🎁', color: '#10B981' },
          { id: 'night_owl', name: '深夜营业', icon: '🌙', color: '#8B5CF6' },
          { id: 'group_friendly', name: '聚餐首选', icon: '👥', color: '#06B6D4' },
          { id: 'family_friendly', name: '家庭友好', icon: '👨‍👩‍👧‍👦', color: '#F59E0B' }
        ]
      }
    }
  }

  @Get('instore-recommendations')
  getInstoreRecommendations(
    @Query('district') district: string,
    @Query('category') category?: string,
    @Query('scene') scene?: string
  ) {
    const regionType = ['思明区', '湖里区'].includes(district) ? 'island_inside' : 'island_outside'
    
    // 模拟到店商家推荐数据
    const merchants = [
      {
        id: '1',
        name: '老厦门沙茶面',
        category: '闽南美食',
        district: '思明区',
        businessArea: '中山路商圈',
        rating: 4.8,
        monthlyVisits: 3580,
        distance: 0.8,
        avgWaitTime: 10,
        localTags: ['本地老字号', '本地人最爱'],
        instoreDiscount: 15,
        urgencyReason: '到店好评TOP1',
        urgencyMessage: `您在${district}，这家沙茶面是本区域到店好评TOP1，到店核销立减15元，券有效期24小时～`
      },
      {
        id: '2',
        name: '沙坡尾海鲜排档',
        category: '海鲜排档',
        district: '思明区',
        businessArea: '沙坡尾',
        rating: 4.7,
        monthlyVisits: 2820,
        distance: 1.2,
        avgWaitTime: 15,
        localTags: ['到店好评如潮', '本地人最爱'],
        instoreDiscount: 12,
        urgencyReason: '到店人气火爆',
        urgencyMessage: '沙坡尾到店人气TOP2！沙坡尾海鲜排档本地人都在排队，线上下单到店免排队～'
      },
      {
        id: '3',
        name: '集美大排档',
        category: '闽南美食',
        district: '集美区',
        businessArea: '集美学村',
        rating: 4.5,
        monthlyVisits: 1580,
        distance: 3.2,
        avgWaitTime: 8,
        localTags: ['新店到店福利'],
        instoreDiscount: 20,
        urgencyReason: '新店到店特惠',
        urgencyMessage: '新店到店福利！集美大排档入驻7天，到店核销8折起，首单再减10元～'
      }
    ]

    // 只返回同区域的商家
    const filteredMerchants = merchants.filter(m => {
      const merchantRegion = ['思明区', '湖里区'].includes(m.district) ? 'island_inside' : 'island_outside'
      return merchantRegion === regionType
    })

    // 生成本地化到店提示
    const localTips = [
      `📍 您在${district}，附近热门到店商圈：${district === '思明区' ? '中山路商圈、沙坡尾、软件园二期' : '集美学村、杏林湾'}`,
      regionType === 'island_inside' ? '🏝️ 岛内用户专享：更多老字号到店优惠，堂食体验更佳' : '🌊 岛外用户专享：本地生鲜到店自提，企业团餐到店更实惠'
    ]

    return {
      code: 200,
      msg: 'success',
      data: {
        merchants: filteredMerchants,
        localTips,
        urgencyMessages: filteredMerchants.slice(0, 3).map(m => m.urgencyMessage),
        notice: '仅展示同区域到店商家，跨区商家不显示'
      }
    }
  }

  @Post('instore-urgency')
  generateInstoreUrgency(
    @Body() body: {
      scenario: string
      params: Record<string, string | number>
    }
  ) {
    const { scenario, params } = body
    
    // 到店话术模板
    const templates: Record<string, string[]> = {
      '区域匹配到店': [
        '您在{district}，这家{name}{category}是本区域到店好评TOP{rank}，到店核销立减{discount}元～',
        '{district}本地宝藏店！{name}到店专属价已上线，到店直接核销，跨区无法使用～'
      ],
      '到店库存稀缺': [
        '今日{product_name}到店名额仅剩{stock}个，到店核销立享{discount}折优惠～',
        '限时到店福利！{product_name}仅剩{stock}个到店名额，过期作废～'
      ],
      '到店时效紧迫': [
        '距店铺打烊还有{hours_left}小时，现在锁单到店立减{discount_amount}元～',
        '今日最后{hours_left}小时！{name}到店专属套餐，到店核销直接用～'
      ],
      '本地到店热度': [
        '{business_area}到店人气TOP{rank}！{name}本地人都在排队，线上下单到店免排队～',
        '厦门本地老字号！{name}传承{years}年，到店专享价比到店直接付更便宜～'
      ],
      '新店到店福利': [
        '新店到店福利！{name}入驻{days}天，到店核销{discount}折起～',
        '首单到店立减{first_discount}元！{name}刚入驻，到店尝鲜价～'
      ],
      '到店裂变引导': [
        '分享好友一起到店，两人都得专属到店券，{district}区域可用～',
        '组队到店更优惠！找{need_count}位{district}好友拼单到店，核销再减{group_discount}元～'
      ]
    }

    const scenarioTemplates = templates[scenario] || templates['区域匹配到店']
    let message = scenarioTemplates[Math.floor(Math.random() * scenarioTemplates.length)]
    
    // 替换变量
    Object.entries(params).forEach(([key, value]) => {
      message = message.replace(`{${key}}`, String(value))
    })

    return {
      code: 200,
      msg: 'success',
      data: { message }
    }
  }

  @Get('share-templates')
  getShareTemplates() {
    return {
      code: 200,
      msg: 'success',
      data: {
        templates: [
          {
            type: 'island_inside',
            title: '厦门岛内到店福利',
            content: '厦门思明/湖里本地福利！AI精选宝藏店，扫码领岛内到店专属券，到店核销立减，分享好友双方都得红包～',
            callToAction: '扫码领到店专属券'
          },
          {
            type: 'island_outside',
            title: '厦门岛外到店福利',
            content: '集美/海沧街坊看过来！AI推荐本地好店，岛外到店专享价，扫码领券，到店即用，分享裂变多省一笔～',
            callToAction: '扫码领到店专属券'
          }
        ]
      }
    }
  }
}
