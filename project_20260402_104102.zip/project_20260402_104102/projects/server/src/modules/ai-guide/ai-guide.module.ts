import { Module } from '@nestjs/common'
import { AIGuideController } from './ai-guide.controller'
import { AIGuideService } from './ai-guide.service'

@Module({
  controllers: [AIGuideController],
  providers: [AIGuideService],
})
export class AIGuideModule {}
