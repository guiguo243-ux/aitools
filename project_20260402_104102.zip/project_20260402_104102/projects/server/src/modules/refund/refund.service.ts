import { Injectable } from '@nestjs/common';
import { getSupabaseClient } from '@/storage/database/supabase-client';

@Injectable()
export class RefundService {
  /**
   * 申请退款
   */
  async requestRefund(data: {
    orderId: string;
    userId: string;
    reason: string;
  }): Promise<{ success: boolean; msg: string; refundId?: string }> {
    const client = getSupabaseClient();

    // 检查订单
    const { data: order, error: orderError } = await client
      .from('orders')
      .select('*')
      .eq('id', data.orderId)
      .eq('user_id', data.userId)
      .maybeSingle();

    if (orderError || !order) {
      return { success: false, msg: '订单不存在' };
    }

    if (!['paid', 'verified'].includes(order.status)) {
      return { success: false, msg: '当前订单状态不支持退款' };
    }

    // 创建退款记录
    const refundId = `RF${Date.now()}`;
    
    const { error } = await client.from('refunds').insert({
      id: refundId,
      order_id: data.orderId,
      user_id: data.userId,
      amount: order.payable_amount,
      reason: data.reason,
      status: 'pending',
      created_at: new Date().toISOString()
    });

    if (error) {
      console.error('Create refund error:', error);
      return { success: false, msg: '申请失败' };
    }

    // 更新订单状态
    await client
      .from('orders')
      .update({ status: 'refunding' })
      .eq('id', data.orderId);

    return { success: true, msg: '申请成功', refundId };
  }

  /**
   * 获取退款详情
   */
  async getRefundDetail(refundId: string): Promise<any> {
    const client = getSupabaseClient();

    const { data, error } = await client
      .from('refunds')
      .select('*')
      .eq('id', refundId)
      .maybeSingle();

    if (error) {
      console.error('Get refund detail error:', error);
      return null;
    }

    return data;
  }

  /**
   * 获取用户退款列表
   */
  async getUserRefunds(userId: string): Promise<any[]> {
    const client = getSupabaseClient();

    const { data, error } = await client
      .from('refunds')
      .select('*')
      .eq('user_id', userId)
      .order('created_at', { ascending: false });

    if (error) {
      console.error('Get user refunds error:', error);
      return [];
    }

    return data || [];
  }

  /**
   * 取消退款申请
   */
  async cancelRefund(refundId: string, userId: string): Promise<{ success: boolean; msg: string }> {
    const client = getSupabaseClient();

    const { data: refund } = await client
      .from('refunds')
      .select('*')
      .eq('id', refundId)
      .eq('user_id', userId)
      .maybeSingle();

    if (!refund) {
      return { success: false, msg: '退款记录不存在' };
    }

    if (refund.status !== 'pending') {
      return { success: false, msg: '当前状态无法取消' };
    }

    // 更新退款状态
    await client
      .from('refunds')
      .update({ status: 'cancelled' })
      .eq('id', refundId);

    // 恢复订单状态
    await client
      .from('orders')
      .update({ status: 'paid' })
      .eq('id', refund.order_id);

    return { success: true, msg: '取消成功' };
  }
}
