import { Controller, Get, Post, Body, Query, Param } from '@nestjs/common';
import { RefundService } from './refund.service';

@Controller('refund')
export class RefundController {
  constructor(private readonly refundService: RefundService) {}

  @Post('request')
  async requestRefund(@Body() body: { orderId: string; userId: string; reason: string }) {
    try {
      console.log('[API] POST /api/refund/request', JSON.stringify(body));
      
      if (!body.orderId || !body.userId || !body.reason) {
        return { code: 400, msg: '参数不完整', data: null };
      }

      const result = await this.refundService.requestRefund(body);
      return { code: result.success ? 200 : 400, msg: result.msg, data: { refundId: result.refundId } };
    } catch (error) {
      console.error('Request refund error:', error);
      return { code: 500, msg: '申请失败', data: null };
    }
  }

  @Get('detail/:refundId')
  async getRefundDetail(@Param('refundId') refundId: string) {
    try {
      const refund = await this.refundService.getRefundDetail(refundId);
      return { code: 200, msg: 'success', data: refund };
    } catch (error) {
      return { code: 500, msg: '获取失败', data: null };
    }
  }

  @Get('list')
  async getUserRefunds(@Query('userId') userId: string) {
    try {
      const refunds = await this.refundService.getUserRefunds(userId);
      return { code: 200, msg: 'success', data: refunds };
    } catch (error) {
      return { code: 500, msg: '获取失败', data: null };
    }
  }

  @Post('cancel')
  async cancelRefund(@Body() body: { refundId: string; userId: string }) {
    try {
      const result = await this.refundService.cancelRefund(body.refundId, body.userId);
      return { code: result.success ? 200 : 400, msg: result.msg, data: null };
    } catch (error) {
      return { code: 500, msg: '取消失败', data: null };
    }
  }
}
