import { Controller, Get, Post, Body, Query } from '@nestjs/common';
import { WalletService, TransactionType } from './wallet.service';

@Controller('wallet')
export class WalletController {
  constructor(private readonly walletService: WalletService) {}

  /**
   * 获取钱包信息
   */
  @Get('info')
  async getWalletInfo(@Query('userId') userId: string) {
    try {
      console.log(`[API] GET /api/wallet/info?userId=${userId}`);

      if (!userId) {
        return { code: 400, msg: '缺少用户ID', data: null };
      }

      const walletInfo = await this.walletService.getWalletInfo(userId);
      console.log('[API] getWalletInfo result:', JSON.stringify(walletInfo));

      return { code: 200, msg: 'success', data: walletInfo };
    } catch (error) {
      console.error('Get wallet info error:', error);
      return { code: 500, msg: '获取钱包信息失败', data: null };
    }
  }

  /**
   * 获取交易记录
   */
  @Get('transactions')
  async getTransactions(
    @Query('userId') userId: string,
    @Query('type') type: TransactionType,
    @Query('page') page: string,
    @Query('pageSize') pageSize: string
  ) {
    try {
      console.log(`[API] GET /api/wallet/transactions?userId=${userId}&type=${type}`);

      if (!userId) {
        return { code: 400, msg: '缺少用户ID', data: null };
      }

      const result = await this.walletService.getTransactions({
        userId,
        type: type || undefined,
        page: parseInt(page) || 1,
        pageSize: parseInt(pageSize) || 20,
      });

      return { code: 200, msg: 'success', data: result };
    } catch (error) {
      console.error('Get transactions error:', error);
      return { code: 500, msg: '获取交易记录失败', data: null };
    }
  }

  /**
   * 提现申请
   */
  @Post('withdraw')
  async withdraw(@Body() body: { userId: string; amount: number }) {
    try {
      console.log('[API] POST /api/wallet/withdraw', JSON.stringify(body));

      if (!body.userId || !body.amount) {
        return { code: 400, msg: '参数不完整', data: null };
      }

      const result = await this.walletService.withdraw(body);
      console.log('[API] withdraw result:', JSON.stringify(result));

      if (result.success) {
        return { code: 200, msg: result.msg, data: null };
      } else {
        return { code: 400, msg: result.msg, data: null };
      }
    } catch (error) {
      console.error('Withdraw error:', error);
      return { code: 500, msg: '提现失败', data: null };
    }
  }
}
