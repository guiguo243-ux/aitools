import { Injectable } from '@nestjs/common';
import { getSupabaseClient } from '@/storage/database/supabase-client';

export interface WalletInfo {
  balance: number;
  cashback: number;
  commission: number;
  frozenAmount: number;
}

export type TransactionType = 'cashback' | 'commission' | 'withdraw' | 'refund';
export type TransactionStatus = 'pending' | 'completed' | 'failed';

export interface Transaction {
  id: string;
  user_id: string;
  type: TransactionType;
  amount: number;
  balance: number;
  description: string;
  status: TransactionStatus;
  created_at: string;
}

@Injectable()
export class WalletService {
  /**
   * 获取用户钱包信息
   */
  async getWalletInfo(userId: string): Promise<WalletInfo> {
    const client = getSupabaseClient();

    // 查询用户钱包
    const { data: wallet, error } = await client
      .from('wallets')
      .select('*')
      .eq('user_id', userId)
      .maybeSingle();

    if (error) {
      console.error('Get wallet error:', error);
    }

    if (!wallet) {
      // 创建默认钱包
      return {
        balance: 0,
        cashback: 0,
        commission: 0,
        frozenAmount: 0,
      };
    }

    return {
      balance: wallet.balance || 0,
      cashback: wallet.total_cashback || 0,
      commission: wallet.total_commission || 0,
      frozenAmount: wallet.frozen_amount || 0,
    };
  }

  /**
   * 获取交易记录
   */
  async getTransactions(params: {
    userId: string;
    type?: TransactionType;
    page?: number;
    pageSize?: number;
  }): Promise<{ transactions: Transaction[]; total: number }> {
    const client = getSupabaseClient();
    const { userId, type, page = 1, pageSize = 20 } = params;
    const offset = (page - 1) * pageSize;

    let query = client
      .from('wallet_transactions')
      .select('*', { count: 'exact' })
      .eq('user_id', userId)
      .order('created_at', { ascending: false })
      .range(offset, offset + pageSize - 1);

    if (type) {
      query = query.eq('type', type);
    }

    const { data, count, error } = await query;

    if (error) {
      console.error('Get transactions error:', error);
      return { transactions: [], total: 0 };
    }

    return {
      transactions: data || [],
      total: count || 0,
    };
  }

  /**
   * 提现申请
   */
  async withdraw(params: { userId: string; amount: number }): Promise<{ success: boolean; msg: string }> {
    const client = getSupabaseClient();
    const { userId, amount } = params;

    if (amount <= 0) {
      return { success: false, msg: '提现金额必须大于0' };
    }

    // 查询钱包
    const { data: wallet, error: walletError } = await client
      .from('wallets')
      .select('*')
      .eq('user_id', userId)
      .maybeSingle();

    if (walletError) {
      console.error('Get wallet error:', walletError);
      return { success: false, msg: '查询钱包失败' };
    }

    if (!wallet || wallet.balance < amount) {
      return { success: false, msg: '余额不足' };
    }

    // 开启事务处理（简化版本）
    try {
      // 冻结余额
      const { error: updateError } = await client
        .from('wallets')
        .update({
          balance: wallet.balance - amount,
          frozen_amount: (wallet.frozen_amount || 0) + amount,
          updated_at: new Date().toISOString(),
        })
        .eq('id', wallet.id);

      if (updateError) throw updateError;

      // 创建提现记录
      const { error: transactionError } = await client
        .from('wallet_transactions')
        .insert({
          user_id: userId,
          type: 'withdraw',
          amount: -amount,
          balance: wallet.balance - amount,
          description: '提现到微信零钱',
          status: 'pending',
        });

      if (transactionError) throw transactionError;

      return { success: true, msg: '提现申请已提交，预计1-3个工作日到账' };
    } catch (error) {
      console.error('Withdraw error:', error);
      return { success: false, msg: '提现失败，请稍后重试' };
    }
  }

  /**
   * 添加余额（内部方法）
   */
  async addBalance(params: {
    userId: string;
    type: TransactionType;
    amount: number;
    description: string;
  }): Promise<{ success: boolean }> {
    const client = getSupabaseClient();
    const { userId, type, amount, description } = params;

    // 查询钱包
    let { data: wallet, error: walletError } = await client
      .from('wallets')
      .select('*')
      .eq('user_id', userId)
      .maybeSingle();

    if (walletError) {
      console.error('Get wallet error:', walletError);
    }

    // 如果没有钱包，创建一个
    if (!wallet) {
      const { data: newWallet, error: createError } = await client
        .from('wallets')
        .insert({
          user_id: userId,
          balance: 0,
          frozen_amount: 0,
          total_cashback: 0,
          total_commission: 0,
        })
        .select()
        .maybeSingle();

      if (createError) {
        console.error('Create wallet error:', createError);
        return { success: false };
      }
      wallet = newWallet;
    }

    const newBalance = (wallet.balance || 0) + amount;

    // 更新钱包
    const updateData: Record<string, unknown> = {
      balance: newBalance,
      updated_at: new Date().toISOString(),
    };

    if (type === 'cashback') {
      updateData.total_cashback = (wallet.total_cashback || 0) + amount;
    } else if (type === 'commission') {
      updateData.total_commission = (wallet.total_commission || 0) + amount;
    }

    const { error: updateError } = await client
      .from('wallets')
      .update(updateData)
      .eq('id', wallet.id);

    if (updateError) {
      console.error('Update wallet error:', updateError);
      return { success: false };
    }

    // 创建交易记录
    await client.from('wallet_transactions').insert({
      user_id: userId,
      type,
      amount,
      balance: newBalance,
      description,
      status: 'completed',
    });

    return { success: true };
  }
}
