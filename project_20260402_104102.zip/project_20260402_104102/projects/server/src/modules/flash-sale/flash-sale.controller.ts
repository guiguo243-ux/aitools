import { Controller, Get, Post, Body, Query, Param } from '@nestjs/common';
import { FlashSaleService } from './flash-sale.service';

@Controller('flash-sale')
export class FlashSaleController {
  constructor(private readonly flashSaleService: FlashSaleService) {}

  // ========== 时段配置 ==========

  @Get('time-slots')
  async getTimeSlots() {
    console.log('[FlashSale API] GET /api/flash-sale/time-slots');
    
    const slots = await this.flashSaleService.getTimeSlots();
    return { code: 200, msg: 'success', data: slots };
  }

  // ========== 活动列表 ==========

  @Get('activities')
  async getActivities(
    @Query('status') status?: string,
    @Query('timeSlot') timeSlot?: string,
    @Query('page') page: string = '1',
    @Query('pageSize') pageSize: string = '20'
  ) {
    console.log('[FlashSale API] GET /api/flash-sale/activities');
    
    const result = await this.flashSaleService.getActivities({
      status,
      timeSlot,
      page: parseInt(page),
      pageSize: parseInt(pageSize),
    });
    
    return { code: 200, msg: 'success', data: result };
  }

  @Get('activities/:id')
  async getActivityDetail(@Param('id') id: string) {
    console.log(`[FlashSale API] GET /api/flash-sale/activities/${id}`);
    
    const activity = await this.flashSaleService.getActivityDetail(id);
    return { code: 200, msg: 'success', data: activity };
  }

  // ========== 秒杀下单 ==========

  @Post('order')
  async createOrder(@Body() body: { activityId: string; userId: string; quantity?: number }) {
    console.log('[FlashSale API] POST /api/flash-sale/order', body);
    
    const result = await this.flashSaleService.createOrder(body);
    return { code: result.success ? 200 : 400, msg: result.msg, data: result.data };
  }

  // ========== 用户秒杀记录 ==========

  @Get('my-orders')
  async getMyOrders(
    @Query('userId') userId: string,
    @Query('page') page: string = '1',
    @Query('pageSize') pageSize: string = '20'
  ) {
    console.log(`[FlashSale API] GET /api/flash-sale/my-orders?userId=${userId}`);
    
    const result = await this.flashSaleService.getMyOrders({
      userId,
      page: parseInt(page),
      pageSize: parseInt(pageSize),
    });
    
    return { code: 200, msg: 'success', data: result };
  }

  // ========== 检查购买资格 ==========

  @Get('check-eligibility')
  async checkEligibility(@Query('activityId') activityId: string, @Query('userId') userId: string) {
    console.log(`[FlashSale API] GET /api/flash-sale/check-eligibility`);
    
    const result = await this.flashSaleService.checkEligibility(activityId, userId);
    return { code: 200, msg: 'success', data: result };
  }
}
