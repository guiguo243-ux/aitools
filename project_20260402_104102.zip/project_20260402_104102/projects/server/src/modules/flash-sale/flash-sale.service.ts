import { Injectable } from '@nestjs/common';
import { getSupabaseClient } from '@/storage/database/supabase-client';

@Injectable()
export class FlashSaleService {
  async getTimeSlots() {
    const client = getSupabaseClient();
    
    const { data, error } = await client
      .from('flash_sale_time_slots')
      .select('*')
      .eq('is_active', true)
      .order('sort_order', { ascending: true });

    if (error) {
      console.error('Get time slots error:', error);
      return [];
    }

    // 检查每个时段的状态
    const now = new Date();
    const currentTime = now.toTimeString().slice(0, 8);

    return (data || []).map((slot) => {
      const isActive = currentTime >= slot.start_time && currentTime <= slot.end_time;
      const isPast = currentTime > slot.end_time;
      
      return {
        ...slot,
        isActive,
        isPast,
        status: isActive ? 'ongoing' : isPast ? 'ended' : 'upcoming',
      };
    });
  }

  async getActivities(params: {
    status?: string;
    timeSlot?: string;
    page: number;
    pageSize: number;
  }) {
    const client = getSupabaseClient();
    const offset = (params.page - 1) * params.pageSize;

    let query = client
      .from('flash_sale_activities')
      .select('*', { count: 'exact' })
      .order('sort_order', { ascending: true })
      .order('created_at', { ascending: false });

    // 根据时间判断状态
    const now = new Date();
    
    if (params.status === 'ongoing') {
      query = query.lte('start_time', now.toISOString()).gte('end_time', now.toISOString());
    } else if (params.status === 'upcoming') {
      query = query.gt('start_time', now.toISOString());
    } else if (params.status === 'ended') {
      query = query.lt('end_time', now.toISOString());
    }

    const { data, count, error } = await query.range(offset, offset + params.pageSize - 1);

    if (error) {
      console.error('Get flash sale activities error:', error);
      return { list: [], total: 0 };
    }

    // 添加实时状态
    const list = (data || []).map((activity) => {
      const startTime = new Date(activity.start_time);
      const endTime = new Date(activity.end_time);
      
      let realStatus = activity.status;
      if (now < startTime) {
        realStatus = 'upcoming';
      } else if (now >= startTime && now <= endTime) {
        realStatus = 'ongoing';
      } else {
        realStatus = 'ended';
      }

      return {
        ...activity,
        realStatus,
        discount: activity.original_price > 0 
          ? Math.round((activity.flash_price / activity.original_price) * 10) / 10 
          : 1,
        progress: activity.stock > 0 
          ? Math.round((activity.sold_count / activity.stock) * 100) 
          : 0,
        remainingStock: Math.max(0, activity.stock - activity.sold_count),
        countdown: this.getCountdown(now, startTime, endTime, realStatus),
      };
    });

    return { list, total: count || 0 };
  }

  private getCountdown(now: Date, startTime: Date, endTime: Date, status: string) {
    if (status === 'upcoming') {
      const diff = startTime.getTime() - now.getTime();
      return {
        type: 'start',
        hours: Math.floor(diff / (1000 * 60 * 60)),
        minutes: Math.floor((diff % (1000 * 60 * 60)) / (1000 * 60)),
        seconds: Math.floor((diff % (1000 * 60)) / 1000),
      };
    } else if (status === 'ongoing') {
      const diff = endTime.getTime() - now.getTime();
      return {
        type: 'end',
        hours: Math.floor(diff / (1000 * 60 * 60)),
        minutes: Math.floor((diff % (1000 * 60 * 60)) / (1000 * 60)),
        seconds: Math.floor((diff % (1000 * 60)) / 1000),
      };
    }
    return null;
  }

  async getActivityDetail(id: string) {
    const client = getSupabaseClient();
    
    const { data, error } = await client
      .from('flash_sale_activities')
      .select('*')
      .eq('id', id)
      .single();

    if (error) {
      console.error('Get activity detail error:', error);
      return null;
    }

    const now = new Date();
    const startTime = new Date(data.start_time);
    const endTime = new Date(data.end_time);
    
    let realStatus = data.status;
    if (now < startTime) {
      realStatus = 'upcoming';
    } else if (now >= startTime && now <= endTime) {
      realStatus = 'ongoing';
    } else {
      realStatus = 'ended';
    }

    return {
      ...data,
      realStatus,
      discount: data.original_price > 0 
        ? Math.round((data.flash_price / data.original_price) * 10) / 10 
        : 1,
      progress: data.stock > 0 
        ? Math.round((data.sold_count / data.stock) * 100) 
        : 0,
      remainingStock: Math.max(0, data.stock - data.sold_count),
      countdown: this.getCountdown(now, startTime, endTime, realStatus),
    };
  }

  async createOrder(params: {
    activityId: string;
    userId: string;
    quantity?: number;
  }) {
    const client = getSupabaseClient();

    // 获取活动信息
    const { data: activity } = await client
      .from('flash_sale_activities')
      .select('*')
      .eq('id', params.activityId)
      .single();

    if (!activity) {
      return { success: false, msg: '活动不存在' };
    }

    const now = new Date();
    const startTime = new Date(activity.start_time);
    const endTime = new Date(activity.end_time);

    if (now < startTime) {
      return { success: false, msg: '活动尚未开始' };
    }

    if (now > endTime) {
      return { success: false, msg: '活动已结束' };
    }

    if (activity.sold_count >= activity.stock) {
      return { success: false, msg: '商品已售罄' };
    }

    // 检查用户购买数量
    const { data: userOrders } = await client
      .from('flash_sale_orders')
      .select('quantity')
      .eq('activity_id', params.activityId)
      .eq('user_id', params.userId);

    const purchasedCount = userOrders?.reduce((sum, o) => sum + o.quantity, 0) || 0;
    const requestQuantity = params.quantity || 1;

    if (purchasedCount + requestQuantity > activity.limit_per_user) {
      return { 
        success: false, 
        msg: `每人限购${activity.limit_per_user}件，您已购买${purchasedCount}件` 
      };
    }

    // 创建订单记录
    const { data: order, error } = await client
      .from('flash_sale_orders')
      .insert({
        activity_id: params.activityId,
        user_id: params.userId,
        quantity: requestQuantity,
        price: activity.flash_price,
        status: 'pending',
      })
      .select()
      .single();

    if (error) {
      console.error('Create flash sale order error:', error);
      return { success: false, msg: '下单失败' };
    }

    // 更新销量
    await client
      .from('flash_sale_activities')
      .update({
        sold_count: activity.sold_count + requestQuantity,
      })
      .eq('id', params.activityId);

    return {
      success: true,
      msg: '下单成功',
      data: {
        orderId: order.id,
        quantity: requestQuantity,
        price: activity.flash_price,
        totalPrice: activity.flash_price * requestQuantity,
      },
    };
  }

  async getMyOrders(params: {
    userId: string;
    page: number;
    pageSize: number;
  }) {
    const client = getSupabaseClient();
    const offset = (params.page - 1) * params.pageSize;

    const { data, count, error } = await client
      .from('flash_sale_orders')
      .select('*', { count: 'exact' })
      .eq('user_id', params.userId)
      .order('created_at', { ascending: false })
      .range(offset, offset + params.pageSize - 1);

    if (error) {
      console.error('Get my orders error:', error);
      return { list: [], total: 0 };
    }

    // 获取活动信息
    const activityIds = [...new Set(data?.map((o) => o.activity_id) || [])];
    const { data: activities } = await client
      .from('flash_sale_activities')
      .select('*')
      .in('id', activityIds);

    const activityMap = new Map(activities?.map((a) => [a.id, a]) || []);

    const list = (data || []).map((order) => ({
      ...order,
      activity: activityMap.get(order.activity_id),
    }));

    return { list, total: count || 0 };
  }

  async checkEligibility(activityId: string, userId: string) {
    const client = getSupabaseClient();

    const { data: activity } = await client
      .from('flash_sale_activities')
      .select('*')
      .eq('id', activityId)
      .single();

    if (!activity) {
      return { eligible: false, reason: '活动不存在' };
    }

    const { data: userOrders } = await client
      .from('flash_sale_orders')
      .select('quantity')
      .eq('activity_id', activityId)
      .eq('user_id', userId);

    const purchasedCount = userOrders?.reduce((sum, o) => sum + o.quantity, 0) || 0;
    const remaining = activity.limit_per_user - purchasedCount;

    return {
      eligible: remaining > 0 && activity.sold_count < activity.stock,
      purchasedCount,
      limitPerUser: activity.limit_per_user,
      remaining: Math.max(0, remaining),
      stockRemaining: Math.max(0, activity.stock - activity.sold_count),
    };
  }
}
