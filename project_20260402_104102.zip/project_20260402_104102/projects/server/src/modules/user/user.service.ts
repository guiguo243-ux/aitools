import { Injectable } from '@nestjs/common';
import { getSupabaseClient } from '@/storage/database/supabase-client';

@Injectable()
export class UserService {
  /**
   * 微信登录
   */
  async wechatLogin(code: string) {
    const client = getSupabaseClient();

    // 模拟获取openid（实际应调用微信API）
    const openid = `openid_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;

    // 检查用户是否存在
    const { data: existingUser, error: userError } = await client
      .from('users')
      .select('*')
      .eq('openid', openid)
      .maybeSingle();

    if (userError) {
      console.error('Check user error:', userError);
      throw new Error(`查询用户失败: ${userError.message}`);
    }

    if (existingUser) {
      return {
        isNewUser: false,
        user: existingUser,
      };
    }

    // 创建新用户
    const { data: newUser, error: createError } = await client
      .from('users')
      .insert([
        {
          openid,
          nickname: '新用户',
          region: 'island_inside',
          is_new_user: true,
        },
      ])
      .select()
      .maybeSingle();

    if (createError) {
      console.error('Create user error:', createError);
      throw new Error(`创建用户失败: ${createError.message}`);
    }

    return {
      isNewUser: true,
      user: newUser,
    };
  }

  /**
   * 更新用户区域
   */
  async updateUserRegion(userId: string, region: string, district?: string) {
    const client = getSupabaseClient();

    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    const updateData: any = { region };
    if (district) {
      updateData.district = district;
    }

    const { data, error } = await client
      .from('users')
      .update(updateData)
      .eq('id', userId)
      .select()
      .maybeSingle();

    if (error) {
      console.error('Update user region error:', error);
      throw new Error(`更新用户区域失败: ${error.message}`);
    }

    return data;
  }

  /**
   * 生成推荐码
   */
  async generateReferralCode(userId: string) {
    const client = getSupabaseClient();

    // 检查是否已有推荐码
    const { data: user, error: userError } = await client
      .from('users')
      .select('referral_code')
      .eq('id', userId)
      .maybeSingle();

    if (userError) {
      console.error('Get user error:', userError);
      throw new Error(`获取用户失败: ${userError.message}`);
    }

    if (user?.referral_code) {
      return user.referral_code;
    }

    // 生成推荐码
    const referralCode = `R${userId.substring(0, 8).toUpperCase()}`;

    const { error: updateError } = await client
      .from('users')
      .update({ referral_code: referralCode })
      .eq('id', userId);

    if (updateError) {
      console.error('Update referral code error:', updateError);
      throw new Error(`更新推荐码失败: ${updateError.message}`);
    }

    return referralCode;
  }

  /**
   * 绑定推荐关系
   */
  async bindReferrer(userId: string, referralCode: string) {
    const client = getSupabaseClient();

    // 检查推荐码是否有效
    const { data: referrer, error: referrerError } = await client
      .from('users')
      .select('*')
      .eq('referral_code', referralCode)
      .maybeSingle();

    if (referrerError) {
      console.error('Get referrer error:', referrerError);
      throw new Error(`查询推荐人失败: ${referrerError.message}`);
    }

    if (!referrer) {
      return { success: false, msg: '推荐码无效' };
    }

    // 检查用户是否已有推荐人
    const { data: user, error: userError } = await client
      .from('users')
      .select('referrer_id')
      .eq('id', userId)
      .maybeSingle();

    if (userError) {
      console.error('Get user error:', userError);
      throw new Error(`查询用户失败: ${userError.message}`);
    }

    if (user?.referrer_id) {
      return { success: false, msg: '已有推荐人' };
    }

    // 绑定推荐关系
    const { error: updateError } = await client
      .from('users')
      .update({ referrer_id: referrer.id })
      .eq('id', userId);

    if (updateError) {
      console.error('Bind referrer error:', updateError);
      throw new Error(`绑定推荐人失败: ${updateError.message}`);
    }

    // 发放新人优惠券
    await this.grantNewUserCoupons(userId);

    // 给推荐人发放奖励
    await this.grantReferrerReward(referrer.id, userId);

    return { success: true, msg: '绑定成功' };
  }

  /**
   * 发放新人优惠券
   */
  private async grantNewUserCoupons(userId: string) {
    const client = getSupabaseClient();

    // 查询新人优惠券
    const { data: coupons, error: couponsError } = await client
      .from('coupons')
      .select('*')
      .eq('type', 'new_user')
      .eq('is_active', true)
      .limit(3);

    if (couponsError) {
      console.error('Get coupons error:', couponsError);
      return;
    }

    if (!coupons || coupons.length === 0) {
      return;
    }

    // 发放优惠券
    const userCoupons = coupons.map((coupon) => ({
      user_id: userId,
      coupon_id: coupon.id,
      source: 'register',
      expire_at: new Date(Date.now() + (coupon.valid_days || 30) * 24 * 60 * 60 * 1000).toISOString(),
    }));

    const { error: insertError } = await client.from('user_coupons').insert(userCoupons);

    if (insertError) {
      console.error('Insert user coupons error:', insertError);
    }
  }

  /**
   * 给推荐人发放奖励
   */
  private async grantReferrerReward(referrerId: string, userId: string) {
    const client = getSupabaseClient();

    const { error } = await client.from('referral_rewards').insert([
      {
        user_id: referrerId,
        related_user_id: userId,
        type: 'register',
        amount: 5,
        status: 'pending',
      },
    ]);

    if (error) {
      console.error('Grant referrer reward error:', error);
    }
  }

  /**
   * 获取用户信息
   */
  async getUserInfo(userId: string) {
    const client = getSupabaseClient();

    const { data, error } = await client
      .from('users')
      .select('*')
      .eq('id', userId)
      .maybeSingle();

    if (error) {
      console.error('Get user info error:', error);
      throw new Error(`获取用户信息失败: ${error.message}`);
    }

    return data;
  }

  /**
   * 获取用户优惠券
   */
  async getUserCoupons(userId: string, status?: string) {
    const client = getSupabaseClient();

    let query = client
      .from('user_coupons')
      .select('*, coupons(*)')
      .eq('user_id', userId);

    if (status) {
      query = query.eq('status', status);
    }

    const { data, error } = await query.order('created_at', { ascending: false });

    if (error) {
      console.error('Get user coupons error:', error);
      throw new Error(`获取优惠券失败: ${error.message}`);
    }

    return data || [];
  }

  /**
   * 获取用户推荐列表
   */
  async getUserReferrals(userId: string) {
    const client = getSupabaseClient();

    const { data, error } = await client
      .from('users')
      .select('id, nickname, avatar, created_at')
      .eq('referrer_id', userId)
      .order('created_at', { ascending: false });

    if (error) {
      console.error('Get user referrals error:', error);
      throw new Error(`获取推荐列表失败: ${error.message}`);
    }

    // 统计推荐人数
    const { count, error: countError } = await client
      .from('users')
      .select('*', { count: 'exact', head: true })
      .eq('referrer_id', userId);

    if (countError) {
      console.error('Get referral count error:', countError);
    }

    return {
      referees: data || [],
      total: count || 0,
    };
  }
}
