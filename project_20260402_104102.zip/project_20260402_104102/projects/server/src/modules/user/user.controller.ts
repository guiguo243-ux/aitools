import { Controller, Get, Post, Query, Body } from '@nestjs/common';
import { UserService } from './user.service';

@Controller('user')
export class UserController {
  constructor(private readonly userService: UserService) {}

  /**
   * 微信登录
   */
  @Post('login')
  async login(@Body() body: { code: string }) {
    try {
      const result = await this.userService.wechatLogin(body.code);
      return { code: 200, msg: 'success', data: result };
    } catch (error) {
      console.error('Login error:', error);
      return { code: 500, msg: '登录失败', data: null };
    }
  }

  /**
   * 通过推荐码注册
   */
  @Post('register')
  async register(@Body() body: { openid: string; referralCode: string; region?: string; district?: string }) {
    try {
      const result = await this.userService.bindReferrer(
        body.openid,
        body.referralCode
      );
      return { code: 200, msg: result.msg, data: result };
    } catch (error: any) {
      console.error('Register error:', error);
      return { code: 500, msg: error.message || '注册失败', data: null };
    }
  }

  /**
   * 获取用户信息
   */
  @Get('info')
  async getUserInfo(@Query('userId') userId: string) {
    try {
      if (!userId) {
        return { code: 400, msg: '缺少用户ID', data: null };
      }
      const user = await this.userService.getUserInfo(userId);
      return { code: 200, msg: 'success', data: user };
    } catch (error) {
      console.error('Get user info error:', error);
      return { code: 500, msg: '获取用户信息失败', data: null };
    }
  }

  /**
   * 更新用户区域
   */
  @Post('region')
  async updateRegion(@Body() body: { userId: string; region: string; district?: string }) {
    try {
      const user = await this.userService.updateUserRegion(body.userId, body.region, body.district);
      return { code: 200, msg: 'success', data: user };
    } catch (error) {
      console.error('Update region error:', error);
      return { code: 500, msg: '更新区域失败', data: null };
    }
  }

  /**
   * 获取用户优惠券
   */
  @Get('coupons')
  async getUserCoupons(@Query('userId') userId: string, @Query('status') status: string) {
    try {
      const coupons = await this.userService.getUserCoupons(userId, status);
      return { code: 200, msg: 'success', data: coupons };
    } catch (error) {
      console.error('Get coupons error:', error);
      return { code: 500, msg: '获取优惠券失败', data: null };
    }
  }

  /**
   * 获取推荐统计
   */
  @Get('referral-stats')
  async getReferralStats(@Query('userId') userId: string) {
    try {
      const stats = await this.userService.getUserReferrals(userId);
      return { code: 200, msg: 'success', data: stats };
    } catch (error) {
      console.error('Get referral stats error:', error);
      return { code: 500, msg: '获取推荐统计失败', data: null };
    }
  }
}
