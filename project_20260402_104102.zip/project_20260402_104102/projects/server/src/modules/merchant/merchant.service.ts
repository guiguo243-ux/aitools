import { Injectable } from '@nestjs/common';
import { getSupabaseClient } from '@/storage/database/supabase-client';

@Injectable()
export class MerchantService {
  /**
   * 获取商家列表
   */
  async getMerchantList(params: {
    region?: string;
    categoryId?: number;
    keyword?: string;
    page?: number;
    pageSize?: number;
  }) {
    const client = getSupabaseClient();
    const page = params.page || 1;
    const pageSize = params.pageSize || 10;
    const offset = (page - 1) * pageSize;

    console.log('[MerchantService] getMerchantList params:', params);
    console.log('[MerchantService] Using Supabase client');

    let query = client
      .from('merchants')
      .select('*', { count: 'exact' })
      .eq('status', 'active');

    if (params.region) {
      query = query.eq('region', params.region);
    }

    if (params.categoryId) {
      query = query.eq('category_id', params.categoryId);
    }

    if (params.keyword) {
      query = query.or(`name.ilike.%${params.keyword}%,description.ilike.%${params.keyword}%`);
    }

    const { data, count, error } = await query
      .order('view_count', { ascending: false })
      .range(offset, offset + pageSize - 1);

    console.log('[MerchantService] Query result:', { dataCount: data?.length, count, error });

    if (error) {
      console.error('Get merchant list error:', error);
      throw new Error(`获取商家列表失败: ${error.message}`);
    }

    return {
      merchants: data || [],
      total: count || 0,
      page,
      pageSize,
    };
  }

  /**
   * 获取商家详情
   */
  async getMerchantDetail(merchantId: string) {
    const client = getSupabaseClient();

    // 获取商家信息
    const { data: merchant, error } = await client
      .from('merchants')
      .select('*')
      .eq('id', merchantId)
      .maybeSingle();

    if (error) {
      console.error('Get merchant detail error:', error);
      throw new Error(`获取商家详情失败: ${error.message}`);
    }

    if (!merchant) {
      return null;
    }

    // 增加浏览量
    await client
      .from('merchants')
      .update({ view_count: (merchant.view_count || 0) + 1 })
      .eq('id', merchantId);

    // 获取商家商品
    const { data: products, error: productsError } = await client
      .from('products')
      .select('*')
      .eq('merchant_id', merchantId)
      .eq('is_active', true)
      .order('sales_count', { ascending: false })
      .limit(10);

    if (productsError) {
      console.error('Get merchant products error:', productsError);
    }

    return {
      ...merchant,
      products: products || [],
    };
  }

  /**
   * AI推荐商家
   */
  async getAIRecommendedMerchants(userId: string, region: string, limit: number = 10) {
    const client = getSupabaseClient();

    // 获取用户偏好（基于历史订单）
    const { data: orders } = await client
      .from('orders')
      .select('merchant_id, merchants(category_id)')
      .eq('user_id', userId)
      .order('created_at', { ascending: false })
      .limit(10);

    // 统计用户偏好的分类
    const categoryPreferences: Record<number, number> = {};
    if (orders && orders.length > 0) {
      for (const order of orders) {
        // eslint-disable-next-line @typescript-eslint/no-explicit-any
        const categoryId = (order as any).merchants?.category_id;
        if (categoryId) {
          categoryPreferences[categoryId] = (categoryPreferences[categoryId] || 0) + 1;
        }
      }
    }

    // 推荐商家（优先推荐用户偏好分类）
    const preferredCategoryIds = Object.keys(categoryPreferences)
      .sort((a, b) => categoryPreferences[Number(b)] - categoryPreferences[Number(a)])
      .slice(0, 3)
      .map(Number);

    let query = client
      .from('merchants')
      .select('*')
      .eq('status', 'active')
      .eq('region', region)
      .order('ai_weight', { ascending: false });

    // 如果有偏好分类，优先推荐
    if (preferredCategoryIds.length > 0) {
      query = query.in('category_id', preferredCategoryIds);
    }

    const { data, error } = await query.limit(limit);

    if (error) {
      console.error('Get AI recommended merchants error:', error);
      throw new Error(`获取推荐商家失败: ${error.message}`);
    }

    return data || [];
  }

  /**
   * 获取分类列表
   */
  async getCategories() {
    const client = getSupabaseClient();

    const { data, error } = await client
      .from('categories')
      .select('*')
      .eq('is_active', true)
      .order('sort_order', { ascending: true });

    if (error) {
      console.error('Get categories error:', error);
      throw new Error(`获取分类失败: ${error.message}`);
    }

    return data || [];
  }

  /**
   * 生成推广码
   */
  async generatePromoCode(merchantId: string) {
    const client = getSupabaseClient();

    // 检查商家是否存在
    const { data: merchant, error: merchantError } = await client
      .from('merchants')
      .select('*')
      .eq('id', merchantId)
      .maybeSingle();

    if (merchantError) {
      console.error('Get merchant error:', merchantError);
      throw new Error(`获取商家失败: ${merchantError.message}`);
    }

    if (!merchant) {
      return { success: false, msg: '商家不存在' };
    }

    // 生成推广码
    const promoCode = `M${merchantId.substring(0, 8).toUpperCase()}`;

    // 更新商家推广码
    const { error: updateError } = await client
      .from('merchants')
      .update({ promo_code: promoCode })
      .eq('id', merchantId);

    if (updateError) {
      console.error('Update promo code error:', updateError);
      throw new Error(`更新推广码失败: ${updateError.message}`);
    }

    return {
      success: true,
      promoCode,
    };
  }

  /**
   * 根据推广码获取商家
   */
  async getMerchantByPromoCode(promoCode: string) {
    const client = getSupabaseClient();

    const { data, error } = await client
      .from('merchants')
      .select('*')
      .eq('promo_code', promoCode)
      .maybeSingle();

    if (error) {
      console.error('Get merchant by promo code error:', error);
      throw new Error(`获取商家失败: ${error.message}`);
    }

    return data;
  }
}
