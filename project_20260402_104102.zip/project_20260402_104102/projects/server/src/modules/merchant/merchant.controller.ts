import { Controller, Get, Post, Query, Body, Param } from '@nestjs/common';
import { MerchantService } from './merchant.service';

@Controller('merchant')
export class MerchantController {
  constructor(private readonly merchantService: MerchantService) {}

  /**
   * 获取分类列表
   */
  @Get('categories')
  async getCategories() {
    try {
      const categories = await this.merchantService.getCategories();
      return { code: 200, msg: 'success', data: categories };
    } catch (error) {
      console.error('Get categories error:', error);
      return { code: 500, msg: '获取分类失败', data: null };
    }
  }

  /**
   * 获取商家列表
   */
  @Get('list')
  async getMerchantList(
    @Query('region') region: string,
    @Query('categoryId') categoryId: string,
    @Query('keyword') keyword: string,
    @Query('page') page: string,
    @Query('pageSize') pageSize: string
  ) {
    try {
      const result = await this.merchantService.getMerchantList({
        region,
        categoryId: categoryId ? parseInt(categoryId, 10) : undefined,
        keyword,
        page: page ? parseInt(page, 10) : 1,
        pageSize: pageSize ? parseInt(pageSize, 10) : 10,
      });
      return { code: 200, msg: 'success', data: result };
    } catch (error) {
      console.error('Get merchant list error:', error);
      return { code: 500, msg: '获取商家列表失败', data: null };
    }
  }

  /**
   * 获取商家详情
   */
  @Get('detail/:id')
  async getMerchantDetail(@Param('id') id: string) {
    try {
      const merchant = await this.merchantService.getMerchantDetail(id);
      if (!merchant) {
        return { code: 404, msg: '商家不存在', data: null };
      }
      return { code: 200, msg: 'success', data: merchant };
    } catch (error) {
      console.error('Get merchant detail error:', error);
      return { code: 500, msg: '获取商家详情失败', data: null };
    }
  }

  /**
   * AI推荐商家
   */
  @Get('ai-recommend')
  async getAIRecommendedMerchants(
    @Query('userId') userId: string,
    @Query('region') region: string,
    @Query('limit') limit: string
  ) {
    try {
      const merchants = await this.merchantService.getAIRecommendedMerchants(
        userId,
        region,
        limit ? parseInt(limit, 10) : 5
      );
      return { code: 200, msg: 'success', data: merchants };
    } catch (error) {
      console.error('Get AI recommend error:', error);
      return { code: 500, msg: '获取推荐失败', data: null };
    }
  }

  /**
   * 生成推广码
   */
  @Post('promo-code')
  async generatePromoCode(@Body() body: { merchantId: string }) {
    try {
      const result = await this.merchantService.generatePromoCode(body.merchantId);
      return { code: 200, msg: 'success', data: result };
    } catch (error) {
      console.error('Generate promo code error:', error);
      return { code: 500, msg: '生成推广码失败', data: null };
    }
  }
}
