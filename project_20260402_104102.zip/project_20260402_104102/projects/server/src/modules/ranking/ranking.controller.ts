import { Controller, Get, Post, Query, Body } from '@nestjs/common';
import { RankingService, RankingType, TimeRange } from './ranking.service';

@Controller('ranking')
export class RankingController {
  constructor(private readonly rankingService: RankingService) {}

  /**
   * 获取商家排行榜
   */
  @Get('merchant')
  async getMerchantRanking(
    @Query('region') region: string,
    @Query('category') category: string,
    @Query('timeRange') timeRange: TimeRange,
    @Query('limit') limit: string
  ) {
    try {
      const result = await this.rankingService.getMerchantRanking({
        region,
        category,
        timeRange: timeRange || 'weekly',
        limit: limit ? parseInt(limit) : 20,
      });
      return { code: 200, msg: 'success', data: result };
    } catch (error) {
      console.error('Get merchant ranking error:', error);
      return { code: 500, msg: '获取商家排行榜失败', data: null };
    }
  }

  /**
   * 获取用户推广排行榜
   */
  @Get('user-referral')
  async getUserReferralRanking(
    @Query('timeRange') timeRange: TimeRange,
    @Query('limit') limit: string
  ) {
    try {
      const result = await this.rankingService.getUserReferralRanking({
        timeRange: timeRange || 'weekly',
        limit: limit ? parseInt(limit) : 20,
      });
      return { code: 200, msg: 'success', data: result };
    } catch (error) {
      console.error('Get user referral ranking error:', error);
      return { code: 500, msg: '获取推广排行榜失败', data: null };
    }
  }

  /**
   * 获取用户消费排行榜
   */
  @Get('user-spending')
  async getUserSpendingRanking(
    @Query('region') region: string,
    @Query('timeRange') timeRange: TimeRange,
    @Query('limit') limit: string
  ) {
    try {
      const result = await this.rankingService.getUserSpendingRanking({
        region,
        timeRange: timeRange || 'monthly',
        limit: limit ? parseInt(limit) : 20,
      });
      return { code: 200, msg: 'success', data: result };
    } catch (error) {
      console.error('Get user spending ranking error:', error);
      return { code: 500, msg: '获取消费排行榜失败', data: null };
    }
  }

  /**
   * 获取用户在榜单中的排名
   */
  @Get('user-rank')
  async getUserRank(
    @Query('userId') userId: string,
    @Query('type') type: RankingType,
    @Query('timeRange') timeRange: TimeRange
  ) {
    try {
      const result = await this.rankingService.getUserRank({
        userId,
        type: type || 'user_referral',
        timeRange: timeRange || 'weekly',
      });
      return { code: 200, msg: 'success', data: result };
    } catch (error) {
      console.error('Get user rank error:', error);
      return { code: 500, msg: '获取用户排名失败', data: null };
    }
  }

  /**
   * 发放榜单奖励
   */
  @Post('grant-reward')
  async grantRankingReward(
    @Body() body: { userId: string; type: RankingType; rank: number; timeRange: TimeRange }
  ) {
    try {
      const result = await this.rankingService.grantRankingReward({
        userId: body.userId,
        type: body.type,
        rank: body.rank,
        timeRange: body.timeRange || 'weekly',
      });
      return { code: result.success ? 200 : 400, msg: result.msg, data: result };
    } catch (error) {
      console.error('Grant ranking reward error:', error);
      return { code: 500, msg: '发放奖励失败', data: null };
    }
  }

  /**
   * 获取榜单配置
   */
  @Get('config')
  async getRankingConfig() {
    try {
      const config = this.rankingService.getRankingConfig();
      return { code: 200, msg: 'success', data: config };
    } catch (error) {
      console.error('Get ranking config error:', error);
      return { code: 500, msg: '获取配置失败', data: null };
    }
  }
}
