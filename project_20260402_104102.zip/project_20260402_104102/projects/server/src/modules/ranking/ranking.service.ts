import { Injectable } from '@nestjs/common';
import { getSupabaseClient } from '@/storage/database/supabase-client';

// 榜单类型
export type RankingType = 'merchant' | 'user_referral' | 'user_spending';

// 时间范围
export type TimeRange = 'daily' | 'weekly' | 'monthly';

@Injectable()
export class RankingService {
  /**
   * 获取商家排行榜
   */
  async getMerchantRanking(params: {
    region?: string;
    category?: string;
    timeRange: TimeRange;
    limit?: number;
  }) {
    const { region, category, timeRange, limit = 20 } = params;
    const client = getSupabaseClient();

    // 计算时间范围
    const startDate = this.getStartDate(timeRange);

    // 模拟商家排行数据
    // 实际生产环境需要从订单表聚合统计
    const mockRankings = this.getMockMerchantRankings(region, category, timeRange);

    return {
      rankings: mockRankings.slice(0, limit),
      updateTime: new Date().toISOString(),
      timeRange,
    };
  }

  /**
   * 获取用户推广排行榜
   */
  async getUserReferralRanking(params: {
    timeRange: TimeRange;
    limit?: number;
  }) {
    const { timeRange, limit = 20 } = params;
    const client = getSupabaseClient();

    // 模拟推广排行数据
    const mockRankings = this.getMockUserReferralRankings(timeRange);

    return {
      rankings: mockRankings.slice(0, limit),
      updateTime: new Date().toISOString(),
      timeRange,
    };
  }

  /**
   * 获取用户消费排行榜
   */
  async getUserSpendingRanking(params: {
    region?: string;
    timeRange: TimeRange;
    limit?: number;
  }) {
    const { region, timeRange, limit = 20 } = params;

    // 模拟消费排行数据
    const mockRankings = this.getMockUserSpendingRankings(region, timeRange);

    return {
      rankings: mockRankings.slice(0, limit),
      updateTime: new Date().toISOString(),
      timeRange,
    };
  }

  /**
   * 获取用户在榜单中的排名
   */
  async getUserRank(params: {
    userId: string;
    type: RankingType;
    timeRange: TimeRange;
  }) {
    const { userId, type, timeRange } = params;

    // 模拟用户排名
    const mockRank = Math.floor(Math.random() * 100) + 1;
    const mockValue = type === 'user_referral' 
      ? Math.floor(Math.random() * 10) + 1 
      : Math.floor(Math.random() * 1000) + 100;

    return {
      rank: mockRank,
      value: mockValue,
      type,
      timeRange,
      reward: this.calculateRankReward(mockRank, type),
    };
  }

  /**
   * 发放榜单奖励
   */
  async grantRankingReward(params: {
    userId: string;
    type: RankingType;
    rank: number;
    timeRange: TimeRange;
  }) {
    const { userId, type, rank, timeRange } = params;
    const client = getSupabaseClient();

    const reward = this.calculateRankReward(rank, type);

    if (reward <= 0) {
      return { success: false, msg: '不在奖励范围内' };
    }

    // 检查是否已发放
    const { data: existing, error: existingError } = await client
      .from('user_red_packets')
      .select('*')
      .eq('user_id', userId)
      .eq('source', `ranking_${type}_${timeRange}`)
      .maybeSingle();

    if (existingError) {
      console.error('Check existing reward error:', existingError);
    }

    if (existing) {
      return { success: false, msg: '奖励已发放' };
    }

    // 发放奖励
    const expireAt = new Date();
    expireAt.setDate(expireAt.getDate() + 7);

    const { error: insertError } = await client
      .from('user_red_packets')
      .insert({
        user_id: userId,
        type: 'red_packet',
        amount: reward,
        min_spend: 0,
        source: `ranking_${type}_${timeRange}`,
        status: 'unused',
        expire_at: expireAt.toISOString(),
      });

    if (insertError) {
      console.error('Insert ranking reward error:', insertError);
      throw new Error(`发放奖励失败: ${insertError.message}`);
    }

    // 更新榜单记录
    await client
      .from('region_rankings')
      .update({ reward_granted: true })
      .eq('user_id', userId)
      .eq('ranking_type', type);

    return {
      success: true,
      msg: '奖励发放成功',
      data: { reward },
    };
  }

  /**
   * 计算榜单奖励金额
   */
  private calculateRankReward(rank: number, type: RankingType): number {
    // TOP 1-3 额外奖励
    if (rank === 1) return type === 'user_referral' ? 50 : 30;
    if (rank === 2) return type === 'user_referral' ? 30 : 20;
    if (rank === 3) return type === 'user_referral' ? 20 : 10;
    
    // TOP 4-10
    if (rank <= 10) return type === 'user_referral' ? 10 : 5;
    
    return 0;
  }

  /**
   * 获取榜单配置
   */
  getRankingConfig() {
    return {
      merchant: {
        title: '商家人气榜',
        rewards: [
          { rank: 1, reward: '30元推广金' },
          { rank: 2, reward: '20元推广金' },
          { rank: 3, reward: '10元推广金' },
          { rank: '4-10', reward: '5元推广金' },
        ],
      },
      user_referral: {
        title: '推广达人榜',
        rewards: [
          { rank: 1, reward: '50元红包' },
          { rank: 2, reward: '30元红包' },
          { rank: 3, reward: '20元红包' },
          { rank: '4-10', reward: '10元红包' },
        ],
      },
      user_spending: {
        title: '消费达人榜',
        rewards: [
          { rank: 1, reward: '30元返现' },
          { rank: 2, reward: '20元返现' },
          { rank: 3, reward: '10元返现' },
          { rank: '4-10', reward: '5元返现' },
        ],
      },
    };
  }

  /**
   * 获取时间范围起始日期
   */
  private getStartDate(timeRange: TimeRange): Date {
    const now = new Date();
    switch (timeRange) {
      case 'daily':
        return new Date(now.setHours(0, 0, 0, 0));
      case 'weekly':
        const dayOfWeek = now.getDay();
        const diff = now.getDate() - dayOfWeek + (dayOfWeek === 0 ? -6 : 1);
        return new Date(now.setDate(diff));
      case 'monthly':
        return new Date(now.getFullYear(), now.getMonth(), 1);
    }
  }

  /**
   * 模拟商家排行数据
   */
  private getMockMerchantRankings(region?: string, category?: string, timeRange?: TimeRange) {
    const merchants = [
      { id: 'm1', name: '老厦门沙茶面', category: '美食', region: 'island_inside', district: '思明区', orders: 1234, rating: 4.9, gmv: 45600 },
      { id: 'm2', name: '鼓浪屿海鲜大排档', category: '美食', region: 'island_inside', district: '思明区', orders: 987, rating: 4.8, gmv: 38900 },
      { id: 'm3', name: '曾厝垵小吃街', category: '美食', region: 'island_inside', district: '思明区', orders: 876, rating: 4.7, gmv: 32100 },
      { id: 'm4', name: '集美学村奶茶店', category: '美食', region: 'island_outside', district: '集美区', orders: 765, rating: 4.8, gmv: 28700 },
      { id: 'm5', name: '海沧湾民宿', category: '民宿', region: 'island_outside', district: '海沧区', orders: 654, rating: 4.9, gmv: 98100 },
      { id: 'm6', name: '同安农家乐', category: '美食', region: 'island_outside', district: '同安区', orders: 543, rating: 4.6, gmv: 21500 },
      { id: 'm7', name: '湖里家政服务', category: '家政', region: 'island_inside', district: '湖里区', orders: 432, rating: 4.7, gmv: 12800 },
      { id: 'm8', name: '翔安果园采摘', category: '娱乐', region: 'island_outside', district: '翔安区', orders: 321, rating: 4.8, gmv: 9600 },
    ];

    // 过滤区域
    let filtered = merchants;
    if (region) {
      filtered = filtered.filter(m => m.region === region);
    }
    if (category) {
      filtered = filtered.filter(m => m.category === category);
    }

    // 按订单量排序
    return filtered.sort((a, b) => b.orders - a.orders).map((m, index) => ({
      rank: index + 1,
      ...m,
      trend: Math.random() > 0.5 ? 'up' : Math.random() > 0.5 ? 'down' : 'same',
    }));
  }

  /**
   * 模拟用户推广排行数据
   */
  private getMockUserReferralRankings(timeRange?: TimeRange) {
    const users = [
      { id: 'u1', nickname: '小明同学', avatar: '', referralCount: 28, referralAmount: 168 },
      { id: 'u2', nickname: '厦门吃货', avatar: '', referralCount: 24, referralAmount: 144 },
      { id: 'u3', nickname: '旅游达人', avatar: '', referralCount: 21, referralAmount: 126 },
      { id: 'u4', nickname: '生活家', avatar: '', referralCount: 18, referralAmount: 108 },
      { id: 'u5', nickname: '本地通', avatar: '', referralCount: 15, referralAmount: 90 },
      { id: 'u6', nickname: '美食家', avatar: '', referralCount: 12, referralAmount: 72 },
      { id: 'u7', nickname: '探索者', avatar: '', referralCount: 10, referralAmount: 60 },
      { id: 'u8', nickname: '新用户', avatar: '', referralCount: 8, referralAmount: 48 },
    ];

    return users.sort((a, b) => b.referralCount - a.referralCount).map((u, index) => ({
      rank: index + 1,
      ...u,
      trend: Math.random() > 0.5 ? 'up' : Math.random() > 0.5 ? 'down' : 'same',
    }));
  }

  /**
   * 模拟用户消费排行数据
   */
  private getMockUserSpendingRankings(region?: string, timeRange?: TimeRange) {
    const users = [
      { id: 'u1', nickname: '消费达人', avatar: '', region: 'island_inside', spending: 3280, orders: 15 },
      { id: 'u2', nickname: '生活家', avatar: '', region: 'island_inside', spending: 2560, orders: 12 },
      { id: 'u3', nickname: '美食控', avatar: '', region: 'island_outside', spending: 1890, orders: 9 },
      { id: 'u4', nickname: '宅男', avatar: '', region: 'island_inside', spending: 1540, orders: 8 },
      { id: 'u5', nickname: '购物狂', avatar: '', region: 'island_outside', spending: 1230, orders: 7 },
      { id: 'u6', nickname: '品质生活', avatar: '', region: 'island_inside', spending: 980, orders: 5 },
      { id: 'u7', nickname: '周末达人', avatar: '', region: 'island_outside', spending: 760, orders: 4 },
      { id: 'u8', nickname: '新用户', avatar: '', region: 'island_inside', spending: 540, orders: 3 },
    ];

    let filtered = users;
    if (region) {
      filtered = filtered.filter(u => u.region === region);
    }

    return filtered.sort((a, b) => b.spending - a.spending).map((u, index) => ({
      rank: index + 1,
      ...u,
      trend: Math.random() > 0.5 ? 'up' : Math.random() > 0.5 ? 'down' : 'same',
    }));
  }
}
