import { Controller, Get, Post, Query, Body } from '@nestjs/common';
import { PosterService, PosterType } from './poster.service';

@Controller('poster')
export class PosterController {
  constructor(private readonly posterService: PosterService) {}

  /**
   * 生成小程序码
   */
  @Get('qrcode')
  async generateQRCode(
    @Query('scene') scene: string,
    @Query('page') page: string,
    @Query('width') width: string
  ) {
    try {
      const result = await this.posterService.generateMiniProgramCode({
        scene: scene || 'default',
        page: page || 'pages/index/index',
        width: width ? parseInt(width) : 430,
      });
      return { code: 200, msg: 'success', data: result };
    } catch (error) {
      console.error('Generate QR code error:', error);
      return { code: 500, msg: '生成小程序码失败', data: null };
    }
  }

  /**
   * 生成分享海报
   */
  @Post('generate')
  async generatePoster(
    @Body() body: { userId: string; type: PosterType; region?: string; merchantId?: string; activityId?: string }
  ) {
    try {
      const result = await this.posterService.generatePoster({
        userId: body.userId,
        type: body.type,
        region: body.region,
        merchantId: body.merchantId,
        activityId: body.activityId,
      });
      return { code: 200, msg: 'success', data: result };
    } catch (error) {
      console.error('Generate poster error:', error);
      return { code: 500, msg: '生成海报失败', data: null };
    }
  }

  /**
   * 获取分享配置（用于微信小程序分享）
   */
  @Get('share-config')
  async getShareConfig(
    @Query('userId') userId: string,
    @Query('type') type: PosterType,
    @Query('region') region: string,
    @Query('merchantId') merchantId: string
  ) {
    try {
      const result = await this.posterService.getShareConfig({
        userId,
        type,
        region,
        merchantId,
      });
      return { code: 200, msg: 'success', data: result };
    } catch (error) {
      console.error('Get share config error:', error);
      return { code: 500, msg: '获取分享配置失败', data: null };
    }
  }

  /**
   * 解析场景值
   */
  @Get('decode-scene')
  async decodeScene(@Query('scene') scene: string) {
    try {
      const result = this.posterService.decodeScene(scene);
      return { code: 200, msg: 'success', data: result };
    } catch (error) {
      console.error('Decode scene error:', error);
      return { code: 500, msg: '解析场景值失败', data: null };
    }
  }

  /**
   * 记录扫码行为
   */
  @Post('record-scan')
  async recordScan(@Body() body: { scene: string; newUserId: string }) {
    try {
      const result = await this.posterService.recordScan(body.scene, body.newUserId);
      return { code: 200, msg: 'success', data: result };
    } catch (error) {
      console.error('Record scan error:', error);
      return { code: 500, msg: '记录扫码失败', data: null };
    }
  }

  /**
   * 获取海报模板列表
   */
  @Get('templates')
  async getTemplates() {
    try {
      const templates = this.posterService.getTemplates();
      return { code: 200, msg: 'success', data: templates };
    } catch (error) {
      console.error('Get templates error:', error);
      return { code: 500, msg: '获取模板失败', data: null };
    }
  }

  /**
   * 生成AI逼单文案
   */
  @Post('urgency-copy')
  async generateUrgencyCopy(
    @Body()
    body: {
      merchantName: string;
      category: string;
      region: string;
      currentPrice?: number;
      originalPrice?: number;
      stock?: number;
      soldCount?: number;
      friendBought?: boolean;
    }
  ) {
    try {
      const copyList = await this.posterService.generateUrgencyCopy(body);
      return { code: 200, msg: 'success', data: { copyList } };
    } catch (error) {
      console.error('Generate urgency copy error:', error);
      return { code: 500, msg: '生成逼单文案失败', data: null };
    }
  }
}
