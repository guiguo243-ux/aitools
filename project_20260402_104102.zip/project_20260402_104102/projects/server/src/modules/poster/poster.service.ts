import { Injectable } from '@nestjs/common';
import { getSupabaseClient } from '@/storage/database/supabase-client';

// 海报模板类型
export type PosterType = 'new_user_invite' | 'group_buy' | 'merchant_promo' | 'region_ranking';

// 海报模板配置
export interface PosterTemplate {
  id: string;
  name: string;
  type: PosterType;
  backgroundUrl: string;
  title: string;
  subtitle: string;
  qrCodePosition: { x: number; y: number };
  qrCodeSize: number;
  avatarPosition?: { x: number; y: number };
  avatarSize?: number;
}

@Injectable()
export class PosterService {
  // 海报模板配置
  private posterTemplates: PosterTemplate[] = [
    {
      id: 'invite_001',
      name: '新人邀请海报',
      type: 'new_user_invite',
      backgroundUrl: 'https://placehold.co/750x1334/FF6B35/white?text=厦门AI生活',
      title: '新人专享福利',
      subtitle: '扫码领取专属红包',
      qrCodePosition: { x: 275, y: 800 },
      qrCodeSize: 200,
    },
    {
      id: 'group_001',
      name: '组队拼单海报',
      type: 'group_buy',
      backgroundUrl: 'https://placehold.co/750x1334/4A90D9/white?text=组队拼单',
      title: '邀请好友一起拼单',
      subtitle: '拼团成功各得7元券',
      qrCodePosition: { x: 275, y: 800 },
      qrCodeSize: 200,
    },
    {
      id: 'merchant_001',
      name: '商家推广海报',
      type: 'merchant_promo',
      backgroundUrl: 'https://placehold.co/750x1334/2ECC71/white?text=好店推荐',
      title: '发现好店',
      subtitle: 'AI智能推荐',
      qrCodePosition: { x: 275, y: 800 },
      qrCodeSize: 200,
    },
    {
      id: 'ranking_001',
      name: '区域榜单海报',
      type: 'region_ranking',
      backgroundUrl: 'https://placehold.co/750x1334/F39C12/white?text=区域榜单',
      title: '本周热门榜单',
      subtitle: '岛内岛外人气TOP',
      qrCodePosition: { x: 275, y: 800 },
      qrCodeSize: 200,
    },
  ];

  /**
   * 生成小程序码
   * 注意：实际生产环境需要调用微信API，这里返回模拟数据
   */
  async generateMiniProgramCode(params: {
    scene: string;
    page?: string;
    width?: number;
  }): Promise<{ codeUrl: string }> {
    const { scene, page = 'pages/index/index', width = 430 } = params;

    // 模拟小程序码URL（实际需要调用微信API）
    // 微信API: POST https://api.weixin.qq.com/wxa/getwxacodeunlimit
    // 需要access_token和scene参数
    
    const codeUrl = `https://placehold.co/${width}x${width}/000000/white?text=${encodeURIComponent(scene)}`;

    // 保存分享记录
    await this.saveShareRecord(scene);

    return { codeUrl };
  }

  /**
   * 生成分享海报
   */
  async generatePoster(params: {
    userId: string;
    type: PosterType;
    region?: string;
    merchantId?: string;
    activityId?: string;
  }): Promise<{ posterUrl: string; shareUrl: string; scene: string }> {
    const { userId, type, region, merchantId, activityId } = params;

    // 查找对应模板
    const template = this.posterTemplates.find((t) => t.type === type);
    if (!template) {
      throw new Error('海报模板不存在');
    }

    // 生成场景值（携带推荐人ID+区域ID）
    const sceneData: Record<string, string> = {
      r: userId, // 推荐人ID
    };
    if (region) sceneData['rg'] = region;
    if (merchantId) sceneData['m'] = merchantId;
    if (activityId) sceneData['a'] = activityId;

    const scene = this.encodeScene(sceneData);

    // 生成小程序码
    const { codeUrl } = await this.generateMiniProgramCode({
      scene,
      page: this.getPageByType(type),
      width: template.qrCodeSize,
    });

    // 组装海报URL（实际需要合成图片，这里返回模板+小程序码）
    const posterUrl = `${template.backgroundUrl}&qrcode=${encodeURIComponent(codeUrl)}`;

    // 生成分享链接
    const shareUrl = `pages/index/index?scene=${scene}`;

    // 保存分享记录
    await this.saveShareRecord(scene, userId, type);

    return { posterUrl, shareUrl, scene };
  }

  /**
   * 获取分享配置（用于微信分享）
   */
  async getShareConfig(params: {
    userId: string;
    type: PosterType;
    region?: string;
    merchantId?: string;
  }) {
    const { userId, type, region, merchantId } = params;

    // 获取用户信息
    const client = getSupabaseClient();
    const { data: user, error } = await client
      .from('users')
      .select('nickname, avatar_url, referral_code')
      .eq('id', userId)
      .maybeSingle();

    if (error) {
      console.error('Get user error:', error);
    }

    // 获取分享文案
    const copywriting = await this.getCopywriting(type, region);

    // 生成小程序码
    const sceneData: Record<string, string> = { r: userId };
    if (region) sceneData['rg'] = region;
    if (merchantId) sceneData['m'] = merchantId;

    const scene = this.encodeScene(sceneData);
    const { codeUrl } = await this.generateMiniProgramCode({
      scene,
      page: this.getPageByType(type),
    });

    return {
      title: copywriting.title,
      path: `pages/index/index?scene=${scene}`,
      imageUrl: codeUrl,
      scene,
      user: {
        nickname: user?.nickname || '好友',
        avatarUrl: user?.avatar_url,
        referralCode: user?.referral_code,
      },
      copywriting,
    };
  }

  /**
   * 解析场景值
   */
  decodeScene(scene: string): Record<string, string> {
    try {
      const decoded = decodeURIComponent(scene);
      const result: Record<string, string> = {};
      
      decoded.split('&').forEach((pair) => {
        const [key, value] = pair.split('=');
        if (key && value) {
          result[key] = value;
        }
      });
      
      return result;
    } catch {
      return {};
    }
  }

  /**
   * 编码场景值
   */
  private encodeScene(data: Record<string, string>): string {
    return Object.entries(data)
      .map(([key, value]) => `${key}=${value}`)
      .join('&');
  }

  /**
   * 根据类型获取跳转页面
   */
  private getPageByType(type: PosterType): string {
    const pageMap: Record<PosterType, string> = {
      new_user_invite: 'pages/index/index',
      group_buy: 'pages/index/index',
      merchant_promo: 'pages/merchant/detail',
      region_ranking: 'pages/index/index',
    };
    return pageMap[type];
  }

  /**
   * 获取分享文案
   */
  private async getCopywriting(type: PosterType, region?: string): Promise<{
    title: string;
    desc: string;
    shortTitle: string;
  }> {
    const copywritingMap: Record<PosterType, Record<string, { title: string; desc: string; shortTitle: string }>> = {
      new_user_invite: {
        default: {
          title: '我在厦门AI生活平台领到了新人红包，你也来试试！',
          desc: '扫码注册即得5元无门槛红包，AI帮你选店、比价、省钱',
          shortTitle: '新人专享红包',
        },
        island_inside: {
          title: '岛内专属！新人领5元红包，AI帮你挑好店',
          desc: '思明、湖里本地商家全覆盖，扫码即用',
          shortTitle: '岛内新人福利',
        },
        island_outside: {
          title: '岛外街坊福利！新人领5元红包，便民服务一键搞定',
          desc: '集美、海沧、同安、翔安就近服务',
          shortTitle: '岛外新人福利',
        },
      },
      group_buy: {
        default: {
          title: '组队拼单啦！邀请好友一起，各得7元券',
          desc: '2-3人即可成团，吃喝玩乐更划算',
          shortTitle: '组队拼单',
        },
      },
      merchant_promo: {
        default: {
          title: '这家店超棒！AI推荐，扫码即享优惠',
          desc: '厦门本地优质商家，口碑好、价格实惠',
          shortTitle: '好店推荐',
        },
      },
      region_ranking: {
        default: {
          title: '本周热门榜单出炉！看看你附近的TOP商家',
          desc: '岛内岛外人气榜单，帮你避坑选好店',
          shortTitle: '区域榜单',
        },
      },
    };

    const typeCopy = copywritingMap[type] || copywritingMap.new_user_invite;
    return typeCopy[region || 'default'] || typeCopy.default;
  }

  /**
   * 保存分享记录
   */
  private async saveShareRecord(
    scene: string,
    userId?: string,
    type?: string
  ): Promise<void> {
    try {
      const client = getSupabaseClient();
      
      await client.from('share_records').insert({
        user_id: userId || null,
        scene,
        share_type: type || 'unknown',
        status: 'pending',
      });
    } catch (error) {
      console.error('Save share record error:', error);
    }
  }

  /**
   * 记录扫码行为
   */
  async recordScan(scene: string, newUserId: string): Promise<{
    referrerId: string | null;
    region: string | null;
    merchantId: string | null;
  }> {
    const sceneData = this.decodeScene(scene);
    
    const client = getSupabaseClient();

    // 更新分享记录
    await client
      .from('share_records')
      .update({
        status: 'scanned',
        scan_user_id: newUserId,
        scanned_at: new Date().toISOString(),
      })
      .eq('scene', scene);

    return {
      referrerId: sceneData['r'] || null,
      region: sceneData['rg'] || null,
      merchantId: sceneData['m'] || null,
    };
  }

  /**
   * 获取海报模板列表
   */
  getTemplates(): PosterTemplate[] {
    return this.posterTemplates;
  }

  /**
   * 生成AI逼单文案
   */
  async generateUrgencyCopy(params: {
    merchantName: string;
    category: string;
    region: string;
    currentPrice?: number;
    originalPrice?: number;
    stock?: number;
    soldCount?: number;
    friendBought?: boolean;
  }): Promise<string[]> {
    const { merchantName, category, region, currentPrice, originalPrice, stock, soldCount, friendBought } = params;

    const copyList: string[] = [];

    // 库存紧迫感
    if (stock && stock <= 5) {
      copyList.push(`⚠️ 仅剩${stock}份！${merchantName}的${category}服务超火爆，手慢无！`);
    }

    // 销量认可
    if (soldCount && soldCount >= 100) {
      copyList.push(`🔥 已有${soldCount}人下单！${region === 'island_inside' ? '岛内' : '岛外'}人气商家，品质有保障！`);
    }

    // 价格优势
    if (currentPrice && originalPrice && originalPrice > currentPrice) {
      const discount = Math.round((1 - currentPrice / originalPrice) * 100);
      copyList.push(`💰 今日特惠立省${originalPrice - currentPrice}元！${discount}%OFF限时抢！`);
    }

    // 社交认同
    if (friendBought) {
      copyList.push(`👥 你的好友也在这家下过单，口碑好评率98%！`);
    }

    // 区域对比
    if (region === 'island_inside') {
      copyList.push(`📍 思明/湖里用户首选，就近上门，最快30分钟响应！`);
    } else {
      copyList.push(`📍 集美/海沧/同安/翔安全覆盖，不用跑远路，服务到家！`);
    }

    // 限时优惠
    copyList.push(`⏰ 优惠券有效期仅剩2小时，错过再等一周！`);

    return copyList.length > 0 ? copyList : [
      `🔥 ${merchantName} - ${region === 'island_inside' ? '岛内' : '岛外'}优质商家，AI精选推荐！`,
      `💰 下单即享优惠，新人还有额外红包！`,
    ];
  }
}
