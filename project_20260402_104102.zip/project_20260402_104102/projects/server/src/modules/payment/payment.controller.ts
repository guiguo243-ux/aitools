import { Controller, Post, Get, Body, Query, Param } from '@nestjs/common';
import { PaymentService } from './payment.service';

@Controller('payment')
export class PaymentController {
  constructor(private readonly paymentService: PaymentService) {}

  /**
   * 创建支付订单
   */
  @Post('create')
  async createPayment(
    @Body() body: { orderId: string; userId: string; amount: number; orderNo: string; body: string }
  ) {
    try {
      console.log('[API] POST /api/payment/create', JSON.stringify(body));

      if (!body.orderId || !body.userId || !body.amount || !body.orderNo) {
        return { code: 400, msg: '参数不完整', data: null };
      }

      const result = await this.paymentService.createPayment({
        orderId: body.orderId,
        userId: body.userId,
        amount: body.amount,
        orderNo: body.orderNo,
        body: body.body || '订单支付'
      });

      console.log('[API] createPayment result:', JSON.stringify(result));

      if (result.success) {
        return { code: 200, msg: '创建支付成功', data: result };
      } else {
        return { code: 400, msg: result.msg || '创建支付失败', data: null };
      }
    } catch (error) {
      console.error('Create payment error:', error);
      return { code: 500, msg: '创建支付失败', data: null };
    }
  }

  /**
   * 支付成功回调（微信支付回调）
   */
  @Post('notify/success')
  async paymentSuccess(
    @Body() body: { paymentId: string; orderId: string; transactionId: string }
  ) {
    try {
      console.log('[API] POST /api/payment/notify/success', JSON.stringify(body));

      const result = await this.paymentService.handlePaymentSuccess(body);
      return { code: result.success ? 200 : 400, msg: result.msg, data: null };
    } catch (error) {
      console.error('Payment success callback error:', error);
      return { code: 500, msg: '处理支付回调失败', data: null };
    }
  }

  /**
   * 支付失败回调
   */
  @Post('notify/fail')
  async paymentFail(
    @Body() body: { paymentId: string; orderId: string; errMsg: string }
  ) {
    try {
      console.log('[API] POST /api/payment/notify/fail', JSON.stringify(body));

      const result = await this.paymentService.handlePaymentFail(body);
      return { code: result.success ? 200 : 400, msg: result.msg, data: null };
    } catch (error) {
      console.error('Payment fail callback error:', error);
      return { code: 500, msg: '处理支付回调失败', data: null };
    }
  }

  /**
   * 模拟支付成功（开发环境使用）
   */
  @Post('mock-success')
  async mockPaymentSuccess(@Body() body: { orderId: string }) {
    try {
      console.log('[API] POST /api/payment/mock-success', JSON.stringify(body));

      if (!body.orderId) {
        return { code: 400, msg: '缺少订单ID', data: null };
      }

      const result = await this.paymentService.mockPaymentSuccess(body.orderId);
      return { code: result.success ? 200 : 400, msg: result.msg, data: null };
    } catch (error) {
      console.error('Mock payment success error:', error);
      return { code: 500, msg: '模拟支付失败', data: null };
    }
  }

  /**
   * 查询支付状态
   */
  @Get('status/:orderId')
  async getPaymentStatus(@Param('orderId') orderId: string) {
    try {
      console.log(`[API] GET /api/payment/status/${orderId}`);

      const result = await this.paymentService.queryPaymentStatus(orderId);
      return { code: 200, msg: 'success', data: result };
    } catch (error) {
      console.error('Query payment status error:', error);
      return { code: 500, msg: '查询支付状态失败', data: null };
    }
  }

  /**
   * 申请退款
   */
  @Post('refund')
  async requestRefund(
    @Body() body: { orderId: string; userId: string; reason: string }
  ) {
    try {
      console.log('[API] POST /api/payment/refund', JSON.stringify(body));

      if (!body.orderId || !body.userId || !body.reason) {
        return { code: 400, msg: '参数不完整', data: null };
      }

      const result = await this.paymentService.requestRefund(body);
      return { 
        code: result.success ? 200 : 400, 
        msg: result.msg, 
        data: result.refundNo ? { refundNo: result.refundNo } : null 
      };
    } catch (error) {
      console.error('Request refund error:', error);
      return { code: 500, msg: '申请退款失败', data: null };
    }
  }
}
