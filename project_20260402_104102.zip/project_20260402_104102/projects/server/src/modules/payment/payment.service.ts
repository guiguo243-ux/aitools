import { Injectable } from '@nestjs/common';
import { getSupabaseClient } from '@/storage/database/supabase-client';

// 支付参数
interface PaymentParams {
  orderId: string;
  userId: string;
  amount: number;
  orderNo: string;
  body: string;
}

// 支付结果
export interface PaymentResult {
  success: boolean;
  msg?: string;
  paymentParams?: {
    timeStamp: string;
    nonceStr: string;
    package: string;
    signType: string;
    paySign: string;
  };
  // 模拟支付场景返回的支付ID
  paymentId?: string;
}

@Injectable()
export class PaymentService {
  /**
   * 创建支付订单
   * 在真实环境中，这里会调用微信支付统一下单接口
   * 在开发环境中，返回模拟数据
   */
  async createPayment(params: PaymentParams): Promise<PaymentResult> {
    const { orderId, userId, amount, orderNo, body } = params;
    const client = getSupabaseClient();

    // 检查订单是否存在
    const { data: order, error: orderError } = await client
      .from('orders')
      .select('*')
      .eq('id', orderId)
      .eq('user_id', userId)
      .eq('status', 'pending')
      .maybeSingle();

    if (orderError || !order) {
      return { success: false, msg: '订单不存在或已支付' };
    }

    // 检查金额是否一致
    if (Math.abs(order.payable_amount - amount) > 0.01) {
      return { success: false, msg: '订单金额不一致' };
    }

    // 在真实环境中，这里会调用微信支付API
    // 这里返回模拟数据，用于开发测试
    const mockPaymentId = `PAY${Date.now()}${Math.random().toString(36).substr(2, 8).toUpperCase()}`;
    const nonceStr = Math.random().toString(36).substr(2, 32);
    const timeStamp = Math.floor(Date.now() / 1000).toString();

    // 记录支付日志
    try {
      await client.from('payment_logs').insert({
        payment_id: mockPaymentId,
        order_id: orderId,
        order_no: orderNo,
        user_id: userId,
        amount,
        status: 'pending',
        body,
        created_at: new Date().toISOString()
      });
    } catch (err) {
      console.error('Insert payment log error:', err);
    }

    // 返回模拟的支付参数
    // 在真实环境中，这些参数需要通过微信支付API获取
    return {
      success: true,
      paymentId: mockPaymentId,
      paymentParams: {
        timeStamp,
        nonceStr,
        package: `prepay_id=wx${Date.now()}`,
        signType: 'MD5',
        paySign: `mock_sign_${nonceStr}_${timeStamp}`
      }
    };
  }

  /**
   * 处理支付成功回调
   */
  async handlePaymentSuccess(data: {
    paymentId: string;
    orderId: string;
    transactionId: string;
  }): Promise<{ success: boolean; msg: string }> {
    const { paymentId, orderId, transactionId } = data;
    const client = getSupabaseClient();

    // 查询支付记录
    const { data: paymentLog, error: logError } = await client
      .from('payment_logs')
      .select('*')
      .eq('payment_id', paymentId)
      .maybeSingle();

    if (logError || !paymentLog) {
      return { success: false, msg: '支付记录不存在' };
    }

    if (paymentLog.status === 'success') {
      return { success: true, msg: '订单已处理' };
    }

    // 更新支付记录状态
    await client
      .from('payment_logs')
      .update({
        status: 'success',
        transaction_id: transactionId,
        paid_at: new Date().toISOString()
      })
      .eq('payment_id', paymentId);

    // 更新订单状态
    const { error: updateError } = await client
      .from('orders')
      .update({
        status: 'paid',
        paid_at: new Date().toISOString(),
        transaction_id: transactionId
      })
      .eq('id', orderId);

    if (updateError) {
      console.error('Update order status error:', updateError);
      return { success: false, msg: '更新订单状态失败' };
    }

    // 发放推荐人佣金
    await this.grantReferrerCommission(orderId);

    // 发送支付成功通知
    await this.sendPaymentSuccessNotification(orderId);

    return { success: true, msg: '支付成功' };
  }

  /**
   * 处理支付失败回调
   */
  async handlePaymentFail(data: {
    paymentId: string;
    orderId: string;
    errMsg: string;
  }): Promise<{ success: boolean; msg: string }> {
    const { paymentId, orderId, errMsg } = data;
    const client = getSupabaseClient();

    // 更新支付记录状态
    await client
      .from('payment_logs')
      .update({
        status: 'failed',
        error_msg: errMsg,
        failed_at: new Date().toISOString()
      })
      .eq('payment_id', paymentId);

    // 记录失败日志
    console.log(`Payment failed: orderId=${orderId}, paymentId=${paymentId}, errMsg=${errMsg}`);

    return { success: true, msg: '已记录失败信息' };
  }

  /**
   * 模拟支付（开发环境使用）
   */
  async mockPaymentSuccess(orderId: string): Promise<{ success: boolean; msg: string }> {
    const client = getSupabaseClient();

    // 查询订单
    const { data: order, error: orderError } = await client
      .from('orders')
      .select('*')
      .eq('id', orderId)
      .maybeSingle();

    if (orderError || !order) {
      return { success: false, msg: '订单不存在' };
    }

    if (order.status !== 'pending') {
      return { success: false, msg: '订单状态不正确' };
    }

    // 模拟支付成功
    const transactionId = `MOCK_TXN_${Date.now()}`;

    // 更新订单状态
    await client
      .from('orders')
      .update({
        status: 'paid',
        paid_at: new Date().toISOString(),
        transaction_id: transactionId
      })
      .eq('id', orderId);

    // 发放推荐人佣金
    await this.grantReferrerCommission(orderId);

    return { success: true, msg: '模拟支付成功' };
  }

  /**
   * 查询支付状态
   */
  async queryPaymentStatus(orderId: string): Promise<{
    status: string;
    paidAt?: string;
    transactionId?: string;
  }> {
    const client = getSupabaseClient();

    const { data: order, error } = await client
      .from('orders')
      .select('status, paid_at, transaction_id')
      .eq('id', orderId)
      .maybeSingle();

    if (error || !order) {
      return { status: 'unknown' };
    }

    return {
      status: order.status,
      paidAt: order.paid_at,
      transactionId: order.transaction_id
    };
  }

  /**
   * 发放推荐人佣金
   */
  private async grantReferrerCommission(orderId: string): Promise<void> {
    const client = getSupabaseClient();

    // 查询订单
    const { data: order } = await client
      .from('orders')
      .select('*')
      .eq('id', orderId)
      .maybeSingle();

    if (!order || !order.referrer_commission || order.referrer_commission <= 0) {
      return;
    }

    // 查询用户的推荐人
    const { data: user } = await client
      .from('users')
      .select('referrer_id')
      .eq('id', order.user_id)
      .maybeSingle();

    if (!user?.referrer_id) {
      return;
    }

    // 记录佣金
    try {
      await client.from('commissions').insert({
        user_id: user.referrer_id,
        order_id: orderId,
        type: 'order',
        amount: order.referrer_commission,
        status: 'pending',
        description: '订单佣金'
      });
    } catch (err) {
      console.error('Insert commission error:', err);
    }
  }

  /**
   * 发送支付成功通知
   */
  private async sendPaymentSuccessNotification(orderId: string): Promise<void> {
    // TODO: 实现消息推送
    console.log(`[Payment] Payment success notification for order: ${orderId}`);
  }

  /**
   * 申请退款
   */
  async requestRefund(data: {
    orderId: string;
    userId: string;
    reason: string;
  }): Promise<{ success: boolean; msg: string; refundNo?: string }> {
    const { orderId, userId, reason } = data;
    const client = getSupabaseClient();

    // 查询订单
    const { data: order, error: orderError } = await client
      .from('orders')
      .select('*')
      .eq('id', orderId)
      .eq('user_id', userId)
      .maybeSingle();

    if (orderError || !order) {
      return { success: false, msg: '订单不存在' };
    }

    // 只有已支付且未核销的订单可以退款
    if (order.status !== 'paid') {
      return { success: false, msg: '当前订单状态不可退款' };
    }

    // 创建退款记录
    const refundNo = `RF${Date.now()}${Math.random().toString(36).substr(2, 6).toUpperCase()}`;
    
    await client.from('refunds').insert({
      refund_no: refundNo,
      order_id: orderId,
      user_id: userId,
      amount: order.payable_amount,
      reason,
      status: 'pending'
    });

    // 更新订单状态为退款中
    await client
      .from('orders')
      .update({
        status: 'refunding',
        refund_requested_at: new Date().toISOString()
      })
      .eq('id', orderId);

    return { success: true, msg: '退款申请已提交', refundNo };
  }
}
