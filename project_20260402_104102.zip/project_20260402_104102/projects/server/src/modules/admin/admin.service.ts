import { Injectable } from '@nestjs/common';
import { getSupabaseClient } from '@/storage/database/supabase-client';

@Injectable()
export class AdminService {
  // ========== 初始化 ==========
  
  async initDefaultAdmin() {
    const client = getSupabaseClient();
    
    // 检查是否已存在管理员
    const { data: existingAdmins } = await client
      .from('admins')
      .select('id')
      .limit(1);
    
    if (existingAdmins && existingAdmins.length > 0) {
      return { success: false, msg: '已存在管理员账号，无需初始化' };
    }
    
    // 创建默认管理员
    const { data, error } = await client
      .from('admins')
      .insert({
        username: 'admin',
        password: 'admin123',
        nickname: '超级管理员',
        role: 'super_admin',
        status: 'active',
      })
      .select()
      .single();
    
    if (error) {
      console.error('Init admin error:', error);
      return { success: false, msg: `初始化失败: ${error.message}` };
    }
    
    return { success: true, data: { username: 'admin', password: 'admin123' } };
  }

  // ========== 认证相关 ==========
  
  async login(username: string, password: string) {
    const client = getSupabaseClient();
    
    const { data, error } = await client
      .from('admins')
      .select('*')
      .eq('username', username)
      .eq('password', password)
      .eq('status', 'active')
      .maybeSingle();

    if (error || !data) {
      return { success: false, msg: '用户名或密码错误' };
    }

    // 更新最后登录时间
    await client
      .from('admins')
      .update({ last_login_at: new Date().toISOString() })
      .eq('id', data.id);

    return { success: true, admin: data };
  }

  // ========== Dashboard 数据 ==========
  
  async getDashboardStats() {
    const client = getSupabaseClient();
    
    // 获取今日日期
    const today = new Date().toISOString().split('T')[0];
    
    // 并行查询所有统计数据
    const [
      usersResult,
      merchantsResult,
      ordersResult,
      todayOrdersResult,
      todayRevenueResult,
      pendingMerchantsResult
    ] = await Promise.all([
      // 用户总数
      client.from('users').select('id', { count: 'exact', head: true }),
      // 商家总数
      client.from('merchants').select('id', { count: 'exact', head: true }),
      // 订单总数
      client.from('orders').select('id', { count: 'exact', head: true }),
      // 今日订单数
      client.from('orders').select('id', { count: 'exact', head: true }).gte('created_at', today),
      // 今日营收
      client.from('orders').select('pay_amount').eq('status', 'completed').gte('created_at', today),
      // 待审核商家
      client.from('merchants').select('id', { count: 'exact', head: true }).eq('status', 'pending'),
    ]);

    const todayRevenue = todayRevenueResult.data?.reduce((sum, order) => {
      return sum + parseFloat(order.pay_amount || '0');
    }, 0) || 0;

    return {
      totalUsers: usersResult.count || 0,
      totalMerchants: merchantsResult.count || 0,
      totalOrders: ordersResult.count || 0,
      todayOrders: todayOrdersResult.count || 0,
      todayRevenue: todayRevenue.toFixed(2),
      pendingMerchants: pendingMerchantsResult.count || 0,
    };
  }

  async getRecentOrders(limit: number = 10) {
    const client = getSupabaseClient();
    
    const { data, error } = await client
      .from('orders')
      .select(`
        id,
        order_no,
        total_amount,
        pay_amount,
        status,
        created_at,
        users!orders_user_id_fkey(nickname, phone),
        merchants!orders_merchant_id_fkey(name)
      `)
      .order('created_at', { ascending: false })
      .limit(limit);

    return data || [];
  }

  async getRecentUsers(limit: number = 10) {
    const client = getSupabaseClient();
    
    const { data, error } = await client
      .from('users')
      .select('id, nickname, phone, region, created_at')
      .order('created_at', { ascending: false })
      .limit(limit);

    return data || [];
  }

  // ========== 用户管理 ==========
  
  async getUsers(params: { page: number; pageSize: number; keyword?: string; status?: string }) {
    const client = getSupabaseClient();
    const { page, pageSize, keyword, status } = params;
    const offset = (page - 1) * pageSize;

    let query = client.from('users').select('*', { count: 'exact' });

    if (keyword) {
      query = query.or(`nickname.ilike.%${keyword}%,phone.ilike.%${keyword}%`);
    }

    if (status) {
      query = query.eq('status', status);
    }

    const { data, error, count } = await query
      .order('created_at', { ascending: false })
      .range(offset, offset + pageSize - 1);

    return { users: data || [], total: count || 0 };
  }

  async getUserDetail(userId: string) {
    const client = getSupabaseClient();
    
    const [userResult, ordersResult, walletResult] = await Promise.all([
      client.from('users').select('*').eq('id', userId).maybeSingle(),
      client.from('orders').select('id, order_no, total_amount, status, created_at').eq('user_id', userId).limit(10),
      client.from('wallet_transactions').select('*').eq('user_id', userId).limit(10),
    ]);

    return {
      user: userResult.data,
      orders: ordersResult.data || [],
      walletTransactions: walletResult.data || [],
    };
  }

  async updateUserStatus(userId: string, status: string) {
    const client = getSupabaseClient();
    
    const { error } = await client
      .from('users')
      .update({ status })
      .eq('id', userId);

    return { success: !error, msg: error?.message || '操作成功' };
  }

  // ========== 商家管理 ==========
  
  async getMerchants(params: { page: number; pageSize: number; keyword?: string; status?: string; category?: string }) {
    const client = getSupabaseClient();
    const { page, pageSize, keyword, status, category } = params;
    const offset = (page - 1) * pageSize;

    let query = client.from('merchants').select('*', { count: 'exact' });

    if (keyword) {
      query = query.or(`name.ilike.%${keyword}%,address.ilike.%${keyword}%`);
    }

    if (status) {
      query = query.eq('status', status);
    }

    if (category) {
      query = query.eq('category', category);
    }

    const { data, error, count } = await query
      .order('created_at', { ascending: false })
      .range(offset, offset + pageSize - 1);

    return { merchants: data || [], total: count || 0 };
  }

  async getMerchantDetail(merchantId: string) {
    const client = getSupabaseClient();
    
    const [merchantResult, productsResult, ordersResult] = await Promise.all([
      client.from('merchants').select('*').eq('id', merchantId).maybeSingle(),
      client.from('products').select('*').eq('merchant_id', merchantId),
      client.from('orders').select('id, order_no, total_amount, status, created_at').eq('merchant_id', merchantId).limit(20),
    ]);

    return {
      merchant: merchantResult.data,
      products: productsResult.data || [],
      orders: ordersResult.data || [],
    };
  }

  async updateMerchantStatus(merchantId: string, status: string, reason?: string) {
    const client = getSupabaseClient();
    
    const updateData: any = { status };
    if (status === 'rejected' && reason) {
      updateData.reject_reason = reason;
    }

    const { error } = await client
      .from('merchants')
      .update(updateData)
      .eq('id', merchantId);

    return { success: !error, msg: error?.message || '操作成功' };
  }

  // ========== 订单管理 ==========
  
  async getOrders(params: { page: number; pageSize: number; keyword?: string; status?: string; startDate?: string; endDate?: string }) {
    const client = getSupabaseClient();
    const { page, pageSize, keyword, status, startDate, endDate } = params;
    const offset = (page - 1) * pageSize;

    let query = client.from('orders').select(`
      id,
      order_no,
      total_amount,
      pay_amount,
      status,
      payment_method,
      created_at,
      paid_at,
      completed_at,
      users!orders_user_id_fkey(nickname, phone),
      merchants!orders_merchant_id_fkey(name)
    `, { count: 'exact' });

    if (keyword) {
      query = query.ilike('order_no', `%${keyword}%`);
    }

    if (status) {
      query = query.eq('status', status);
    }

    if (startDate) {
      query = query.gte('created_at', startDate);
    }

    if (endDate) {
      query = query.lte('created_at', endDate);
    }

    const { data, error, count } = await query
      .order('created_at', { ascending: false })
      .range(offset, offset + pageSize - 1);

    return { orders: data || [], total: count || 0 };
  }

  async getOrderDetail(orderId: string) {
    const client = getSupabaseClient();
    
    const { data, error } = await client
      .from('orders')
      .select(`
        *,
        users!orders_user_id_fkey(nickname, phone, avatar),
        merchants!orders_merchant_id_fkey(name, address, phone),
        products!orders_product_id_fkey(name, image_url)
      `)
      .eq('id', orderId)
      .maybeSingle();

    return data;
  }

  async updateOrderStatus(orderId: string, status: string, adminId: string) {
    const client = getSupabaseClient();
    
    const updateData: any = { status };
    if (status === 'completed') {
      updateData.completed_at = new Date().toISOString();
    } else if (status === 'cancelled') {
      updateData.cancelled_at = new Date().toISOString();
    }

    const { error } = await client
      .from('orders')
      .update(updateData)
      .eq('id', orderId);

    // 记录操作日志
    await this.logAction(adminId, 'update_order_status', 'order', orderId, { status });

    return { success: !error, msg: error?.message || '操作成功' };
  }

  // ========== 商品管理 ==========
  
  async getAllProducts(params: { page: number; pageSize: number; keyword?: string; status?: string; merchantId?: string }) {
    const client = getSupabaseClient();
    const { page, pageSize, keyword, status, merchantId } = params;
    const offset = (page - 1) * pageSize;

    let query = client.from('products').select(`
      *,
      merchants!products_merchant_id_fkey(name)
    `, { count: 'exact' });

    if (keyword) {
      query = query.ilike('name', `%${keyword}%`);
    }

    if (status !== undefined) {
      query = query.eq('is_active', status === 'active');
    }

    if (merchantId) {
      query = query.eq('merchant_id', merchantId);
    }

    const { data, error, count } = await query
      .order('created_at', { ascending: false })
      .range(offset, offset + pageSize - 1);

    return { products: data || [], total: count || 0 };
  }

  async updateProductStatus(productId: string, isActive: boolean, adminId: string) {
    const client = getSupabaseClient();
    
    const { error } = await client
      .from('products')
      .update({ is_active: isActive })
      .eq('id', productId);

    await this.logAction(adminId, 'update_product_status', 'product', productId, { is_active: isActive });

    return { success: !error, msg: error?.message || '操作成功' };
  }

  // ========== 优惠券管理 ==========
  
  async getCoupons(params: { page: number; pageSize: number; keyword?: string; type?: string; status?: string }) {
    const client = getSupabaseClient();
    const { page, pageSize, keyword, type, status } = params;
    const offset = (page - 1) * pageSize;

    let query = client.from('coupons').select(`
      *,
      merchants!coupons_merchant_id_fkey(name)
    `, { count: 'exact' });

    if (keyword) {
      query = query.ilike('name', `%${keyword}%`);
    }

    if (type) {
      query = query.eq('type', type);
    }

    if (status) {
      query = query.eq('status', status);
    }

    const { data, error, count } = await query
      .order('created_at', { ascending: false })
      .range(offset, offset + pageSize - 1);

    return { coupons: data || [], total: count || 0 };
  }

  async createCoupon(couponData: any) {
    const client = getSupabaseClient();
    
    const { data, error } = await client
      .from('coupons')
      .insert({
        name: couponData.name,
        type: couponData.type,
        value: couponData.value,
        min_amount: couponData.min_amount || '0',
        total_count: couponData.total_count || 100,
        used_count: 0,
        start_time: couponData.start_time,
        end_time: couponData.end_time,
        status: 'active',
      })
      .select()
      .single();

    if (error) {
      return { success: false, msg: error.message };
    }

    return { success: true, data };
  }

  async updateCouponStatus(couponId: string, isActive: boolean) {
    const client = getSupabaseClient();
    
    const { error } = await client
      .from('coupons')
      .update({ status: isActive ? 'active' : 'inactive' })
      .eq('id', couponId);

    return { success: !error, msg: error?.message || '操作成功' };
  }

  async updateCoupon(couponId: string, couponData: any) {
    const client = getSupabaseClient();
    
    const { error } = await client
      .from('coupons')
      .update({
        name: couponData.name,
        type: couponData.type,
        value: couponData.value,
        min_amount: couponData.min_amount,
        total_count: couponData.total_count,
        start_time: couponData.start_time,
        end_time: couponData.end_time,
      })
      .eq('id', couponId);

    return { success: !error, msg: error?.message || '操作成功' };
  }

  // ========== 分类管理 ==========
  
  async getCategories() {
    const client = getSupabaseClient();
    
    const { data, error } = await client
      .from('categories')
      .select('*')
      .order('sort_order', { ascending: true });

    return data || [];
  }

  async createCategory(categoryData: any) {
    const client = getSupabaseClient();
    
    const { data, error } = await client
      .from('categories')
      .insert(categoryData)
      .select()
      .single();

    if (error) {
      return { success: false, msg: error.message };
    }

    return { success: true, data };
  }

  async updateCategory(categoryId: number, categoryData: any) {
    const client = getSupabaseClient();
    
    const { error } = await client
      .from('categories')
      .update(categoryData)
      .eq('id', categoryId);

    return { success: !error, msg: error?.message || '操作成功' };
  }

  async deleteCategory(categoryId: number) {
    const client = getSupabaseClient();
    
    const { error } = await client
      .from('categories')
      .delete()
      .eq('id', categoryId);

    return { success: !error, msg: error?.message || '操作成功' };
  }

  // ========== 趋势统计 ==========

  async getOrderTrend(days: number = 7) {
    const client = getSupabaseClient();
    const trend: { date: string; count: number; revenue: number }[] = [];
    
    for (let i = days - 1; i >= 0; i--) {
      const date = new Date();
      date.setDate(date.getDate() - i);
      const dateStr = date.toISOString().split('T')[0];
      
      const nextDate = new Date(date);
      nextDate.setDate(nextDate.getDate() + 1);
      const nextDateStr = nextDate.toISOString().split('T')[0];
      
      // 查询当天订单数
      const { count } = await client
        .from('orders')
        .select('id', { count: 'exact', head: true })
        .gte('created_at', dateStr)
        .lt('created_at', nextDateStr);
      
      // 查询当天营收（已完成的订单）
      const { data: revenueData } = await client
        .from('orders')
        .select('pay_amount')
        .in('status', ['paid', 'completed'])
        .gte('created_at', dateStr)
        .lt('created_at', nextDateStr);
      
      const revenue = revenueData?.reduce((sum, order) => {
        return sum + parseFloat(order.pay_amount || '0');
      }, 0) || 0;
      
      trend.push({
        date: dateStr,
        count: count || 0,
        revenue: Math.round(revenue * 100) / 100
      });
    }
    
    return trend;
  }

  async getUserTrend(days: number = 7) {
    const client = getSupabaseClient();
    const trend: { date: string; count: number }[] = [];
    
    for (let i = days - 1; i >= 0; i--) {
      const date = new Date();
      date.setDate(date.getDate() - i);
      const dateStr = date.toISOString().split('T')[0];
      
      const nextDate = new Date(date);
      nextDate.setDate(nextDate.getDate() + 1);
      const nextDateStr = nextDate.toISOString().split('T')[0];
      
      const { count } = await client
        .from('users')
        .select('id', { count: 'exact', head: true })
        .gte('created_at', dateStr)
        .lt('created_at', nextDateStr);
      
      trend.push({
        date: dateStr,
        count: count || 0
      });
    }
    
    return trend;
  }

  async getOrderStatusDistribution() {
    const client = getSupabaseClient();
    
    const { data, error } = await client
      .from('orders')
      .select('status');
    
    if (error || !data) {
      return [];
    }
    
    const distribution: Record<string, number> = {};
    data.forEach(order => {
      const status = order.status || 'unknown';
      distribution[status] = (distribution[status] || 0) + 1;
    });
    
    return Object.entries(distribution).map(([status, count]) => ({
      status,
      count,
      label: this.getStatusLabel(status)
    }));
  }

  async getCategoryDistribution() {
    const client = getSupabaseClient();
    
    const { data, error } = await client
      .from('merchants')
      .select('category');
    
    if (error || !data) {
      return [];
    }
    
    const distribution: Record<string, number> = {};
    data.forEach(merchant => {
      const category = merchant.category || 'other';
      distribution[category] = (distribution[category] || 0) + 1;
    });
    
    return Object.entries(distribution).map(([category, count]) => ({
      category,
      count,
      label: this.getCategoryLabel(category)
    }));
  }

  private getStatusLabel(status: string): string {
    const labels: Record<string, string> = {
      pending: '待支付',
      paid: '已支付',
      completed: '已完成',
      cancelled: '已取消',
      refunding: '退款中',
      refunded: '已退款'
    };
    return labels[status] || status;
  }

  private getCategoryLabel(category: string): string {
    const labels: Record<string, string> = {
      food: '美食',
      entertainment: '娱乐',
      shopping: '购物',
      service: '服务',
      hotel: '酒店',
      travel: '旅游',
      other: '其他'
    };
    return labels[category] || category;
  }

  // ========== 操作日志 ==========
  
  async logAction(adminId: string, action: string, target: string, targetId: string, details: any) {
    const client = getSupabaseClient();
    
    await client.from('admin_logs').insert({
      admin_id: adminId,
      action,
      target,
      target_id: targetId,
      details: JSON.stringify(details),
    });
  }

  async getAdminLogs(params: { page: number; pageSize: number; adminId?: string }) {
    const client = getSupabaseClient();
    const { page, pageSize, adminId } = params;
    const offset = (page - 1) * pageSize;

    let query = client.from('admin_logs').select(`
      *,
      admins!admin_logs_admin_id_fkey(username, nickname)
    `, { count: 'exact' });

    if (adminId) {
      query = query.eq('admin_id', adminId);
    }

    const { data, error, count } = await query
      .order('created_at', { ascending: false })
      .range(offset, offset + pageSize - 1);

    return { logs: data || [], total: count || 0 };
  }

  // ========== 系统配置 ==========

  async getSettings() {
    const client = getSupabaseClient();

    const { data, error } = await client
      .from('system_settings')
      .select('*')
      .order('key', { ascending: true });

    return data || [];
  }

  async updateSettings(settings: any[]) {
    const client = getSupabaseClient();

    for (const setting of settings) {
      const { error } = await client
        .from('system_settings')
        .upsert({
          key: setting.key,
          value: setting.value,
          description: setting.description,
          updated_at: new Date().toISOString(),
        }, { onConflict: 'key' });

      if (error) {
        return { success: false, msg: error.message };
      }
    }

    return { success: true, msg: '更新成功' };
  }

  // ========== 数据导出 ==========

  async exportUsers(params: { status?: string; startDate?: string; endDate?: string }) {
    const client = getSupabaseClient();

    let query = client.from('users').select('id, nickname, phone, region, status, created_at');

    if (params.status) {
      query = query.eq('status', params.status);
    }

    if (params.startDate) {
      query = query.gte('created_at', params.startDate);
    }

    if (params.endDate) {
      query = query.lte('created_at', params.endDate);
    }

    const { data, error } = await query.order('created_at', { ascending: false });

    // 转换为CSV格式数据
    const exportData = (data || []).map(user => ({
      '用户ID': user.id,
      '昵称': user.nickname || '',
      '手机号': user.phone || '',
      '区域': user.region === 'island_inside' ? '岛内' : user.region === 'island_outside' ? '岛外' : '',
      '状态': user.status === 'active' ? '正常' : user.status === 'inactive' ? '禁用' : user.status,
      '注册时间': user.created_at,
    }));

    return { data: exportData, total: exportData.length };
  }

  async exportOrders(params: { status?: string; startDate?: string; endDate?: string }) {
    const client = getSupabaseClient();

    let query = client.from('orders').select(`
      id,
      order_no,
      total_amount,
      pay_amount,
      status,
      payment_method,
      created_at,
      users!orders_user_id_fkey(nickname, phone),
      merchants!orders_merchant_id_fkey(name)
    `);

    if (params.status) {
      query = query.eq('status', params.status);
    }

    if (params.startDate) {
      query = query.gte('created_at', params.startDate);
    }

    if (params.endDate) {
      query = query.lte('created_at', params.endDate);
    }

    const { data, error } = await query.order('created_at', { ascending: false });

    const exportData = (data || []).map((order: any) => ({
      '订单号': order.order_no,
      '用户': order.users?.nickname || '',
      '手机号': order.users?.phone || '',
      '商家': order.merchants?.name || '',
      '订单金额': order.total_amount,
      '实付金额': order.pay_amount,
      '支付方式': order.payment_method || '',
      '状态': this.getStatusLabel(order.status),
      '创建时间': order.created_at,
    }));

    return { data: exportData, total: exportData.length };
  }

  async exportMerchants(params: { status?: string; category?: string }) {
    const client = getSupabaseClient();

    let query = client.from('merchants').select('id, name, category, address, phone, status, created_at');

    if (params.status) {
      query = query.eq('status', params.status);
    }

    if (params.category) {
      query = query.eq('category', params.category);
    }

    const { data, error } = await query.order('created_at', { ascending: false });

    const exportData = (data || []).map(merchant => ({
      '商家ID': merchant.id,
      '商家名称': merchant.name,
      '分类': this.getCategoryLabel(merchant.category),
      '地址': merchant.address || '',
      '电话': merchant.phone || '',
      '状态': this.getStatusLabel(merchant.status),
      '创建时间': merchant.created_at,
    }));

    return { data: exportData, total: exportData.length };
  }

  // ========== RBAC 权限管理 ==========

  async getRoles() {
    const client = getSupabaseClient();

    const { data, error } = await client
      .from('admin_roles')
      .select(`
        *,
        role_permissions(permission)
      `)
      .order('created_at', { ascending: false });

    return data || [];
  }

  async createRole(roleData: any) {
    const client = getSupabaseClient();

    const { permissions, ...role } = roleData;

    const { data, error } = await client
      .from('admin_roles')
      .insert(role)
      .select()
      .single();

    if (error) {
      return { success: false, msg: error.message };
    }

    // 添加权限关联
    if (permissions && permissions.length > 0) {
      const rolePermissions = permissions.map((p: string) => ({
        role_id: data.id,
        permission: p,
      }));

      await client.from('role_permissions').insert(rolePermissions);
    }

    return { success: true, data };
  }

  async updateRole(roleId: string, roleData: any) {
    const client = getSupabaseClient();

    const { permissions, ...role } = roleData;

    const { error } = await client
      .from('admin_roles')
      .update(role)
      .eq('id', roleId);

    if (error) {
      return { success: false, msg: error.message };
    }

    // 更新权限关联
    if (permissions !== undefined) {
      // 先删除旧的权限
      await client.from('role_permissions').delete().eq('role_id', roleId);

      // 添加新的权限
      if (permissions.length > 0) {
        const rolePermissions = permissions.map((p: string) => ({
          role_id: roleId,
          permission: p,
        }));

        await client.from('role_permissions').insert(rolePermissions);
      }
    }

    return { success: true, msg: '更新成功' };
  }

  async deleteRole(roleId: string) {
    const client = getSupabaseClient();

    // 先删除权限关联
    await client.from('role_permissions').delete().eq('role_id', roleId);

    const { error } = await client
      .from('admin_roles')
      .delete()
      .eq('id', roleId);

    return { success: !error, msg: error?.message || '删除成功' };
  }

  async getPermissions() {
    // 预定义权限列表
    return [
      { key: 'dashboard', label: '数据统计', description: '查看Dashboard统计数据' },
      { key: 'user.view', label: '查看用户', description: '查看用户列表和详情' },
      { key: 'user.manage', label: '管理用户', description: '启用/禁用用户' },
      { key: 'merchant.view', label: '查看商家', description: '查看商家列表和详情' },
      { key: 'merchant.manage', label: '管理商家', description: '审核和管理商家' },
      { key: 'order.view', label: '查看订单', description: '查看订单列表和详情' },
      { key: 'order.manage', label: '管理订单', description: '修改订单状态' },
      { key: 'coupon.view', label: '查看优惠券', description: '查看优惠券列表' },
      { key: 'coupon.manage', label: '管理优惠券', description: '创建、编辑、删除优惠券' },
      { key: 'settings.view', label: '查看设置', description: '查看系统配置' },
      { key: 'settings.manage', label: '管理设置', description: '修改系统配置' },
      { key: 'admin.manage', label: '管理管理员', description: '创建和管理管理员账号' },
      { key: 'role.manage', label: '管理角色', description: '创建和管理角色权限' },
      { key: 'export', label: '数据导出', description: '导出用户、订单、商家数据' },
    ];
  }

  async createAdmin(adminData: any) {
    const client = getSupabaseClient();

    const { data, error } = await client
      .from('admins')
      .insert({
        username: adminData.username,
        password: adminData.password,
        nickname: adminData.nickname,
        role: adminData.role,
        role_id: adminData.role_id,
        status: 'active',
      })
      .select()
      .single();

    if (error) {
      return { success: false, msg: error.message };
    }

    return { success: true, data };
  }

  async getAdmins(params: { page: number; pageSize: number }) {
    const client = getSupabaseClient();
    const { page, pageSize } = params;
    const offset = (page - 1) * pageSize;

    const { data, error, count } = await client
      .from('admins')
      .select(`
        *,
        admin_roles(name)
      `, { count: 'exact' })
      .order('created_at', { ascending: false })
      .range(offset, offset + pageSize - 1);

    return { admins: data || [], total: count || 0 };
  }

  async updateAdminStatus(adminId: string, status: string) {
    const client = getSupabaseClient();

    const { error } = await client
      .from('admins')
      .update({ status })
      .eq('id', adminId);

    return { success: !error, msg: error?.message || '操作成功' };
  }

  // ========== 优惠券删除 ==========

  async deleteCoupon(couponId: string) {
    const client = getSupabaseClient();

    const { error } = await client
      .from('coupons')
      .delete()
      .eq('id', couponId);

    return { success: !error, msg: error?.message || '删除成功' };
  }

  // ========== 提现管理 ==========

  async getWithdrawals(params: { page: number; pageSize: number; status?: string; keyword?: string }) {
    const client = getSupabaseClient();
    const { page, pageSize, status, keyword } = params;
    const offset = (page - 1) * pageSize;

    let query = client
      .from('wallet_transactions')
      .select(`
        *,
        users!wallet_transactions_user_id_fkey(nickname, phone, avatar)
      `, { count: 'exact' })
      .eq('type', 'withdraw')
      .order('created_at', { ascending: false });

    if (status) {
      query = query.eq('status', status);
    }

    if (keyword) {
      // 通过用户手机号或昵称搜索需要join，这里简化处理
    }

    const { data, error, count } = await query.range(offset, offset + pageSize - 1);

    return { withdrawals: data || [], total: count || 0 };
  }

  async approveWithdrawal(withdrawalId: string, adminId: string) {
    const client = getSupabaseClient();

    // 获取提现记录
    const { data: withdrawal, error: fetchError } = await client
      .from('wallet_transactions')
      .select('*')
      .eq('id', withdrawalId)
      .single();

    if (fetchError || !withdrawal) {
      return { success: false, msg: '提现记录不存在' };
    }

    if (withdrawal.status !== 'pending') {
      return { success: false, msg: '该提现已处理' };
    }

    // 更新状态为已完成
    const { error } = await client
      .from('wallet_transactions')
      .update({ 
        status: 'completed',
        description: `${withdrawal.description}（已打款）`
      })
      .eq('id', withdrawalId);

    if (error) {
      return { success: false, msg: error.message };
    }

    // 记录操作日志
    await this.logAction(adminId, 'approve_withdrawal', 'withdrawal', withdrawalId, { amount: withdrawal.amount });

    return { success: true, msg: '已通过并打款' };
  }

  async rejectWithdrawal(withdrawalId: string, adminId: string, reason: string) {
    const client = getSupabaseClient();

    // 获取提现记录
    const { data: withdrawal, error: fetchError } = await client
      .from('wallet_transactions')
      .select('*')
      .eq('id', withdrawalId)
      .single();

    if (fetchError || !withdrawal) {
      return { success: false, msg: '提现记录不存在' };
    }

    if (withdrawal.status !== 'pending') {
      return { success: false, msg: '该提现已处理' };
    }

    // 获取用户钱包
    const { data: wallet } = await client
      .from('wallets')
      .select('*')
      .eq('user_id', withdrawal.user_id)
      .single();

    // 退回冻结金额
    if (wallet) {
      await client
        .from('wallets')
        .update({
          balance: wallet.balance + Math.abs(withdrawal.amount),
          frozen_amount: Math.max(0, wallet.frozen_amount - Math.abs(withdrawal.amount)),
        })
        .eq('id', wallet.id);
    }

    // 更新状态为已拒绝
    const { error } = await client
      .from('wallet_transactions')
      .update({ 
        status: 'failed',
        description: `提现拒绝：${reason}`
      })
      .eq('id', withdrawalId);

    if (error) {
      return { success: false, msg: error.message };
    }

    // 记录操作日志
    await this.logAction(adminId, 'reject_withdrawal', 'withdrawal', withdrawalId, { reason });

    return { success: true, msg: '已拒绝并退回余额' };
  }

  // ========== 分销管理 ==========

  async getReferrers(params: { page: number; pageSize: number; keyword?: string }) {
    const client = getSupabaseClient();
    const { page, pageSize, keyword } = params;
    const offset = (page - 1) * pageSize;

    // 查询有推荐码的用户
    let query = client
      .from('users')
      .select('id, nickname, phone, avatar_url, referral_code, created_at', { count: 'exact' })
      .not('referral_code', 'is', null)
      .order('created_at', { ascending: false });

    if (keyword) {
      query = query.or(`nickname.ilike.%${keyword}%,phone.ilike.%${keyword}%`);
    }

    const { data, error, count } = await query.range(offset, offset + pageSize - 1);

    if (error) {
      return { referrers: [], total: 0 };
    }

    // 查询每个用户的推荐人数
    const referrers = await Promise.all((data || []).map(async (user) => {
      const { count: referralCount } = await client
        .from('referral_rewards')
        .select('id', { count: 'exact', head: true })
        .eq('user_id', user.id);

      // 查询佣金总额
      const { data: rewards } = await client
        .from('referral_rewards')
        .select('amount')
        .eq('user_id', user.id)
        .eq('status', 'completed');

      const totalCommission = (rewards || []).reduce((sum, r) => sum + parseFloat(r.amount || '0'), 0);

      return {
        ...user,
        referralCount: referralCount || 0,
        totalCommission: totalCommission.toFixed(2),
      };
    }));

    return { referrers, total: count || 0 };
  }

  async getCommissionStats() {
    const client = getSupabaseClient();

    // 总佣金发放
    const { data: totalData } = await client
      .from('referral_rewards')
      .select('amount')
      .eq('status', 'completed');

    const totalCommission = (totalData || []).reduce((sum, r) => sum + parseFloat(r.amount || '0'), 0);

    // 本月佣金
    const thisMonth = new Date().toISOString().slice(0, 7);
    const { data: monthData } = await client
      .from('referral_rewards')
      .select('amount')
      .eq('status', 'completed')
      .gte('created_at', `${thisMonth}-01`);

    const monthCommission = (monthData || []).reduce((sum, r) => sum + parseFloat(r.amount || '0'), 0);

    // 分销员数量
    const { count: referrerCount } = await client
      .from('users')
      .select('id', { count: 'exact', head: true })
      .not('referral_code', 'is', null);

    // 今日新增推荐
    const today = new Date().toISOString().split('T')[0];
    const { count: todayReferrals } = await client
      .from('referral_rewards')
      .select('id', { count: 'exact', head: true })
      .gte('created_at', today);

    return {
      totalCommission: totalCommission.toFixed(2),
      monthCommission: monthCommission.toFixed(2),
      referrerCount: referrerCount || 0,
      todayReferrals: todayReferrals || 0,
    };
  }

  async getCommissionRecords(params: { page: number; pageSize: number; userId?: string }) {
    const client = getSupabaseClient();
    const { page, pageSize, userId } = params;
    const offset = (page - 1) * pageSize;

    let query = client
      .from('referral_rewards')
      .select(`
        *,
        users!referral_rewards_user_id_fkey(nickname, phone),
        related_users:users!referral_rewards_related_user_id_fkey(nickname, phone)
      `, { count: 'exact' })
      .order('created_at', { ascending: false });

    if (userId) {
      query = query.eq('user_id', userId);
    }

    const { data, error, count } = await query.range(offset, offset + pageSize - 1);

    return { records: data || [], total: count || 0 };
  }

  // ========== 消息推送 ==========

  async getMessages(params: { page: number; pageSize: number; type?: string }) {
    const client = getSupabaseClient();
    const { page, pageSize, type } = params;
    const offset = (page - 1) * pageSize;

    let query = client
      .from('user_messages')
      .select('*', { count: 'exact' })
      .order('created_at', { ascending: false });

    if (type) {
      query = query.eq('type', type);
    }

    const { data, error, count } = await query.range(offset, offset + pageSize - 1);

    return { messages: data || [], total: count || 0 };
  }

  async broadcastMessage(data: { userIds: string[]; type: string; title: string; content: string }) {
    const client = getSupabaseClient();

    const messages = data.userIds.map(userId => ({
      user_id: userId,
      type: data.type,
      title: data.title,
      content: data.content,
      status: 'unread',
    }));

    const { error } = await client
      .from('user_messages')
      .insert(messages);

    if (error) {
      return { success: false, msg: error.message };
    }

    return { success: true, msg: `成功发送 ${data.userIds.length} 条消息` };
  }

  async sendToAllUsers(data: { type: string; title: string; content: string }) {
    const client = getSupabaseClient();

    // 获取所有用户ID
    const { data: users, error: fetchError } = await client
      .from('users')
      .select('id')
      .eq('status', 'active');

    if (fetchError || !users?.length) {
      return { success: false, msg: '获取用户列表失败' };
    }

    const messages = users.map(user => ({
      user_id: user.id,
      type: data.type,
      title: data.title,
      content: data.content,
      status: 'unread',
    }));

    // 分批插入（每批500条）
    const batchSize = 500;
    for (let i = 0; i < messages.length; i += batchSize) {
      const batch = messages.slice(i, i + batchSize);
      await client.from('user_messages').insert(batch);
    }

    return { success: true, msg: `成功发送 ${users.length} 条消息` };
  }

  // ========== 退款管理 ==========

  async getRefunds(params: { page: number; pageSize: number; status?: string; keyword?: string }) {
    const client = getSupabaseClient();
    const { page, pageSize, status, keyword } = params;
    const offset = (page - 1) * pageSize;

    let query = client
      .from('refunds')
      .select(`
        *,
        users!refunds_user_id_fkey(nickname, phone, avatar_url),
        orders(order_no, pay_amount, merchants(name))
      `, { count: 'exact' })
      .order('created_at', { ascending: false });

    if (status) {
      query = query.eq('status', status);
    }

    const { data, error, count } = await query.range(offset, offset + pageSize - 1);

    if (error) {
      console.error('Get refunds error:', error);
      return { refunds: [], total: 0 };
    }

    return { refunds: data || [], total: count || 0 };
  }

  async getRefundDetail(refundId: string) {
    const client = getSupabaseClient();

    const { data, error } = await client
      .from('refunds')
      .select(`
        *,
        users!refunds_user_id_fkey(nickname, phone, avatar_url),
        orders(
          order_no, 
          pay_amount, 
          total_amount,
          merchants(name, address, phone)
        )
      `)
      .eq('id', refundId)
      .maybeSingle();

    if (error) {
      console.error('Get refund detail error:', error);
      return null;
    }

    return data;
  }

  async approveRefund(refundId: string, adminId: string) {
    const client = getSupabaseClient();

    // 获取退款记录
    const { data: refund, error: fetchError } = await client
      .from('refunds')
      .select('*')
      .eq('id', refundId)
      .maybeSingle();

    if (fetchError || !refund) {
      return { success: false, msg: '退款记录不存在' };
    }

    if (refund.status !== 'pending') {
      return { success: false, msg: '该退款已处理' };
    }

    // 更新退款状态
    const { error } = await client
      .from('refunds')
      .update({ 
        status: 'approved',
        processed_at: new Date().toISOString()
      })
      .eq('id', refundId);

    if (error) {
      return { success: false, msg: error.message };
    }

    // 更新订单状态
    await client
      .from('orders')
      .update({ status: 'refunded' })
      .eq('id', refund.order_id);

    // 退款到用户钱包
    const { data: wallet } = await client
      .from('wallets')
      .select('*')
      .eq('user_id', refund.user_id)
      .maybeSingle();

    if (wallet) {
      await client
        .from('wallets')
        .update({
          balance: wallet.balance + parseFloat(refund.amount || '0'),
        })
        .eq('id', wallet.id);

      // 记录交易
      await client.from('wallet_transactions').insert({
        user_id: refund.user_id,
        type: 'refund',
        amount: parseFloat(refund.amount || '0'),
        description: `订单退款返还`,
        status: 'completed',
      });
    }

    // 记录操作日志
    await this.logAction(adminId, 'approve_refund', 'refund', refundId, { amount: refund.amount });

    return { success: true, msg: '退款已通过，金额已返还用户余额' };
  }

  async rejectRefund(refundId: string, adminId: string, reason: string) {
    const client = getSupabaseClient();

    // 获取退款记录
    const { data: refund, error: fetchError } = await client
      .from('refunds')
      .select('*')
      .eq('id', refundId)
      .maybeSingle();

    if (fetchError || !refund) {
      return { success: false, msg: '退款记录不存在' };
    }

    if (refund.status !== 'pending') {
      return { success: false, msg: '该退款已处理' };
    }

    // 更新退款状态
    const { error } = await client
      .from('refunds')
      .update({ 
        status: 'rejected',
        reject_reason: reason,
        processed_at: new Date().toISOString()
      })
      .eq('id', refundId);

    if (error) {
      return { success: false, msg: error.message };
    }

    // 恢复订单状态
    await client
      .from('orders')
      .update({ status: 'paid' })
      .eq('id', refund.order_id);

    // 记录操作日志
    await this.logAction(adminId, 'reject_refund', 'refund', refundId, { reason });

    return { success: true, msg: '已拒绝退款申请' };
  }

  // ========== 评价管理 ==========

  async getReviews(params: { page: number; pageSize: number; rating?: number; merchantId?: string; keyword?: string }) {
    const client = getSupabaseClient();
    const { page, pageSize, rating, merchantId, keyword } = params;
    const offset = (page - 1) * pageSize;

    let query = client
      .from('reviews')
      .select(`
        *,
        users!reviews_user_id_fkey(nickname, phone, avatar_url),
        merchants!reviews_merchant_id_fkey(name)
      `, { count: 'exact' })
      .order('created_at', { ascending: false });

    if (rating) {
      query = query.eq('rating', rating);
    }

    if (merchantId) {
      query = query.eq('merchant_id', merchantId);
    }

    if (keyword) {
      query = query.ilike('content', `%${keyword}%`);
    }

    const { data, error, count } = await query.range(offset, offset + pageSize - 1);

    if (error) {
      console.error('Get reviews error:', error);
      return { reviews: [], total: 0 };
    }

    return { reviews: data || [], total: count || 0 };
  }

  async getReviewDetail(reviewId: string) {
    const client = getSupabaseClient();

    const { data, error } = await client
      .from('reviews')
      .select(`
        *,
        users!reviews_user_id_fkey(nickname, phone, avatar_url),
        merchants!reviews_merchant_id_fkey(name, address),
        orders(order_no, pay_amount)
      `)
      .eq('id', reviewId)
      .maybeSingle();

    if (error) {
      console.error('Get review detail error:', error);
      return null;
    }

    return data;
  }

  async adminReplyReview(reviewId: string, reply: string) {
    const client = getSupabaseClient();

    const { error } = await client
      .from('reviews')
      .update({
        reply,
        reply_at: new Date().toISOString(),
      })
      .eq('id', reviewId);

    if (error) {
      return { success: false, msg: error.message };
    }

    return { success: true, msg: '回复成功' };
  }

  async deleteReview(reviewId: string) {
    const client = getSupabaseClient();

    const { error } = await client
      .from('reviews')
      .delete()
      .eq('id', reviewId);

    if (error) {
      return { success: false, msg: error.message };
    }

    return { success: true, msg: '删除成功' };
  }

  async getReviewStats() {
    const client = getSupabaseClient();

    // 总评价数
    const { count: totalReviews } = await client
      .from('reviews')
      .select('id', { count: 'exact', head: true });

    // 平均评分
    const { data: ratings } = await client
      .from('reviews')
      .select('rating');

    const avgRating = ratings && ratings.length > 0
      ? ratings.reduce((sum, r) => sum + r.rating, 0) / ratings.length
      : 0;

    // 评分分布
    const distribution = { 1: 0, 2: 0, 3: 0, 4: 0, 5: 0 };
    ratings?.forEach(r => {
      if (r.rating >= 1 && r.rating <= 5) {
        distribution[r.rating as keyof typeof distribution]++;
      }
    });

    // 今日新增评价
    const today = new Date().toISOString().split('T')[0];
    const { count: todayReviews } = await client
      .from('reviews')
      .select('id', { count: 'exact', head: true })
      .gte('created_at', today);

    return {
      totalReviews: totalReviews || 0,
      avgRating: Math.round(avgRating * 10) / 10,
      distribution,
      todayReviews: todayReviews || 0,
    };
  }

  // ========== 积分商品管理 ==========

  async getPointsProducts(params: {
    page: number;
    pageSize: number;
    category?: string;
    isActive?: boolean;
  }) {
    const client = getSupabaseClient();
    const offset = (params.page - 1) * params.pageSize;

    let query = client
      .from('points_products')
      .select('*', { count: 'exact' })
      .order('sort_order', { ascending: false })
      .order('created_at', { ascending: false })
      .range(offset, offset + params.pageSize - 1);

    if (params.category) {
      query = query.eq('category', params.category);
    }
    if (params.isActive !== undefined) {
      query = query.eq('is_active', params.isActive);
    }

    const { data, count, error } = await query;

    if (error) {
      console.error('Get points products error:', error);
      return { products: [], total: 0 };
    }

    return { products: data || [], total: count || 0 };
  }

  async createPointsProduct(data: any) {
    const client = getSupabaseClient();

    const { data: product, error } = await client
      .from('points_products')
      .insert({
        name: data.name,
        description: data.description,
        image_url: data.image_url,
        points_price: data.points_price,
        original_price: data.original_price,
        stock: data.stock,
        total_count: data.total_count || data.stock,
        category: data.category || 'other',
        region: data.region,
        sort_order: data.sort_order || 0,
        is_active: true,
      })
      .select()
      .single();

    if (error) {
      console.error('Create points product error:', error);
      return { success: false, msg: `创建失败: ${error.message}` };
    }

    return { success: true, msg: '创建成功', data: product };
  }

  async updatePointsProduct(productId: string, data: any) {
    const client = getSupabaseClient();

    const updateData: any = {};
    if (data.name !== undefined) updateData.name = data.name;
    if (data.description !== undefined) updateData.description = data.description;
    if (data.image_url !== undefined) updateData.image_url = data.image_url;
    if (data.points_price !== undefined) updateData.points_price = data.points_price;
    if (data.original_price !== undefined) updateData.original_price = data.original_price;
    if (data.stock !== undefined) updateData.stock = data.stock;
    if (data.category !== undefined) updateData.category = data.category;
    if (data.region !== undefined) updateData.region = data.region;
    if (data.sort_order !== undefined) updateData.sort_order = data.sort_order;
    updateData.updated_at = new Date().toISOString();

    const { error } = await client
      .from('points_products')
      .update(updateData)
      .eq('id', productId);

    if (error) {
      console.error('Update points product error:', error);
      return { success: false, msg: `更新失败: ${error.message}` };
    }

    return { success: true, msg: '更新成功' };
  }

  async updatePointsProductStatus(productId: string, isActive: boolean) {
    const client = getSupabaseClient();

    const { error } = await client
      .from('points_products')
      .update({
        is_active: isActive,
        updated_at: new Date().toISOString(),
      })
      .eq('id', productId);

    if (error) {
      console.error('Update points product status error:', error);
      return { success: false, msg: `状态更新失败: ${error.message}` };
    }

    return { success: true, msg: isActive ? '已上架' : '已下架' };
  }

  async deletePointsProduct(productId: string) {
    const client = getSupabaseClient();

    const { error } = await client
      .from('points_products')
      .delete()
      .eq('id', productId);

    if (error) {
      console.error('Delete points product error:', error);
      return { success: false, msg: `删除失败: ${error.message}` };
    }

    return { success: true, msg: '删除成功' };
  }

  async getPointsExchanges(params: {
    page: number;
    pageSize: number;
    status?: string;
  }) {
    const client = getSupabaseClient();
    const offset = (params.page - 1) * params.pageSize;

    let query = client
      .from('points_exchange_records')
      .select('*, users(nickname, phone)', { count: 'exact' })
      .order('created_at', { ascending: false })
      .range(offset, offset + params.pageSize - 1);

    if (params.status) {
      query = query.eq('status', params.status);
    }

    const { data, count, error } = await query;

    if (error) {
      console.error('Get points exchanges error:', error);
      return { records: [], total: 0 };
    }

    return { records: data || [], total: count || 0 };
  }

  async shipPointsExchange(exchangeId: string, trackingNo: string) {
    const client = getSupabaseClient();

    const { error } = await client
      .from('points_exchange_records')
      .update({
        status: 'shipped',
        tracking_no: trackingNo,
        shipped_at: new Date().toISOString(),
      })
      .eq('id', exchangeId);

    if (error) {
      console.error('Ship points exchange error:', error);
      return { success: false, msg: `发货失败: ${error.message}` };
    }

    return { success: true, msg: '已发货' };
  }

  async completePointsExchange(exchangeId: string) {
    const client = getSupabaseClient();

    const { error } = await client
      .from('points_exchange_records')
      .update({
        status: 'completed',
        completed_at: new Date().toISOString(),
      })
      .eq('id', exchangeId);

    if (error) {
      console.error('Complete points exchange error:', error);
      return { success: false, msg: `操作失败: ${error.message}` };
    }

    return { success: true, msg: '已完成' };
  }
}
