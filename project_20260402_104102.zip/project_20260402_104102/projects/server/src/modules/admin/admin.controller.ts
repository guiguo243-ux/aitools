import { Controller, Get, Post, Delete, Body, Query, Param } from '@nestjs/common';
import { AdminService } from './admin.service';

@Controller('admin')
export class AdminController {
  constructor(private readonly adminService: AdminService) {}

  // ========== 初始化 ==========
  
  @Post('init')
  async initAdmin() {
    console.log('[Admin API] POST /api/admin/init');
    
    const result = await this.adminService.initDefaultAdmin();
    
    if (result.success) {
      return { code: 200, msg: '初始化成功', data: result.data };
    }
    
    return { code: 400, msg: result.msg, data: null };
  }

  // ========== 认证相关 ==========
  
  @Post('login')
  async login(@Body() body: { username: string; password: string }) {
    console.log('[Admin API] POST /api/admin/login', body.username);
    
    const result = await this.adminService.login(body.username, body.password);
    
    if (result.success) {
      return { code: 200, msg: '登录成功', data: result.admin };
    }
    
    return { code: 401, msg: result.msg, data: null };
  }

  // ========== Dashboard ==========
  
  @Get('dashboard/stats')
  async getDashboardStats() {
    console.log('[Admin API] GET /api/admin/dashboard/stats');
    
    const stats = await this.adminService.getDashboardStats();
    return { code: 200, msg: 'success', data: stats };
  }

  @Get('dashboard/recent-orders')
  async getRecentOrders(@Query('limit') limit?: string) {
    console.log('[Admin API] GET /api/admin/dashboard/recent-orders');
    
    const orders = await this.adminService.getRecentOrders(parseInt(limit || '10'));
    return { code: 200, msg: 'success', data: orders };
  }

  @Get('dashboard/recent-users')
  async getRecentUsers(@Query('limit') limit?: string) {
    console.log('[Admin API] GET /api/admin/dashboard/recent-users');
    
    const users = await this.adminService.getRecentUsers(parseInt(limit || '10'));
    return { code: 200, msg: 'success', data: users };
  }

  @Get('dashboard/order-trend')
  async getOrderTrend(@Query('days') days?: string) {
    console.log('[Admin API] GET /api/admin/dashboard/order-trend');
    
    const trend = await this.adminService.getOrderTrend(parseInt(days || '7'));
    return { code: 200, msg: 'success', data: trend };
  }

  @Get('dashboard/user-trend')
  async getUserTrend(@Query('days') days?: string) {
    console.log('[Admin API] GET /api/admin/dashboard/user-trend');
    
    const trend = await this.adminService.getUserTrend(parseInt(days || '7'));
    return { code: 200, msg: 'success', data: trend };
  }

  @Get('dashboard/order-status-distribution')
  async getOrderStatusDistribution() {
    console.log('[Admin API] GET /api/admin/dashboard/order-status-distribution');
    
    const distribution = await this.adminService.getOrderStatusDistribution();
    return { code: 200, msg: 'success', data: distribution };
  }

  @Get('dashboard/category-distribution')
  async getCategoryDistribution() {
    console.log('[Admin API] GET /api/admin/dashboard/category-distribution');
    
    const distribution = await this.adminService.getCategoryDistribution();
    return { code: 200, msg: 'success', data: distribution };
  }

  // ========== 用户管理 ==========
  
  @Get('users')
  async getUsers(
    @Query('page') page: string = '1',
    @Query('pageSize') pageSize: string = '20',
    @Query('keyword') keyword?: string,
    @Query('status') status?: string
  ) {
    console.log(`[Admin API] GET /api/admin/users?page=${page}&pageSize=${pageSize}`);
    
    const result = await this.adminService.getUsers({
      page: parseInt(page),
      pageSize: parseInt(pageSize),
      keyword,
      status,
    });
    
    return { code: 200, msg: 'success', data: result };
  }

  @Get('user/:id')
  async getUserDetail(@Param('id') userId: string) {
    console.log(`[Admin API] GET /api/admin/user/${userId}`);
    
    const data = await this.adminService.getUserDetail(userId);
    return { code: 200, msg: 'success', data };
  }

  @Post('user/status')
  async updateUserStatus(@Body() body: { userId: string; status: string }) {
    console.log('[Admin API] POST /api/admin/user/status', body);
    
    const result = await this.adminService.updateUserStatus(body.userId, body.status);
    return { code: result.success ? 200 : 500, msg: result.msg, data: null };
  }

  // ========== 商家管理 ==========
  
  @Get('merchants')
  async getMerchants(
    @Query('page') page: string = '1',
    @Query('pageSize') pageSize: string = '20',
    @Query('keyword') keyword?: string,
    @Query('status') status?: string,
    @Query('category') category?: string
  ) {
    console.log(`[Admin API] GET /api/admin/merchants?page=${page}`);
    
    const result = await this.adminService.getMerchants({
      page: parseInt(page),
      pageSize: parseInt(pageSize),
      keyword,
      status,
      category,
    });
    
    return { code: 200, msg: 'success', data: result };
  }

  @Get('merchant/:id')
  async getMerchantDetail(@Param('id') merchantId: string) {
    console.log(`[Admin API] GET /api/admin/merchant/${merchantId}`);
    
    const data = await this.adminService.getMerchantDetail(merchantId);
    return { code: 200, msg: 'success', data };
  }

  @Post('merchant/status')
  async updateMerchantStatus(@Body() body: { merchantId: string; status: string; reason?: string }) {
    console.log('[Admin API] POST /api/admin/merchant/status', body);
    
    const result = await this.adminService.updateMerchantStatus(body.merchantId, body.status, body.reason);
    return { code: result.success ? 200 : 500, msg: result.msg, data: null };
  }

  // ========== 订单管理 ==========
  
  @Get('orders')
  async getOrders(
    @Query('page') page: string = '1',
    @Query('pageSize') pageSize: string = '20',
    @Query('keyword') keyword?: string,
    @Query('status') status?: string,
    @Query('startDate') startDate?: string,
    @Query('endDate') endDate?: string
  ) {
    console.log(`[Admin API] GET /api/admin/orders?page=${page}`);
    
    const result = await this.adminService.getOrders({
      page: parseInt(page),
      pageSize: parseInt(pageSize),
      keyword,
      status,
      startDate,
      endDate,
    });
    
    return { code: 200, msg: 'success', data: result };
  }

  @Get('order/:id')
  async getOrderDetail(@Param('id') orderId: string) {
    console.log(`[Admin API] GET /api/admin/order/${orderId}`);
    
    const data = await this.adminService.getOrderDetail(orderId);
    return { code: 200, msg: 'success', data };
  }

  @Post('order/status')
  async updateOrderStatus(@Body() body: { orderId: string; status: string; adminId: string }) {
    console.log('[Admin API] POST /api/admin/order/status', body);
    
    const result = await this.adminService.updateOrderStatus(body.orderId, body.status, body.adminId);
    return { code: result.success ? 200 : 500, msg: result.msg, data: null };
  }

  // ========== 商品管理 ==========
  
  @Get('products')
  async getAllProducts(
    @Query('page') page: string = '1',
    @Query('pageSize') pageSize: string = '20',
    @Query('keyword') keyword?: string,
    @Query('status') status?: string,
    @Query('merchantId') merchantId?: string
  ) {
    console.log(`[Admin API] GET /api/admin/products?page=${page}`);
    
    const result = await this.adminService.getAllProducts({
      page: parseInt(page),
      pageSize: parseInt(pageSize),
      keyword,
      status,
      merchantId,
    });
    
    return { code: 200, msg: 'success', data: result };
  }

  @Post('product/status')
  async updateProductStatus(@Body() body: { productId: string; isActive: boolean; adminId: string }) {
    console.log('[Admin API] POST /api/admin/product/status', body);
    
    const result = await this.adminService.updateProductStatus(body.productId, body.isActive, body.adminId);
    return { code: result.success ? 200 : 500, msg: result.msg, data: null };
  }

  // ========== 优惠券管理 ==========
  
  @Get('coupons')
  async getCoupons(
    @Query('page') page: string = '1',
    @Query('pageSize') pageSize: string = '20',
    @Query('keyword') keyword?: string,
    @Query('type') type?: string,
    @Query('status') status?: string
  ) {
    console.log(`[Admin API] GET /api/admin/coupons?page=${page}`);
    
    const result = await this.adminService.getCoupons({
      page: parseInt(page),
      pageSize: parseInt(pageSize),
      keyword,
      type,
      status,
    });
    
    return { code: 200, msg: 'success', data: result };
  }

  @Post('coupon/create')
  async createCoupon(@Body() body: any) {
    console.log('[Admin API] POST /api/admin/coupon/create', body);
    
    const result = await this.adminService.createCoupon(body);
    
    if (result.success) {
      return { code: 200, msg: '创建成功', data: result.data };
    }
    
    return { code: 500, msg: result.msg, data: null };
  }

  @Post('coupon/status')
  async updateCouponStatus(@Body() body: { couponId: string; isActive: boolean }) {
    console.log('[Admin API] POST /api/admin/coupon/status', body);
    
    const result = await this.adminService.updateCouponStatus(body.couponId, body.isActive);
    return { code: result.success ? 200 : 500, msg: result.msg, data: null };
  }

  @Post('coupon/update')
  async updateCoupon(@Body() body: { couponId: string; name: string; type: string; value: string; min_amount: string; total_count: number; start_time: string; end_time: string }) {
    console.log('[Admin API] POST /api/admin/coupon/update', body);
    
    const result = await this.adminService.updateCoupon(body.couponId, body);
    return { code: result.success ? 200 : 500, msg: result.msg, data: null };
  }

  // ========== 分类管理 ==========
  
  @Get('categories')
  async getCategories() {
    console.log('[Admin API] GET /api/admin/categories');
    
    const categories = await this.adminService.getCategories();
    return { code: 200, msg: 'success', data: categories };
  }

  @Post('category/create')
  async createCategory(@Body() body: any) {
    console.log('[Admin API] POST /api/admin/category/create', body);
    
    const result = await this.adminService.createCategory(body);
    
    if (result.success) {
      return { code: 200, msg: '创建成功', data: result.data };
    }
    
    return { code: 500, msg: result.msg, data: null };
  }

  @Post('category/update')
  async updateCategory(@Body() body: { categoryId: number; data: any }) {
    console.log('[Admin API] POST /api/admin/category/update', body);
    
    const result = await this.adminService.updateCategory(body.categoryId, body.data);
    return { code: result.success ? 200 : 500, msg: result.msg, data: null };
  }

  @Post('category/delete')
  async deleteCategory(@Body() body: { categoryId: number }) {
    console.log('[Admin API] POST /api/admin/category/delete', body);
    
    const result = await this.adminService.deleteCategory(body.categoryId);
    return { code: result.success ? 200 : 500, msg: result.msg, data: null };
  }

  // ========== 操作日志 ==========
  
  @Get('logs')
  async getAdminLogs(
    @Query('page') page: string = '1',
    @Query('pageSize') pageSize: string = '20',
    @Query('adminId') adminId?: string
  ) {
    console.log(`[Admin API] GET /api/admin/logs?page=${page}`);
    
    const result = await this.adminService.getAdminLogs({
      page: parseInt(page),
      pageSize: parseInt(pageSize),
      adminId,
    });
    
    return { code: 200, msg: 'success', data: result };
  }

  // ========== 系统配置 ==========
  
  @Get('settings')
  async getSettings() {
    console.log('[Admin API] GET /api/admin/settings');
    
    const settings = await this.adminService.getSettings();
    return { code: 200, msg: 'success', data: settings };
  }

  @Post('settings')
  async updateSettings(@Body() body: { settings: any[] }) {
    console.log('[Admin API] POST /api/admin/settings', body);
    
    const result = await this.adminService.updateSettings(body.settings);
    return { code: result.success ? 200 : 500, msg: result.msg, data: null };
  }

  // ========== 数据导出 ==========
  
  @Get('export/users')
  async exportUsers(
    @Query('status') status?: string,
    @Query('startDate') startDate?: string,
    @Query('endDate') endDate?: string
  ) {
    console.log('[Admin API] GET /api/admin/export/users');
    
    const result = await this.adminService.exportUsers({ status, startDate, endDate });
    return { code: 200, msg: 'success', data: result };
  }

  @Get('export/orders')
  async exportOrders(
    @Query('status') status?: string,
    @Query('startDate') startDate?: string,
    @Query('endDate') endDate?: string
  ) {
    console.log('[Admin API] GET /api/admin/export/orders');
    
    const result = await this.adminService.exportOrders({ status, startDate, endDate });
    return { code: 200, msg: 'success', data: result };
  }

  @Get('export/merchants')
  async exportMerchants(
    @Query('status') status?: string,
    @Query('category') category?: string
  ) {
    console.log('[Admin API] GET /api/admin/export/merchants');
    
    const result = await this.adminService.exportMerchants({ status, category });
    return { code: 200, msg: 'success', data: result };
  }

  // ========== RBAC 权限管理 ==========
  
  @Get('roles')
  async getRoles() {
    console.log('[Admin API] GET /api/admin/roles');
    
    const roles = await this.adminService.getRoles();
    return { code: 200, msg: 'success', data: roles };
  }

  @Post('role/create')
  async createRole(@Body() body: any) {
    console.log('[Admin API] POST /api/admin/role/create', body);
    
    const result = await this.adminService.createRole(body);
    return { code: result.success ? 200 : 500, msg: result.msg, data: result.data };
  }

  @Post('role/update')
  async updateRole(@Body() body: { roleId: string; data: any }) {
    console.log('[Admin API] POST /api/admin/role/update', body);
    
    const result = await this.adminService.updateRole(body.roleId, body.data);
    return { code: result.success ? 200 : 500, msg: result.msg, data: null };
  }

  @Delete('role/:id')
  async deleteRole(@Param('id') roleId: string) {
    console.log(`[Admin API] DELETE /api/admin/role/${roleId}`);
    
    const result = await this.adminService.deleteRole(roleId);
    return { code: result.success ? 200 : 500, msg: result.msg, data: null };
  }

  @Get('permissions')
  async getPermissions() {
    console.log('[Admin API] GET /api/admin/permissions');
    
    const permissions = await this.adminService.getPermissions();
    return { code: 200, msg: 'success', data: permissions };
  }

  @Post('admin/create')
  async createAdmin(@Body() body: any) {
    console.log('[Admin API] POST /api/admin/admin/create', body);
    
    const result = await this.adminService.createAdmin(body);
    return { code: result.success ? 200 : 500, msg: result.msg, data: result.data };
  }

  @Get('admins')
  async getAdmins(
    @Query('page') page: string = '1',
    @Query('pageSize') pageSize: string = '20'
  ) {
    console.log(`[Admin API] GET /api/admin/admins?page=${page}`);
    
    const result = await this.adminService.getAdmins({
      page: parseInt(page),
      pageSize: parseInt(pageSize),
    });
    
    return { code: 200, msg: 'success', data: result };
  }

  @Post('admin/status')
  async updateAdminStatus(@Body() body: { adminId: string; status: string }) {
    console.log('[Admin API] POST /api/admin/admin/status', body);
    
    const result = await this.adminService.updateAdminStatus(body.adminId, body.status);
    return { code: result.success ? 200 : 500, msg: result.msg, data: null };
  }

  // ========== 优惠券删除 ==========
  
  @Delete('coupon/:id')
  async deleteCoupon(@Param('id') couponId: string) {
    console.log(`[Admin API] DELETE /api/admin/coupon/${couponId}`);
    
    const result = await this.adminService.deleteCoupon(couponId);
    return { code: result.success ? 200 : 500, msg: result.msg, data: null };
  }

  // ========== 提现管理 ==========

  @Get('withdrawals')
  async getWithdrawals(
    @Query('page') page: string = '1',
    @Query('pageSize') pageSize: string = '20',
    @Query('status') status?: string,
    @Query('keyword') keyword?: string
  ) {
    console.log(`[Admin API] GET /api/admin/withdrawals?page=${page}`);
    
    const result = await this.adminService.getWithdrawals({
      page: parseInt(page),
      pageSize: parseInt(pageSize),
      status,
      keyword,
    });
    
    return { code: 200, msg: 'success', data: result };
  }

  @Post('withdrawal/approve')
  async approveWithdrawal(@Body() body: { withdrawalId: string; adminId: string }) {
    console.log('[Admin API] POST /api/admin/withdrawal/approve', body);
    
    const result = await this.adminService.approveWithdrawal(body.withdrawalId, body.adminId);
    return { code: result.success ? 200 : 500, msg: result.msg, data: null };
  }

  @Post('withdrawal/reject')
  async rejectWithdrawal(@Body() body: { withdrawalId: string; adminId: string; reason: string }) {
    console.log('[Admin API] POST /api/admin/withdrawal/reject', body);
    
    const result = await this.adminService.rejectWithdrawal(body.withdrawalId, body.adminId, body.reason);
    return { code: result.success ? 200 : 500, msg: result.msg, data: null };
  }

  // ========== 分销管理 ==========

  @Get('referrers')
  async getReferrers(
    @Query('page') page: string = '1',
    @Query('pageSize') pageSize: string = '20',
    @Query('keyword') keyword?: string
  ) {
    console.log(`[Admin API] GET /api/admin/referrers?page=${page}`);
    
    const result = await this.adminService.getReferrers({
      page: parseInt(page),
      pageSize: parseInt(pageSize),
      keyword,
    });
    
    return { code: 200, msg: 'success', data: result };
  }

  @Get('commission-stats')
  async getCommissionStats() {
    console.log('[Admin API] GET /api/admin/commission-stats');
    
    const stats = await this.adminService.getCommissionStats();
    return { code: 200, msg: 'success', data: stats };
  }

  @Get('commission-records')
  async getCommissionRecords(
    @Query('page') page: string = '1',
    @Query('pageSize') pageSize: string = '20',
    @Query('userId') userId?: string
  ) {
    console.log(`[Admin API] GET /api/admin/commission-records?page=${page}`);
    
    const result = await this.adminService.getCommissionRecords({
      page: parseInt(page),
      pageSize: parseInt(pageSize),
      userId,
    });
    
    return { code: 200, msg: 'success', data: result };
  }

  // ========== 消息推送 ==========

  @Get('messages')
  async getMessages(
    @Query('page') page: string = '1',
    @Query('pageSize') pageSize: string = '20',
    @Query('type') type?: string
  ) {
    console.log(`[Admin API] GET /api/admin/messages?page=${page}`);
    
    const result = await this.adminService.getMessages({
      page: parseInt(page),
      pageSize: parseInt(pageSize),
      type,
    });
    
    return { code: 200, msg: 'success', data: result };
  }

  @Post('message/send')
  async sendMessage(@Body() body: { userIds: string[]; type: string; title: string; content: string }) {
    console.log('[Admin API] POST /api/admin/message/send', body);
    
    const result = await this.adminService.broadcastMessage(body);
    return { code: result.success ? 200 : 500, msg: result.msg, data: null };
  }

  @Post('message/send-all')
  async sendToAllUsers(@Body() body: { type: string; title: string; content: string }) {
    console.log('[Admin API] POST /api/admin/message/send-all', body);
    
    const result = await this.adminService.sendToAllUsers(body);
    return { code: result.success ? 200 : 500, msg: result.msg, data: null };
  }

  // ========== 退款管理 ==========

  @Get('refunds')
  async getRefunds(
    @Query('page') page: string = '1',
    @Query('pageSize') pageSize: string = '20',
    @Query('status') status?: string,
    @Query('keyword') keyword?: string
  ) {
    console.log(`[Admin API] GET /api/admin/refunds?page=${page}`);
    
    const result = await this.adminService.getRefunds({
      page: parseInt(page),
      pageSize: parseInt(pageSize),
      status,
      keyword,
    });
    
    return { code: 200, msg: 'success', data: result };
  }

  @Get('refund/:id')
  async getRefundDetail(@Param('id') refundId: string) {
    console.log(`[Admin API] GET /api/admin/refund/${refundId}`);
    
    const result = await this.adminService.getRefundDetail(refundId);
    return { code: 200, msg: 'success', data: result };
  }

  @Post('refund/approve')
  async approveRefund(@Body() body: { refundId: string; adminId: string }) {
    console.log('[Admin API] POST /api/admin/refund/approve', body);
    
    const result = await this.adminService.approveRefund(body.refundId, body.adminId);
    return { code: result.success ? 200 : 500, msg: result.msg, data: null };
  }

  @Post('refund/reject')
  async rejectRefund(@Body() body: { refundId: string; adminId: string; reason: string }) {
    console.log('[Admin API] POST /api/admin/refund/reject', body);
    
    const result = await this.adminService.rejectRefund(body.refundId, body.adminId, body.reason);
    return { code: result.success ? 200 : 500, msg: result.msg, data: null };
  }

  // ========== 评价管理 ==========

  @Get('reviews')
  async getReviews(
    @Query('page') page: string = '1',
    @Query('pageSize') pageSize: string = '20',
    @Query('rating') rating?: string,
    @Query('merchantId') merchantId?: string,
    @Query('keyword') keyword?: string
  ) {
    console.log(`[Admin API] GET /api/admin/reviews?page=${page}`);
    
    const result = await this.adminService.getReviews({
      page: parseInt(page),
      pageSize: parseInt(pageSize),
      rating: rating ? parseInt(rating) : undefined,
      merchantId,
      keyword,
    });
    
    return { code: 200, msg: 'success', data: result };
  }

  @Get('review/:id')
  async getReviewDetail(@Param('id') reviewId: string) {
    console.log(`[Admin API] GET /api/admin/review/${reviewId}`);
    
    const result = await this.adminService.getReviewDetail(reviewId);
    return { code: 200, msg: 'success', data: result };
  }

  @Post('review/reply')
  async replyReview(@Body() body: { reviewId: string; reply: string }) {
    console.log('[Admin API] POST /api/admin/review/reply', body);
    
    const result = await this.adminService.adminReplyReview(body.reviewId, body.reply);
    return { code: result.success ? 200 : 500, msg: result.msg, data: null };
  }

  @Delete('review/:id')
  async deleteReview(@Param('id') reviewId: string) {
    console.log(`[Admin API] DELETE /api/admin/review/${reviewId}`);
    
    const result = await this.adminService.deleteReview(reviewId);
    return { code: result.success ? 200 : 500, msg: result.msg, data: null };
  }

  @Get('review-stats')
  async getReviewStats() {
    console.log('[Admin API] GET /api/admin/review-stats');
    
    const stats = await this.adminService.getReviewStats();
    return { code: 200, msg: 'success', data: stats };
  }

  // ========== 积分商品管理 ==========

  @Get('points-products')
  async getPointsProducts(
    @Query('page') page: string = '1',
    @Query('pageSize') pageSize: string = '20',
    @Query('category') category?: string,
    @Query('isActive') isActive?: string
  ) {
    console.log(`[Admin API] GET /api/admin/points-products?page=${page}`);
    
    const result = await this.adminService.getPointsProducts({
      page: parseInt(page),
      pageSize: parseInt(pageSize),
      category,
      isActive: isActive === 'true' ? true : isActive === 'false' ? false : undefined,
    });
    
    return { code: 200, msg: 'success', data: result };
  }

  @Post('points-product/create')
  async createPointsProduct(@Body() body: any) {
    console.log('[Admin API] POST /api/admin/points-product/create', body);
    
    const result = await this.adminService.createPointsProduct(body);
    return { code: result.success ? 200 : 500, msg: result.msg, data: result.data };
  }

  @Post('points-product/update')
  async updatePointsProduct(@Body() body: { productId: string } & any) {
    console.log('[Admin API] POST /api/admin/points-product/update', body);
    
    const result = await this.adminService.updatePointsProduct(body.productId, body);
    return { code: result.success ? 200 : 500, msg: result.msg, data: null };
  }

  @Post('points-product/status')
  async updatePointsProductStatus(@Body() body: { productId: string; isActive: boolean }) {
    console.log('[Admin API] POST /api/admin/points-product/status', body);
    
    const result = await this.adminService.updatePointsProductStatus(body.productId, body.isActive);
    return { code: result.success ? 200 : 500, msg: result.msg, data: null };
  }

  @Delete('points-product/:id')
  async deletePointsProduct(@Param('id') productId: string) {
    console.log(`[Admin API] DELETE /api/admin/points-product/${productId}`);
    
    const result = await this.adminService.deletePointsProduct(productId);
    return { code: result.success ? 200 : 500, msg: result.msg, data: null };
  }

  @Get('points-exchanges')
  async getPointsExchanges(
    @Query('page') page: string = '1',
    @Query('pageSize') pageSize: string = '20',
    @Query('status') status?: string
  ) {
    console.log(`[Admin API] GET /api/admin/points-exchanges?page=${page}`);
    
    const result = await this.adminService.getPointsExchanges({
      page: parseInt(page),
      pageSize: parseInt(pageSize),
      status,
    });
    
    return { code: 200, msg: 'success', data: result };
  }

  @Post('points-exchange/ship')
  async shipPointsExchange(@Body() body: { exchangeId: string; trackingNo: string }) {
    console.log('[Admin API] POST /api/admin/points-exchange/ship', body);
    
    const result = await this.adminService.shipPointsExchange(body.exchangeId, body.trackingNo);
    return { code: result.success ? 200 : 500, msg: result.msg, data: null };
  }

  @Post('points-exchange/complete')
  async completePointsExchange(@Body() body: { exchangeId: string }) {
    console.log('[Admin API] POST /api/admin/points-exchange/complete', body);
    
    const result = await this.adminService.completePointsExchange(body.exchangeId);
    return { code: result.success ? 200 : 500, msg: result.msg, data: null };
  }
}
