import { Injectable } from '@nestjs/common';
import { getSupabaseClient } from '@/storage/database/supabase-client';

@Injectable()
export class MemberService {
  async getLevels() {
    const client = getSupabaseClient();
    
    const { data, error } = await client
      .from('member_levels')
      .select('*')
      .order('level', { ascending: true });

    if (error) {
      console.error('Get member levels error:', error);
      return [];
    }

    return data;
  }

  async getBenefits(level?: number) {
    const client = getSupabaseClient();
    
    let query = client
      .from('member_benefits')
      .select('*')
      .eq('is_active', true)
      .order('level', { ascending: true });

    if (level) {
      query = query.eq('level', level);
    }

    const { data, error } = await query;

    if (error) {
      console.error('Get member benefits error:', error);
      return [];
    }

    return data;
  }

  async getUserMemberInfo(userId: string) {
    const client = getSupabaseClient();
    
    // 获取用户信息
    const { data: user, error: userError } = await client
      .from('users')
      .select('id, points, level, nickname')
      .eq('id', userId)
      .single();

    if (userError || !user) {
      return null;
    }

    // 获取当前等级信息
    const { data: currentLevel } = await client
      .from('member_levels')
      .select('*')
      .eq('level', user.level || 1)
      .single();

    // 获取下一等级信息
    const { data: nextLevel } = await client
      .from('member_levels')
      .select('*')
      .gt('level', user.level || 1)
      .order('level', { ascending: true })
      .limit(1)
      .single();

    // 获取用户权益
    const { data: benefits } = await client
      .from('member_benefits')
      .select('*')
      .eq('is_active', true)
      .lte('level', user.level || 1);

    // 计算成长进度
    const currentPoints = user.points || 0;
    const currentMin = currentLevel?.min_points || 0;
    const nextMin = nextLevel?.min_points || currentMin;
    const progress = nextLevel
      ? Math.min(100, Math.round(((currentPoints - currentMin) / (nextMin - currentMin)) * 100))
      : 100;

    return {
      level: user.level || 1,
      levelName: currentLevel?.name || '普通会员',
      levelIcon: currentLevel?.icon,
      levelColor: currentLevel?.color || '#9ca3af',
      points: currentPoints,
      nextLevel: nextLevel?.name,
      nextLevelPoints: nextLevel?.min_points,
      progress,
      benefits: benefits || [],
      discount: currentLevel?.discount || 1.00,
      pointsMultiplier: currentLevel?.points_multiplier || 1.00,
    };
  }

  async addGrowthValue(params: {
    userId: string;
    value: number;
    type: string;
    description?: string;
    relatedId?: string;
  }) {
    const client = getSupabaseClient();

    // 添加成长值记录
    const { error: recordError } = await client
      .from('member_growth_records')
      .insert({
        user_id: params.userId,
        growth_value: params.value,
        type: params.type,
        description: params.description,
        related_id: params.relatedId,
      });

    if (recordError) {
      console.error('Add growth record error:', recordError);
      return { success: false, msg: '记录添加失败' };
    }

    // 更新用户积分和等级
    const { data: user } = await client
      .from('users')
      .select('points, level')
      .eq('id', params.userId)
      .single();

    if (!user) {
      return { success: false, msg: '用户不存在' };
    }

    const newPoints = (user.points || 0) + params.value;

    // 计算新等级
    const { data: levels } = await client
      .from('member_levels')
      .select('level, min_points, max_points')
      .order('level', { ascending: true });

    let newLevel = user.level || 1;
    for (const level of levels || []) {
      if (newPoints >= level.min_points) {
        if (!level.max_points || newPoints <= level.max_points) {
          newLevel = level.level;
        }
      }
    }

    // 更新用户
    const { error: updateError } = await client
      .from('users')
      .update({
        points: newPoints,
        level: newLevel,
      })
      .eq('id', params.userId);

    if (updateError) {
      console.error('Update user level error:', updateError);
      return { success: false, msg: '更新失败' };
    }

    return {
      success: true,
      msg: '成长值添加成功',
      data: {
        addedValue: params.value,
        totalPoints: newPoints,
        newLevel,
        levelUp: newLevel > (user.level || 1),
      },
    };
  }

  async getGrowthRecords(params: {
    userId: string;
    page: number;
    pageSize: number;
  }) {
    const client = getSupabaseClient();
    const offset = (params.page - 1) * params.pageSize;

    const { data, count, error } = await client
      .from('member_growth_records')
      .select('*', { count: 'exact' })
      .eq('user_id', params.userId)
      .order('created_at', { ascending: false })
      .range(offset, offset + params.pageSize - 1);

    if (error) {
      console.error('Get growth records error:', error);
      return { records: [], total: 0 };
    }

    return { records: data || [], total: count || 0 };
  }
}
