import { Controller, Get, Post, Body, Query } from '@nestjs/common';
import { MemberService } from './member.service';

@Controller('member')
export class MemberController {
  constructor(private readonly memberService: MemberService) {}

  // ========== 会员等级配置 ==========

  @Get('levels')
  async getLevels() {
    console.log('[Member API] GET /api/member/levels');
    
    const levels = await this.memberService.getLevels();
    return { code: 200, msg: 'success', data: levels };
  }

  @Get('benefits')
  async getBenefits(@Query('level') level?: string) {
    console.log('[Member API] GET /api/member/benefits');
    
    const benefits = await this.memberService.getBenefits(level ? parseInt(level) : undefined);
    return { code: 200, msg: 'success', data: benefits };
  }

  // ========== 用户会员信息 ==========

  @Get('user-info')
  async getUserMemberInfo(@Query('userId') userId: string) {
    console.log(`[Member API] GET /api/member/user-info?userId=${userId}`);
    
    const info = await this.memberService.getUserMemberInfo(userId);
    return { code: 200, msg: 'success', data: info };
  }

  // ========== 成长值 ==========

  @Post('add-growth')
  async addGrowth(@Body() body: { userId: string; value: number; type: string; description?: string; relatedId?: string }) {
    console.log('[Member API] POST /api/member/add-growth', body);
    
    const result = await this.memberService.addGrowthValue(body);
    return { code: result.success ? 200 : 400, msg: result.msg, data: result.data };
  }

  @Get('growth-records')
  async getGrowthRecords(
    @Query('userId') userId: string,
    @Query('page') page: string = '1',
    @Query('pageSize') pageSize: string = '20'
  ) {
    console.log(`[Member API] GET /api/member/growth-records?userId=${userId}`);
    
    const result = await this.memberService.getGrowthRecords({
      userId,
      page: parseInt(page),
      pageSize: parseInt(pageSize),
    });
    
    return { code: 200, msg: 'success', data: result };
  }
}
