import { Injectable } from '@nestjs/common';
import { getSupabaseClient } from '@/storage/database/supabase-client';

export interface Address {
  id: string;
  user_id: string;
  name: string;
  phone: string;
  province: string;
  city: string;
  district: string;
  detail: string;
  is_default: boolean;
  tag?: string;
  created_at: string;
  updated_at: string;
}

@Injectable()
export class AddressService {
  /**
   * 获取用户地址列表
   */
  async getAddressList(userId: string): Promise<{ addresses: Address[] }> {
    const client = getSupabaseClient();

    const { data, error } = await client
      .from('addresses')
      .select('*')
      .eq('user_id', userId)
      .order('is_default', { ascending: false })
      .order('created_at', { ascending: false });

    if (error) {
      console.error('Get address list error:', error);
      return { addresses: [] };
    }

    return { addresses: data || [] };
  }

  /**
   * 获取地址详情
   */
  async getAddressDetail(addressId: string, userId: string): Promise<Address | null> {
    const client = getSupabaseClient();

    const { data, error } = await client
      .from('addresses')
      .select('*')
      .eq('id', addressId)
      .eq('user_id', userId)
      .maybeSingle();

    if (error) {
      console.error('Get address detail error:', error);
      return null;
    }

    return data;
  }

  /**
   * 创建地址
   */
  async createAddress(params: {
    userId: string;
    name: string;
    phone: string;
    province?: string;
    city?: string;
    district: string;
    detail: string;
    isDefault?: boolean;
    tag?: string;
  }): Promise<{ success: boolean; address?: Address; msg?: string }> {
    const client = getSupabaseClient();
    const { userId, name, phone, province = '福建省', city = '厦门市', district, detail, isDefault, tag } = params;

    if (!name || !phone || !district || !detail) {
      return { success: false, msg: '参数不完整' };
    }

    // 如果设置为默认，先取消其他默认地址
    if (isDefault) {
      try {
        await client
          .from('addresses')
          .update({ is_default: false })
          .eq('user_id', userId);
      } catch (e) {
        console.error('Update default addresses error:', e);
      }
    }

    const { data, error } = await client
      .from('addresses')
      .insert({
        user_id: userId,
        name,
        phone,
        province: province || '福建省',
        city: city || '厦门市',
        district,
        detail,
        is_default: isDefault || false,
        tag,
      })
      .select()
      .single();

    if (error) {
      console.error('Create address error:', error);
      return { success: false, msg: '创建地址失败' };
    }

    return { success: true, address: data };
  }

  /**
   * 更新地址
   */
  async updateAddress(params: {
    addressId: string;
    userId: string;
    name?: string;
    phone?: string;
    province?: string;
    city?: string;
    district?: string;
    detail?: string;
    isDefault?: boolean;
    tag?: string;
  }): Promise<{ success: boolean; address?: Address; msg?: string }> {
    const client = getSupabaseClient();
    const { addressId, userId, name, phone, province, city, district, detail, isDefault, tag } = params;

    // 如果设置为默认，先取消其他默认地址
    if (isDefault) {
      try {
        await client
          .from('addresses')
          .update({ is_default: false })
          .eq('user_id', userId);
      } catch (e) {
        console.error('Update default addresses error:', e);
      }
    }

    const updateData: Record<string, unknown> = { updated_at: new Date().toISOString() };
    if (name) updateData.name = name;
    if (phone) updateData.phone = phone;
    if (province) updateData.province = province;
    if (city) updateData.city = city;
    if (district) updateData.district = district;
    if (detail) updateData.detail = detail;
    if (isDefault !== undefined) updateData.is_default = isDefault;
    if (tag !== undefined) updateData.tag = tag;

    try {
      const { data, error } = await client
        .from('addresses')
        .update(updateData)
        .eq('id', addressId)
        .select()
        .single();

      if (error) {
        console.error('Update address error:', error);
        return { success: false, msg: '更新地址失败' };
      }

      return { success: true, address: data };
    } catch (e) {
      console.error('Update address error:', e);
      return { success: false, msg: '更新地址失败' };
    }
  }

  /**
   * 删除地址
   */
  async deleteAddress(addressId: string, userId: string): Promise<{ success: boolean; msg?: string }> {
    const client = getSupabaseClient();

    try {
      const { error } = await client
        .from('addresses')
        .delete()
        .eq('id', addressId);

      if (error) {
        console.error('Delete address error:', error);
        return { success: false, msg: '删除地址失败' };
      }

      return { success: true };
    } catch (e) {
      console.error('Delete address error:', e);
      return { success: false, msg: '删除地址失败' };
    }
  }

  /**
   * 设置默认地址
   */
  async setDefaultAddress(addressId: string, userId: string): Promise<{ success: boolean; msg?: string }> {
    const client = getSupabaseClient();

    try {
      // 先取消所有默认
      await client
        .from('addresses')
        .update({ is_default: false })
        .eq('user_id', userId);

      // 再设置指定地址为默认
      const { error } = await client
        .from('addresses')
        .update({ is_default: true, updated_at: new Date().toISOString() })
        .eq('id', addressId);

      if (error) {
        console.error('Set default address error:', error);
        return { success: false, msg: '设置默认地址失败' };
      }

      return { success: true };
    } catch (e) {
      console.error('Set default address error:', e);
      return { success: false, msg: '设置默认地址失败' };
    }
  }
}
