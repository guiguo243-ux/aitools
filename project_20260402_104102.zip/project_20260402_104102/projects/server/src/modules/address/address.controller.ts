import { Controller, Get, Post, Body, Query } from '@nestjs/common';
import { AddressService } from './address.service';

@Controller('address')
export class AddressController {
  constructor(private readonly addressService: AddressService) {}

  /**
   * 获取地址列表
   */
  @Get('list')
  async getAddressList(@Query('userId') userId: string) {
    try {
      console.log(`[API] GET /api/address/list?userId=${userId}`);

      if (!userId) {
        return { code: 400, msg: '缺少用户ID', data: null };
      }

      const result = await this.addressService.getAddressList(userId);
      console.log('[API] getAddressList result:', JSON.stringify(result));

      return { code: 200, msg: 'success', data: result };
    } catch (error) {
      console.error('Get address list error:', error);
      return { code: 500, msg: '获取地址列表失败', data: null };
    }
  }

  /**
   * 获取地址详情
   */
  @Get('detail')
  async getAddressDetail(
    @Query('addressId') addressId: string,
    @Query('userId') userId: string
  ) {
    try {
      console.log(`[API] GET /api/address/detail?addressId=${addressId}`);

      if (!addressId || !userId) {
        return { code: 400, msg: '参数不完整', data: null };
      }

      const address = await this.addressService.getAddressDetail(addressId, userId);

      if (!address) {
        return { code: 404, msg: '地址不存在', data: null };
      }

      return { code: 200, msg: 'success', data: address };
    } catch (error) {
      console.error('Get address detail error:', error);
      return { code: 500, msg: '获取地址详情失败', data: null };
    }
  }

  /**
   * 创建地址
   */
  @Post('create')
  async createAddress(
    @Body()
    body: {
      userId: string;
      name: string;
      phone: string;
      province?: string;
      city?: string;
      district: string;
      detail: string;
      isDefault?: boolean;
      tag?: string;
    }
  ) {
    try {
      console.log('[API] POST /api/address/create', JSON.stringify(body));

      if (!body.userId || !body.name || !body.phone || !body.district || !body.detail) {
        return { code: 400, msg: '参数不完整', data: null };
      }

      const result = await this.addressService.createAddress(body);

      if (result.success) {
        return { code: 200, msg: '创建成功', data: result.address };
      } else {
        return { code: 400, msg: result.msg || '创建失败', data: null };
      }
    } catch (error) {
      console.error('Create address error:', error);
      return { code: 500, msg: '创建地址失败', data: null };
    }
  }

  /**
   * 更新地址
   */
  @Post('update')
  async updateAddress(
    @Body()
    body: {
      addressId: string;
      userId: string;
      name?: string;
      phone?: string;
      province?: string;
      city?: string;
      district?: string;
      detail?: string;
      isDefault?: boolean;
      tag?: string;
    }
  ) {
    try {
      console.log('[API] POST /api/address/update', JSON.stringify(body));

      if (!body.addressId || !body.userId) {
        return { code: 400, msg: '参数不完整', data: null };
      }

      const result = await this.addressService.updateAddress(body);

      if (result.success) {
        return { code: 200, msg: '更新成功', data: result.address };
      } else {
        return { code: 400, msg: result.msg || '更新失败', data: null };
      }
    } catch (error) {
      console.error('Update address error:', error);
      return { code: 500, msg: '更新地址失败', data: null };
    }
  }

  /**
   * 删除地址
   */
  @Post('delete')
  async deleteAddress(@Body() body: { addressId: string; userId: string }) {
    try {
      console.log('[API] POST /api/address/delete', JSON.stringify(body));

      if (!body.addressId || !body.userId) {
        return { code: 400, msg: '参数不完整', data: null };
      }

      const result = await this.addressService.deleteAddress(body.addressId, body.userId);

      if (result.success) {
        return { code: 200, msg: '删除成功', data: null };
      } else {
        return { code: 400, msg: result.msg || '删除失败', data: null };
      }
    } catch (error) {
      console.error('Delete address error:', error);
      return { code: 500, msg: '删除地址失败', data: null };
    }
  }

  /**
   * 设置默认地址
   */
  @Post('set-default')
  async setDefaultAddress(@Body() body: { addressId: string; userId: string }) {
    try {
      console.log('[API] POST /api/address/set-default', JSON.stringify(body));

      if (!body.addressId || !body.userId) {
        return { code: 400, msg: '参数不完整', data: null };
      }

      const result = await this.addressService.setDefaultAddress(body.addressId, body.userId);

      if (result.success) {
        return { code: 200, msg: '设置成功', data: null };
      } else {
        return { code: 400, msg: result.msg || '设置失败', data: null };
      }
    } catch (error) {
      console.error('Set default address error:', error);
      return { code: 500, msg: '设置默认地址失败', data: null };
    }
  }
}
