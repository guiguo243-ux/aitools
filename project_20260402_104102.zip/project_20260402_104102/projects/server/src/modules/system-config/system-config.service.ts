import { Injectable } from '@nestjs/common';
import { getSupabaseClient } from '@/storage/database/supabase-client';

interface ConfigItem {
  configKey: string;
  configValue: string;
  configType: string;
  category: string;
  description?: string;
  isSecret: boolean;
}

@Injectable()
export class SystemConfigService {
  async getAllConfigs() {
    const supabase = getSupabaseClient();
    const { data, error } = await supabase
      .from('system_configs')
      .select('*')
      .order('category')
      .order('config_key');

    if (error) {
      console.error('Get configs error:', error);
      throw error;
    }

    return data;
  }

  async getConfigByKey(key: string) {
    const supabase = getSupabaseClient();
    const { data, error } = await supabase
      .from('system_configs')
      .select('*')
      .eq('config_key', key)
      .single();

    if (error) {
      console.error('Get config error:', error);
      return null;
    }

    return data;
  }

  async getConfigsByCategory(category: string) {
    const supabase = getSupabaseClient();
    const { data, error } = await supabase
      .from('system_configs')
      .select('*')
      .eq('category', category)
      .order('config_key');

    if (error) {
      console.error('Get configs by category error:', error);
      throw error;
    }

    return data;
  }

  async upsertConfig(config: ConfigItem) {
    const supabase = getSupabaseClient();
    
    // 先查询旧值
    const { data: oldConfig } = await supabase
      .from('system_configs')
      .select('config_value')
      .eq('config_key', config.configKey)
      .single();

    // 更新或插入配置
    const { data, error } = await supabase
      .from('system_configs')
      .upsert({
        config_key: config.configKey,
        config_value: config.configValue,
        config_type: config.configType,
        category: config.category,
        description: config.description,
        is_secret: config.isSecret,
        updated_at: new Date().toISOString()
      }, {
        onConflict: 'config_key'
      })
      .select()
      .single();

    if (error) {
      console.error('Upsert config error:', error);
      throw error;
    }

    // 记录变更日志
    if (oldConfig && oldConfig.config_value !== config.configValue) {
      await this.logConfigChange(
        config.configKey,
        oldConfig.config_value,
        config.configValue
      );
    }

    return data;
  }

  async batchUpsertConfigs(configs: ConfigItem[]) {
    const results: any[] = [];
    for (const config of configs) {
      const result = await this.upsertConfig(config);
      results.push(result);
    }
    return results;
  }

  async deleteConfig(key: string) {
    const supabase = getSupabaseClient();
    const { error } = await supabase
      .from('system_configs')
      .delete()
      .eq('config_key', key);

    if (error) {
      console.error('Delete config error:', error);
      throw error;
    }

    return { success: true };
  }

  async testConnection(category: string) {
    // 根据类别测试连接
    switch (category) {
      case 'wechat':
        return this.testWechatConnection();
      case 'payment':
        return this.testPaymentConnection();
      case 'storage':
        return this.testStorageConnection();
      case 'database':
        return this.testDatabaseConnection();
      default:
        return { success: false, message: '未知的配置类别' };
    }
  }

  private async testWechatConnection() {
    const appid = await this.getConfigByKey('wechat_appid');
    const secret = await this.getConfigByKey('wechat_secret');
    
    if (!appid?.config_value || !secret?.config_value) {
      return { success: false, message: '微信 AppID 或 Secret 未配置' };
    }

    // 实际测试微信接口
    try {
      const response = await fetch(
        `https://api.weixin.qq.com/cgi-bin/token?grant_type=client_credential&appid=${appid.config_value}&secret=${secret.config_value}`
      );
      const data = await response.json();
      
      if (data.errcode) {
        return { success: false, message: `微信接口错误: ${data.errmsg}` };
      }
      
      return { success: true, message: '微信配置验证成功' };
    } catch (error) {
      return { success: false, message: '微信接口调用失败' };
    }
  }

  private async testPaymentConnection() {
    const mchid = await this.getConfigByKey('payment_mchid');
    const apiKey = await this.getConfigByKey('payment_api_key');
    
    if (!mchid?.config_value || !apiKey?.config_value) {
      return { success: false, message: '支付商户号或 API 密钥未配置' };
    }

    // 这里应该调用微信支付接口进行验证
    // 目前仅返回模拟结果
    return { success: true, message: '支付配置验证成功（模拟）' };
  }

  private async testStorageConnection() {
    const provider = await this.getConfigByKey('storage_provider');
    const bucket = await this.getConfigByKey('storage_bucket');
    const accessKey = await this.getConfigByKey('storage_access_key');
    
    if (!bucket?.config_value || !accessKey?.config_value) {
      return { success: false, message: '存储桶或 Access Key 未配置' };
    }

    // 这里应该调用存储服务接口进行验证
    // 目前仅返回模拟结果
    return { success: true, message: `${provider?.config_value || 'TOS'} 存储配置验证成功（模拟）` };
  }

  private async testDatabaseConnection() {
    try {
      const supabase = getSupabaseClient();
      const { error } = await supabase.from('system_configs').select('id').limit(1);
      
      if (error) {
        return { success: false, message: '数据库连接失败' };
      }
      
      return { success: true, message: '数据库连接正常' };
    } catch (error) {
      return { success: false, message: '数据库连接测试失败' };
    }
  }

  private async logConfigChange(configKey: string, oldValue: string | null, newValue: string) {
    const supabase = getSupabaseClient();
    
    await supabase
      .from('system_config_logs')
      .insert({
        config_key: configKey,
        old_value: oldValue,
        new_value: newValue,
        created_at: new Date().toISOString()
      });
  }
}
