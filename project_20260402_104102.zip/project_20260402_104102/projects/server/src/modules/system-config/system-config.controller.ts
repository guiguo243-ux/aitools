import { Controller, Get, Post, Body, Param } from '@nestjs/common';
import { SystemConfigService } from './system-config.service';

@Controller('system-config')
export class SystemConfigController {
  constructor(private readonly systemConfigService: SystemConfigService) {}

  @Get()
  async getAllConfigs() {
    const data = await this.systemConfigService.getAllConfigs();
    return { code: 200, data, msg: '获取成功' };
  }

  @Get(':key')
  async getConfigByKey(@Param('key') key: string) {
    const data = await this.systemConfigService.getConfigByKey(key);
    return { code: 200, data, msg: '获取成功' };
  }

  @Get('category/:category')
  async getConfigsByCategory(@Param('category') category: string) {
    const data = await this.systemConfigService.getConfigsByCategory(category);
    return { code: 200, data, msg: '获取成功' };
  }

  @Post()
  async upsertConfig(@Body() body: any) {
    const data = await this.systemConfigService.upsertConfig({
      configKey: body.configKey,
      configValue: body.configValue,
      configType: body.configType || 'text',
      category: body.category || 'general',
      description: body.description,
      isSecret: body.isSecret || false
    });
    return { code: 200, data, msg: '保存成功' };
  }

  @Post('batch')
  async batchUpsertConfigs(@Body() body: { configs: any[] }) {
    const configs = body.configs.map(c => ({
      configKey: c.configKey,
      configValue: c.configValue,
      configType: c.configType || 'text',
      category: c.category || 'general',
      description: c.description,
      isSecret: c.isSecret || false
    }));
    const data = await this.systemConfigService.batchUpsertConfigs(configs);
    return { code: 200, data, msg: '保存成功' };
  }

  @Post('test/:category')
  async testConnection(@Param('category') category: string) {
    const data = await this.systemConfigService.testConnection(category);
    return { code: 200, data, msg: '测试完成' };
  }
}
