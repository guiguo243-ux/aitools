import { Controller, Get, Post, Body, Query } from '@nestjs/common';
import { CouponService } from './coupon.service';

@Controller('coupon')
export class CouponController {
  constructor(private readonly couponService: CouponService) {}

  @Get('available')
  async getAvailableCoupons(
    @Query('userId') userId: string,
    @Query('region') region: string,
    @Query('page') page: string,
    @Query('pageSize') pageSize: string
  ) {
    try {
      console.log(`[API] GET /api/coupon/available?userId=${userId}`);

      const result = await this.couponService.getAvailableCoupons({
        userId,
        region,
        page: parseInt(page) || 1,
        pageSize: parseInt(pageSize) || 20
      });

      return { code: 200, msg: 'success', data: result };
    } catch (error) {
      return { code: 500, msg: '获取失败', data: null };
    }
  }

  @Post('receive')
  async receiveCoupon(@Body() body: { userId: string; couponId: string }) {
    try {
      console.log('[API] POST /api/coupon/receive', JSON.stringify(body));

      if (!body.userId || !body.couponId) {
        return { code: 400, msg: '参数不完整', data: null };
      }

      const result = await this.couponService.receiveCoupon(body);
      return { code: result.success ? 200 : 400, msg: result.msg, data: null };
    } catch (error) {
      return { code: 500, msg: '领取失败', data: null };
    }
  }

  @Get('my')
  async getUserCoupons(@Query('userId') userId: string, @Query('status') status: string) {
    const coupons = await this.couponService.getUserCoupons(userId, status);
    return { code: 200, msg: 'success', data: coupons };
  }

  @Post('use')
  async useCoupon(@Body() body: { userCouponId: string; orderId: string }) {
    const result = await this.couponService.useCoupon(body.userCouponId, body.orderId);
    return { code: result.success ? 200 : 400, msg: result.msg, data: null };
  }
}
