import { Injectable } from '@nestjs/common';
import { getSupabaseClient } from '@/storage/database/supabase-client';

@Injectable()
export class CouponService {
  /**
   * 获取可用优惠券列表
   */
  async getAvailableCoupons(params: {
    userId: string;
    region?: string;
    page?: number;
    pageSize?: number;
  }): Promise<{ coupons: any[]; total: number }> {
    const client = getSupabaseClient();
    const { userId, region, page = 1, pageSize = 20 } = params;
    const offset = (page - 1) * pageSize;

    let query = client
      .from('coupons')
      .select('*', { count: 'exact' })
      .eq('status', 'active')
      .gte('end_time', new Date().toISOString())
      .filter('total_count', 'gt', 'used_count')
      .order('created_at', { ascending: false })
      .range(offset, offset + pageSize - 1);

    // 岛内外分区限制
    if (region) {
      query = query.or(`region.eq.all,region.eq.${region}`);
    }

    const { data, count } = await query;

    // 检查用户是否已领取
    const couponIds = (data || []).map((c: any) => c.id);
    const { data: userCoupons } = await client
      .from('user_coupons')
      .select('coupon_id')
      .eq('user_id', userId)
      .in('coupon_id', couponIds);

    const receivedIds = new Set((userCoupons || []).map((uc: any) => uc.coupon_id));

    const coupons = (data || []).map((c: any) => ({
      ...c,
      isReceived: receivedIds.has(c.id)
    }));

    return { coupons, total: count || 0 };
  }

  /**
   * 领取优惠券
   */
  async receiveCoupon(data: { userId: string; couponId: string }): Promise<{ success: boolean; msg: string }> {
    const client = getSupabaseClient();

    // 检查优惠券
    const { data: coupon } = await client
      .from('coupons')
      .select('*')
      .eq('id', data.couponId)
      .maybeSingle();

    if (!coupon) {
      return { success: false, msg: '优惠券不存在' };
    }

    if (coupon.used_count >= coupon.total_count) {
      return { success: false, msg: '已领完' };
    }

    // 检查是否已领取
    const { data: existing } = await client
      .from('user_coupons')
      .select('id')
      .eq('user_id', data.userId)
      .eq('coupon_id', data.couponId)
      .maybeSingle();

    if (existing) {
      return { success: false, msg: '已领取' };
    }

    // 创建用户优惠券
    await client.from('user_coupons').insert({
      id: `UC${Date.now()}`,
      user_id: data.userId,
      coupon_id: data.couponId,
      status: 'unused',
      received_at: new Date().toISOString()
    });

    // 更新已领取数量
    await client
      .from('coupons')
      .update({ used_count: coupon.used_count + 1 })
      .eq('id', data.couponId);

    return { success: true, msg: '领取成功' };
  }

  /**
   * 获取用户优惠券
   */
  async getUserCoupons(userId: string, status?: string): Promise<any[]> {
    const client = getSupabaseClient();

    let query = client
      .from('user_coupons')
      .select('*, coupon:coupons(*)')
      .eq('user_id', userId)
      .order('received_at', { ascending: false });

    if (status) {
      query = query.eq('status', status);
    }

    const { data } = await query;
    return data || [];
  }

  /**
   * 使用优惠券
   */
  async useCoupon(userCouponId: string, orderId: string): Promise<{ success: boolean; msg: string }> {
    const client = getSupabaseClient();

    const { data: userCoupon } = await client
      .from('user_coupons')
      .select('*, coupon:coupons(*)')
      .eq('id', userCouponId)
      .maybeSingle();

    if (!userCoupon) {
      return { success: false, msg: '优惠券不存在' };
    }

    if (userCoupon.status !== 'unused') {
      return { success: false, msg: '优惠券已使用' };
    }

    await client
      .from('user_coupons')
      .update({
        status: 'used',
        used_at: new Date().toISOString(),
        order_id: orderId
      })
      .eq('id', userCouponId);

    return { success: true, msg: '使用成功' };
  }
}
