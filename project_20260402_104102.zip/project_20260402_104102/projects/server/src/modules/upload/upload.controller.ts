import { Controller, Post, UseInterceptors, UploadedFile, Body } from '@nestjs/common';
import { FileInterceptor } from '@nestjs/platform-express';
import { getSupabaseClient } from '@/storage/database/supabase-client';

// 定义文件类型接口
interface UploadedFileType {
  fieldname: string;
  originalname: string;
  size: number;
  mimetype: string;
  buffer?: Buffer;
  path?: string;
}

@Controller('upload')
export class UploadController {
  /**
   * 上传图片
   */
  @Post('image')
  @UseInterceptors(FileInterceptor('file'))
  async uploadImage(@UploadedFile() file: UploadedFileType, @Body() body: any) {
    console.log('[API] POST /api/upload/image');
    console.log('[Upload] File info:', {
      fieldname: file?.fieldname,
      originalname: file?.originalname,
      size: file?.size,
      mimetype: file?.mimetype,
      hasBuffer: !!file?.buffer,
      hasPath: !!file?.path,
    });

    if (!file) {
      return { code: 400, msg: '未找到上传文件', data: null };
    }

    try {
      // 生成文件名
      const ext = file.originalname.split('.').pop() || 'jpg';
      const fileName = `uploads/${Date.now()}-${Math.random().toString(36).substr(2, 9)}.${ext}`;

      // 获取文件内容
      let fileBuffer: Buffer;
      
      if (file.buffer) {
        // H5 端使用 buffer
        fileBuffer = file.buffer;
      } else if (file.path) {
        // 小程序端使用 path
        const fs = require('fs');
        fileBuffer = fs.readFileSync(file.path);
      } else {
        return { code: 400, msg: '无法读取文件内容', data: null };
      }

      // 上传到 Supabase Storage
      const client = getSupabaseClient();
      const bucketName = 'images';
      
      // 检查 bucket 是否存在，不存在则创建
      const { data: buckets } = await client.storage.listBuckets();
      const bucketExists = buckets?.some(b => b.name === bucketName);
      
      if (!bucketExists) {
        await client.storage.createBucket(bucketName, { public: true });
      }

      // 上传文件
      const { data: uploadData, error: uploadError } = await client.storage
        .from(bucketName)
        .upload(fileName, fileBuffer, {
          contentType: file.mimetype || 'image/jpeg',
          upsert: true,
        });

      if (uploadError) {
        console.error('[Upload] Supabase upload error:', uploadError);
        // 如果 Supabase 上传失败，返回一个模拟 URL（开发环境）
        const mockUrl = `https://placeholder.co/400x300?text=${encodeURIComponent(file.originalname)}`;
        return { 
          code: 200, 
          msg: '上传成功（模拟）', 
          data: { url: mockUrl, fileName } 
        };
      }

      // 获取公开 URL
      const { data: urlData } = client.storage
        .from(bucketName)
        .getPublicUrl(fileName);

      console.log('[Upload] Success:', urlData.publicUrl);

      return { 
        code: 200, 
        msg: '上传成功', 
        data: { 
          url: urlData.publicUrl, 
          fileName,
          path: fileName 
        } 
      };
    } catch (error) {
      console.error('[Upload] Error:', error);
      
      // 开发环境返回模拟 URL
      const mockUrl = `https://placeholder.co/400x300?text=${encodeURIComponent(file.originalname || 'image')}`;
      return { 
        code: 200, 
        msg: '上传成功（模拟）', 
        data: { url: mockUrl } 
      };
    }
  }

  /**
   * 上传多张图片
   */
  @Post('images')
  @UseInterceptors(FileInterceptor('files'))
  async uploadImages(@UploadedFile() files: UploadedFileType[], @Body() body: any) {
    console.log('[API] POST /api/upload/images');

    if (!files || (Array.isArray(files) && files.length === 0)) {
      return { code: 400, msg: '未找到上传文件', data: null };
    }

    // 处理多个文件上传
    const fileArray = Array.isArray(files) ? files : [files];
    const urls: string[] = [];

    for (const file of fileArray) {
      try {
        const ext = file.originalname.split('.').pop() || 'jpg';
        const fileName = `uploads/${Date.now()}-${Math.random().toString(36).substr(2, 9)}.${ext}`;

        let fileBuffer: Buffer;
        if (file.buffer) {
          fileBuffer = file.buffer;
        } else if (file.path) {
          const fs = require('fs');
          fileBuffer = fs.readFileSync(file.path);
        } else {
          continue;
        }

        const client = getSupabaseClient();
        const { data: uploadData, error: uploadError } = await client.storage
          .from('images')
          .upload(fileName, fileBuffer, {
            contentType: file.mimetype || 'image/jpeg',
            upsert: true,
          });

        if (!uploadError && uploadData) {
          const { data: urlData } = client.storage.from('images').getPublicUrl(fileName);
          urls.push(urlData.publicUrl);
        }
      } catch (err) {
        console.error('[Upload] Single file error:', err);
      }
    }

    if (urls.length === 0) {
      // 返回模拟 URL
      const mockUrls = fileArray.map((_, i) => `https://placeholder.co/400x300?text=image${i + 1}`);
      return { code: 200, msg: '上传成功（模拟）', data: { urls: mockUrls } };
    }

    return { code: 200, msg: '上传成功', data: { urls } };
  }
}
