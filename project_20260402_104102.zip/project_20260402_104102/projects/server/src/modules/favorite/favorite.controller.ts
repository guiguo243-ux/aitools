import { Controller, Get, Post, Delete, Body, Query } from '@nestjs/common';
import { FavoriteService } from './favorite.service';

@Controller('favorite')
export class FavoriteController {
  constructor(private readonly favoriteService: FavoriteService) {}

  @Post('add')
  async addFavorite(@Body() body: { userId: string; merchantId: string }) {
    try {
      console.log('[API] POST /api/favorite/add', JSON.stringify(body));
      
      if (!body.userId || !body.merchantId) {
        return { code: 400, msg: '参数不完整', data: null };
      }

      const result = await this.favoriteService.addFavorite(body);
      return { code: result.success ? 200 : 400, msg: result.msg, data: null };
    } catch (error) {
      return { code: 500, msg: '操作失败', data: null };
    }
  }

  @Delete('remove')
  async removeFavorite(@Query('userId') userId: string, @Query('merchantId') merchantId: string) {
    try {
      await this.favoriteService.removeFavorite({ userId, merchantId });
      return { code: 200, msg: '已取消', data: null };
    } catch (error) {
      return { code: 500, msg: '操作失败', data: null };
    }
  }

  @Get('check')
  async checkFavorited(@Query('userId') userId: string, @Query('merchantId') merchantId: string) {
    const isFavorited = await this.favoriteService.isFavorited(userId, merchantId);
    return { code: 200, msg: 'success', data: { isFavorited } };
  }

  @Get('list')
  async getUserFavorites(
    @Query('userId') userId: string,
    @Query('page') page: string,
    @Query('pageSize') pageSize: string
  ) {
    try {
      const result = await this.favoriteService.getUserFavorites(
        userId,
        parseInt(page) || 1,
        parseInt(pageSize) || 20
      );
      return { code: 200, msg: 'success', data: result };
    } catch (error) {
      return { code: 500, msg: '获取失败', data: null };
    }
  }
}
