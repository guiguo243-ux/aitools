import { Injectable } from '@nestjs/common';
import { getSupabaseClient } from '@/storage/database/supabase-client';

@Injectable()
export class FavoriteService {
  /**
   * 添加收藏
   */
  async addFavorite(data: { userId: string; merchantId: string }): Promise<{ success: boolean; msg: string }> {
    const client = getSupabaseClient();

    // 检查是否已收藏
    const { data: existing } = await client
      .from('favorites')
      .select('id')
      .eq('user_id', data.userId)
      .eq('merchant_id', data.merchantId)
      .maybeSingle();

    if (existing) {
      return { success: false, msg: '已收藏' };
    }

    const { error } = await client.from('favorites').insert({
      id: `F${Date.now()}`,
      user_id: data.userId,
      merchant_id: data.merchantId,
      created_at: new Date().toISOString()
    });

    if (error) {
      return { success: false, msg: '收藏失败' };
    }

    return { success: true, msg: '收藏成功' };
  }

  /**
   * 取消收藏
   */
  async removeFavorite(data: { userId: string; merchantId: string }): Promise<{ success: boolean }> {
    const client = getSupabaseClient();

    await client
      .from('favorites')
      .delete()
      .eq('user_id', data.userId)
      .eq('merchant_id', data.merchantId);

    return { success: true };
  }

  /**
   * 检查是否已收藏
   */
  async isFavorited(userId: string, merchantId: string): Promise<boolean> {
    const client = getSupabaseClient();

    const { data } = await client
      .from('favorites')
      .select('id')
      .eq('user_id', userId)
      .eq('merchant_id', merchantId)
      .maybeSingle();

    return !!data;
  }

  /**
   * 获取用户收藏列表
   */
  async getUserFavorites(userId: string, page: number = 1, pageSize: number = 20): Promise<{ merchants: any[]; total: number }> {
    const client = getSupabaseClient();
    const offset = (page - 1) * pageSize;

    // 获取收藏的商家ID
    const { data: favorites, count } = await client
      .from('favorites')
      .select('merchant_id', { count: 'exact' })
      .eq('user_id', userId)
      .order('created_at', { ascending: false })
      .range(offset, offset + pageSize - 1);

    if (!favorites || favorites.length === 0) {
      return { merchants: [], total: 0 };
    }

    // 获取商家详情
    const merchantIds = favorites.map((f: any) => f.merchant_id);
    const { data: merchants } = await client
      .from('merchants')
      .select('*')
      .in('id', merchantIds);

    return { merchants: merchants || [], total: count || 0 };
  }
}
