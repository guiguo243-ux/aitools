import { Module } from '@nestjs/common'
import { InstoreVerificationController } from './instore-verification.controller'

@Module({
  controllers: [InstoreVerificationController],
  providers: [],
})
export class InstoreVerificationModule {}
