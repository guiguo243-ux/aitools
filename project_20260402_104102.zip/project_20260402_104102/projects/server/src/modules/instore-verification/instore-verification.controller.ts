import { Controller, Get, Post, Body, Query, Param } from '@nestjs/common'

@Controller('instore-verification')
export class InstoreVerificationController {
  /**
   * 生成到店核销码
   */
  @Post('generate-code')
  generateVerificationCode(
    @Body() body: {
      orderId: string
      userId: string
      merchantId: string
      merchantName: string
      district: string
      amount: number
      validHours: number
    }
  ) {
    const { orderId, userId, merchantId, merchantName, district, amount, validHours } = body
    
    // 生成12位核销码
    const verifyCode = this.generateRandomCode(12)
    
    // 生成二维码内容（实际应生成二维码图片）
    const qrContent = `INSTORE:${orderId}:${verifyCode}:${merchantId}`
    
    const verification = {
      orderId,
      userId,
      merchantId,
      merchantName,
      district,
      amount,
      verifyCode,
      qrContent,
      status: 'pending', // pending | verified | expired
      createdAt: new Date().toISOString(),
      expiresAt: new Date(Date.now() + validHours * 60 * 60 * 1000).toISOString(),
      validHours,
      notice: '到店核销码仅限对应区域商家使用，跨区无法核销'
    }

    return {
      code: 200,
      msg: 'success',
      data: {
        verification,
        displayCode: this.formatDisplayCode(verifyCode),
        instructions: [
          '1. 到店后向商家出示核销码',
          '2. 商家扫码或输入核销码完成核销',
          '3. 核销成功后即可享受优惠',
          '4. 请在有效期内到店使用，过期作废'
        ]
      }
    }
  }

  /**
   * 商家扫码/输入核销码核销
   */
  @Post('verify')
  verifyOrder(
    @Body() body: {
      merchantId: string
      verifyCode: string
      operatorId: string // 操作员ID
    }
  ) {
    const { merchantId, verifyCode, operatorId } = body
    
    // 模拟核销验证（实际应查询数据库）
    const isValidCode = verifyCode.length === 12
    
    if (!isValidCode) {
      return {
        code: 400,
        msg: '核销码无效',
        data: null
      }
    }

    // 模拟订单信息
    const orderInfo = {
      orderId: 'ORD' + Date.now(),
      verifyCode,
      merchantId,
      merchantName: '老厦门沙茶面',
      userDistrict: '思明区',
      merchantDistrict: '思明区',
      amount: 68.00,
      discount: 15.00,
      finalAmount: 53.00,
      status: 'pending'
    }

    // 区域验证
    const isRegionMatch = orderInfo.userDistrict === orderInfo.merchantDistrict
    
    if (!isRegionMatch) {
      return {
        code: 403,
        msg: '核销失败：跨区域到店券无法核销',
        data: {
          reason: `用户所在区域（${orderInfo.userDistrict}）与商家区域（${orderInfo.merchantDistrict}）不一致`,
          suggestion: '请引导用户使用对应区域的到店券'
        }
      }
    }

    // 核销成功
    const verificationResult = {
      orderId: orderInfo.orderId,
      verifyCode,
      verifiedAt: new Date().toISOString(),
      verifiedBy: operatorId,
      status: 'verified',
      originalAmount: orderInfo.amount,
      discount: orderInfo.discount,
      finalAmount: orderInfo.finalAmount
    }

    return {
      code: 200,
      msg: '核销成功',
      data: {
        verification: verificationResult,
        receipt: {
          merchantName: orderInfo.merchantName,
          amount: orderInfo.finalAmount,
          verifiedAt: verificationResult.verifiedAt,
          receiptNo: 'RCP' + Date.now()
        }
      }
    }
  }

  /**
   * 查询核销状态
   */
  @Get('status/:orderId')
  getVerificationStatus(
    @Param('orderId') orderId: string
  ) {
    // 模拟核销状态查询
    const status = {
      orderId,
      status: 'pending', // pending | verified | expired
      verifyCode: '1234 5678 9012',
      merchantName: '老厦门沙茶面',
      amount: 68.00,
      discount: 15.00,
      finalAmount: 53.00,
      createdAt: new Date(Date.now() - 2 * 60 * 60 * 1000).toISOString(),
      expiresAt: new Date(Date.now() + 22 * 60 * 60 * 1000).toISOString(),
      remainingHours: 22
    }

    return {
      code: 200,
      msg: 'success',
      data: status
    }
  }

  /**
   * 获取商家待核销订单列表
   */
  @Get('merchant/pending')
  getMerchantPendingOrders(
    @Query('merchantId') merchantId: string
  ) {
    // 模拟待核销订单
    const pendingOrders = [
      {
        orderId: 'ORD001',
        verifyCode: '1234 5678 9012',
        userName: '张*明',
        userDistrict: '思明区',
        amount: 68.00,
        discount: 15.00,
        finalAmount: 53.00,
        createdAt: new Date(Date.now() - 1 * 60 * 60 * 1000).toISOString(),
        expiresAt: new Date(Date.now() + 23 * 60 * 60 * 1000).toISOString(),
        status: 'pending'
      },
      {
        orderId: 'ORD002',
        verifyCode: '9876 5432 1098',
        userName: '李*华',
        userDistrict: '思明区',
        amount: 125.00,
        discount: 25.00,
        finalAmount: 100.00,
        createdAt: new Date(Date.now() - 3 * 60 * 60 * 1000).toISOString(),
        expiresAt: new Date(Date.now() + 21 * 60 * 60 * 1000).toISOString(),
        status: 'pending'
      }
    ]

    return {
      code: 200,
      msg: 'success',
      data: {
        merchantId,
        pendingOrders,
        totalCount: pendingOrders.length,
        notice: '请在有效内核销，过期订单将自动作废'
      }
    }
  }

  /**
   * 获取核销记录
   */
  @Get('merchant/history')
  getMerchantVerificationHistory(
    @Query('merchantId') merchantId: string,
    @Query('date') date?: string
  ) {
    // 模拟核销历史
    const history = [
      {
        orderId: 'ORD001',
        verifyCode: '1234 5678 9012',
        userName: '张*明',
        amount: 68.00,
        discount: 15.00,
        finalAmount: 53.00,
        verifiedAt: new Date(Date.now() - 2 * 60 * 60 * 1000).toISOString(),
        operatorName: '店长'
      },
      {
        orderId: 'ORD002',
        verifyCode: '9876 5432 1098',
        userName: '李*华',
        amount: 125.00,
        discount: 25.00,
        finalAmount: 100.00,
        verifiedAt: new Date(Date.now() - 5 * 60 * 60 * 1000).toISOString(),
        operatorName: '店长'
      }
    ]

    // 今日统计
    const todayStats = {
      totalOrders: 12,
      totalAmount: 1580.00,
      totalDiscount: 180.00,
      totalFinalAmount: 1400.00,
      avgAmount: 131.67
    }

    return {
      code: 200,
      msg: 'success',
      data: {
        merchantId,
        date: date || new Date().toISOString().split('T')[0],
        history,
        todayStats
      }
    }
  }

  /**
   * 核销过期订单作废
   */
  @Post('expire')
  expireOrder(
    @Body() body: {
      orderId: string
      reason: string
    }
  ) {
    const { orderId, reason } = body

    return {
      code: 200,
      msg: '订单已作废',
      data: {
        orderId,
        status: 'expired',
        expiredAt: new Date().toISOString(),
        reason
      }
    }
  }

  /**
   * 生成随机核销码
   */
  private generateRandomCode(length: number): string {
    const chars = '0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ'
    let code = ''
    for (let i = 0; i < length; i++) {
      code += chars.charAt(Math.floor(Math.random() * chars.length))
    }
    return code
  }

  /**
   * 格式化显示核销码（每4位一组）
   */
  private formatDisplayCode(code: string): string {
    return code.match(/.{1,4}/g)?.join(' ') || code
  }
}
