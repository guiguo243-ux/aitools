import { Controller, Get, Post, Body, Query, Param } from '@nestjs/common';
import { GroupBuyService } from './group-buy.service';

@Controller('group-buy')
export class GroupBuyController {
  constructor(private readonly groupBuyService: GroupBuyService) {}

  // ========== 活动列表 ==========

  @Get('activities')
  async getActivities(
    @Query('status') status?: string,
    @Query('page') page: string = '1',
    @Query('pageSize') pageSize: string = '20'
  ) {
    console.log('[GroupBuy API] GET /api/group-buy/activities');
    
    const result = await this.groupBuyService.getActivities({
      status,
      page: parseInt(page),
      pageSize: parseInt(pageSize),
    });
    
    return { code: 200, msg: 'success', data: result };
  }

  @Get('activities/:id')
  async getActivityDetail(@Param('id') id: string) {
    console.log(`[GroupBuy API] GET /api/group-buy/activities/${id}`);
    
    const activity = await this.groupBuyService.getActivityDetail(id);
    return { code: 200, msg: 'success', data: activity };
  }

  // ========== 拼团 ==========

  @Get('groups')
  async getGroups(
    @Query('activityId') activityId?: string,
    @Query('status') status?: string,
    @Query('page') page: string = '1',
    @Query('pageSize') pageSize: string = '20'
  ) {
    console.log('[GroupBuy API] GET /api/group-buy/groups');
    
    const result = await this.groupBuyService.getGroups({
      activityId,
      status,
      page: parseInt(page),
      pageSize: parseInt(pageSize),
    });
    
    return { code: 200, msg: 'success', data: result };
  }

  @Get('groups/:id')
  async getGroupDetail(@Param('id') id: string, @Query('userId') userId?: string) {
    console.log(`[GroupBuy API] GET /api/group-buy/groups/${id}`);
    
    const group = await this.groupBuyService.getGroupDetail(id, userId);
    return { code: 200, msg: 'success', data: group };
  }

  @Post('groups/create')
  async createGroup(@Body() body: { activityId: string; userId: string; userName: string; userAvatar?: string }) {
    console.log('[GroupBuy API] POST /api/group-buy/groups/create', body);
    
    const result = await this.groupBuyService.createGroup(body);
    return { code: result.success ? 200 : 400, msg: result.msg, data: result.data };
  }

  @Post('groups/join')
  async joinGroup(@Body() body: { groupId: string; userId: string; userName: string; userAvatar?: string; orderId?: string }) {
    console.log('[GroupBuy API] POST /api/group-buy/groups/join', body);
    
    const result = await this.groupBuyService.joinGroup(body);
    return { code: result.success ? 200 : 400, msg: result.msg, data: result.data };
  }

  // ========== 我的拼团 ==========

  @Get('my-groups')
  async getMyGroups(
    @Query('userId') userId: string,
    @Query('status') status?: string,
    @Query('page') page: string = '1',
    @Query('pageSize') pageSize: string = '20'
  ) {
    console.log(`[GroupBuy API] GET /api/group-buy/my-groups?userId=${userId}`);
    
    const result = await this.groupBuyService.getMyGroups({
      userId,
      status,
      page: parseInt(page),
      pageSize: parseInt(pageSize),
    });
    
    return { code: 200, msg: 'success', data: result };
  }
}
