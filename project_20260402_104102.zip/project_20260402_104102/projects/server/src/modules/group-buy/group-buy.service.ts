import { Injectable } from '@nestjs/common';
import { getSupabaseClient } from '@/storage/database/supabase-client';

@Injectable()
export class GroupBuyService {
  async getActivities(params: {
    status?: string;
    page: number;
    pageSize: number;
  }) {
    const client = getSupabaseClient();
    const offset = (params.page - 1) * params.pageSize;

    let query = client
      .from('group_buy_activities')
      .select('*', { count: 'exact' })
      .order('created_at', { ascending: false });

    if (params.status) {
      query = query.eq('status', params.status);
    } else {
      query = query.eq('status', 'active');
    }

    const { data, count, error } = await query.range(offset, offset + params.pageSize - 1);

    if (error) {
      console.error('Get group buy activities error:', error);
      return { list: [], total: 0 };
    }

    return { list: data || [], total: count || 0 };
  }

  async getActivityDetail(id: string) {
    const client = getSupabaseClient();
    
    const { data, error } = await client
      .from('group_buy_activities')
      .select('*')
      .eq('id', id)
      .single();

    if (error) {
      console.error('Get activity detail error:', error);
      return null;
    }

    // 获取进行中的团
    const { data: activeGroups } = await client
      .from('group_buy_groups')
      .select('id, leader_name, leader_avatar, current_people, target_people, expire_time')
      .eq('activity_id', id)
      .eq('status', 'pending')
      .order('created_at', { ascending: true })
      .limit(10);

    return {
      ...data,
      activeGroups: activeGroups || [],
      discount: data.original_price > 0 ? Math.round((data.group_price / data.original_price) * 10) / 10 : 1,
      progress: data.stock > 0 ? Math.round((data.sold_count / data.stock) * 100) : 0,
    };
  }

  async getGroups(params: {
    activityId?: string;
    status?: string;
    page: number;
    pageSize: number;
  }) {
    const client = getSupabaseClient();
    const offset = (params.page - 1) * params.pageSize;

    let query = client
      .from('group_buy_groups')
      .select('*', { count: 'exact' })
      .order('created_at', { ascending: false });

    if (params.activityId) {
      query = query.eq('activity_id', params.activityId);
    }

    if (params.status) {
      query = query.eq('status', params.status);
    }

    const { data, count, error } = await query.range(offset, offset + params.pageSize - 1);

    if (error) {
      console.error('Get groups error:', error);
      return { list: [], total: 0 };
    }

    return { list: data || [], total: count || 0 };
  }

  async getGroupDetail(id: string, userId?: string) {
    const client = getSupabaseClient();
    
    const { data: group, error } = await client
      .from('group_buy_groups')
      .select('*')
      .eq('id', id)
      .single();

    if (error || !group) {
      return null;
    }

    // 获取参与者
    const { data: participants } = await client
      .from('group_buy_participants')
      .select('*')
      .eq('group_id', id)
      .order('joined_at', { ascending: true });

    // 获取活动信息
    const { data: activity } = await client
      .from('group_buy_activities')
      .select('*')
      .eq('id', group.activity_id)
      .single();

    // 检查用户是否已参加
    const isJoined = userId
      ? participants?.some((p) => p.user_id === userId)
      : false;

    // 计算剩余时间
    const now = new Date();
    const expireTime = new Date(group.expire_time);
    const remainingTime = Math.max(0, expireTime.getTime() - now.getTime());

    return {
      ...group,
      activity,
      participants: participants || [],
      isJoined,
      remainingTime,
      isExpired: remainingTime === 0,
    };
  }

  async createGroup(params: {
    activityId: string;
    userId: string;
    userName: string;
    userAvatar?: string;
  }) {
    const client = getSupabaseClient();

    // 获取活动信息
    const { data: activity } = await client
      .from('group_buy_activities')
      .select('*')
      .eq('id', params.activityId)
      .single();

    if (!activity) {
      return { success: false, msg: '活动不存在' };
    }

    if (activity.status !== 'active') {
      return { success: false, msg: '活动已结束' };
    }

    if (activity.stock <= activity.sold_count) {
      return { success: false, msg: '库存不足' };
    }

    // 计算过期时间
    const expireTime = new Date();
    expireTime.setHours(expireTime.getHours() + (activity.time_limit || 24));

    // 创建团
    const { data: group, error } = await client
      .from('group_buy_groups')
      .insert({
        activity_id: params.activityId,
        leader_id: params.userId,
        leader_name: params.userName,
        leader_avatar: params.userAvatar,
        target_people: activity.min_people,
        expire_time: expireTime.toISOString(),
      })
      .select()
      .single();

    if (error) {
      console.error('Create group error:', error);
      return { success: false, msg: '创建失败' };
    }

    // 添加团长为参与者
    await client.from('group_buy_participants').insert({
      group_id: group.id,
      user_id: params.userId,
      user_name: params.userName,
      user_avatar: params.userAvatar,
      status: 'joined',
    });

    return { success: true, msg: '开团成功', data: group };
  }

  async joinGroup(params: {
    groupId: string;
    userId: string;
    userName: string;
    userAvatar?: string;
    orderId?: string;
  }) {
    const client = getSupabaseClient();

    // 获取团信息
    const { data: group } = await client
      .from('group_buy_groups')
      .select('*')
      .eq('id', params.groupId)
      .single();

    if (!group) {
      return { success: false, msg: '团不存在' };
    }

    if (group.status !== 'pending') {
      return { success: false, msg: '该团已结束' };
    }

    // 检查是否已参加
    const { data: existingParticipant } = await client
      .from('group_buy_participants')
      .select('*')
      .eq('group_id', params.groupId)
      .eq('user_id', params.userId)
      .single();

    if (existingParticipant) {
      return { success: false, msg: '您已参加该团' };
    }

    // 检查是否已满
    if (group.current_people >= group.target_people) {
      return { success: false, msg: '该团已满员' };
    }

    // 获取活动信息
    const { data: activityData } = await client
      .from('group_buy_activities')
      .select('sold_count')
      .eq('id', group.activity_id)
      .single();

    // 添加参与者
    const { error } = await client.from('group_buy_participants').insert({
      group_id: params.groupId,
      user_id: params.userId,
      user_name: params.userName,
      user_avatar: params.userAvatar,
      order_id: params.orderId,
      status: 'joined',
    });

    if (error) {
      console.error('Join group error:', error);
      return { success: false, msg: '参团失败' };
    }

    // 更新团人数
    const newPeopleCount = group.current_people + 1;
    const newStatus = newPeopleCount >= group.target_people ? 'success' : 'pending';

    await client
      .from('group_buy_groups')
      .update({
        current_people: newPeopleCount,
        status: newStatus,
      })
      .eq('id', params.groupId);

    // 更新活动销量
    await client
      .from('group_buy_activities')
      .update({
        sold_count: (activityData?.sold_count || 0) + 1,
      })
      .eq('id', group.activity_id);

    return {
      success: true,
      msg: '参团成功',
      data: {
        currentPeople: newPeopleCount,
        targetPeople: group.target_people,
        isSuccess: newStatus === 'success',
      },
    };
  }

  async getMyGroups(params: {
    userId: string;
    status?: string;
    page: number;
    pageSize: number;
  }) {
    const client = getSupabaseClient();
    const offset = (params.page - 1) * params.pageSize;

    // 先获取用户参与的团ID
    const { data: participants } = await client
      .from('group_buy_participants')
      .select('group_id')
      .eq('user_id', params.userId);

    const groupIds = participants?.map((p) => p.group_id) || [];

    if (groupIds.length === 0) {
      return { list: [], total: 0 };
    }

    let query = client
      .from('group_buy_groups')
      .select('*', { count: 'exact' })
      .in('id', groupIds)
      .order('created_at', { ascending: false });

    if (params.status) {
      query = query.eq('status', params.status);
    }

    const { data, count, error } = await query.range(offset, offset + params.pageSize - 1);

    if (error) {
      console.error('Get my groups error:', error);
      return { list: [], total: 0 };
    }

    // 获取活动信息
    const activityIds = [...new Set(data?.map((g) => g.activity_id) || [])];
    const { data: activities } = await client
      .from('group_buy_activities')
      .select('*')
      .in('id', activityIds);

    const activityMap = new Map(activities?.map((a) => [a.id, a]) || []);

    const list = (data || []).map((group) => ({
      ...group,
      activity: activityMap.get(group.activity_id),
    }));

    return { list, total: count || 0 };
  }
}
