import { Controller, Get, Post, Delete, Body, Query } from '@nestjs/common';
import { SearchService } from './search.service';

@Controller('search')
export class SearchController {
  constructor(private readonly searchService: SearchService) {}

  @Get('merchants')
  async searchMerchants(
    @Query('keyword') keyword: string,
    @Query('region') region: string,
    @Query('categoryId') categoryId: string,
    @Query('page') page: string,
    @Query('pageSize') pageSize: string
  ) {
    try {
      console.log(`[API] GET /api/search/merchants?keyword=${keyword}`);

      if (!keyword) {
        return { code: 400, msg: '请输入搜索关键词', data: null };
      }

      const result = await this.searchService.searchMerchants({
        keyword,
        region,
        categoryId: categoryId ? parseInt(categoryId) : undefined,
        page: parseInt(page) || 1,
        pageSize: parseInt(pageSize) || 20
      });

      return { code: 200, msg: 'success', data: result };
    } catch (error) {
      return { code: 500, msg: '搜索失败', data: null };
    }
  }

  @Get('hot')
  async getHotSearches() {
    const searches = await this.searchService.getHotSearches();
    return { code: 200, msg: 'success', data: searches };
  }

  @Get('history')
  async getSearchHistory(@Query('userId') userId: string) {
    const history = await this.searchService.getSearchHistory(userId);
    return { code: 200, msg: 'success', data: history };
  }

  @Post('history')
  async saveSearchHistory(@Body() body: { userId: string; keyword: string }) {
    await this.searchService.saveSearchHistory(body.userId, body.keyword);
    return { code: 200, msg: 'success', data: null };
  }

  @Delete('history')
  async clearSearchHistory(@Query('userId') userId: string) {
    await this.searchService.clearSearchHistory(userId);
    return { code: 200, msg: '已清空', data: null };
  }
}
