import { Injectable } from '@nestjs/common';
import { getSupabaseClient } from '@/storage/database/supabase-client';

@Injectable()
export class SearchService {
  /**
   * 搜索商家
   */
  async searchMerchants(params: {
    keyword: string;
    region?: string;
    categoryId?: number;
    page?: number;
    pageSize?: number;
  }): Promise<{ merchants: any[]; total: number }> {
    const client = getSupabaseClient();
    const { keyword, region, categoryId, page = 1, pageSize = 20 } = params;
    const offset = (page - 1) * pageSize;

    let query = client
      .from('merchants')
      .select('*', { count: 'exact' })
      .or(`name.ilike.%${keyword}%,description.ilike.%${keyword}%`)
      .order('rating', { ascending: false })
      .range(offset, offset + pageSize - 1);

    if (region) {
      query = query.eq('region', region);
    }

    if (categoryId) {
      query = query.eq('category_id', categoryId);
    }

    const { data, count, error } = await query;

    if (error) {
      console.error('Search merchants error:', error);
      return { merchants: [], total: 0 };
    }

    return { merchants: data || [], total: count || 0 };
  }

  /**
   * 获取热门搜索
   */
  async getHotSearches(): Promise<string[]> {
    return [
      '沙茶面',
      '海蛎煎',
      '土笋冻',
      '姜母鸭',
      '家政服务',
      '美容美发',
      '休闲娱乐'
    ];
  }

  /**
   * 获取搜索历史
   */
  async getSearchHistory(userId: string): Promise<string[]> {
    const client = getSupabaseClient();

    const { data } = await client
      .from('search_history')
      .select('keyword')
      .eq('user_id', userId)
      .order('created_at', { ascending: false })
      .limit(10);

    return data?.map((h: any) => h.keyword) || [];
  }

  /**
   * 保存搜索历史
   */
  async saveSearchHistory(userId: string, keyword: string): Promise<void> {
    const client = getSupabaseClient();

    await client.from('search_history').upsert({
      user_id: userId,
      keyword,
      created_at: new Date().toISOString()
    }, { onConflict: 'user_id,keyword' });
  }

  /**
   * 清空搜索历史
   */
  async clearSearchHistory(userId: string): Promise<void> {
    const client = getSupabaseClient();
    await client.from('search_history').delete().eq('user_id', userId);
  }
}
