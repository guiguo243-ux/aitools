import { Test, TestingModule } from '@nestjs/testing';
import { ConfigService } from '@nestjs/config';

/**
 * 创建测试模块
 */
export async function createTestModule(imports: any[] = [], providers: any[] = []) {
  const module: TestingModule = await Test.createTestingModule({
    imports,
    providers: [
      {
        provide: ConfigService,
        useValue: {
          get: jest.fn((key: string) => {
            const config: Record<string, any> = {
              DATABASE_URL: process.env.DATABASE_URL || 'postgresql://test:test@localhost:5432/test',
              SUPABASE_URL: process.env.SUPABASE_URL || 'https://test.supabase.co',
              SUPABASE_ANON_KEY: process.env.SUPABASE_ANON_KEY || 'test-key',
            };
            return config[key];
          }),
        },
      },
      ...providers,
    ],
  }).compile();

  return module;
}

/**
 * 模拟 Supabase Client
 */
export function createMockSupabaseClient() {
  return {
    from: jest.fn(() => ({
      select: jest.fn(() => ({
        eq: jest.fn(() => ({
          maybeSingle: jest.fn(),
          single: jest.fn(),
          limit: jest.fn(),
          order: jest.fn(),
          range: jest.fn(),
        })),
        order: jest.fn(() => ({
          limit: jest.fn(),
          range: jest.fn(),
        })),
        limit: jest.fn(),
      })),
      insert: jest.fn(() => ({
        select: jest.fn(() => ({
          single: jest.fn(),
        })),
      })),
      update: jest.fn(() => ({
        eq: jest.fn(),
      })),
      delete: jest.fn(() => ({
        eq: jest.fn(),
      })),
    })),
    auth: {
      getUser: jest.fn(),
      signUp: jest.fn(),
      signInWithPassword: jest.fn(),
      signOut: jest.fn(),
    },
    storage: {
      from: jest.fn(() => ({
        upload: jest.fn(),
        getPublicUrl: jest.fn(),
        download: jest.fn(),
      })),
    },
  };
}

/**
 * 模拟 HTTP 请求
 */
export function mockRequest(data: any = {}) {
  return {
    body: data,
    query: {},
    params: {},
    headers: {},
    ...data,
  };
}

/**
 * 模拟 HTTP 响应
 */
export function mockResponse() {
  const res: any = {};
  res.status = jest.fn().mockReturnValue(res);
  res.json = jest.fn().mockReturnValue(res);
  res.send = jest.fn().mockReturnValue(res);
  return res;
}

/**
 * 等待异步操作
 */
export function waitFor(ms: number) {
  return new Promise(resolve => setTimeout(resolve, ms));
}

/**
 * 生成随机 ID
 */
export function generateId(): string {
  return `test_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
}

/**
 * 创建模拟用户
 */
export function createMockUser(overrides: any = {}) {
  return {
    id: generateId(),
    phone: '13800138000',
    nickname: '测试用户',
    avatar: 'https://example.com/avatar.png',
    region: 'siming',
    status: 'active',
    created_at: new Date().toISOString(),
    ...overrides,
  };
}

/**
 * 创建模拟商家
 */
export function createMockMerchant(overrides: any = {}) {
  return {
    id: generateId(),
    user_id: generateId(),
    name: '测试商家',
    category: '美食餐饮',
    region: 'island_inside',
    district: '思明区',
    address: '厦门市思明区测试路123号',
    phone: '0592-12345678',
    status: 'active',
    rating: '5.0',
    ...overrides,
  };
}

/**
 * 创建模拟订单
 */
export function createMockOrder(overrides: any = {}) {
  return {
    id: generateId(),
    order_no: `ORD${Date.now()}`,
    user_id: generateId(),
    merchant_id: generateId(),
    total_amount: '100.00',
    pay_amount: '90.00',
    status: 'pending',
    ...overrides,
  };
}
